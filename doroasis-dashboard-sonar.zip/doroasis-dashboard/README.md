# 사고처리 대시보드 개발 인수인계

인수인계 기준: 2026-10-06. 현재 작업 소스(2026-10-01 정리 변경 포함)를 전달합니다.
기존 변경의 체크포인트 커밋은 `79e29bc`이며, 이 압축파일에는 그 이후 목록 API 전환·미사용 코드 정리도 포함됩니다.
Git 이력과 이전 WAR는 제외했습니다. 소스, 설정, 개발 문서, 빌드 스크립트와 이 소스로 빌드한 WAR를 포함합니다.

## 1. 빠른 실행: Docker

Docker Desktop 또는 Docker Engine + Compose v2를 설치합니다. 별도 Node/npm 설치는 필요 없습니다.
압축을 풀고 `doroasis-dashboard` 폴더에서 실행합니다.

```sh
docker compose up -d --build
docker compose logs -f dashboard
```

접속 주소:

- 실데이터: http://localhost:8080/lockdown/ac/main.do
- 목업: http://localhost:8080/lockdown/ac/main.do?mock=1
- 특정 사고 개발 확인: http://localhost:8080/lockdown/ac/main.do?pk=15423075
- 목업 갱신 표시 확인: http://localhost:8080/lockdown/ac/main.do?mock=1&refreshing=1

종료:

```sh
docker compose down
```

소스는 컨테이너에 볼륨 마운트되어 있지 않습니다. 수정 후 `docker compose up -d --build`로 재빌드해야 반영됩니다.
기본 포트는 8080이며 `.env`의 `DASHBOARD_PORT`로 변경할 수 있습니다.
다른 프로젝트가 `doroasis-dashboard`라는 컨테이너 이름을 사용하면 compose.yaml의 container_name을 변경합니다.

## 2. 전달한 환경 설정

루트 `.env`에 실제 API 키를 넣었습니다. 이 파일도 함께 전달해야 동일 설정으로 빌드할 수 있습니다.

| 환경변수 | 전달 설정 | 용도 |
|---|---|---|
| LOCKDOWN_API_BASE_URL | http://210.223.56.170:28081/trscDoroApi | 외부 업무/분석 API |
| LOCKDOWN_API_KEY | .env에 실제 값 포함 | 외부 요청의 X-API-KEY 헤더 |
| LOCKDOWN_MAP_PROVIDER | vworld | 개발 지도 제공자 |
| DASHBOARD_PORT | 8080 | Docker 호스트 포트 |

지도 제공자는 `vworld` 또는 `himap`입니다. 전달본은 VWorld 개발환경입니다.
VWorld 지도 키는 업무 API 키와 별개이며 `src/main/webapp/index.jsp`의 스크립트 URL에 포함돼 있습니다.
HiMap은 도공 환경의 지도 서비스 접근 조건을 확인한 뒤 사용합니다.

설정 우선순위는 **Tomcat 프로세스 환경변수 → WAR에 포함된 lockdown.properties → 코드 기본값**입니다.
Java 시스템 프로퍼티 `-Dlockdown.*`를 Tomcat에 넣는 방식이 아니라, Maven 빌드 때 넣어 WAR의 properties를 치환하는 방식입니다.
Docker Compose는 .env 값을 빌드 인자와 런타임 환경변수 양쪽에 전달합니다.
동일 이름의 쉘 환경변수를 이미 export했다면 Compose에서는 그 값이 .env보다 우선합니다.

## 3. WAR 빌드

### Docker만 사용하는 방법

로컬 JDK/Maven 설치 없이:

```sh
sh scripts/build-war.sh docker
```

생성 파일: `target/dashboard.war`.
빌드 스크립트는 .env 값을 읽고 API 주소·키·지도 설정을 WAR에 포함합니다.
빌드용 컨테이너만 생성하며 개발 서버는 시작하지 않습니다.

### 로컬 JDK/Maven 사용하는 방법

권장 재현 환경: JDK 8, Maven 3.9.x. Docker 빌드는 Maven 3.9.9 + Eclipse Temurin 8입니다.

```sh
sh scripts/build-war.sh maven
```

스크립트 없이 직접 빌드할 경우:

```sh
set -a
. ./.env
set +a
mvn --batch-mode --no-transfer-progress -DskipTests \
  "-Dlockdown.apiBaseUrl=$LOCKDOWN_API_BASE_URL" \
  "-Dlockdown.apiKey=$LOCKDOWN_API_KEY" \
  "-Dlockdown.mapProvider=$LOCKDOWN_MAP_PROVIDER" \
  clean package
```

`mvn package`만 실행하면 API 키는 빈 값이고 지도 기본값은 himap입니다. 전달한 스크립트 또는 위 설정 옵션을 사용합니다.
현재 저장소에는 자동 테스트 파일이 없으며 빌드의 -DskipTests가 실행 테스트를 대신하는 것은 아닙니다.
이번 전달본은 WAR 빌드와 JavaScript 구문 검사를 확인했습니다.

## 4. Tomcat 배포

Servlet API가 `javax.servlet` 기반입니다. 개발 Docker는 Tomcat 7.0.109/JDK 8이며,
일반 WAR 실행 환경은 Tomcat 7 / 8.5 / 9 계열을 사용합니다. Tomcat 10+의 jakarta 환경은 코드 전환이 필요합니다.

루트 컨텍스트로 배포합니다:

1. 전달한 `releases/dashboard-20261006-v1.war` 또는 새로 빌드한 `target/dashboard.war`를 사용합니다.
2. Tomcat webapps에 `ROOT.war`라는 이름으로 배포합니다.
3. 접속: `http://호스트:포트/lockdown/ac/main.do`.

브라우저의 /asset, /api 경로가 루트 절대경로이므로 `dashboard.war` 이름으로 /dashboard 컨텍스트에 배포하면 경로 수정이 필요합니다.
WAR 자체에 설정을 넣었으므로 환경변수가 없어도 전달 설정으로 동작합니다.
운영 Tomcat에서 설정을 바꾸려면 프로세스 실행 환경에 다음 값을 넣고 재시작합니다.

```sh
export LOCKDOWN_API_BASE_URL="http://210.223.56.170:28081/trscDoroApi"
export LOCKDOWN_API_KEY="전달한 .env의 키"
export LOCKDOWN_MAP_PROVIDER="vworld"
```


# 로컬배포환경구성: lockdown.properties
```sh
lockdown.apiBaseUrl=http://127.0.0.1:8081/trscDoroApi
lockdown.apiKey=br9ZdcBt+wARSpY67hoyQ9XGH+SOxjZrXBNaxpcmGTQ=
lockdown.mapProvider=vworld
```
# 개발배포환경구성: lockdown.properties
```sh
lockdown.apiBaseUrl=http://192.168.0.251:8081/trscDoroApi
lockdown.apiKey=br9ZdcBt+wARSpY67hoyQ9XGH+SOxjZrXBNaxpcmGTQ=
lockdown.mapProvider=vworld
```
# 운영배포환경구성 :lockdown.properties
```sh
lockdown.apiBaseUrl=http://172.16.162.51:8081/trscDoroApi
lockdown.apiKey=br9ZdcBt+wARSpY67hoyQ9XGH+SOxjZrXBNaxpcmGTQ=
lockdown.mapProvider=himap
```


JSP/JavaScript/CSS/리소스 인코딩은 UTF-8입니다.

## 5. 개발할 파일

- `src/main/webapp/WEB-INF/publishing/original-body.jspf`: 화면 HTML/JSP 구성 및 목업 값.
- `original-style.jspf`: 공통 레이아웃, 다크/라이트 스타일.
- `src/main/webapp/asset/css/resolution-1280x720.css`: 해상도별 덮어쓰기.
- `asset/js/lockdown/analysis-adapter.js`: 실데이터 목록·선택 사고·타임라인·모달 갱신.
- `asset/js/lockdown/api-bridge.js`: 브라우저 요청 및 AS-IS 지도 API 응답 변환.
- `asset/js/lockdown/lockdownAc001Map.asis.js`: 지도 초기화, 레이어·교통정보·선택 사고 지도.
- `asset/js/publishing/publishing-original.js`: 공통 UI 및 목업 지도/그래프.
- `src/main/java/com/ex/dashboard/ApiProxyServlet.java`: 외부 API 프록시.
- `LockdownSettings.java`: 환경변수와 WAR 빌드 설정 조회.
- `src/main/webapp/index.jsp`: 지도 라이브러리와 스크립트 포함 순서.
- `src/main/webapp/asset/font`: 로컬 웹폰트 및 라이선스.
- `src/main/webapp/asset/map`: AS-IS 지도 라이브러리/자산.

빌드: Maven WAR 프로젝트. 화면은 JSP + 일반 JavaScript/CSS이며 React/Vue, Node 빌드 단계, 프론트 패키지 설치는 없습니다.
이 프로젝트 자체에 DB 연결은 없습니다. 업무 데이터는 모두 외부 API 프록시를 통해 받습니다.

세부 API 계약, 현재 동작과 시연 데이터 범위는 `docs/API-and-behavior.md`를 확인합니다.
