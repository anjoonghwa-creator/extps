# 현재 동작과 API 계약

기준: 2026-10-06 전달 소스.

## 요청 구조와 갱신

브라우저는 동일 출처의 `POST /api/{endpoint}`로 JSON을 보냅니다.
Java ApiProxyServlet이 외부 `LOCKDOWN_API_BASE_URL/{endpoint}`에 같은 JSON을 전달하며 `X-API-KEY` 헤더를 붙입니다.
API 키는 브라우저 호출 헤더에 넣지 않습니다.
프록시 연결 타임아웃은 10초, 응답 대기는 120초입니다.

| 시점 | 호출 | 목적 |
|---|---|---|
| 최초 화면 준비 | getLineCode, getEtlDataList | 노선 코드와 사고목록 |
| 최초 선택/사고 클릭 | execAnalysis, getEtlData → searchAnalMap | 선택 사고의 분석·조치 상세·지도 |
| 1분마다 | getEtlDataList | 목록 내용, 예측시간, 완료 상태 갱신 |
| 3분마다 | 선택 사고의 execAnalysis, getEtlData → searchAnalMap | 현재 선택한 상세 갱신 |
| 5분마다 | searchInitMap (지도 활성 시) | 지도 교통정보 갱신 |

최초 상세가 준비되면 전체 로딩을 해제합니다. 자동 목록 갱신은 전체 로딩을 표시하지 않습니다.
선택 사고의 자동 분석 갱신은 기존 화면을 유지하며 소형 상태 표시를 사용합니다.
프론트의 사고분석 결과 재사용 캐시는 제거된 상태입니다.
목록 각 사고의 execAnalysis 일괄 호출 및 처리중 사건 전체 재분석은 제거했습니다.
일반 목록은 `ANAL_COMP=Y`만 표시합니다. 오늘 날짜 필터는 프론트에서 하지 않으며 목록 범위는 백엔드가 결정합니다.
URL pk는 개발 확인 예외로 목록에 없는 사고도 직접 분석할 수 있습니다. 그 사고를 목록에 새로 끼워 넣지는 않습니다.
사고목록 클릭은 URL의 pk를 변경하지 않습니다.

## 업무 API

| endpoint | 요청 JSON | 사용 응답 |
|---|---|---|
| getLineCode | {} | 노선 코드 목록 |
| getEtlDataList | {} | 사고 객체 배열 |
| getEtlData | {"pk":"사고번호"} | 선택 사고 원본 정보·ACDT_ACTN_LIST |
| execAnalysis | {"pk":"사고번호"} | analResult, etlExtractedData, cnzn_id 등 |
| searchAnalMap | {"pk":"사고번호","cnzn_id":"값"} | analResult 좌표/지도 정보, inTgInfo, outTgInfo 등 |

목록 응답의 기본 형태:

```json
{
  "result": "SUCCESS",
  "data": [
    {
      "RPRQ_CRCM_SEQ": "15423075",
      "LOCAL_NAME": "수도권본부",
      "BRANCH_NAME": "화성",
      "ANAL_COMP": "Y",
      "FRCS_BLC_HOUR": 60,
      "ROUTE_CD": "0150",
      "ROUTE_DRCT_CD": "E",
      "STPNT_DSTNC": 293,
      "RPRQ_CRCM_OCRN_DTTM": "2026-09-21 17:12:00",
      "RPRQ_CRCM_CMPT_DTTM": null,
      "ACDT_CAUS_CTNT": "추돌사고",
      "ACDT_OCRN_VHCL_CTNT": "승용차 2대",
      "ACDT_ACTN_LIST": [
        {
          "ACDT_ACTN_CTNT_LLM": "V,M",
          "LSTTM_ALTR_DTTM": "2026-09-21 17:16:00"
        }
      ]
    }
  ]
}
```

이 예시는 연동 계약 설명용이며 실서버에서 이번에 수집한 응답은 아닙니다.

- 목록 지사 뱃지는 BRANCH_NAME 사용. LOCAL_NAME은 본부명으로 현재 뱃지에 사용하지 않습니다.
- 목록 예측시간은 목록 객체의 FRCS_BLC_HOUR 사용. 단위는 분이며 60이면 /60분입니다. 미제공 시 /-.
- 중앙 예측시간은 선택 사고 execAnalysis의 analResult.FRCS_BLC_HOUR 사용.
- 사고내용은 ACDT_CAUS_CTNT + ACDT_OCRN_VHCL_CTNT. 차량 문구는 원문이며 오탈자를 교정하지 않습니다.
- api-bridge.js는 최상위 etlExtractedData가 내려오면 분석 payload 안에 보존합니다.
- 선택 사고 상세는 getEtlData 원본과 분석 etlExtractedData를 합쳐 사용합니다.
- 날짜는 YYYY-MM-DD HH:mm:ss 또는 YYYYMMDDHHmmss를 지원합니다.

## 완료 판정과 경과시간

완료시간은 다음 우선순위입니다.

1. RPRQ_CRCM_CMPT_DTTM에 값이 있으면 사용.
2. 없으면 ACDT_ACTN_LIST 중 ACDT_ACTN_CTNT_LLM에 F가 포함된 조치의 기록 시각 사용.
3. 둘 다 없으면 처리중.

F가 여러 건이면 시간순으로 첫 번째 기록을 사용합니다. 조치 시각은 LSTTM_ALTR_DTTM 우선이며 해당 키가 없는 경우 FSTTM_RGST_DTTM을 참조합니다.
완료시간 기준은 목록 탭 분류, 경과시간, 단계 완료 시각에 같이 적용합니다.
진행중 경과시간은 현재시각 - 발생시각, 완료는 완료시각 - 발생시각입니다.
발생시각을 파싱할 수 없으면 제공된 PROC_MIN을 사용합니다.

## 조치 코드와 단계

ACDT_ACTN_LIST의 각 ACDT_ACTN_CTNT_LLM은 쉼표로 구분합니다.

| 코드 | 의미 | 화면 기관명 |
|---|---|---|
| A / O | 119 출동요청 / 도착 | 구급차 |
| B / P | 고순대 출동요청 / 도착 | 고순대 |
| C / Q | 순찰차 출동요청 / 도착 | 순찰차 |
| D / R | 견인차 출동요청 / 도착 | 견인차 |
| V | VMS 표출 | VMS |
| M | 문자 표출 | 문자 |
| F | 사고처리완료 | 처리완료 |
| 10, 20, 30... | 1, 2, 3... 차로 차단 | 차로 |
| 100, 200, 300... | 1, 2, 3... 차로 차단해제 | 차로 |

구형 VMS/문자 숫자 코드 1/2는 사용하지 않습니다.
실제 조치 코드에 있는 기관과 기록 시각만 표시합니다. 기관을 4개로 자동 채우거나 시간을 생성하지 않습니다.
기존 USE_LEGACY_ACTION_FALLBACK 플래그와 보정 코드는 삭제했습니다.

차단 또는 해제 코드가 있으면:
발생 → 교통정보표출 → 차로차단 → 현장출동 → 현장도착 → 차단해제 → 처리완료.

차로차단 코드가 없으면 차단해제 단계를 숨겨 처리완료가 6단계가 됩니다.
발생은 발생 HH:mm 형식으로 표시합니다. 단계 카드의 없는 상세값은 빈칸이며, 이 규칙은 화면 전체의 '-'를 없애는 규칙은 아닙니다.
확인된 가장 뒤 단계에 따라 연결선/진행 상태를 표시하며, 이전 단계의 없는 시간은 생성하지 않습니다.

## 지도와 외부 라이브러리

전달 환경은 VWorld 2.0을 로드합니다. 키는 index.jsp의 vworldMapInit.js.do URL에 포함되어 있습니다.
지도 키 변경은 index.jsp 수정 후 재빌드합니다.
HiMap 로컬 자산은 asset/map 아래에 있으며 서버 접근 조건은 운영환경 담당자와 확인합니다.
VWorld 스크립트 로드 실패 시 지도만 비활성화하고 데이터 화면 요청은 계속 진행합니다.
목업 지도도 외부 제공자 라이브러리가 필요하므로 완전 오프라인 목업은 아닙니다.
searchAnalMap 응답은 이름과 달리 LAT을 경도, LNG를 위도로 읽도록 현재 구현되어 있습니다. 백엔드 변경 시 좌표 계약을 함께 맞춥니다.
전체 사고 지도 마커를 만들던 미사용 큐는 삭제했습니다. 현재 이 어댑터는 선택 사고의 마커를 표시합니다.
사고등급 판정/필터는 사용하지 않습니다. CSS의 grade-B/C 명칭은 일부 카드 상태 색상용으로 남아 있습니다.

## 아직 실데이터가 아닌 부분

아래는 이전에 시연용으로 합의되어 유지한 활성 동작입니다. 단계 보정 삭제와는 별개입니다.

- 정체 그래프: MAX_CNGS_LNGT와 사고 PK 해시로 현재~+5분 시연 추세를 만듭니다. 실제 시계열 예측 API가 아닙니다.
- 상단 정체 구간: 그 그래프의 시작/종료 값의 큰 값 - 작은 값입니다.
- 우회 소요시간/단축: 사고처리 예측시간의 25%를 단축분으로 계산합니다. 실제 우회 경로 소요시간이 아닙니다.
- 우회 경로명·IC 이름은 분석/지도 API 값을 사용하지만, 소요시간 계산과는 구분해야 합니다.
- ?mock=1 화면은 퍼블리싱 샘플입니다.
- 화면의 이력/알림 등 공통 퍼블리싱 영역은 별도 실API 연동을 확인해야 합니다.

실데이터 화면에서 모달 샘플 값을 복원하던 코드는 제거했습니다. 분석 API에 없는 세부 예측 항목은 새 개발 단계에서 API 계약을 정한 뒤 연결합니다.

## 점검과 알려진 조건

- /api 요청은 목록이면 {}, 상세면 pk 문자열을 POST JSON으로 전달합니다.
- ANAL_COMP=Y 값과 목록 FRCS_BLC_HOUR를 확인합니다. FRCS_BLC_HOUR가 목록에서 빠지면 전체 분석으로 보정하지 않고 /-가 됩니다.
- 목록은 1분, 선택 상세는 3분 갱신되는지 Network 탭으로 확인합니다.
- 분석 API 연결 실패는 502 JSON으로 전달됩니다. API 키가 없으면 503입니다.
- VWorld ERR_HTTP2_SERVER_REFUSED_STREAM은 외부 지도 로드 문제입니다. 사고 데이터 요청과 구분해 확인합니다.
- 2026-10-01 점검 때 210.223.56.170:28081은 ENETUNREACH로 연결되지 않아 최신 실서버 응답 검증은 하지 못했습니다.
- 전달 시 빌드/구문 검사는 했지만, 외부 업무 API의 가용성이나 응답 필드 추가 배포 여부를 뜻하지는 않습니다.
