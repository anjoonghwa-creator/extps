# 전달본 검증 기록

전달 날짜: 2026-10-06.

- 기존 변경 체크포인트: 79e29bc.
- 전달 소스에는 이후 정리 변경(목록 FRCS_BLC_HOUR 직접 사용, 전체 분석 제거, 단계 보정 삭제)이 포함됩니다.
- 전달 준비 전 analysis-adapter.js와 publishing-original.js의 Node 구문 검사를 통과했습니다.
- 2026-10-01 정리 시 검증: 목록 생성/1분 갱신은 execAnalysis 호출 없음, Y 필터, 목록 예측시간 변경 반영, 완료시각 기존 필드 우선/F 코드 적용, 실제 코드의 기관만 표시, 선택 사고만 3분 분석.
- scripts/build-war.sh docker로 전달 폴더에서 WAR를 빌드합니다.
- release WAR 내 설정 및 목록 API 예측시간 코드, 삭제한 incident-grade.js가 없는지를 확인합니다.
- 외부 API 실응답/지도 연결 성공은 이 검증 범위에 포함되지 않습니다.
