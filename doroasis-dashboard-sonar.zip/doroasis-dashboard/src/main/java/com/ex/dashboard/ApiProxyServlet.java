package com.ex.dashboard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** 분석 API의 CORS와 API 키 전달만 담당하는 최소 중계 서블릿. */
public class ApiProxyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Set<String> ALLOWED_ENDPOINTS = new HashSet<String>(Arrays.asList(
            "getSearch", "getLineCode", "searchInitMap",
            "searchVmsIcon", "searchVdsSpeed", "execAnalysis",
            "searchAnalMap", "getEtlData", "getEtlDataList",
            "getTrafficList", "getEtlDataAcdtList", "setReadInfo",
            "dv/getDvCcodeList"
    ));

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String endpoint = request.getPathInfo();
        endpoint = endpoint == null ? "" : endpoint.replaceFirst("^/+", "");
        if (!ALLOWED_ENDPOINTS.contains(endpoint)) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        String apiKey = LockdownSettings.get("LOCKDOWN_API_KEY", "lockdown.apiKey", "");
        if (apiKey.trim().isEmpty()) {
            writeError(response, HttpServletResponse.SC_SERVICE_UNAVAILABLE,
                    "분석 API 키가 설정되지 않았습니다.");
            return;
        }

        String baseUrl = LockdownSettings.get("LOCKDOWN_API_BASE_URL", "lockdown.apiBaseUrl",
                "http://210.223.56.170:28081/trscDoroApi").replaceAll("/+$", "");
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(baseUrl + "/" + endpoint).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(120000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("X-API-KEY", apiKey);

            byte[] body = readBody(request).getBytes(StandardCharsets.UTF_8);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body.length == 0 ? "{}".getBytes(StandardCharsets.UTF_8) : body);
            }

            int status = connection.getResponseCode();
            response.setStatus(status);
            response.setCharacterEncoding("UTF-8");
            response.setContentType("application/json");
            InputStream input = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (input != null) {
                copy(input, response.getOutputStream());
            }
        } catch (IOException error) {
            writeError(response, HttpServletResponse.SC_BAD_GATEWAY,
                    "분석 API 연결 실패: " + error.getMessage());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String endpoint = request.getPathInfo();
        endpoint = endpoint == null ? "" : endpoint.replaceFirst("^/+", "");
        if (!ALLOWED_ENDPOINTS.contains(endpoint)) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        String apiKey = LockdownSettings.get("LOCKDOWN_API_KEY", "lockdown.apiKey", "");
        if (apiKey.trim().isEmpty()) {
            writeError(response, HttpServletResponse.SC_SERVICE_UNAVAILABLE,
                    "분석 API 키가 설정되지 않았습니다.");
            return;
        }

        String baseUrl = LockdownSettings.get("LOCKDOWN_API_BASE_URL", "lockdown.apiBaseUrl",
                "http://210.223.56.170:28081/trscDoroApi").replaceAll("/+$", "");
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(baseUrl + "/" + endpoint).openConnection();
            connection.setRequestMethod("PUT");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(120000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("X-API-KEY", apiKey);

            byte[] body = readBody(request).getBytes(StandardCharsets.UTF_8);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body.length == 0 ? "{}".getBytes(StandardCharsets.UTF_8) : body);
            }

            int status = connection.getResponseCode();
            response.setStatus(status);
            response.setCharacterEncoding("UTF-8");
            response.setContentType("application/json");
            InputStream input = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (input != null) {
                copy(input, response.getOutputStream());
            }
        } catch (IOException error) {
            writeError(response, HttpServletResponse.SC_BAD_GATEWAY,
                    "분석 API 연결 실패: " + error.getMessage());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String readBody(HttpServletRequest request) throws IOException {
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = request.getReader()) {
            char[] buffer = new char[2048];
            int length;
            while ((length = reader.read(buffer)) >= 0) result.append(buffer, 0, length);
        }
        return result.toString();
    }

    private static void copy(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[8192];
        int length;
        while ((length = input.read(buffer)) >= 0) output.write(buffer, 0, length);
    }

    private static void writeError(HttpServletResponse response, int status, String message) throws IOException {
        response.setStatus(status);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");
        response.getWriter().write("{\"result\":\"ERROR\",\"message\":\""
                + escapeJson(message) + "\"}");
    }

    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\r", "\\r").replace("\n", "\\n");
    }
}
