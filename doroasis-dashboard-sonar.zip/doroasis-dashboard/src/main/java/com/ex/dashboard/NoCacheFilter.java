package com.ex.dashboard;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

/** 개발 중 정적 자산 변경이 브라우저 캐시에 남지 않도록 응답 헤더를 설정한다. */
public class NoCacheFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) {
        // 설정 없음
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
        httpResponse.setHeader("Pragma", "no-cache");
        httpResponse.setDateHeader("Expires", 0L);
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // 정리할 자원 없음
    }
}
