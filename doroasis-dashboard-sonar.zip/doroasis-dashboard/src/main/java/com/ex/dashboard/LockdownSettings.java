package com.ex.dashboard;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/** 런타임 환경변수, WAR 빌드 설정, 코드 기본값 순서로 설정을 조회한다. */
public final class LockdownSettings {
    private static final Properties BUILD_SETTINGS = loadBuildSettings();

    private LockdownSettings() {
    }

    public static String get(String environmentName, String propertyName, String defaultValue) {
        String environmentValue = System.getenv(environmentName);
        if (hasText(environmentValue)) return environmentValue.trim();

        String buildValue = BUILD_SETTINGS.getProperty(propertyName);
        if (hasText(buildValue)) return buildValue.trim();

        return defaultValue;
    }

    private static Properties loadBuildSettings() {
        Properties properties = new Properties();
        try (InputStream input = LockdownSettings.class.getClassLoader()
                .getResourceAsStream("lockdown.properties")) {
            if (input != null) properties.load(input);
        } catch (IOException ignored) {
            // 설정 파일을 읽지 못하면 호출부의 코드 기본값을 사용한다.
        }
        return properties;
    }

    private static boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }
}
