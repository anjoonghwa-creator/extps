<%@ page pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>신뢰도 검증</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;600;700;800;900&display=swap');

        ::-webkit-scrollbar {
            display: none;
        }
        * {
            -ms-overflow-style: none; /* IE and Edge */
            scrollbar-width: none; /* Firefox */
        }


        :root {
            --bg-canvas: #EDF1F6;
            --bg-header: #FFFFFF;
            --bg-panel: #FFFFFF;
            --bg-surface: #F5F7FB;
            --bg-surface-hover: #EEF2F8;
            --bg-selected: #E7EFFF;
            --bg-critical: #FFF5F5;
            --border-critical: #FCA5A5;
            --bg-success-soft: #E8F7EE;
            --bg-info-soft: #E6EEFF;
            --bg-warn-soft: #FFF5E0;
            --bg-alg25-soft: #F5EFE4;
            --border-default: #DCE3EC;
            --border-strong: #C5CFDC;
            --text-primary: #0F172A;
            --text-secondary: #475569;
            --text-tertiary: #8592A6;
            --text-inverse: #FFFFFF;
            --brand-blue: #1E5FD9;
            --status-green: #10A04A;
            --status-red: #E1252F;
            --status-amber: #D98900;
            --status-gray: #B8C2D1;
            --chart-track: #E4E9F0;
            --chart-alg-25: #8A6D3B;
            --chart-alg-26: #1F5FBF;
            --chart-actual: #1D2433;
            --overlay-dim: rgba(15, 23, 42, 0.55);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-canvas);
            font-family: 'Noto Sans KR', sans-serif;
            color: var(--text-primary);
            padding: 28px;
            font-size: 13px;
        }

        /* 공통 스타일 적용 */
        select {
            outline: none;
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            padding-right: 32px;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23475569' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 10px center;
        }
        input {
            outline: none;
        }

        /* Utility Classes */
        .flex { display: flex; }
        .flex-col { display: flex; flex-direction: column; }
        .items-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        .justify-end { justify-content: flex-end; }
        .justify-center { justify-content: center; }
        .gap-2 { gap: 8px; }
        .gap-3 { gap: 12px; }
        .gap-4 { gap: 16px; }
        .font-bold { font-weight: 700; }
        .font-semibold { font-weight: 600; }
        .font-medium { font-weight: 500; }
        .text-sm { font-size: 14px; }
        .text-lg { font-size: 16px; }
        .text-xl { font-size: 20px; }
        .text-2xl { font-size: 24px; }
        .text-tertiary { color: var(--text-tertiary); }
        .text-secondary { color: var(--text-secondary); }
        .text-primary { color: var(--text-primary); }
        .text-brand { color: var(--brand-blue); }
        .text-green { color: var(--status-green); }
        .text-alg25 { color: var(--chart-alg-25); }
        .text-alg26 { color: var(--chart-alg-26); }
        
        .panel {
            background-color: var(--bg-panel);
            border-radius: 12px;
            border: 1px solid var(--border-default);
        }

        /* Header Area */
        .header-area {
            margin-bottom: 16px;
        }
        .header-title {
            font-size: 24px; /* 타이틀 폰트크기 24px */
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .header-subtitle {
            font-size: 13px;
            color: var(--brand-blue);
            font-weight: 600;
            padding: 4px 10px;
            background-color: var(--bg-info-soft);
        }

        /* 상단 필터 영역 (기존 .filter-panel 관련 스타일을 이것으로 교체) */
        .filter-panel {
            padding: 14px 25px;
            margin-bottom: 16px;
            border: 1px solid var(--border-default);
        }
        .filter-row {
            display: flex;
            align-items: flex-end; /* 라벨 제외 하단 폼 영역 높이 맞춤 */
            gap: 10px;
            width: 100%;
        }
        .filter-col {
            display: flex;
            flex-direction: column;
        }
        .filter-label {
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 500;
            height: 26px;
            display: flex;
            align-items: center;
        }
        .filter-input-row {
            display: flex;
            gap: 12px;
            height: 38px;
        }

        /* 실제 달력이 뜨는 날짜 입력 폼 스타일 */
        .date-input-wrap {
            display: flex;
            align-items: center;
            gap: 6px;
            border: 1px solid var(--border-default);
            border-radius: 6px;
            padding: 0 12px;
            height: 38px;
            background-color: var(--bg-surface);
        }
        .date-picker-input {
            border: none;
            background: transparent;
            font-family: inherit;
            font-size: 12px;
            font-weight: 500;
            color: var(--text-primary);
            outline: none;
            cursor: pointer;
        }
        /* 날짜 입력창 우측 캘린더 아이콘 크기 및 색상 맞춤 */
        .date-picker-input::-webkit-calendar-picker-indicator {
            cursor: pointer;
            opacity: 0.6;
            filter: invert(0.5); /* 아이콘 색상 톤 맞춤 */
        }
        .date-picker-input::-webkit-calendar-picker-indicator:hover {
            opacity: 1;
        }

        /* 세그먼트 버튼 영역 */
        .btn-group {
            display: flex;
            border: 1px solid var(--border-default);
            border-radius: 6px;
            padding: 4px;
            background-color: #ffffff;
            gap: 2px;
        }
        .btn-group button {
            border: none;
            background: transparent;
            padding: 4px 10px;
            font-size: 12px;
            color: var(--text-secondary);
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
        }
        .btn-group button.active {
            background-color: var(--bg-surface);
            color: var(--brand-blue);
            font-weight: 700;
        }

        /* 날짜 선택 영역 */
        .date-input {
            display: flex;
            align-items: center;
            gap: 8px;
            border: 1px solid var(--border-default);
            border-radius: 6px;
            padding: 0 16px;
            height: 38px;
            background-color: var(--bg-surface);
            color: var(--text-primary);
            font-size: 12px;
            font-weight: 500;
        }

        /* 드롭다운(Select) 영역 */
        .select-input {
            width: 295px;
            border: 1px solid var(--border-default);
            border-radius: 6px;
            padding: 0 36px 0 16px;
            height: 38px;
            background-color: #ffffff;
            background-repeat: no-repeat;
            background-position: right 16px center;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
        }

        /* 조회 버튼 */
        .btn-search {
            background-color: var(--brand-blue);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 0 28px;
            height: 38px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        /* Sub Header / Legend */
        .sub-header {
            display: flex;
            align-items: center;
            margin-bottom: 16px;
            gap: 16px;
        }
        .btn-tab {
            border: 1px solid var(--brand-blue);
            color: var(--brand-blue);
            background: var(--bg-info-soft);
            padding: 7px 16px;
            border-radius: 4px;
            font-weight: 600;
            font-size: 14px;
        }
        .legend-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            color: var(--text-secondary);
        }
        .legend-dot-25 { width: 8px; height: 8px; border-radius: 50%; background-color: var(--chart-alg-25); }
        .legend-dot-26 { width: 8px; height: 8px; border-radius: 50%; background-color: var(--chart-alg-26); }
        .legend-diamond { width: 7px; height: 7px; background-color: var(--chart-actual); transform: rotate(45deg); }

        /* Metrics Cards */
        .metrics-grid {
            display: flex;
            gap: 16px; /* 5개 박스 간격 16px */
            margin-bottom: 16px;
        }
        .metric-card {
            flex: 1;
            height: 114px;
            flex-shrink: 0;
            padding: 18px 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between; /* 내부 요소 간격 정렬 */
        }
        .metric-title {
            font-size: 13px;
            color: var(--text-secondary);
            font-weight: 600;
        }
        .metric-value-row {
            display: flex;
            align-items: baseline;
            gap: 8px;
        }
        .metric-val-25 {
            color: var(--chart-alg-25);
            font-size: 24px;
            font-weight: 600;
        }
        .metric-arrow {
            color: var(--text-tertiary);
            font-size: 12px;
        }
        .metric-val-26 {
            color: var(--chart-alg-26);
            font-size: 32px;
            font-weight: 700;
        }
        .metric-unit {
            font-size: 14px;
            font-weight: 500;
        }
        .metric-sub {
            font-size: 12px;
            color: var(--status-green);
        }
        .metric-sub.gray {
            color: var(--text-tertiary);
        }

        /* Main Content Area */
        .main-content {
            display: flex;
            gap: 16px; /* 하단 패널 간격 16px */
        }

        /* Left Panel - Table */
        .table-panel {
            width: 800px;
            flex-shrink: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
        }
        .panel-title {
            font-size: 15px;
            font-weight: 700;
            margin-bottom: 4px;
        }
        .panel-subtitle {
            font-size: 11px;
            color: var(--text-tertiary);
            margin-bottom: 12px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead tr {
            border-radius: 6px;
            background-color: var(--bg-surface);
            color: var(--text-secondary);
            font-weight: 700;
        }
        tr th {
            border-bottom: none;
        }
        th, td {
            text-align: center;
            padding: 8px 4px;
            border-bottom: 1px solid var(--border-default);
            font-size: 13px;
            height: 40px;
        }
        .col-우세 { width: 60px; }
        .badge-25 {
            display: inline-block;
            color: var(--chart-alg-25);
            background-color: var(--bg-alg25-soft);
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge-26 {
            display: inline-block;
            color: var(--chart-alg-26);
            background-color: var(--bg-info-soft);
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        /* Pagination (수정된 영역) */
        .pagination {
            position: relative;
            display: flex;
            justify-content: center; /* 버튼 가운데 정렬 */
            align-items: center;
            margin-top: 12px;
            color: var(--text-tertiary);
            font-size: 13px;
        }
        .pagination-info {
            position: absolute;
            left: 0; /* 텍스트는 좌측 고정 */
        }
        .page-numbers {
            display: flex;
            gap: 6px; /* 버튼 사이 간격 넓힘 */
        }
        .page-btn {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--border-default);
            background-color: var(--bg-surface); /* 시안과 동일한 연한 배경색 */
            border-radius: 6px; /* 둥근 모서리 */
            cursor: pointer;
            color: var(--text-secondary);
            font-weight: 500;
        }
        .page-btn.active {
            background-color: var(--brand-blue);
            border-color: var(--brand-blue);
            color: white;
            font-weight: 700;
        }
        .page-btn.dots {
            border: none;
            background-color: transparent;
            cursor: default;
        }

        /* Right Panel - Chart */
        .chart-panel {
            flex: 1;
            flex-shrink: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
        }
        .badge-new {
            background-color: var(--status-red);
            color: white;
            font-size: 10px;
            padding: 2px 4px;
            border-radius: 2px;
            font-weight: bold;
            margin-left: 6px;
            margin-bottom: 4px;
        }
        .chart-header {
            display: flex;
            height: 40px;
            align-items: center;
            position: relative;
            border-radius: 6px;
            background-color: var(--bg-surface);
            color: var(--text-secondary);
            font-weight: 700;
        }
        .chart-header-grid {
            flex: 1;
            position: relative;
            height: 100%;
        }
        .grid-label {
            position: absolute;
            top: 50%;
            transform: translateY(-50%) translateX(-50%);;
            font-size: 11px;
        }
        .chart-header-err {
            width:115px;
            text-align: center;
            font-size: 12px;
            font-weight: 500;
        }

        .chart-body {
            position: relative;
            flex: 1;
        }
        .grid-line {
            position: absolute;
            top: 0;
            bottom: 0;
            width: 1px;
            background-color: var(--border-default);
            z-index: 1;
        }
        
        .chart-row {
            height: 40px; /* 테이블 td와 높이 맞춤 */
            border-bottom: 1px solid var(--border-default);
            display: flex;
            position: relative;
            z-index: 2;
        }
        .chart-track {
            flex: 1;
            position: relative;
        }
        .chart-err-val {
            width: 115px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            background-color: #fff;
        }
        
        /* Chart Elements */
        .c-line-25 {
            position: absolute;
            height: 1.5px;
            background-color: var(--chart-alg-25);
            top: 38%;
        }
        .c-line-26 {
            position: absolute;
            height: 1.5px;
            background-color: var(--chart-alg-26);
            top: 62%;
        }
        .c-dot-25 {
            position: absolute;
            width: 7px;
            height: 7px;
            background-color: var(--chart-alg-25);
            border-radius: 50%;
            top: 38%;
            transform: translate(-50%, -50%);
            z-index: 3;
        }
        .c-dot-26 {
            position: absolute;
            width: 7px;
            height: 7px;
            background-color: var(--chart-alg-26);
            border-radius: 50%;
            top: 62%;
            transform: translate(-50%, -50%);
            z-index: 3;
        }
        .c-diamond {
            position: absolute;
            width: 7px;
            height: 7px;
            background-color: var(--chart-actual);
            top: 50%;
            transform: translate(-50%, -50%) rotate(45deg);
            z-index: 3;
        }

        /* Coloring for error texts */
        .err-25 { color: var(--chart-alg-25); }
        .err-26 { color: var(--chart-alg-26); }
        .err-divider { color: var(--text-tertiary); margin: 0 4px; }
        
        .p-0   { left: 5%; }
        .p-60  { left: 35%; }
        .p-120 { left: 65%; }
        .p-180 { left: 95%; }

    </style>
</head>
<body>

    <!-- Header -->
    <div class="header-area flex items-center gap-4">
        <h1 class="header-title">예측 검증 · 실측 대비 예측 비교</h1>
        <span class="header-subtitle">25년 · 26년 · 실측 3값 비교</span>
    </div>

    <!-- Filter Panel -->
    <div class="panel filter-panel">
        <div class="filter-row">
            
            <!-- 1. 검증 기간 -->
            <div class="filter-col">
                <span class="filter-label">검증 기간 (처리완료 기준)</span>
                <div class="filter-input-row">
                    <div class="btn-group">
                        <button class="active">최근 1개월</button>
                        <button>최근 3개월</button>
                        <button>최근 6개월</button>
                        <button>기간 지정</button>
                    </div>
                    <div class="date-input-wrap">
                        <input type="date" class="date-picker-input" value="2026-10-21">
                        <span style="color: var(--text-tertiary); font-size: 11px;">~</span>
                        <input type="date" class="date-picker-input" value="2026-10-21">
                    </div>
                </div>
            </div>

            <!-- 2. 노선 -->
            <div class="filter-col">
                <span class="filter-label">노선</span>
                <select class="select-input">
                    <option>전체</option>
                </select>
            </div>
            
            <!-- 3. 방향 -->
            <div class="filter-col">
                <span class="filter-label">방향</span>
                <select class="select-input">
                    <option>전체</option>
                </select>
            </div>
            
            <!-- 4. 사고유형·차단 유형 -->
            <div class="filter-col">
                <span class="filter-label">사고유형 · 차단 유형</span>
                <select class="select-input">
                    <option>전체</option>
                </select>
            </div>

            <div class="flex-1" style="flex: 1;"></div>

            <!-- 조회 버튼 -->
            <button class="btn-search">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                조회
            </button>
            
        </div>
    </div>

    <!-- Sub Header -->
    <div class="sub-header">
        <button class="btn-tab">실측 대비 검증</button>
        <span class="text-sm font-medium">검증 건수 n = 214</span>
        <div class="legend-item">
            <div class="legend-dot-25"></div> 25년 알고리즘 (RF)
        </div>
        <div class="legend-item">
            <div class="legend-dot-26"></div> 26년 개선 알고리즘 (XGB)
        </div>
        <div class="legend-item">
            <div class="legend-diamond"></div> 실측
        </div>
    </div>

    <!-- Metrics Cards -->
    <div class="metrics-grid">
        <div class="panel metric-card">
            <div>
                <div class="metric-title">MAE (평균 절대 오차)</div>
                <div class="metric-value-row">
                    <span class="metric-unit text-alg25">25년</span><span class="metric-val-25">22.6</span><span class="metric-unit text-alg25">분</span>
                    <span class="metric-arrow">→</span>
                    <span class="metric-unit text-alg26">26년</span><span class="metric-val-26">18.4</span><span class="metric-unit text-alg26">분</span>
                </div>
            </div>
            <div class="metric-sub">26년 -4.2분 개선</div>
        </div>
        <div class="panel metric-card">
            <div>
                <div class="metric-title">MAPE (평균 절대 비율 오차)</div>
                <div class="metric-value-row">
                    <span class="metric-unit text-alg25">25년</span><span class="metric-val-25">26.9</span><span class="metric-unit text-alg25">%</span>
                    <span class="metric-arrow">→</span>
                    <span class="metric-unit text-alg26">26년</span><span class="metric-val-26">21.7</span><span class="metric-unit text-alg26">%</span>
                </div>
            </div>
            <div class="metric-sub">26년 -5.2%p 개선</div>
        </div>
        <div class="panel metric-card">
            <div>
                <div class="metric-title">범주 정확도 [30분 구간]</div>
                <div class="metric-value-row">
                    <span class="metric-unit text-alg25">25년</span><span class="metric-val-25">57.0</span><span class="metric-unit text-alg25">%</span>
                    <span class="metric-arrow">→</span>
                    <span class="metric-unit text-alg26">26년</span><span class="metric-val-26">64.5</span><span class="metric-unit text-alg26">%</span>
                </div>
            </div>
            <div class="metric-sub">26년 +7.5%p 개선</div>
        </div>
        <div class="panel metric-card">
            <div>
                <div class="metric-title">허용오차[±30분] 이내 비율</div>
                <div class="metric-value-row">
                    <span class="metric-unit text-alg25">25년</span><span class="metric-val-25">74.3</span><span class="metric-unit text-alg25">%</span>
                    <span class="metric-arrow">→</span>
                    <span class="metric-unit text-alg26">26년</span><span class="metric-val-26">82.2</span><span class="metric-unit text-alg26">%</span>
                </div>
            </div>
            <div class="metric-sub gray">26년 176 / 214건</div>
        </div>
        <div class="panel metric-card">
            <div>
                <div class="metric-title">개선율 (MAE) · 26년 우세 비율</div>
                <div class="metric-value-row">
                    <span class="metric-val-26" style="color:var(--status-green)">+18.6</span><span class="metric-unit" style="color:var(--status-green)">%</span>
                    <span class="metric-arrow" style="margin:0 4px">·</span>
                    <span class="metric-unit text-alg26">우세</span><span class="metric-val-26" style="font-size:20px">63</span><span class="metric-unit text-alg26">%</span>
                </div>
            </div>
            <div class="metric-sub gray">개선율 = (25년 - 26년 MAE) ÷ 25년 MAE</div>
        </div>
    </div>

    <!-- Main Content Grid -->
    <div class="main-content">
        
        <!-- Left Panel: Table (800x565) -->
        <div class="panel table-panel">
            <div class="panel-title">검증 대상 사고 목록</div>
            <div class="panel-subtitle">검색조건에 해당하는 사고 · 노선 · 방향 · 사고유형 · 차단유형</div>
            
            <table>
                <thead>
                    <tr>
                        <th>사고번호</th>
                        <th>노선·방향</th>
                        <th>사고유형·차단</th>
                        <th>실측</th>
                        <th>25년 / 26년 오차</th>
                        <th class="col-우세">우세</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>2026-ACC-00131</td><td>경부선 서울방향</td><td>추돌-부분차단</td><td>152분</td>
                        <td><span class="err-25">-94</span><span class="err-divider">/</span><span class="err-26">-82</span>분</td>
                        <td><span class="badge-26">26년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00122</td><td>영동선 강릉방향</td><td>차량화재-전면차단</td><td>104분</td>
                        <td><span class="err-25">+62</span><span class="err-divider">/</span><span class="err-26">+76</span>분</td>
                        <td><span class="badge-25">25년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00109</td><td>서해안선 목포방향</td><td>추돌-부분차단</td><td>111분</td>
                        <td><span class="err-25">-71</span><span class="err-divider">/</span><span class="err-26">-66</span>분</td>
                        <td><span class="badge-26">26년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00140</td><td>중앙선 춘천방향</td><td>낙하물-부분차단</td><td>40분</td>
                        <td><span class="err-25">+72</span><span class="err-divider">/</span><span class="err-26">+55</span>분</td>
                        <td><span class="badge-26">26년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00117</td><td>경부선 부산방향</td><td>추돌-전면차단</td><td>82분</td>
                        <td><span class="err-25">+59</span><span class="err-divider">/</span><span class="err-26">+48</span>분</td>
                        <td><span class="badge-26">26년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00154</td><td>영동선 인천방향</td><td>추돌-부분차단</td><td>102분</td>
                        <td><span class="err-25">-31</span><span class="err-divider">/</span><span class="err-26">-42</span>분</td>
                        <td><span class="badge-25">25년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00126</td><td>서해안선 서울방향</td><td>차량화재-부분차단</td><td>88분</td>
                        <td><span class="err-25">-49</span><span class="err-divider">/</span><span class="err-26">-38</span>분</td>
                        <td><span class="badge-26">26년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00113</td><td>경부선 서울방향</td><td>낙하물-부분차단</td><td>74분</td>
                        <td><span class="err-25">-37</span><span class="err-divider">/</span><span class="err-26">-34</span>분</td>
                        <td><span class="badge-26">26년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00151</td><td>중부선 하남방향</td><td>추돌-전면차단</td><td>120분</td>
                        <td><span class="err-25">+27</span><span class="err-divider">/</span><span class="err-26">+31</span>분</td>
                        <td><span class="badge-25">25년</span></td>
                    </tr>
                    <tr>
                        <td>2026-ACC-00133</td><td>호남선 순천방향</td><td>추돌-부분차단</td><td>58분</td>
                        <td><span class="err-25">-36</span><span class="err-divider">/</span><span class="err-26">-29</span>분</td>
                        <td><span class="badge-26">26년</span></td>
                    </tr>
                </tbody>
            </table>

            <div class="pagination">
                <span class="pagination-info">전체 214건 · 10건/페이지</span>
                <div class="page-numbers">
                    <div class="page-btn">&laquo;</div>
                    <div class="page-btn">&lsaquo;</div>
                    <div class="page-btn active">1</div>
                    <div class="page-btn">2</div>
                    <div class="page-btn">3</div>
                    <div class="page-btn">4</div>
                    <div class="page-btn">5</div>
                    <div class="page-btn dots">...</div>
                    <div class="page-btn">22</div>
                    <div class="page-btn">&rsaquo;</div>
                    <div class="page-btn">&raquo;</div>
                </div>
            </div>
        </div>

        <!-- Right Panel: Chart (1048x565) -->
        <div class="panel chart-panel">
            <div class="flex items-center mb-1">
                <span class="panel-title">사고별 3값 비교</span>
                <span class="badge-new">NEW</span>
            </div>
            <div class="panel-subtitle">검증 대상 사고 목록과 동일한 사고 - 실측(◆)과 예측(●) 사이 선이 짧을수록 정확</div>
            
            <div class="chart-header">
                <div class="chart-header-grid">
                    <span class="grid-label p-0">0분</span>
                    <span class="grid-label p-60">60분</span>
                    <span class="grid-label p-120">120분</span>
                    <span class="grid-label p-180">180분</span>
                </div>
                <div class="chart-header-err">25년 / 26년 오차</div>
            </div>

            <div class="chart-body">
                <!-- Vertical Grid Lines -->
                <div class="grid-lines-wrapper" style="position: absolute; top: 0; bottom: 0; left: 0; right: 115px; z-index: 1; pointer-events: none;">
                    <div class="grid-line p-0"></div>
                    <div class="grid-line p-60"></div>
                    <div class="grid-line p-120"></div>
                    <div class="grid-line p-180"></div>
                </div>

                <!-- Row 1 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 35%; width: 45%;"></div>
                        <div class="c-line-26" style="left: 42%; width: 38%;"></div>
                        <div class="c-dot-25" style="left: 35%;"></div>
                        <div class="c-dot-26" style="left: 42%;"></div>
                        <div class="c-diamond" style="left: 80%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">-94</span><span class="err-divider">/</span><span class="err-26">-82</span>분</div>
                </div>

                <!-- Row 2 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 55%; width: 25%;"></div>
                        <div class="c-line-26" style="left: 55%; width: 35%;"></div>
                        <div class="c-diamond" style="left: 55%;"></div>
                        <div class="c-dot-25" style="left: 80%;"></div>
                        <div class="c-dot-26" style="left: 90%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">+62</span><span class="err-divider">/</span><span class="err-26">+76</span>분</div>
                </div>

                <!-- Row 3 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 25%; width: 35%;"></div>
                        <div class="c-line-26" style="left: 28%; width: 32%;"></div>
                        <div class="c-dot-25" style="left: 25%;"></div>
                        <div class="c-dot-26" style="left: 28%;"></div>
                        <div class="c-diamond" style="left: 60%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">-71</span><span class="err-divider">/</span><span class="err-26">-66</span>분</div>
                </div>

                <!-- Row 4 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 22%; width: 40%;"></div>
                        <div class="c-line-26" style="left: 22%; width: 30%;"></div>
                        <div class="c-diamond" style="left: 22%;"></div>
                        <div class="c-dot-25" style="left: 62%;"></div>
                        <div class="c-dot-26" style="left: 52%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">+72</span><span class="err-divider">/</span><span class="err-26">+55</span>분</div>
                </div>

                <!-- Row 5 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 45%; width: 30%;"></div>
                        <div class="c-line-26" style="left: 45%; width: 25%;"></div>
                        <div class="c-diamond" style="left: 45%;"></div>
                        <div class="c-dot-25" style="left: 75%;"></div>
                        <div class="c-dot-26" style="left: 70%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">+59</span><span class="err-divider">/</span><span class="err-26">+48</span>분</div>
                </div>

                <!-- Row 6 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 38%; width: 17%;"></div>
                        <div class="c-line-26" style="left: 32%; width: 23%;"></div>
                        <div class="c-dot-25" style="left: 38%;"></div>
                        <div class="c-dot-26" style="left: 32%;"></div>
                        <div class="c-diamond" style="left: 55%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">-31</span><span class="err-divider">/</span><span class="err-26">-42</span>분</div>
                </div>

                <!-- Row 7 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 22%; width: 26%;"></div>
                        <div class="c-line-26" style="left: 28%; width: 20%;"></div>
                        <div class="c-dot-25" style="left: 22%;"></div>
                        <div class="c-dot-26" style="left: 28%;"></div>
                        <div class="c-diamond" style="left: 48%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">-49</span><span class="err-divider">/</span><span class="err-26">-38</span>분</div>
                </div>

                <!-- Row 8 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 20%; width: 20%;"></div>
                        <div class="c-line-26" style="left: 22%; width: 18%;"></div>
                        <div class="c-dot-25" style="left: 20%;"></div>
                        <div class="c-dot-26" style="left: 22%;"></div>
                        <div class="c-diamond" style="left: 40%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">-37</span><span class="err-divider">/</span><span class="err-26">-34</span>분</div>
                </div>

                <!-- Row 9 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 65%; width: 13%;"></div>
                        <div class="c-line-26" style="left: 65%; width: 15%;"></div>
                        <div class="c-diamond" style="left: 65%;"></div>
                        <div class="c-dot-25" style="left: 78%;"></div>
                        <div class="c-dot-26" style="left: 80%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">+27</span><span class="err-divider">/</span><span class="err-26">+31</span>분</div>
                </div>

                <!-- Row 10 -->
                <div class="chart-row">
                    <div class="chart-track">
                        <div class="c-line-25" style="left: 12%; width: 20%;"></div>
                        <div class="c-line-26" style="left: 16%; width: 16%;"></div>
                        <div class="c-dot-25" style="left: 12%;"></div>
                        <div class="c-dot-26" style="left: 16%;"></div>
                        <div class="c-diamond" style="left: 32%;"></div>
                    </div>
                    <div class="chart-err-val"><span class="err-25">-36</span><span class="err-divider">/</span><span class="err-26">-29</span>분</div>
                </div>
                
            </div>
        </div>

    </div>

</body>
</html>