<%@ page pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="ko" data-theme="day">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>한국도로공사 사고처리 총괄화면</title>
<script>
	const savedTheme = localStorage.getItem('dashboard-theme') || 'day';
	document.documentElement.setAttribute('data-theme', savedTheme);
</script>
<link rel="stylesheet" href="/asset/css/incidentDashboard.css">
</head>
<body>

  <!-- 헤더 영역 -->
  <header>
    <div class="header-left">
      <div class="header-logo" style="display: flex; justify-content: center;">
        <svg width="196" height="22" viewBox="0 0 196 22" fill="none" xmlns="http://www.w3.org/2000/svg">
          <g clip-path="url(#clip0_1_1611)">
          <path d="M46.8308 14.8885C45.0969 16.6219 43.0421 16.9778 40.4909 16.9778H18.6376C16.8961 16.9778 15.3531 15.554 14.6351 13.5498H8.95984C9.99102 18.3862 13.94 22 18.6453 22H40.4986C43.6074 22 47.5946 21.5744 50.9096 18.2779L54.4844 14.7105L50.7492 10.9884C48.6181 13.1164 46.8384 14.8885 46.8384 14.8885H46.8308Z" fill="#ED1A2E"/>
          <path d="M18.6376 5.0918H32.8831C33.5095 5.0918 34.2122 5.79599 34.2122 6.80197C34.2122 7.80795 33.5095 8.51987 32.8831 8.51987H14.6351C14.3602 9.28596 14.1997 10.1449 14.1997 11.0348C14.1997 11.9247 14.3602 12.7759 14.6351 13.5498H32.8831C36.6565 13.5498 39.7271 10.5241 39.7271 6.80971C39.7271 3.09532 36.6565 0.0619049 32.8831 0.0619049H18.6376C13.94 0.0619049 9.99102 3.67569 8.95984 8.51987H14.6351C15.3531 6.51565 16.8961 5.0918 18.6376 5.0918Z" fill="#ED1A2E"/>
          <path d="M14.1996 11.0271C14.1996 10.1372 14.36 9.28597 14.635 8.51214H8.95972C8.78404 9.31692 8.69238 10.1604 8.69238 11.0271C8.69238 11.8938 8.78404 12.7295 8.95972 13.542H14.635C14.36 12.7682 14.1996 11.917 14.1996 11.0271Z" fill="#7F2629"/>
          <path d="M8.95978 8.51987H2.75744C1.23741 8.51987 0 9.64193 0 11.0348C0 12.4277 1.23741 13.5498 2.75744 13.5498H8.95978C8.7841 12.7373 8.69244 11.9015 8.69244 11.0348C8.69244 10.1681 8.7841 9.3324 8.95978 8.51987Z" fill="#ED1A2E"/>
          <path d="M62.031 7.17341C63.7649 5.44003 65.8196 5.08407 68.3708 5.08407H70.1887C71.7087 5.08407 72.9462 3.96201 72.9462 2.56912C72.9462 1.17622 71.7087 0.0541687 70.1887 0.0541687H68.3708C65.262 0.0541687 61.2671 0.479775 57.9597 3.77629C57.9597 3.77629 56.4091 5.31622 54.469 7.25853L58.2041 10.9807L62.0233 7.17341H62.031Z" fill="#ED1A2E"/>
          <path d="M50.543 3.35069C48.9695 1.77981 47.0064 0.580374 44.8295 0.139291C43.3476 -0.162503 41.8429 0.549421 41.438 1.88815C41.0332 3.22687 41.8887 4.61203 43.3553 4.98347C44.5927 5.293 45.5857 5.8579 46.4717 6.74007L50.7416 10.9884C51.9561 9.77348 53.2928 8.45023 54.4767 7.26627L50.543 3.35069Z" fill="#0071CE"/>
          <path d="M70.227 16.9314H68.409C65.8578 16.9314 63.8031 16.5755 62.0692 14.8421L58.2118 10.9884L54.4767 14.7105L57.998 18.2314C61.3054 21.528 65.3002 21.9536 68.4014 21.9536H70.2193C71.7393 21.9536 72.9768 20.8315 72.9768 19.4386C72.9768 18.0457 71.7393 16.9237 70.2193 16.9237L70.227 16.9314Z" fill="#0071CE"/>
          <path d="M54.4767 7.26627C53.2928 8.45023 51.9561 9.77348 50.7416 10.9884L54.4767 14.7105L58.2119 10.9884L54.4767 7.26627Z" fill="#0A1F8F"/>
          <path d="M193.647 0.711922H190.814V21.1024H193.647V8.92226H196V6.94899H193.647V0.711922Z" fill="var(--logo)"/>
          <path d="M184.856 5.0918V0.874428H182.029V5.08407C182.029 8.52761 180.67 11.383 177.508 13.3873L178.753 15.0123C180.853 13.898 182.419 12.211 183.45 10.3771C184.474 12.2033 186.047 13.8903 188.14 15.0123L189.385 13.3873C186.215 11.383 184.856 8.52761 184.856 5.08407V5.0918Z" fill="var(--logo)"/>
          <path d="M99.8561 6.05909V0.711922H97.0299V15.5617H99.8561V8.03236H102.209V6.05909H99.8561Z" fill="var(--logo)"/>
          <path d="M94.5169 7.50616C94.5169 5.95076 93.7913 4.64298 92.6608 3.79177H94.6391V1.81076H90.6825V0H87.8486V1.80302H83.892V3.78403H85.939C84.8086 4.64298 84.0829 5.94302 84.0829 7.49842C84.0829 10.2997 86.4203 12.5747 89.2999 12.5747C92.1796 12.5747 94.5169 10.2997 94.5169 7.49842V7.50616ZM86.9168 7.50616C86.9168 5.76504 87.9861 4.34893 89.2999 4.34893C90.6137 4.34893 91.6831 5.7573 91.6831 7.50616C91.6831 9.25501 90.6137 10.6634 89.2999 10.6634C87.9861 10.6634 86.9168 9.24727 86.9168 7.50616Z" fill="var(--logo)"/>
          <path d="M100.009 21.0404V19.0594H89.4069V14.6331H86.5807V19.3535C86.5807 20.2279 87.2605 21.0404 88.3604 21.0404H100.017H100.009Z" fill="var(--logo)"/>
          <path d="M124.559 0.982765V9.9592C124.559 10.8336 125.238 11.6539 126.338 11.6539H129.974V17.6201H123.52V19.6011H139.262V17.6201H132.808V11.6539H137.903V9.67288H127.392V2.96377H137.903V0.982765H124.559Z" fill="var(--logo)"/>
          <path d="M113.605 13.4337V10.0134H120.357V8.03236H118.937V2.67745C118.937 1.80303 118.249 0.982765 117.157 0.982765H105.012V2.96377H116.103V8.03236H104.019V10.0134H110.771V13.4337H105.012V15.4147H116.103V21.1024H118.937V13.4337H113.605Z" fill="var(--logo)"/>
          <path d="M142.768 11.1664C142.768 12.0408 143.448 12.8611 144.548 12.8611H148.337V17.6201H141.729V19.6011H157.77V17.6201H151.163V12.8611H156.41V10.8801H145.594V8.04784H156.41V2.67745C156.41 1.80303 155.731 0.982765 154.631 0.982765H142.768V2.96377H153.577V6.06683H142.768V11.1664Z" fill="var(--logo)"/>
          <path d="M161.162 0.982765V2.96377H172.107V9.46395H168.158V5.61027H165.324V9.46395H159.718V11.445H176.652V9.46395H174.933V2.67745C174.933 1.80303 174.246 0.982765 173.154 0.982765H161.162Z" fill="var(--logo)"/>
          <path d="M168.097 12.5206C164.752 12.5206 162.04 14.6254 162.04 17.2255C162.04 19.8255 164.752 21.9304 168.097 21.9304C171.443 21.9304 174.154 19.8255 174.154 17.2255C174.154 14.6254 171.443 12.5206 168.097 12.5206ZM168.097 20.0035C166.31 20.0035 164.866 18.7576 164.866 17.2255C164.866 15.6933 166.31 14.4474 168.097 14.4474C169.885 14.4474 171.328 15.6933 171.328 17.2255C171.328 18.7576 169.885 20.0035 168.097 20.0035Z" fill="var(--logo)"/>
          </g>
          <defs>
          <clipPath id="clip0_1_1611">
          <rect width="196" height="22" fill="white"/>
          </clipPath>
          </defs>
        </svg>
      </div>
      <div class="header-title">사고처리 총괄화면</div>
    </div>
    <div class="header-right">
      <div class="header-box header-time-box">
        <span id="cur-date">2026. 09. 17 (목)</span>
        <span id="cur-time" class="time">16:22:21</span>
      </div>
      <button class="btn-history" onclick="openHistoryPopup()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        이력 조회
      </button>
      <div class="theme-toggle-container">
        <button id="btn-day" class="theme-toggle-btn active" onclick="setTheme('day')">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10.6667 8C10.6667 9.47276 9.47275 10.6667 7.99999 10.6667C6.52724 10.6667 5.33333 9.47276 5.33333 8C5.33333 6.52724 6.52724 5.33334 7.99999 5.33334C9.47275 5.33334 10.6667 6.52724 10.6667 8Z" stroke-width="0.72" stroke-linecap="round" stroke-linejoin="round" stroke="var(--text-tertiary)"/>
          <path d="M8.00001 1.66666V3M8.00001 13V14.3333M1.66667 8H3.00001M13 8H14.3333M3.53334 3.53333L4.46667 4.46666M11.5333 11.5333L12.4667 12.4667M3.53334 12.4667L4.46667 11.5333M11.5333 4.46666L12.4667 3.53333" stroke-width="0.72" stroke-linecap="round" stroke-linejoin="round" stroke="var(--text-tertiary)"/>
          </svg>
          주간
        </button>
        <button id="btn-night" class="theme-toggle-btn" onclick="setTheme('night')">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M13.3333 9.66666C12.354 10.0851 11.2719 10.2008 10.2262 9.99886C9.18064 9.79692 8.21942 9.28657 7.4664 8.53354C6.71337 7.78052 6.20302 6.8193 6.00107 5.77369C5.79912 4.72807 5.91482 3.64595 6.33327 2.66666C5.53136 3.00932 4.8257 3.54339 4.27812 4.22209C3.73053 4.90079 3.35773 5.70341 3.19236 6.55964C3.02698 7.41587 3.07409 8.29959 3.32956 9.13339C3.58502 9.96719 4.04104 10.7256 4.65768 11.3423C5.27432 11.9589 6.03275 12.4149 6.86655 12.6704C7.70035 12.9258 8.58407 12.973 9.4403 12.8076C10.2965 12.6422 11.0991 12.2694 11.7778 11.7218C12.4565 11.1742 12.9906 10.4686 13.3333 9.66666Z" fill="var(--text-tertiary)"/>
          </svg>
          야간
        </button>
      </div>
      <div class="alarm-wrapper">
        <button id="btnAlarm" class="btn-alarm" onclick="toggleAlarmDropdown(event)" title="신규사고 알람">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
          <span id="alarmBadge" class="alarm-badge">2</span>
        </button>

        <!-- 신규 사고 드롭다운 목록 -->
        <div id="alarmDropdown" class="alarm-dropdown" onclick="event.stopPropagation()">
          <div class="alarm-header">
            <div class="alarm-title">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--status-red)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              신규 사고
              <span id="alarmCountPill" class="alarm-count-pill">2</span>
            </div>
            <button class="btn-read-all" onclick="markAllAlarmRead()">모두 읽음</button>
          </div>
          <div class="alarm-list" id="alarmList">
            <!-- 항목 1 -->
            <div class="alarm-item" onclick="selectAlarmAccident(this, '춘천지사', '중앙선', '210.3km', '춘천', '16:20:15', '2026-ACC-00160')">
              <div class="alarm-item-left">
                <span class="unread-dot"></span>
                <div class="alarm-item-info">
                  <div class="alarm-item-title">춘천지사 / 중앙선 / 210.3km / 춘천</div>
                  <div class="alarm-item-time">16:20 발생 · <span class="just-now">방금 전</span></div>
                </div>
              </div>
              <span class="alarm-item-arrow">❯</span>
            </div>
            <!-- 항목 2 -->
            <div class="alarm-item" onclick="selectAlarmAccident(this, '목포지사', '서해안선', '288.5km', '서울', '16:16:40', '2026-ACC-00159')">
              <div class="alarm-item-left">
                <span class="unread-dot"></span>
                <div class="alarm-item-info">
                  <div class="alarm-item-title">목포지사 / 서해안선 / 288.5km / 서울</div>
                  <div class="alarm-item-time">16:16 발생 · <span class="just-now">4분 전</span></div>
                </div>
              </div>
              <span class="alarm-item-arrow">❯</span>
            </div>
            <!-- 항목 3 (읽음 상태) -->
            <div class="alarm-item read" onclick="selectAlarmAccident(this, '충주지사', '중부내륙선', '209.0km', '양평', '16:10:05', '2026-ACC-00158')">
              <div class="alarm-item-left">
                <span class="unread-dot"></span>
                <div class="alarm-item-info">
                  <div class="alarm-item-title">충주지사 / 중부내륙선 / 209.0km / 양평</div>
                  <div class="alarm-item-time">16:10 발생 · 10분 전</div>
                </div>
              </div>
              <span class="alarm-item-arrow">❯</span>
            </div>
          </div>
          <div class="alarm-footer">항목을 클릭하면 해당 사고 정보가 화면에 표출됩니다</div>
        </div>
      </div>
    </div>
  </header>

  <div class="layout">

    <!-- 1. Left Sidebar (968px 고정) -->
    <aside class="panel left-panel">
      <!-- 폰트 20px bold 반영됨 -->
      <div class="panel-header">사고 목록</div>

      <!-- 탭 버튼 -->
      <div class="tab-group">
        <div class="tab active" id="tab-processing" data-status-filter="processing" onclick="//switchTab('processing')">처리중 (9)</div>
        <div class="tab" id="tab-completed" data-status-filter="completed" onclick="//switchTab('completed')">완료 (7)</div>
      </div>
		<div class="legend" style="display: block; text-align: right; font-size: 15px;">
		범례: &nbsp
        <span style="display:inline-block; width:10px; height:10px; border:1.5px solid var(--status-red); border-radius:2px;background-color: var(--bg-critical);"></span>
          인명사고 발생
      </div>

      <div class="list-container">
        <!-- ======================= 처리중 (9) 리스트 ======================= -->
        <div id="content-processing" class="tab-content active">
          <!-- Item 1 (Selected) -->
          <div class="list-item selected">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">수원지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  031-8007-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">15:41</span> 경부선(서울) 178.4km</div>
              <div class="list-desc">
                <span class="badge-casualty checking">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 조사중
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 2대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">41분</div>
                <div class="time-small">/ 70분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 2 (인명사고 있음 / 시간초과) -->
          <div class="list-item casualty-alert">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">대전지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  042-620-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">13:32</span> 경부선(부산) 239.0km</div>
              <div class="list-desc">
                <span class="badge-casualty yes">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 있음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 4대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large red">170분</div>
                <div class="time-small">/ 97분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 3 -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">홍천지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  033-430-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">15:30</span> 서울양양선(양양) 68.0km</div>
              <div class="list-desc">
                <span class="badge-casualty no">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 없음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 1대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">52분</div>
                <div class="time-small">/ 60분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 4 (인명사고 있음 / 시간초과) -->
          <div class="list-item casualty-alert">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">원주지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  033-740-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">14:54</span> 영동선(강릉) 101.2km</div>
              <div class="list-desc">
                <span class="badge-casualty yes">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 있음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 3대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large red">88분</div>
                <div class="time-small">/ 80분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 5 -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">성남지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  031-750-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">15:54</span> 수도권제1순환선(판교) 74.0km</div>
              <div class="list-desc">
                <span class="badge-casualty no">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 없음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 2대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">28분</div>
                <div class="time-small">/ 63분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 6 -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">충주지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  043-850-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">16:10</span> 중부내륙선(양평) 209.0km</div>
              <div class="list-desc">
                <span class="badge-casualty checking">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 조사중
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 1대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">12분</div>
                <div class="time-small">/ 35분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 7 -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">양산지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  055-380-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">15:56</span> 경부선(서울) 392.0km</div>
              <div class="list-desc">
                <span class="badge-casualty no">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 없음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 2대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">26분</div>
                <div class="time-small">/ 30분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 8 (인명사고 있음) -->
          <div class="list-item casualty-alert">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">목포지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  061-280-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">16:16</span> 서해안선(서울) 288.5km</div>
              <div class="list-desc">
                <span class="badge-casualty yes">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 있음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 2대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">6분</div>
                <div class="time-small">/ 50분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 9 -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">춘천지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  033-250-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">16:20</span> 중앙선(춘천) 210.3km</div>
              <div class="list-desc">
                <span class="badge-casualty checking">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 조사중
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 1대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">2분</div>
                <div class="time-small">/ 35분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>
        </div>

        <!-- ======================= 완료 (7) 리스트 ======================= -->
        <div id="content-completed" class="tab-content">
          <!-- Item 1 (Selected) -->
          <div class="list-item selected">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">수원지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  031-8007-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">15:41</span> 경부선(서울) 178.4km</div>
              <div class="list-desc">
                <span class="badge-casualty no">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 없음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 2대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">40분</div>
                <div class="time-small">/ 70분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 2 (인명사고 있음) -->
          <div class="list-item casualty-alert">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">서천지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  041-950-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">14:05</span> 서해안선(목포) 301.2km</div>
              <div class="list-desc">
                <span class="badge-casualty yes">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 있음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 3대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">57분</div>
                <div class="time-small">/ 60분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 3 -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">이천지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  031-640-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">13:40</span> 중부선(하남) 112.6km</div>
              <div class="list-desc">
                <span class="badge-casualty no">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 없음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 1대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">42분</div>
                <div class="time-small">/ 45분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 4 (예측시간 초과 - Red) -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">용인지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  031-330-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">12:58</span> 영동선(인천) 52.3km</div>
              <div class="list-desc">
                <span class="badge-casualty no">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 없음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 2대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large red">72분</div>
                <div class="time-small">/ 60분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 5 (인명사고 있음) -->
          <div class="list-item casualty-alert">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">언양지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  052-260-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">11:20</span> 경부선(부산) 345.1km</div>
              <div class="list-desc">
                <span class="badge-casualty yes">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 있음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 2대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">38분</div>
                <div class="time-small">/ 40분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 6 -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">순천지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  061-750-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">10:47</span> 남해선(순천) 88.0km</div>
              <div class="list-desc">
                <span class="badge-casualty no">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 없음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 1대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">43분</div>
                <div class="time-small">/ 50분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>

          <!-- Item 7 -->
          <div class="list-item">
            <div class="list-item-content">
              <div class="list-top-row">
                <span class="badge-region">논산지사</span>
                <span class="branch-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                  041-730-2114
                </span>
              </div>
              <div class="list-title"><span class="occ-time">09:15</span> 호남선(천안) 150.4km</div>
              <div class="list-desc">
                <span class="badge-casualty no">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/></svg>
                  인명사고 없음
                </span>
                <span class="vehicle-count">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>
                  관련차량 2대
                </span>
              </div>
            </div>
            <div class="list-item-right">
              <div style="text-align: right;">
                <div class="time-large">37분</div>
                <div class="time-small">/ 45분</div>
              </div>
              <span class="arrow-icon">❯</span>
            </div>
          </div>
        </div>

      </div>
    </aside>

    <!-- 2. Main Content (Center + Right 패널 묶음) -->
    <div class="main-content">

      <!-- [상단 영역] : Center (1028px) + Right (420px) 묶음 -->
      <div class="top-row">

        <!-- Center Column (1028px, 요소간 12px 간격) -->
        <div class="center-col">
          <!-- 20261109 수정2 -->
          <div class="info-card-top">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div class="red-bar"></div>
              <div class="info-header-left">
                <div class="info-header-top-row">
                  <span class="badge-region-large">수원지사</span>
                  <span class="info-occ-time">15:41</span>
                  <span class="info-title">경부선(서울) 178.4km</span>
                  <span class="info-sub">(오산JC~기흥IC)</span>
                </div>
                <div class="info-header-bottom-row">
                  <span class="badge-casualty-large checking">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.6663 4.66667C10.6663 6.13943 9.47243 7.33333 7.99967 7.33333C6.52692 7.33333 5.33301 6.13943 5.33301 4.66667C5.33301 3.19391 6.52692 2 7.99967 2C9.47243 2 10.6663 3.19391 10.6663 4.66667Z" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" stroke="#D98900"/>
                    <path d="M3.66699 14V12.6667C3.66699 11.5174 4.12354 10.4152 4.9362 9.60258C5.74885 8.78992 6.85105 8.33337 8.00033 8.33337C9.1496 8.33337 10.2518 8.78992 11.0645 9.60258C11.8771 10.4152 12.3337 11.5174 12.3337 12.6667V14" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" stroke="#D98900"/>
                    <path d="M12.6663 2V3.33333M12.6663 3.33333V4.66667M12.6663 3.33333H11.333M12.6663 3.33333H13.9997" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" stroke="#D98900"/>
                    </svg>
                    인명사고 조사중
                  </span>
                  <span class="vehicle-count-large">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3.75 12.75H14.25V9.37495L12.9 5.92495C12.7932 5.63905 12.6017 5.39254 12.3511 5.21832C12.1005 5.04411 11.8027 4.95049 11.4975 4.94995H6.5025C6.19729 4.95049 5.89951 5.04411 5.64891 5.21832C5.39831 5.39254 5.20682 5.63905 5.1 5.92495L3.75 9.37495V12.75Z" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round" stroke="#475569"/>
                    <path d="M3.75 9.375H14.25" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round" stroke="#475569"/>
                    <path d="M7.35039 13.125C7.35039 13.8706 6.74598 14.475 6.00039 14.475C5.25481 14.475 4.65039 13.8706 4.65039 13.125C4.65039 12.3794 5.25481 11.775 6.00039 11.775C6.74598 11.775 7.35039 12.3794 7.35039 13.125Z" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round" stroke="#475569"/>
                    <path d="M13.3504 13.125C13.3504 13.8706 12.746 14.475 12.0004 14.475C11.2548 14.475 10.6504 13.8706 10.6504 13.125C10.6504 12.3794 11.2548 11.775 12.0004 11.775C12.746 11.775 13.3504 12.3794 13.3504 13.125Z" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round" stroke="#475569"/>
                    </svg>
                    관련차량 2대
                  </span>
                </div>
              </div>
            </div>
            <div class="info-header-right">
              <div class="info-time-row" style="display: none;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
                발생시각 <strong class="occur-time">15:41:08</strong>
              </div>
              <div class="info-receipt">접수번호 2026-ACC-00158</div>
            </div>
          </div>
          <!-- //20261109 수정2 -->

          <!-- 통계/경과시간 진행률 (120px) -->
          <div class="info-card-bottom">
            <div class="stats-container">
              <div class="stat-box">
                <div class="stat-label">경과시간</div>
                <div class="stat-val pass-time green">41분</div>
              </div>
              <div class="stat-divider"></div>
              <div class="stat-box">
                <div class="stat-label">진행률 (경과/예측)</div>
                <div class="stat-val progress-fill green">58%</div>
              </div>
              <div class="stat-divider"></div>
              <div class="stat-box">
                <div class="stat-label">사고처리 예측시간</div>
                <div class="stat-val pred-time">70분</div>
              </div>
            </div>
            <div class="progress-container">
              <div class="progress-bar"></div>
            </div>
          </div>

          <div class="process-card">
            <div class="process-header">
              <h2 class="card-title">사고처리 진행상황</h2>
              <div class="process-legend">
                <span><span style="color: var(--status-red); font-size: 16px;">●</span> 사고발생</span>
                <span><span style="color: var(--status-green); font-size: 16px;">●</span> 완료</span>
                <span><span style="color: var(--status-amber); font-size: 16px;">●</span> 진행중</span>
              </div>
            </div>

            <!--20261109 수정-->
            <div class="process-grid mode-12" id="processGridContainer">

              <!-- ROW 1 (1~4단계) -->
              <div class="process-row row-1">

                <div class="process-step">
                  <span class="step-label">1. 사고발생</span>
                  <div class="step-icon red">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <path d="M13.1351 22.1325L11.6378 22.7742L12.0933 21.0927L9.98635 20.4704L11.7607 19.3368L10.8812 17.4495L13.0534 17.7985L13.4138 15.8048L14.7936 17.2924" stroke-width="0.571429" stroke="white"/>
                    <use xlink:href="#stroke0_20_991" fill="white"/>
                    <mask id="stroke1_20_991" fill="white">
                    <use xlink:href="#stroke0_20_991"/>
                    </mask>
                    <path d="M21.4322 19.5329L20.9055 17.8435C20.8291 17.5976 20.6822 17.3836 20.4855 17.232C20.2889 17.0805 20.0526 16.999 19.8101 16.9993H16.2995C16.0571 16.999 15.8208 17.0805 15.6241 17.232C15.4275 17.3836 15.2805 17.5976 15.2041 17.8435L14.6774 19.5329C14.5373 19.5955 14.4177 19.701 14.3336 19.8362C14.2495 19.9713 14.2046 20.13 14.2046 20.2923V22.3505C14.2046 22.6543 14.3601 22.9169 14.5896 23.0597V23.4325C14.5896 23.5417 14.6302 23.6464 14.7024 23.7236C14.7746 23.8008 14.8725 23.8441 14.9746 23.8441H15.3597C15.4618 23.8441 15.5597 23.8008 15.6319 23.7236C15.7041 23.6464 15.7447 23.5417 15.7447 23.4325V23.1738H20.365V23.4325C20.365 23.5417 20.4055 23.6464 20.4777 23.7236C20.5499 23.8008 20.6479 23.8441 20.75 23.8441H21.135C21.2371 23.8441 21.3351 23.8008 21.4073 23.7236C21.4795 23.6464 21.52 23.5417 21.52 23.4325V23.0597C21.6368 22.9881 21.7339 22.8848 21.8015 22.7603C21.8691 22.6358 21.9048 22.4945 21.9051 22.3505V20.2923C21.9051 20.13 21.8602 19.9713 21.776 19.8362C21.6919 19.701 21.5723 19.5955 21.4322 19.5329ZM16.2995 17.8225H19.8098C19.9757 17.8225 20.1228 17.9353 20.1751 18.1041L20.601 19.4691H15.5087L15.9341 18.1041C15.9597 18.0221 16.0087 17.9508 16.0743 17.9002C16.1399 17.8497 16.2187 17.8225 16.2995 17.8225ZM15.5522 21.9389C15.4763 21.9388 15.4012 21.9228 15.3311 21.8918C15.261 21.8607 15.1973 21.8152 15.1437 21.7578C15.0901 21.7004 15.0476 21.6323 15.0185 21.5574C14.9895 21.4824 14.9746 21.4021 14.9746 21.321C14.9747 21.2399 14.9896 21.1596 15.0187 21.0846C15.0477 21.0097 15.0903 20.9416 15.144 20.8843C15.1977 20.827 15.2614 20.7815 15.3315 20.7505C15.4016 20.7195 15.4767 20.7035 15.5526 20.7035C15.7058 20.7036 15.8527 20.7687 15.961 20.8846C16.0693 21.0005 16.1301 21.1576 16.1301 21.3214C16.13 21.4852 16.0691 21.6423 15.9607 21.7581C15.8524 21.8739 15.7054 21.9389 15.5522 21.9389ZM20.5575 21.9389C20.4816 21.9388 20.4065 21.9228 20.3364 21.8918C20.2663 21.8607 20.2026 21.8152 20.149 21.7578C20.0954 21.7004 20.0529 21.6323 20.0238 21.5574C19.9948 21.4824 19.9799 21.4021 19.9799 21.321C19.98 21.2399 19.9949 21.1596 20.024 21.0846C20.053 21.0097 20.0956 20.9416 20.1493 20.8843C20.203 20.827 20.2667 20.7815 20.3368 20.7505C20.4069 20.7195 20.482 20.7035 20.5579 20.7035C20.7111 20.7036 20.858 20.7687 20.9663 20.8846C21.0746 21.0005 21.1354 21.1576 21.1354 21.3214C21.1353 21.4852 21.0744 21.6423 20.966 21.7581C20.8577 21.8739 20.7107 21.9389 20.5575 21.9389Z" stroke-width="5.55556" stroke="white" mask="url(#stroke1_20_991)"/>
                    <path d="M16.1904 4.85693L3.92371 26.1903H28.457L16.1904 4.85693Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <defs>
                    <path id="stroke0_20_991" d="M21.4322 19.5329L20.9055 17.8435C20.8291 17.5976 20.6822 17.3836 20.4855 17.232C20.2889 17.0805 20.0526 16.999 19.8101 16.9993H16.2995C16.0571 16.999 15.8208 17.0805 15.6241 17.232C15.4275 17.3836 15.2805 17.5976 15.2041 17.8435L14.6774 19.5329C14.5373 19.5955 14.4177 19.701 14.3336 19.8362C14.2495 19.9713 14.2046 20.13 14.2046 20.2923V22.3505C14.2046 22.6543 14.3601 22.9169 14.5896 23.0597V23.4325C14.5896 23.5417 14.6302 23.6464 14.7024 23.7236C14.7746 23.8008 14.8725 23.8441 14.9746 23.8441H15.3597C15.4618 23.8441 15.5597 23.8008 15.6319 23.7236C15.7041 23.6464 15.7447 23.5417 15.7447 23.4325V23.1738H20.365V23.4325C20.365 23.5417 20.4055 23.6464 20.4777 23.7236C20.5499 23.8008 20.6479 23.8441 20.75 23.8441H21.135C21.2371 23.8441 21.3351 23.8008 21.4073 23.7236C21.4795 23.6464 21.52 23.5417 21.52 23.4325V23.0597C21.6368 22.9881 21.7339 22.8848 21.8015 22.7603C21.8691 22.6358 21.9048 22.4945 21.9051 22.3505V20.2923C21.9051 20.13 21.8602 19.9713 21.776 19.8362C21.6919 19.701 21.5723 19.5955 21.4322 19.5329ZM16.2995 17.8225H19.8098C19.9757 17.8225 20.1228 17.9353 20.1751 18.1041L20.601 19.4691H15.5087L15.9341 18.1041C15.9597 18.0221 16.0087 17.9508 16.0743 17.9002C16.1399 17.8497 16.2187 17.8225 16.2995 17.8225ZM15.5522 21.9389C15.4763 21.9388 15.4012 21.9228 15.3311 21.8918C15.261 21.8607 15.1973 21.8152 15.1437 21.7578C15.0901 21.7004 15.0476 21.6323 15.0185 21.5574C14.9895 21.4824 14.9746 21.4021 14.9746 21.321C14.9747 21.2399 14.9896 21.1596 15.0187 21.0846C15.0477 21.0097 15.0903 20.9416 15.144 20.8843C15.1977 20.827 15.2614 20.7815 15.3315 20.7505C15.4016 20.7195 15.4767 20.7035 15.5526 20.7035C15.7058 20.7036 15.8527 20.7687 15.961 20.8846C16.0693 21.0005 16.1301 21.1576 16.1301 21.3214C16.13 21.4852 16.0691 21.6423 15.9607 21.7581C15.8524 21.8739 15.7054 21.9389 15.5522 21.9389ZM20.5575 21.9389C20.4816 21.9388 20.4065 21.9228 20.3364 21.8918C20.2663 21.8607 20.2026 21.8152 20.149 21.7578C20.0954 21.7004 20.0529 21.6323 20.0238 21.5574C19.9948 21.4824 19.9799 21.4021 19.9799 21.321C19.98 21.2399 19.9949 21.1596 20.024 21.0846C20.053 21.0097 20.0956 20.9416 20.1493 20.8843C20.203 20.827 20.2667 20.7815 20.3368 20.7505C20.4069 20.7195 20.482 20.7035 20.5579 20.7035C20.7111 20.7036 20.858 20.7687 20.9663 20.8846C21.0746 21.0005 21.1354 21.1576 21.1354 21.3214C21.1353 21.4852 21.0744 21.6423 20.966 21.7581C20.8577 21.8739 20.7107 21.9389 20.5575 21.9389Z"/>
                    </defs>
                    </svg>
                  </div>
                  <div class="time-pill red">15:41 완료</div>
                  <div class="step-desc">접보 <b>보험사</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 green">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">2. 비상방송</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4.66663 12.6666V19.3333H8.93329L18.6666 25.3333V6.66663L8.93329 12.6666H4.66663Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M23.0667 12C23.6342 12.5004 24.0887 13.116 24.4 13.8056C24.7113 14.4953 24.8723 15.2433 24.8723 16C24.8723 16.7566 24.7113 17.5046 24.4 18.1943C24.0887 18.884 23.6342 19.4995 23.0667 20M26.1333 8.66663C27.1256 9.61294 27.9156 10.7508 28.4553 12.0113C28.995 13.2718 29.2733 14.6288 29.2733 16C29.2733 17.3712 28.995 18.7281 28.4553 19.9886C27.9156 21.2491 27.1256 22.387 26.1333 23.3333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">15:42 완료</div>
                  <div class="step-desc">터널 방송 <b>15:42</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 green">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">3. 교통정보표출</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6 4.66663H26C27.1046 4.66663 28 5.56206 28 6.66663V16C28 17.1045 27.1046 18 26 18H6C4.89543 18 4 17.1045 4 16V6.66663C4 5.56206 4.89543 4.66663 6 4.66663Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M16 18V27.3333M16 27.3333H10.6666M16 27.3333H21.3333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M8.66663 11.4667C9.99996 9.86672 11.3333 9.86672 12.6666 11.4667C14 13.0667 15.3333 13.0667 16.6666 11.4667C18 9.86672 19.3333 9.86672 20.6666 11.4667" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">15:44 완료</div>
                  <div class="step-desc">VMS <b>15:44</b><br>문자 <b>15:45</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 green">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">4. 차단막 하강</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 4.66663H28" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M9.33333 4.66663H22.6667C23.403 4.66663 24 5.26358 24 5.99996V15.3333C24 16.0697 23.403 16.6666 22.6667 16.6666H9.33333C8.59695 16.6666 8 16.0697 8 15.3333V5.99996C8 5.26358 8.59695 4.66663 9.33333 4.66663Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M16 20V28M20 24L16 28L12 24" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">15:45 완료</div>
                  <div class="step-desc">진입부 <b>15:45</b></div>
                </div>
              </div>

              <!-- ROW 2 (5~8단계) - 왼쪽에서 오른쪽으로 진행 -->
              <div class="process-row row-2">

                <div class="process-step">
                  <div class="step-arrow-60 green">
                    <svg width="60" height="16" viewBox="0 0 60 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H58M50 1L58.5 8L50 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">5. 제트팬 작동</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M28 16C28 22.6274 22.6274 28 16 28C9.37258 28 4 22.6274 4 16C4 9.37258 9.37258 4 16 4C22.6274 4 28 9.37258 28 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M18.1334 16C18.1334 17.1782 17.1782 18.1334 16 18.1334C14.8218 18.1334 13.8667 17.1782 13.8667 16C13.8667 14.8218 14.8218 13.8667 16 13.8667C17.1782 13.8667 18.1334 14.8218 18.1334 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M16 13.8666C14.6667 9.46662 16.2667 6.79995 19.4667 7.33329M17.8667 17.0666C22.1334 18.8 23.4667 21.6 21.2 23.7333M14 16.8C10.2667 19.4666 7.33338 18.9333 6.80005 15.7333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">15:46 완료</div>
                  <div class="step-desc">4기 작동 <b>15:46</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 green">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">6. 차로차단</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13.7333 4H18.2667L24 24H8L13.7333 4Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M11.0666 12.6666H20.9333M9.59998 18H22.4" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M4.66663 28H27.3333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">15:46 완료</div>
                  <div class="step-desc">전차로 차단 <b>15:46</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 green">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">7. 현장출동</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3.33337 22V12H16V22" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M16 14.6666H21.3333L26 18.9333V22H16" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M10.9334 23.3333C10.9334 24.5852 9.91854 25.6 8.66669 25.6C7.41485 25.6 6.40002 24.5852 6.40002 23.3333C6.40002 22.0815 7.41485 21.0667 8.66669 21.0667C9.91854 21.0667 10.9334 22.0815 10.9334 23.3333Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M23.6 23.3333C23.6 24.5852 22.5852 25.6 21.3333 25.6C20.0815 25.6 19.0667 24.5852 19.0667 23.3333C19.0667 22.0815 20.0815 21.0667 21.3333 21.0667C22.5852 21.0667 23.6 22.0815 23.6 23.3333Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M9.60004 14.4V16.6667M9.60004 16.6667V18.9334M9.60004 16.6667H7.33337M9.60004 16.6667H11.8667" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M18.6666 7.33329H27.3333M24.6666 9.99996L27.3333 7.33329L24.6666 4.66663" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">15:47 완료</div>
                  <div class="step-desc">119 <b>15:47</b><br>고순대 <b>15:48</b><br>견인 <b>15:50</b><br>구급 <b>15:52</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 green">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">8. 현장도착</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M16 28C16 28 7.33337 20.2667 7.33337 14C7.33337 11.7015 8.24647 9.4971 9.87178 7.87178C11.4971 6.24647 13.7015 5.33337 16 5.33337C18.2986 5.33337 20.503 6.24647 22.1283 7.87178C23.7536 9.4971 24.6667 11.7015 24.6667 14C24.6667 20.2667 16 28 16 28Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M12.4 14.1333L14.9334 16.6666L19.7334 11.7333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">16:02 완료</div>
                  <div class="step-desc">고순대 <b>16:02</b><br>119 <b>16:05</b><br>구급 <b>16:08</b><br>견인 <b>16:12</b></div>
                </div>
              </div>

              <!-- ROW 3 (9~12단계) -->
              <div class="process-row row-3">

                <div class="process-step">
                  <div class="step-arrow-60 green">
                    <svg width="60" height="16" viewBox="0 0 60 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H58M50 1L58.5 8L50 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">9. 차단막 해제</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 4.66663H28" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M9.33333 4.66663H22.6667C23.403 4.66663 24 5.26358 24 5.99996V9.33329C24 10.0697 23.403 10.6666 22.6667 10.6666H9.33333C8.59695 10.6666 8 10.0697 8 9.33329V5.99996C8 5.26358 8.59695 4.66663 9.33333 4.66663Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M16 28V16M20 20L16 16L12 20" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">16:10 완료</div>
                  <div class="step-desc">진입부 <b>16:10</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 green">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">10. 제트팬 해제</span>
                  <div class="step-icon green">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M28 16C28 22.6274 22.6274 28 16 28C9.37258 28 4 22.6274 4 16C4 9.37258 9.37258 4 16 4C22.6274 4 28 9.37258 28 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M18.1334 16C18.1334 17.1782 17.1782 18.1334 16 18.1334C14.8218 18.1334 13.8667 17.1782 13.8667 16C13.8667 14.8218 14.8218 13.8667 16 13.8667C17.1782 13.8667 18.1334 14.8218 18.1334 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M16 13.8666C14.6667 9.46662 16.2667 6.79995 19.4667 7.33329M17.8667 17.0666C22.1334 18.8 23.4667 21.6 21.2 23.7333M14 16.8C10.2667 19.4666 7.33338 18.9333 6.80005 15.7333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M7.46667 7.46667L24.5333 24.5333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill green">16:12 완료</div>
                  <div class="step-desc">4기 정지 <b>16:12</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 amber">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label">11. 차단해제</span>
                  <div class="step-icon amber">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6.66663 28L10.6666 4M25.3333 28L21.3333 4" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                  <path d="M16 24V10.6666M20 14.6666L16 10.6666L12 14.6666" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                  </svg>
                  </div>
                  <div class="time-pill amber">16:18 진행 중</div>
                  <div class="step-desc">1차로 해제 <b>16:14</b><br>전차로 해제 <b>16:18</b></div>
                </div>

                <div class="process-step">
                  <div class="step-arrow-175 gray">
                    <svg width="175" height="16" viewBox="0 0 175 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M0 8H173M165 1L173.5 8L165 15" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </div>
                  <span class="step-label" style="color: var(--text-tertiary);">12. 처리완료</span>
                  <div class="step-icon gray">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M28 16C28 22.6274 22.6274 28 16 28C9.37258 28 4 22.6274 4 16C4 9.37258 9.37258 4 16 4C22.6274 4 28 9.37258 28 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    <path d="M10.4 16.2666L14.2667 20.1333L21.7334 12.1333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                    </svg>
                  </div>
                  <div class="time-pill gray">- 대기</div>
                  <div class="step-desc gray-text">총 소요 -</div>
                </div>
              </div>
            </div>
            <!--//20261109 수정-->

          </div>
        </div>

        <!-- 상단 우측 (420px) : 원클릭 보고서 개편 -->
        <div class="right-col">
          <aside class="panel report-panel">
            <div class="report-header-new">
              <!-- 폰트 20px bold 반영됨 -->
              <div class="report-title-new">원클릭 보고서</div>
              <div class="report-header-right">
                <span class="report-count">전체 속보 <strong>15건</strong></span>

                <select class="report-sort-select">
                  <option value="latest">최신순</option>
                  <option value="oldest">과거순</option>
                </select>
                <button class="btn-report-popup" onclick="openReportPopup()" title="팝업으로 보기">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </button>
              </div>
            </div>

            <div class="report-list">
              <div class="report-item highlight">
                <div class="report-time">16:12</div>
                <div class="report-text">견인차 현장 도착 (화성견인 2호)</div>
              </div>
              <div class="report-item">
                <div class="report-time">16:05</div>
                <div class="report-text">119 구급대 현장 도착, 경상자 1명 응급처치 중</div>
              </div>
              <div class="report-item">
                <div class="report-time">16:02</div>
                <div class="report-text">고순대 1지구대 현장 도착, 1·2차로 통제 유지</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:52</div>
                <div class="report-text">구급차 추가 출동 요청</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:50</div>
                <div class="report-text">견인차 출동 요청 (발안-서평택-청북 견인업체)</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:48</div>
                <div class="report-text">화성2호, 본부, 고순대 1지구대 상황 전파</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:47</div>
                <div class="report-text">119 통화 출동 요청</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:46</div>
                <div class="report-text">1·2차로 차단 (전면차단 아님)</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:45</div>
                <div class="report-text">문자정보 표출</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:44</div>
                <div class="report-text">도로전광표지(VMS) 표출</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:43</div>
                <div class="report-text">고속도로순찰대 출동 지시</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:43</div>
                <div class="report-text">상황실 사고 인지 · 상황 전파</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:42</div>
                <div class="report-text">CCTV 사고 확인 (오산JC 부근)</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:42</div>
                <div class="report-text">112 신고 접수 (차량 3대 추돌)</div>
              </div>
              <div class="report-item">
                <div class="report-time">15:41</div>
                <div class="report-text">보험사 사고 접수</div>
              </div>
            </div>
          </aside>
        </div>

      </div>

      <div class="bottom-row">
        <!-- 사고 정체길이 현황 -->
        <div class="bottom-card congestion-card">
          <div class="card-title-fixed">사고 정체길이 현황</div>
          <div class="congestion-inner-flex">
            <div class="congestion-box congestion-left">
              <div class="c-header-row">
                <div class="c-header-title">
                  <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6.87502 1.25H8.12502V3.125H6.87502V1.25ZM6.87502 4.375H8.12502V6.875H6.87502V4.375ZM6.87502 8.125H8.12502V10.625H6.87502V8.125ZM6.87502 11.875H8.12502V13.75H6.87502V11.875ZM1.30627 13.75H2.56252L3.69377 1.25H2.43752L1.30627 13.75ZM11.3063 1.25L12.4375 13.75H13.6938L12.5625 1.25H11.3063Z" fill="currentColor"/>
                  </svg>
                  정체길이 현황
                </div>
              </div>
              <div class="c-data-row">
                <div class="c-bar-track"><div class="c-bar-fill amber" style="width: 65%;"></div></div>
                <div class="c-value">5.2<span>km</span></div>
              </div>
            </div>

            <div class="congestion-box congestion-right">
              <div class="c-header-row" style="margin-bottom: 4px; justify-content: center;">
                <div class="c-header-title">
                  <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M7.85299 3.99903H7.1484C7.08394 3.99903 7.03121 4.05176 7.03121 4.11621V8.14893C7.03121 8.18701 7.04879 8.22217 7.07955 8.24414L9.50094 10.0122C9.55367 10.0503 9.62691 10.04 9.665 9.98731L10.0839 9.41602C10.1235 9.36182 10.1118 9.28858 10.059 9.25196L7.97017 7.7417V4.11621C7.97017 4.05176 7.91744 3.99903 7.85299 3.99903ZM11.0727 5.10059L13.3696 5.66162C13.4428 5.6792 13.5146 5.62354 13.5146 5.54883L13.5263 3.18311C13.5263 3.08496 13.4135 3.0293 13.3374 3.09082L11.0288 4.89404C11.0113 4.90754 10.998 4.92569 10.9904 4.9464C10.9829 4.96711 10.9813 4.98955 10.9858 5.01112C10.9904 5.0327 11.001 5.05254 11.0164 5.06837C11.0318 5.08419 11.0513 5.09536 11.0727 5.10059ZM13.5293 9.51123L12.6987 9.22559C12.6697 9.21566 12.638 9.21746 12.6104 9.2306C12.5827 9.24374 12.5613 9.26718 12.5507 9.2959C12.5229 9.37061 12.4936 9.44385 12.4628 9.51709C12.2021 10.1338 11.8286 10.689 11.351 11.165C10.8788 11.6387 10.3191 12.0163 9.70308 12.2769C9.06489 12.5467 8.37888 12.6852 7.68599 12.6841C6.9858 12.6841 6.30758 12.5479 5.6689 12.2769C5.05285 12.0163 4.49319 11.6387 4.02096 11.165C3.54488 10.689 3.17135 10.1338 2.90914 9.51709C2.64079 8.87855 2.50331 8.19264 2.50484 7.5C2.50484 6.79981 2.64107 6.12012 2.91207 5.48145C3.17281 4.86475 3.54635 4.30957 4.02389 3.8335C4.49612 3.3598 5.05578 2.98221 5.67183 2.72168C6.30758 2.45069 6.98726 2.31445 7.68746 2.31445C8.38765 2.31445 9.06588 2.45069 9.70455 2.72168C10.3206 2.98221 10.8803 3.3598 11.3525 3.8335C11.5019 3.98438 11.6425 4.14111 11.7714 4.30664L12.6474 3.6211C11.4946 2.14746 9.70015 1.19971 7.68453 1.20117C4.17476 1.20264 1.3564 4.05322 1.39156 7.56446C1.42672 11.0142 4.23189 13.7988 7.68746 13.7988C10.4047 13.7988 12.7192 12.0762 13.601 9.66358C13.623 9.60205 13.5908 9.53321 13.5293 9.51123Z" fill="currentColor"/>
                  </svg>
                  정체해소 예상시간
                </div>
              </div>
              <div class="c-time-huge">17:05</div>
            </div>
          </div>
        </div>

        <div class="bottom-card detour-card">
          <div class="d-left-group">
            <div class="card-title-fixed">우회도로 안내</div>

            <div class="d-route-box">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M13.6666 2.33337L2.33331 7.20004L7.13331 8.86671L8.79998 13.6667L13.6666 2.33337Z" stroke-width="0.72" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/>
              </svg>
              <span class="detour-start">오산IC</span>
              <span class="arr">➔</span>
              <span class="detour-road highlight">국도1호선</span>
              <span class="arr">➔</span>
              <span class="detour-end">기흥IC</span>
            </div>

            <button class="d-btn" onclick="openMapPopup()">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M5.99998 2.66663L2.33331 3.99996V13.3333L5.99998 12L9.99998 13.3333L13.6666 12V2.66663L9.99998 3.99996L5.99998 2.66663Z" stroke-width="0.72" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
              <path d="M6 2.66663V12M10 3.99996V13.3333" stroke-width="0.72" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
              </svg>
              우회경로 보기
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="color:white;">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
            </button>
          </div>

          <div class="d-right-group">

            <!-- 본선 소요시간 (Red) -->
            <div class="d-donut red">
              <div class="d-donut-content">
                <div class="d-donut-title">본선 소요시간</div>
                <div class="d-donut-val">52<span>분</span></div>
                <div class="d-donut-desc">정체 포함 예상</div>
              </div>
            </div>

            <!-- 중앙 요약 뱃지 -->
            <div class="d-badges">
              <div class="d-badge d-recommend">우회권장</div>
              <div class="d-badge-arrow">></div>
              <div class="d-badge calc-time">24분 단축</div>
            </div>

            <!-- 우회 소요시간 (Blue) -->
            <div class="d-donut blue">
              <div class="d-donut-content">
                <div class="d-donut-title">우회 소요시간</div>
                <div class="d-donut-val">28<span>분</span></div>
                <div class="d-donut-desc">국도1호선</div>
              </div>
            </div>

          </div>

        </div>
      </div>

    </div>
  </div>

  <!-- ======================= 모달 팝업 영역 ======================= -->
  <div class="modal-overlay" id="mapPopup" onclick="closeMapPopup(event)">
    <div class="modal-content" onclick="event.stopPropagation()">
      <div class="modal-header">
        <div class="modal-title-wrap">
          <div class="modal-title">
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.25016 3.66663L3.2085 5.49996V18.3333L8.25016 16.5L13.7502 18.3333L18.7918 16.5V3.66663L13.7502 5.49996L8.25016 3.66663Z" stroke-width="0.99" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/>
            <path d="M8.25 3.66663V16.5M13.75 5.49996V18.3333" stroke-width="0.99" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/>
            </svg>
            우회경로 지도
          </div>
          <div class="modal-subtitle">경부선(서울) 178.4km · 2026-ACC-00158</div>
        </div>
        <button class="modal-close" onclick="closeMapPopup()">×</button>
      </div>
      <div id="map-panel" class="modal-body">
        <!-- 임시 지도 배경 공간 -->

        <div id="map">
          <!-- 우회경로 그래픽 및 사고 마커 라벨 -->
          <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 520px; height: 260px;">
            <svg width="520" height="260" viewBox="0 0 520 260" fill="none" xmlns="http://www.w3.org/2000/svg">
              <!-- 본선 정체 구간 -->
              <path d="M250 40 L265 120 L275 185 L255 215" stroke="#F87171" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" opacity="0.85"/>
              <!-- 우회도로(국도1호선) 구간 -->
              <path d="M250 40 L225 110 L225 215 L255 215" stroke="var(--brand-blue)" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
              <!-- 기흥IC / 오산IC 포인트 -->
              <circle cx="250" cy="40" r="5" fill="white" stroke="var(--brand-blue)" stroke-width="3.5"/>
              <circle cx="255" cy="215" r="5" fill="white" stroke="var(--brand-blue)" stroke-width="3.5"/>
            </svg>

            <!-- 기흥IC 라벨 -->
            <div style="position: absolute; top: 18px; left: 195px; background: var(--bg-panel); border: 1px solid var(--border-strong); border-radius: 4px; padding: 2px 8px; font-size: 11px; font-weight: 700; color: var(--text-primary);">기흥IC</div>

            <!-- 국도1호선 라벨 -->
            <div style="position: absolute; top: 150px; left: 105px; background: var(--bg-info-soft); border: 1px solid var(--brand-blue); border-radius: 4px; padding: 3px 8px; font-size: 11px; font-weight: 700; color: var(--brand-blue);">국도1호선 · 52km/h</div>

            <!-- 사고 지점 마커 -->
            <div style="position: absolute; top: 65px; left: 212px; width: 100px; height: 100px; pointer-events: none;">
              <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g filter="url(#filter0_d_318_4484)"><rect x="28" y="28" width="44" height="44" rx="22" fill="#E1252F"/><rect x="29.5" y="29.5" width="41" height="41" rx="20.5" stroke="white" stroke-width="3"/><path d="M50.0001 37.9584L36.9668 60.625H63.0335L50.0001 37.9584Z" stroke-width="0.99" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M46.2944 56.4159L44.4665 57.1993L45.0226 55.1465L42.4505 54.3869L44.6166 53.0031L43.5428 50.6991L46.1946 51.1252L46.6345 48.6914L48.319 50.5074" stroke-width="0.392857" stroke="white"/><use xlink:href="#stroke0_318_4484" fill="white"/><mask id="stroke1_318_4484" fill="white"><use xlink:href="#stroke0_318_4484"/></mask><path d="M56.4228 53.2421L55.7798 51.1798C55.6865 50.8795 55.5071 50.6184 55.2671 50.4333C55.027 50.2483 54.7385 50.1489 54.4426 50.1492H50.157C49.8611 50.1489 49.5726 50.2483 49.3325 50.4333C49.0925 50.6184 48.9131 50.8795 48.8198 51.1798L48.1768 53.2421C48.0058 53.3186 47.8598 53.4474 47.7571 53.6123C47.6544 53.7773 47.5996 53.971 47.5996 54.1692V56.6817C47.5996 57.0525 47.7895 57.3731 48.0696 57.5475V58.0026C48.0696 58.1358 48.1191 58.2636 48.2073 58.3579C48.2954 58.4521 48.415 58.5051 48.5396 58.5051H49.0097C49.1343 58.5051 49.2539 58.4521 49.342 58.3579C49.4302 58.2636 49.4797 58.1358 49.4797 58.0026V57.6867H55.1199V58.0026C55.1199 58.1358 55.1694 58.2636 55.2576 58.3579C55.3457 58.4521 55.4653 58.5051 55.5899 58.5051H56.0599C56.1846 58.5051 56.3042 58.4521 56.3923 58.3579C56.4804 58.2636 56.53 58.1358 56.53 58.0026V57.5475C56.6726 57.4601 56.7911 57.334 56.8736 57.182C56.9561 57.03 56.9997 56.8574 57 56.6817V54.1692C57 53.971 56.9452 53.7773 56.8425 53.6123C56.7398 53.4474 56.5938 53.3186 56.4228 53.2421ZM50.157 51.1542H54.4421C54.6447 51.1542 54.8243 51.2919 54.8882 51.4979L55.408 53.1642H49.1916L49.7109 51.4979C49.7421 51.3978 49.802 51.3107 49.882 51.249C49.9621 51.1873 50.0583 51.1541 50.157 51.1542ZM49.2447 56.1792C49.1521 56.1792 49.0604 56.1596 48.9748 56.1217C48.8892 56.0838 48.8115 56.0282 48.746 55.9582C48.6806 55.8881 48.6287 55.805 48.5932 55.7135C48.5578 55.622 48.5396 55.524 48.5396 55.4249C48.5397 55.3259 48.558 55.2279 48.5934 55.1364C48.6289 55.0449 48.6809 54.9618 48.7464 54.8918C48.8119 54.8219 48.8897 54.7663 48.9752 54.7285C49.0608 54.6906 49.1525 54.6712 49.2451 54.6712C49.4322 54.6713 49.6116 54.7508 49.7438 54.8922C49.876 55.0337 49.9502 55.2255 49.9502 55.4254C49.9501 55.6254 49.8757 55.8172 49.7434 55.9585C49.6111 56.0999 49.4317 56.1793 49.2447 56.1792ZM55.3549 56.1792C55.2623 56.1792 55.1706 56.1596 55.085 56.1217C54.9995 56.0838 54.9218 56.0282 54.8563 55.9582C54.7908 55.8881 54.7389 55.805 54.7035 55.7135C54.6681 55.622 54.6499 55.524 54.6499 55.4249C54.6499 55.3259 54.6682 55.2279 54.7037 55.1364C54.7391 55.0449 54.7911 54.9618 54.8566 54.8918C54.9221 54.8219 54.9999 54.7663 55.0855 54.7285C55.1711 54.6906 55.2628 54.6712 55.3554 54.6712C55.5424 54.6713 55.7218 54.7508 55.854 54.8922C55.9862 55.0337 56.0605 55.2255 56.0604 55.4254C56.0604 55.6254 55.986 55.8172 55.8537 55.9585C55.7214 56.0999 55.542 56.1793 55.3549 56.1792Z" stroke-width="3.81944" stroke="white" mask="url(#stroke1_318_4484)"/></g><defs><filter id="filter0_d_318_4484" x="0" y="0" width="100" height="100" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feMorphology radius="6" operator="dilate" in="SourceAlpha" result="effect1_dropShadow_318_4484"/><feOffset/><feGaussianBlur stdDeviation="11"/><feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 0.29 0 0 0 0 0.33 0 0 0 0.6 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_318_4484"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_318_4484" result="shape"/></filter><path id="stroke0_318_4484" d="M56.4228 53.2421L55.7798 51.1798C55.6865 50.8795 55.5071 50.6184 55.2671 50.4333C55.027 50.2483 54.7385 50.1489 54.4426 50.1492H50.157C49.8611 50.1489 49.5726 50.2483 49.3325 50.4333C49.0925 50.6184 48.9131 50.8795 48.8198 51.1798L48.1768 53.2421C48.0058 53.3186 47.8598 53.4474 47.7571 53.6123C47.6544 53.7773 47.5996 53.971 47.5996 54.1692V56.6817C47.5996 57.0525 47.7895 57.3731 48.0696 57.5475V58.0026C48.0696 58.1358 48.1191 58.2636 48.2073 58.3579C48.2954 58.4521 48.415 58.5051 48.5396 58.5051H49.0097C49.1343 58.5051 49.2539 58.4521 49.342 58.3579C49.4302 58.2636 49.4797 58.1358 49.4797 58.0026V57.6867H55.1199V58.0026C55.1199 58.1358 55.1694 58.2636 55.2576 58.3579C55.3457 58.4521 55.4653 58.5051 55.5899 58.5051H56.0599C56.1846 58.5051 56.3042 58.4521 56.3923 58.3579C56.4804 58.2636 56.53 58.1358 56.53 58.0026V57.5475C56.6726 57.4601 56.7911 57.334 56.8736 57.182C56.9561 57.03 56.9997 56.8574 57 56.6817V54.1692C57 53.971 56.9452 53.7773 56.8425 53.6123C56.7398 53.4474 56.5938 53.3186 56.4228 53.2421ZM50.157 51.1542H54.4421C54.6447 51.1542 54.8243 51.2919 54.8882 51.4979L55.408 53.1642H49.1916L49.7109 51.4979C49.7421 51.3978 49.802 51.3107 49.882 51.249C49.9621 51.1873 50.0583 51.1541 50.157 51.1542ZM49.2447 56.1792C49.1521 56.1792 49.0604 56.1596 48.9748 56.1217C48.8892 56.0838 48.8115 56.0282 48.746 55.9582C48.6806 55.8881 48.6287 55.805 48.5932 55.7135C48.5578 55.622 48.5396 55.524 48.5396 55.4249C48.5397 55.3259 48.558 55.2279 48.5934 55.1364C48.6289 55.0449 48.6809 54.9618 48.7464 54.8918C48.8119 54.8219 48.8897 54.7663 48.9752 54.7285C49.0608 54.6906 49.1525 54.6712 49.2451 54.6712C49.4322 54.6713 49.6116 54.7508 49.7438 54.8922C49.876 55.0337 49.9502 55.2255 49.9502 55.4254C49.9501 55.6254 49.8757 55.8172 49.7434 55.9585C49.6111 56.0999 49.4317 56.1793 49.2447 56.1792ZM55.3549 56.1792C55.2623 56.1792 55.1706 56.1596 55.085 56.1217C54.9995 56.0838 54.9218 56.0282 54.8563 55.9582C54.7908 55.8881 54.7389 55.805 54.7035 55.7135C54.6681 55.622 54.6499 55.524 54.6499 55.4249C54.6499 55.3259 54.6682 55.2279 54.7037 55.1364C54.7391 55.0449 54.7911 54.9618 54.8566 54.8918C54.9221 54.8219 54.9999 54.7663 55.0855 54.7285C55.1711 54.6906 55.2628 54.6712 55.3554 54.6712C55.5424 54.6713 55.7218 54.7508 55.854 54.8922C55.9862 55.0337 56.0605 55.2255 56.0604 55.4254C56.0604 55.6254 55.986 55.8172 55.8537 55.9585C55.7214 56.0999 55.542 56.1793 55.3549 56.1792Z"/></defs></svg>
            </div>

            <!-- 사고 마커 라벨 (방향 표기 축약 반영) -->
            <div style="position: absolute; top: 94px; left: 290px; background: var(--bg-panel); border: 1.5px solid var(--status-red); border-radius: 6px; padding: 7px 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
              <div style="font-size: 12px; font-weight: 800; color: var(--text-primary); margin-bottom: 2px;">경부선(서울) 178.4km</div>
              <div style="font-size: 11px; font-weight: 600; color: var(--status-red);">추돌사고 · 1·2차로 차단 · 정체 5.2km</div>
            </div>
          </div>
        </div>

        <!-- 1. 좌측 상단: 표출 정보 체크박스 그룹 -->
        <div class="map-overlay-box overlay-top-left">
          <div class="overlay-box-title">표출 정보</div>
          <label class="custom-checkbox">
            <input type="checkbox" name="vms" checked>
            <span class="checkmark"></span>
            VMS
          </label>
          <label class="custom-checkbox">
            <input type="checkbox" name="ic" checked>
            <span class="checkmark"></span>
            영업소
          </label>
        </div>

        <!-- 2. 우측 상단: 줌 컨트롤 -->
        <div class="map-overlay-box overlay-top-right zoom-control">
          <button type="button">+</button>
          <div class="zoom-divider"></div>
          <button type="button">−</button>
        </div>

        <!-- 3. 좌측 하단: 실시간 교통정보 갱신 -->
        <div id="mapLiveStatus" class="map-live-status map-overlay-box overlay-bottom-left" style="display: flex; align-items: center; gap: 8px;">
          <div class="map-live-status-head">
            <div class="overlay-box-title" style="margin-bottom: 2px;">실시간 교통정보</div>
            <div class="map-refresh-time" style="font-size: 12px; color: var(--text-tertiary);">
            	<span id="mapRefreshLabel">최종 갱신</span>
            	<time id="mapRefreshTime">-</time>
           	</div>
          </div>
          <button id="mapRefreshButton" class="refresh-btn map-refresh-button" aria-label="지도 정보 새로고침" title="새로고침">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
            </svg>
          </button>
        </div>

        <!-- 4. 우측 하단: 소통정보 + 사고정보 범례 -->
        <div class="map-overlay-box overlay-bottom-right legend-box">
          <span class="legend-title">소통정보</span>
          <div class="legend-item"><span class="color-line green"></span>원활 80+</div>
          <div class="legend-item"><span class="color-line amber"></span>서행 40~80</div>
          <div class="legend-item"><span class="color-line red"></span>정체 ~40</div>
          <div class="legend-item"><span class="color-line blue"></span>우회경로</div>
          <div class="legend-divider"></div>
          <span class="legend-title">사고정보</span>
          <div class="legend-item">
            <span class="legend-acc-icon">
              <svg width="16" height="16" viewBox="28 28 44 44" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <rect x="28" y="28" width="44" height="44" rx="22" fill="#E1252F"/>
                <path d="M50.0001 37.9584L36.9668 60.625H63.0335L50.0001 37.9584Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
                <path d="M46.2944 56.4159L44.4665 57.1993L45.0226 55.1465L42.4505 54.3869L44.6166 53.0031L43.5428 50.6991L46.1946 51.1252L46.6345 48.6914L48.319 50.5074" stroke-width="0.6" stroke="white"/>
                <use xlink:href="#stroke0_318_4484" fill="white"/>
              </svg>
            </span>
            사고지점
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- ======================= 이력조회 팝업 영역 ======================= -->
  <div class="history-modal-overlay" id="historyPopup" onclick="closeHistoryPopup(event)">
    <div class="history-modal-content" onclick="event.stopPropagation()">
      <div class="modal-header" style="background-color: var(--bg-selected);">
        <div class="modal-title-wrap">
          <div class="modal-title" style="font-size: 20px;">사고속보 이력조회</div>
        </div>
        <button class="modal-close" onclick="closeHistoryPopup()">×</button>
      </div>

      <div class="hist-filter-bar">
        <div class="hist-filter-item">
          조회기간 <input type="date" id="history-start-date" class="hist-input" value="2026-09-10" style="width: 130px;">
           ~
           <input type="date" id="history-end-date" class="hist-input" value="2026-09-17" style="width: 130px;">
        </div>
        <div class="hist-filter-item">
          사고접수번호 <input type="text" id="incident-num" class="hist-input" placeholder="예) 15497620" style="width: 180px;">
        </div>
        <div class="hist-filter-item">
          접보유형코드 <select id="accident-code" class="hist-input" style="width: 150px;"><option value="">전체</option></select>
        </div>
        <!-- <div class="hist-filter-item">
          인명사고 유무
          <div class="hist-radio-group">
            <label class="hist-radio"><input type="radio" name="casualty" checked>전체</label>
            <label class="hist-radio"><input type="radio" name="casualty">유</label>
            <label class="hist-radio"><input type="radio" name="casualty">무</label>
          </div>
        </div> -->
        <div style="display: flex; gap: 10px;">
          <button class="hist-btn-blue">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M11.6667 7.33333C11.6667 9.72657 9.72657 11.6667 7.33333 11.6667C4.9401 11.6667 3 9.72657 3 7.33333C3 4.9401 4.9401 3 7.33333 3C9.72657 3 11.6667 4.9401 11.6667 7.33333Z" stroke-width="0.72" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
            <path d="M13.3337 13.3334L10.4004 10.4" stroke-width="0.72" stroke-linecap="round" stroke-linejoin="round" stroke="white"/>
            </svg>
            조회
          </button>
          <button class="hist-btn-white">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M11.6663 6.41661C11.6637 5.4211 11.3428 4.45252 10.7505 3.65237C10.1582 2.85223 9.32559 2.26246 8.37424 1.96923C7.42289 1.67601 6.4027 1.6947 5.46273 2.02257C4.52276 2.35044 3.71227 2.97031 3.14967 3.79161M2.33301 7.58328C2.33562 8.57879 2.65652 9.54737 3.24882 10.3475C3.84111 11.1477 4.67376 11.7374 5.62511 12.0307C6.57646 12.3239 7.59665 12.3052 8.53662 11.9773C9.47659 11.6494 10.2871 11.0296 10.8497 10.2083" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#475569"/>
            <path d="M2.91699 1.75V4.08333H5.25033M11.0837 12.25V9.91667H8.75033" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#475569"/>
            </svg>
            초기화
          </button>
        </div>
      </div>

      <div class="hist-table-wrap">
        <div class="hist-total">전체 <span class="text-blue">47건</span></div>
        <table class="hist-table">
          <thead>
            <tr style="background-color: var(--bg-surface);">
              <th width="48px">No.</th>
              <th width="150px">사고접수번호</th>
              <th width="118px">사고발생일시</th>
              <th style="text-align: left; padding-left: 20px;">사고위치</th>
              <th width="150px">속보내용</th>
            </tr>
          </thead>
          <tbody>
            <!-- 펼쳐진 1번째 열 (기본 활성화) -->
            <tr class="main-row active" id="row-1">
              <td>1</td>
              <td>2026-ACC-00158</td>
              <td>09/17 15:41</td>
              <td style="text-align: left; padding-left: 20px;">경부선 178km+400 (서울방향)</td>
              <td>
              	<button class="badge-sokbo active" onclick="toggleHistoryRow(1, this)">속보 11건
	              	<span>
	              		<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 8.75L7 5.25L10.5 8.75" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>
	              	</span>
              	</button>
              </td>
            </tr>
            <tr class="sub-row open" id="sub-row-1">
              <td colspan="5">
                <div class="hist-sub-container">
                  <div class="hist-sub-list">
                    <div class="hist-sub-item">
                    	<span class="badge-time">09/17 15:41:08</span>
                    	<span>경부고속도로 178km+400(서울방향) 오산JC~기흥IC 구간 승용차 3대 추돌사고 발생. 보험사 접수.</span>
                    </div>
                    <div class="hist-sub-item"><span class="badge-time">09/17 15:41:08</span> <span>경부고속도로 178km+400(서울방향) 오산JC~기흥IC 구간 승용차 3대 추돌사고 발생. 보험사 접수.</span></div>
                    <div class="hist-sub-item"><span class="badge-time">09/17 15:44:20</span> <span>[수도권본부] 도로전광표지(VMS) 및 문자정보 표출. 1·2차로 일시 통제.</span></div>
                    <div class="hist-sub-item"><span class="badge-time">09/17 15:47:52</span> <span>119 통화 출동 요청. 화성2호, 본부, 고순대 1지구대 상황 전파.</span></div>
                    <div class="hist-sub-item"><span class="badge-time">09/17 16:05:13</span> <span>119 구급대 현장 도착. 경상자 1명 응급처치 중. 견인차 16:12 도착.</span></div>
                  </div>
                </div>
              </td>
            </tr>

            <!-- 닫혀있는 2번째 열 -->
            <tr class="main-row" id="row-2">
              <td>2</td>
              <td>2026-ACC-00157</td>
              <td>09/17 14:10</td>
              <td style="text-align: left; padding-left: 20px;">경부선 239km+000 (부산방향)</td>
              <td><button class="badge-sokbo" onclick="toggleHistoryRow(2, this)">속보 8건 <span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/></svg></span></button></td>
            </tr>
            <tr class="sub-row" id="sub-row-2">
              <td colspan="5">
                <div class="hist-sub-container">
                  <div class="hist-sub-list">
                    <div class="hist-sub-item"><span class="badge-time">09/17 14:10:00</span> <span>화재 발생 속보 내용 예시입니다.</span></div>
                  </div>
                </div>
              </td>
            </tr>

            <!-- 나머지 열 -->
            <tr class="main-row" id="row-3">
              <td>3</td>
              <td>2026-ACC-00156</td>
              <td>09/17 11:22</td>
              <td style="text-align: left; padding-left: 20px;">서해안선 288km+500 (서울방향)</td>
              <td><button class="badge-sokbo" onclick="toggleHistoryRow(3, this)">속보 6건 <span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/></svg></span></button></td>
            </tr>
            <tr class="sub-row" id="sub-row-3"><td colspan="5"></td></tr>

            <tr class="main-row" id="row-4">
              <td>4</td>
              <td>2026-ACC-00155</td>
              <td>09/17 09:05</td>
              <td style="text-align: left; padding-left: 20px;">중앙선 210km+300 (춘천방향)</td>
              <td><button class="badge-sokbo" onclick="toggleHistoryRow(4, this)">속보 3건 <span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/></svg></span></button></td>
            </tr>
            <tr class="sub-row" id="sub-row-4"><td colspan="5"></td></tr>

            <tr class="main-row" id="row-5">
              <td>5</td>
              <td>2026-ACC-00154</td>
              <td>09/16 22:48</td>
              <td style="text-align: left; padding-left: 20px;">영동선 101km+200 (강릉방향)</td>
              <td><button class="badge-sokbo" onclick="toggleHistoryRow(5, this)">속보 14건 <span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/></svg></span></button></td>
            </tr>
            <tr class="sub-row" id="sub-row-5"><td colspan="5"></td></tr>

            <tr class="main-row" id="row-6">
              <td>6</td>
              <td>2026-ACC-00153</td>
              <td>09/16 18:31</td>
              <td style="text-align: left; padding-left: 20px;">중부내륙선 209km+000 (양평방향)</td>
              <td><button class="badge-sokbo" onclick="toggleHistoryRow(6, this)">속보 2건 <span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/></svg></span></button></td>
            </tr>
            <tr class="sub-row" id="sub-row-6"><td colspan="5"></td></tr>

            <tr class="main-row" id="row-7">
              <td>7</td>
              <td>2026-ACC-00152</td>
              <td>09/16 13:07</td>
              <td style="text-align: left; padding-left: 20px;">수도권제1순환선 74km+000 (판교방향)</td>
              <td><button class="badge-sokbo" onclick="toggleHistoryRow(7, this)">속보 5건 <span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/></svg></span></button></td>
            </tr>
            <tr class="sub-row" id="sub-row-7"><td colspan="5"></td></tr>

            <tr class="main-row" id="row-8">
              <td>8</td>
              <td>2026-ACC-00151</td>
              <td>09/16 07:44</td>
              <td style="text-align: left; padding-left: 20px;">호남선 88km+500 (서울방향)</td>
              <td><button class="badge-sokbo" onclick="toggleHistoryRow(8, this)">속보 4건 <span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/></svg></span></button></td>
            </tr>
            <tr class="sub-row" id="sub-row-8"><td colspan="5"></td></tr>
          </tbody>
        </table>

        <div class="hist-footer">
          <!-- <div class="pagination">
            <button class="page-btn">«</button>
            <button class="page-btn">‹</button>
            <button class="page-btn active">1</button>
            <button class="page-btn">2</button>
            <button class="page-btn">3</button>
            <button class="page-btn">4</button>
            <button class="page-btn">5</button>
            <button class="page-btn">›</button>
            <button class="page-btn">»</button>
          </div> -->
        </div>
      </div>

      <div class="hist-footer-info">
        조회기간: 2026-09-10 ~ 2026-09-17  |  전체 47건
      </div>
    </div>
  </div>

  <!-- ======================= 원클릭 보고서 팝업 영역 ======================= -->
  <div class="report-modal-overlay" id="reportPopup">
    <div class="report-modal-content">
      <!-- 헤더 (아이콘 미표출) -->
      <div class="report-modal-header">
        <div class="report-modal-title-wrap">
          <div class="report-modal-title">원클릭 보고서</div>
          <div class="report-modal-subtitle">경부선(서울) 178.4km · 2026-ACC-00158</div>
        </div>
        <button class="modal-close" style="font-size: 26px;" onclick="event.stopPropagation(); closeReportPopup(this)">×</button>
      </div>

      <!-- 사고요약 (지사·발생시각·인명사고·관련차량 / 전화번호 미표출) -->
      <div class="report-modal-summary">
        <span>지사 <b class="report-modal-jisa">수원지사</b></span>
        <span>발생시각 <b class="report-modal-occur-time">15:41:08</b></span>
        <span>인명사고 <b class="report-modal-injured-person">조사중</b></span>
        <span>관련차량 <b class="report-modal-related-car">2대</b></span>
      </div>

      <!-- 2컬럼 헤더 (시각 · 속보 내용) -->
      <div class="report-modal-table-head">
        <div class="col-time">시각</div>
        <div class="col-desc">속보 내용</div>
      </div>

      <!-- 속보 목록 (2컬럼, NEW 미표출) -->
      <div class="report-modal-list">
        <div class="report-item highlight">
          <div class="report-time">16:12</div>
          <div class="report-text">견인차 현장 도착 (화성견인 2호)</div>
        </div>
        <div class="report-item">
          <div class="report-time">16:05</div>
          <div class="report-text">119 구급대 현장 도착, 경상자 1명 응급처치 중</div>
        </div>
        <div class="report-item">
          <div class="report-time">16:02</div>
          <div class="report-text">고순대 1지구대 현장 도착, 1·2차로 통제 유지</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:52</div>
          <div class="report-text">구급차 추가 출동 요청</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:50</div>
          <div class="report-text">견인차 출동 요청 (발안-서평택-청북 견인업체)</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:48</div>
          <div class="report-text">화성2호, 본부, 고순대 1지구대 상황 전파</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:47</div>
          <div class="report-text">119 통화 출동 요청</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:46</div>
          <div class="report-text">1·2차로 차단 (전면차단 아님)</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:45</div>
          <div class="report-text">문자정보 표출</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:44</div>
          <div class="report-text">도로전광표지(VMS) 표출</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:43</div>
          <div class="report-text">고속도로순찰대 출동 지시</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:43</div>
          <div class="report-text">상황실 사고 인지 · 상황 전파</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:42</div>
          <div class="report-text">CCTV 사고 확인 (오산JC 부근)</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:42</div>
          <div class="report-text">112 신고 접수 (차량 3대 추돌)</div>
        </div>
        <div class="report-item">
          <div class="report-time">15:41</div>
          <div class="report-text">보험사 사고 접수</div>
        </div>
      </div>

      <!-- 하단 닫기 버튼 -->
      <div class="report-modal-footer">
        <button class="btn-report-modal-close" onclick="closeReportPopup(this)">닫기</button>
      </div>
    </div>
  </div>

  <script>
  	function setTheme(theme) {
	    localStorage.setItem('dashboard-theme', theme);
	    document.documentElement.setAttribute('data-theme', theme);

	    document.getElementById('btn-day').classList.remove('active');
	    document.getElementById('btn-night').classList.remove('active');
	    document.getElementById('btn-' + theme).classList.add('active');
	}

	// 페이지 로드 시 버튼 상태만 복원
	document.addEventListener('DOMContentLoaded', function() {
	    const savedTheme = localStorage.getItem('dashboard-theme') || 'day';

	    document.getElementById('btn-day').classList.toggle('active', savedTheme === 'day');
	    document.getElementById('btn-night').classList.toggle('active', savedTheme === 'night');
	});

    // 탭 전환 함수
    function switchTab(tabId) {
      document.getElementById('tab-processing').classList.remove('active');
      document.getElementById('tab-completed').classList.remove('active');

      document.getElementById('content-processing').classList.remove('active');
      document.getElementById('content-completed').classList.remove('active');

      document.getElementById('tab-' + tabId).classList.add('active');
      document.getElementById('content-' + tabId).classList.add('active');
    }

    // 모달 팝업 열기
	function openMapPopup() {
	    document.getElementById("mapPopup").classList.add("active");
	    var mapTitle = document.querySelector(".info-title").textContent;
	    var mapSeq = document.querySelector(".info-receipt").textContent;

	    document.querySelector(".modal-subtitle").textContent = mapTitle + " - " + mapSeq;

	    requestAnimationFrame(function () {
	        vmap.updateSize();
	        vmap.renderSync();
	    });
	}

    // 모달 팝업 닫기 (오버레이 클릭 시에도 동작하도록 설정)
    function closeMapPopup(event) {
      if (event && event.target !== event.currentTarget) return;
      document.getElementById('mapPopup').classList.remove('active');
    }

    // 이력조회 팝업 열기
    function openHistoryPopup() {
      document.getElementById('historyPopup').classList.add('active');
    }

    // 이력조회 팝업 닫기 (오버레이 클릭 시에도 동작)
    function closeHistoryPopup(event) {
      if (event && event.target !== event.currentTarget) return;
      document.getElementById('historyPopup').classList.remove('active');
    }

    // 속보 내용 토글(열기/닫기) 함수
    function toggleHistoryRow(id, btn) {
      const mainRow = document.getElementById('row-' + id);
      const subRow = document.getElementById('sub-row-' + id);

      const isOpen = subRow.classList.contains('open');
      const iconSpan = btn.querySelector('span'); // 아이콘을 감싸고 있는 span

      const openIcon = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 8.75L7 5.25L10.5 8.75" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`;
      const closeIcon = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"/></svg>`;

      if(isOpen) {
        subRow.classList.remove('open');
        mainRow.classList.remove('active');
        btn.classList.remove('active');
        if(iconSpan) iconSpan.innerHTML = closeIcon;
      } else {
        subRow.classList.add('open');
        mainRow.classList.add('active');
        btn.classList.add('active');
        if(iconSpan) iconSpan.innerHTML = openIcon;
      }
    }

    /**
   * 사고처리 진행상황 단계를 동적으로 변경하는 함수
   * @param {number} stepCount - 단계 개수 (5 또는 12)
   */
  function updateProcessSteps(stepCount) {
    const gridContainer = document.getElementById('processGridContainer');

    if (stepCount === 5) {
      // 5개 단계 모드로 전환
      gridContainer.classList.remove('mode-12');
      gridContainer.classList.add('mode-5');

      gridContainer.innerHTML = `
        <!-- ROW 1 (1 ~ 3단계) -->
        <div class="process-row">
          <div class="process-step">
            <span class="step-label">1. 사고발생</span>
            <div class="step-icon red">
              <!-- SVG 아이콘 -->
            </div>
            <div class="time-pill red">15:41 완료</div>
            <span class="step-desc">접보 <b>보험사</b></span>
          </div>
          <div class="step-arrow-wrap">
            <div class="step-arrow"><svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M0.8 4H7.1M3.8 7.2L7.2 4L3.8 0.8" stroke-width="1.6" stroke="var(--border-strong)"/></svg></div>
          </div>
          <div class="process-step">
            <span class="step-label">2. 교통정보표출</span>
            <div class="step-icon green"></div>
            <div class="time-pill green">15:44 완료</div>
            <span class="step-desc">VMS 표출 <b>15:44</b><br>문자정보 <b>15:45</b></span>
          </div>
          <div class="step-arrow-wrap">
            <div class="step-arrow"><svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M0.8 4H7.1M3.8 7.2L7.2 4L3.8 0.8" stroke-width="1.6" stroke="var(--border-strong)"/></svg></div>
          </div>
          <div class="process-step">
            <span class="step-label">3. 차로차단</span>
            <div class="step-icon green"></div>
            <div class="time-pill green">15:46 완료</div>
            <span class="step-desc">1·2차로 차단 <b>15:46</b></span>
          </div>
        </div>

        <!-- ROW 2 (4 ~ 5단계) -->
        <div class="process-row" style="margin-top: 10px;">
          <div class="step-arrow-wrap first">
            <div class="step-arrow"><svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M0.8 4H7.1M3.8 7.2L7.2 4L3.8 0.8" stroke-width="1.6" stroke="var(--border-strong)"/></svg></div>
          </div>
          <div class="process-step">
            <span class="step-label">4. 현장출동</span>
            <div class="step-icon green"></div>
            <div class="time-pill green">15:47 완료</div>
            <span class="step-desc">119 <b>15:47</b><br>고순대 <b>15:48</b><br>견인차 <b>15:50</b><br>구급차 <b>15:52</b></span>
          </div>
          <div class="step-arrow-wrap">
            <div class="step-arrow active"><svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M0.8 4H7.1M3.8 7.2L7.2 4L3.8 0.8" stroke-width="1.6" stroke="var(--status-amber)"/></svg></div>
          </div>
          <div class="process-step">
            <span class="step-label">5. 현장도착</span>
            <div class="step-icon amber"></div>
            <div class="time-pill amber">16:02 진행 중</div>
            <span class="step-desc">고순대 <b>16:02</b><br>119 <b>16:05</b><br>견인차 <b>16:12</b><br>구급차 <b>도착대기</b></span>
          </div>
        </div>
      `;
    } else {
      // 12개 단계 모드로 전환 (기존 정렬 유지)
      gridContainer.classList.remove('mode-5');
      gridContainer.classList.add('mode-12');

      // 기존 12단계 HTML 구조 복원 코드를 여기에 작성하거나 원본 12단계 코드를 삽입
    }}

    let alarmHighlightTimer = null;

    // 신규 사고 수신 시 1분간 빨간색 하이라이트 (State = 신규 사고)
    function triggerNewAccidentAlarm() {
      const btn = document.getElementById('btnAlarm');
      if (!btn) return;
      btn.classList.add('new-accident');

      if (alarmHighlightTimer) clearTimeout(alarmHighlightTimer);
      alarmHighlightTimer = setTimeout(() => {
        btn.classList.remove('new-accident');
      }, 60000); // 1분(60초) 유지 후 기본 상태로 복귀
    }

    // 알람 드롭다운 열기/닫기
    function toggleAlarmDropdown(event) {
      event.stopPropagation();
      const dropdown = document.getElementById('alarmDropdown');
      dropdown.classList.toggle('active');
    }

    // 외부 영역 클릭 시 알람 드롭다운 닫기
    document.addEventListener('click', function(event) {
      const dropdown = document.getElementById('alarmDropdown');
      if (dropdown && dropdown.classList.contains('active')) {
        dropdown.classList.remove('active');
      }
    });

    // 미확인 알람 개수 업데이트
    function updateAlarmCount() {
      const unreadCount = document.querySelectorAll('#alarmList .alarm-item:not(.read)').length;
      const badge = document.getElementById('alarmBadge');
      const pill = document.getElementById('alarmCountPill');

      if (badge) {
        badge.textContent = unreadCount;
        if (unreadCount > 0) {
          badge.classList.add('has-count');
        } else {
          badge.classList.remove('has-count');
          document.getElementById('btnAlarm').classList.remove('new-accident');
        }
      }
      if (pill) {
        pill.textContent = unreadCount;
        pill.style.display = unreadCount > 0 ? 'inline-flex' : 'none';
      }
    }

    // 모두 읽음 처리
    function markAllAlarmRead() {
      document.querySelectorAll('#alarmList .alarm-item').forEach(item => {
    	var pk = item.getAttribute("data-pk");
  		if(pk) {
  			window.readApi.put("setReadInfo", {pk: pk})
  			.then(function (items) {
  				console.log("setReadInfo: ", items);
  		    }).catch(function (error) {
  		      console.warn("setReadInfo 실패", error);
  		    }).then(function () {

  		    });
  		}

        item.classList.add('read');
      });
      updateAlarmCount();
    }

    // 알람 항목 클릭 시 해당 사고 정보 표출
    /* function selectAlarmAccident(el, branch, route, km, dir, time, receiptNo) {
      // 읽음 처리 및 카운트 갱신
      el.classList.add('read');
      updateAlarmCount();

      // 상단 사고 기본정보 패널 업데이트
      const regionBadge = document.querySelector('.info-card-top .badge-region-large');
      const infoTitle = document.querySelector('.info-card-top .info-title');
      const infoSub = document.querySelector('.info-card-top .info-sub');
      const infoTime = document.querySelector('.info-card-top .info-time-row strong');
      const infoReceipt = document.querySelector('.info-card-top .info-receipt');

      if (regionBadge) regionBadge.textContent = branch;
      if (infoTitle) infoTitle.textContent = `${route} ${km}`;
      if (infoSub) infoSub.textContent = `(${dir})`;
      if (infoTime) infoTime.textContent = time;
      if (infoReceipt) infoReceipt.textContent = `접수번호 ${receiptNo}`;

      // 좌측 사고목록에서 동일 이정 항목이 있으면 선택(selected) 연동
      switchTab('processing');
      const listItems = document.querySelectorAll('#content-processing .list-item');
      listItems.forEach(item => {
        if (item.textContent.includes(km)) {
          listItems.forEach(i => i.classList.remove('selected'));
          item.classList.add('selected');
        }
      });
      // 드롭다운 닫기
      document.getElementById('alarmDropdown').classList.remove('active');
    } */
    // 초기 진입 시 신규사고 수신 상태(1분 하이라이트) 시연
    triggerNewAccidentAlarm();


// 원클릭 보고서 팝업 열기
var reportModalZIndex = 1000;

function openReportPopup() {
    const originalPopup = document.getElementById("reportPopup");

    // 새로운 모달 복제
    const popup = originalPopup.cloneNode(true);
    popup.removeAttribute("id");

    // 화면에 추가
    document.body.appendChild(popup);
    popup.classList.add("active");
    popup.style.zIndex = ++reportModalZIndex;

    // 현재 선택된 리포트 내용 복사
    const reportList = document.querySelector(".report-list");
    const reportModalList = popup.querySelector(".report-modal-list");

    reportModalList.replaceChildren(
        ...Array.from(reportList.children, child => child.cloneNode(true))
    );

    var subTitle = document.querySelector(".info-title").textContent;
    var receipt = document.querySelector(".info-receipt").textContent;
    popup.querySelector(".report-modal-subtitle").textContent = subTitle + " · " + receipt;

    // 지사
    var jisa = document.querySelector(".list-item.selected .badge-region").textContent;
    popup.querySelector(".report-modal-jisa").textContent = jisa;

    // 발생 시간
    var ocTime = document.querySelector(".occur-time").textContent;
    popup.querySelector(".report-modal-occur-time").textContent = ocTime;

    // 인명 피해
    var injuredPerson = document.querySelector(".badge-casualty-large").textContent;
    var injuredColor = injuredPerson.substring(injuredPerson.indexOf(" ") + 1).trim();
    var injuredElement = popup.querySelector(".report-modal-injured-person");

    injuredElement.classList.remove("amber", "red");
    if (injuredColor === "조사중") {
        injuredElement.classList.add("amber");
    }
    else if (injuredColor !== "없음") {
        injuredElement.classList.add("red");
    }
    injuredElement.textContent = injuredColor;

    // 관련 차량
    var vehicle = document.querySelector(".vehicle-count-large").textContent;
    popup.querySelector(".report-modal-related-car").textContent = vehicle;

    // 모달 클릭 시 최상단으로
    popup.addEventListener("mousedown", function() {
        popup.style.zIndex = ++reportModalZIndex;
    });

    // 새 모달에 드래그 적용
    enableModalDrag(popup.querySelector(".report-modal-content"));
    return popup;
}


// 모달 닫기
function closeReportPopup(element) {
    const popup = element.closest(".report-modal-overlay");
    if (popup) {
        // 원본은 복제용이므로 삭제하지 않음
        if (popup.id === "reportPopup") {
            popup.classList.remove("active");
        } else {
            popup.remove();
        }
    }
}


// 모달 드래그
function enableModalDrag(modal) {
    var header = modal.querySelector(".report-modal-header");
    if (!header) return;
    var isDragging = false;
    var offsetX = 0;
    var offsetY = 0;
    header.style.cursor = "move";
    header.addEventListener("mousedown", function(e) {
        if (e.button !== 0) return;
        if (e.target.closest("button")) return;

        isDragging = true;
        var rect = modal.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;

        modal.style.position = "fixed";
        modal.style.left = rect.left + "px";
        modal.style.top = rect.top + "px";
        modal.style.margin = "0";
        modal.style.transform = "none";

        e.preventDefault();
    });
    document.addEventListener("mousemove", function(e) {
        if (!isDragging) return;
        modal.style.left = (e.clientX - offsetX) + "px";
        modal.style.top = (e.clientY - offsetY) + "px";
    });
    document.addEventListener("mouseup", function() {
        isDragging = false;
    });
  }

var zoomButtons = document.querySelectorAll(".zoom-control button");
zoomButtons[0].addEventListener("click", function() {
	var view = vmap.getView();
	var zoom = view.getZoom();
	view.setZoom(zoom + 1);
});

zoomButtons[1].addEventListener("click", function() {
	var view = vmap.getView();
	var zoom = view.getZoom();
	view.setZoom(zoom - 1);
});

</script>
</body>
</html>