
  // 실시간 시계
  const dayNames = ['일','월','화','수','목','금','토'];
  function pad(n){ return n.toString().padStart(2,'0'); }
  function tick(){
    const now = new Date();
    document.getElementById('cur-date').textContent =
      `${now.getFullYear()}. ${pad(now.getMonth()+1)}. ${pad(now.getDate())} (${dayNames[now.getDay()]})`;
    document.getElementById('cur-time').textContent =
      `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  }
  tick(); setInterval(tick, 1000);

  // ==========================================
  // OpenLayers 지도 초기화 및 사고 마커 추가
  // ==========================================
  if (window.LOCKDOWN_MOCK_MODE) {
  // 목업 여부가 아닌 LOCKDOWN_MAP_PROVIDER 환경값으로 배경지도를 선택한다.
  const mockCenter = [14148697.445280691, 4476589.251449499];
  let map;
  if (window.LOCKDOWN_MAP_PROVIDER === 'himap') {
    map = new himap.Map({
      sysKey: 'TIS',
      target: 'map',
      layers: [new himap.layer.vworld.Base({ visible: true, sysKey: 'TIS' })],
      center: mockCenter,
      zoom: 3
    });
  } else {
    vw.ol3.CameraPosition.center = mockCenter;
    vw.ol3.CameraPosition.zoom = 9;
    vw.ol3.MapOptions = {
      basemapType: vw.ol3.BasemapType.GRAPHIC,
      controlDensity: vw.ol3.DensityType.BASIC,
      interactionDensity: vw.ol3.DensityType.BASIC,
      controlsAutoArrange: true,
      homePosition: vw.ol3.CameraPosition,
      initPosition: vw.ol3.CameraPosition
    };
    map = new vw.ol3.Map('map', vw.ol3.MapOptions);
  }

  // 사고 마커 데이터 정보
  const incidentMarkers = [
    { coords: [127.085, 37.195], title: '영동선 인천방향 사고' }
  ];

  incidentMarkers.forEach(inc => {
    const el = document.createElement('div');
    el.className = 'ol-incident-marker marker-incident';
    el.textContent = '사고';
    el.title = inc.title;

    const overlay = new ol.Overlay({
      position: ol.proj.fromLonLat(inc.coords),
      positioning: 'center-center',
      element: el,
      stopEvent: false
    });
    map.addOverlay(overlay);
  });
  }

  // 다크/라이트 모드 토글 및 아이콘 동적 변경 (주간모드: 해 ☀️ / 야간모드: 달 🌙)
  const root = document.documentElement;
  const toggleBtn = document.getElementById('mode-toggle');
  const modeLabel = document.getElementById('mode-label');
  const modeIcon = document.getElementById('mode-icon');

  let congestionChart = null;

  function initChart(isDark) {
    const ctx = document.getElementById('congestionChart').getContext('2d');
    
    const textColor = isDark ? '#9bb0c7' : '#5a6578';
    const gridColor = isDark ? '#1a2f4a' : '#dbe2ea';

    if (congestionChart) {
      congestionChart.destroy();
    }

    congestionChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['현재', '+1분', '+2분', '+3분', '+4분', '+5분'],
        datasets: [{
          label: '정체길이(km)',
          data: [83.9, 84.5, 87.1, 90.8, 91.2, 94.3],
          borderColor: '#e0303f',
          backgroundColor: '#e0303f',
          borderWidth: 2.5,
          pointRadius: 4,
          pointHoverRadius: 6,
          tension: 0.1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { enabled: true }
        },
        scales: {
          y: {
            min: 82,
            max: 96,
            ticks: { stepSize: 2, color: textColor, font: { size: 11, weight: 'bold' } },
            grid: { color: gridColor }
          },
          x: {
            ticks: { 
              color: function(context) {
                return context.index === 5 ? '#3b82f6' : textColor;
              },
              font: function(context) {
                return { size: 11, weight: context.index === 5 ? 'bold' : 'normal' };
              }
            },
            grid: { display: false }
          }
        }
      }
    });
  }

  function applyMode(isDark){
    if (isDark) {
      root.classList.add('dark');
      modeLabel.textContent = '주간모드';
      toggleBtn.classList.add('active');
      modeIcon.innerHTML = '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
    } else {
      root.classList.remove('dark');
      modeLabel.textContent = '야간모드';
      toggleBtn.classList.remove('active');
      modeIcon.innerHTML = '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
    }
    localStorage.setItem('dashboard-theme', isDark ? 'dark' : 'light');
    initChart(isDark);
  }

  toggleBtn.addEventListener('click', () => applyMode(!root.classList.contains('dark')));
  
  const saved = localStorage.getItem('dashboard-theme');
  if(saved){ applyMode(saved === 'dark'); } else { applyMode(true); }

  // 알림 및 이력 드롭다운 인터랙션
  const bellToggleBtn = document.getElementById('bell-toggle-btn');
  const alarmDropdownPanel = document.getElementById('alarm-dropdown-panel');
  const historyToggleBtn = document.getElementById('history-toggle-btn');
  const historyDropdownPanel = document.getElementById('history-dropdown-panel');
  const historyCloseDropBtn = document.getElementById('history-close-drop-btn');

  function initHistoryDateRange() {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - 7);
    const formatDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const startInput = document.getElementById('history-start-date');
    const endInput = document.getElementById('history-end-date');
    if (startInput && endInput) {
      startInput.value = formatDate(startDate);
      endInput.value = formatDate(endDate);
    }
  }
  initHistoryDateRange();

  bellToggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    alarmDropdownPanel.classList.toggle('active');
    historyDropdownPanel.classList.remove('active');
  });

  historyToggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    historyDropdownPanel.classList.toggle('active');
    alarmDropdownPanel.classList.remove('active');
  });

  historyCloseDropBtn.addEventListener('click', () => {
    historyDropdownPanel.classList.remove('active');
  });

  document.addEventListener('click', (e) => {
    if (!historyDropdownPanel.contains(e.target) && e.target !== historyToggleBtn) {
      historyDropdownPanel.classList.remove('active');
    }
    if (!alarmDropdownPanel.contains(e.target) && e.target !== bellToggleBtn && !bellToggleBtn.contains(e.target)) {
      alarmDropdownPanel.classList.remove('active');
    }
  });

  // 모달 팝업 열기/닫기
  const modalBackdrop = document.getElementById('incident-modal');
  const openModalBtn = document.getElementById('open-modal-btn');
  const closeModalBtn = document.getElementById('close-modal-btn');

  openModalBtn.addEventListener('click', () => modalBackdrop.classList.add('active'));
  closeModalBtn.addEventListener('click', () => modalBackdrop.classList.remove('active'));
  modalBackdrop.addEventListener('click', (e) => { if (e.target === modalBackdrop) modalBackdrop.classList.remove('active'); });

  // 사고 목록 선택 연동
  const mainCard = document.getElementById('main-incident-card');
  const cardBadge = document.getElementById('card-badge');
  const cardTitle = document.getElementById('card-title');
  const cardSub = document.getElementById('card-sub');
  const cardOffice = document.getElementById('card-office');

  document.querySelectorAll('.incident-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.incident-item').forEach(i => i.classList.remove('selected', 'sel-A', 'sel-B', 'sel-C'));
      item.classList.add('selected');
      mainCard.classList.remove('grade-A', 'grade-B', 'grade-C');
      if (cardBadge) {
        cardBadge.style.display = 'none';
      }
      cardTitle.textContent = item.querySelector('.item-road-text').textContent;
      cardSub.textContent = item.querySelector('.item-cause').textContent;
      if (cardOffice) cardOffice.textContent = item.querySelector('.office-chip').textContent;
    });
  });
