(function () {
  "use strict";

  var state = {
    lines: [], incidents: [], analysis: null,
    currentPk: "", analysisLoading: false, analysisPolling: false,
    incidentMarkers: {},
    incidentListRefreshing: false, incidentListPollingStarted: false
  };

  function hasValue(value) {
    return value !== undefined && value !== null && String(value).trim() !== "";
  }

  function pick(source, names) {
	// console.log("pick source : ", source);
    source = source || {};
    var keys = Object.keys(source);
    for (var index = 0; index < names.length; index += 1) {
      var target = String(names[index]).toUpperCase();
      for (var keyIndex = 0; keyIndex < keys.length; keyIndex += 1) {
        if (String(keys[keyIndex]).toUpperCase() === target) return source[keys[keyIndex]];
      }
    }
    return null;
  }

  function setText(element, value) {
    if (element) element.textContent = hasValue(value) ? String(value) : "-";
  }

  function setStageStatus(element, value) {
    if (!element) return;
    element.textContent = "";
    var dot = document.createElement("span");
    dot.className = "dot-mark";
    element.appendChild(dot);
    element.appendChild(document.createTextNode(hasValue(value) ? String(value) : "-"));
  }

  function setStepDetail(element, value, agencyGrid) {
    if (!element) return;
    var useGrid = agencyGrid && hasValue(value) && value !== "-";
    element.classList.toggle("agency-times", useGrid);
    if (!useGrid) {
      element.textContent = !hasValue(value) || value === "-" ? "" : String(value);
      return;
    }
    element.textContent = "";
    String(value).split("\n").forEach(function (line) {
      var item = document.createElement("span");
      item.textContent = line;
      element.appendChild(item);
    });
  }

  function clock(value) {
    var str = String(value || "").trim();
    var match = str.match(/\b(\d{2}:\d{2})(?::\d{2})?\b/);
    if (match) return match[1];
    var compactMatch = str.match(/^\d{8}(\d{2})(\d{2})/);
    if (compactMatch) return compactMatch[1] + ":" + compactMatch[2];
    return "-";
  }

  function minutes(value) {
    return hasValue(value) ? String(value).replace(/분$/, "") + "분" : "-";
  }

  function extractedData(analysis) {
    var data = pick(analysis, ["etlExtractedData"]);
    return data && typeof data === "object" ? data : {};
  }

  function mergedEtlData(analysis) {
    var raw = pick(analysis, ["etlData"]);
    var merged = Object.assign({}, raw && typeof raw === "object" ? raw : {});
    var extracted = extractedData(analysis);
    Object.keys(extracted).forEach(function (key) {
      var val = extracted[key];
      if (hasValue(val)) {
        merged[key] = val;
      } else if (!(key in merged)) {
        merged[key] = val;
      }
    });
    return merged;
  }

  function flag(source, name) {
    var value = pick(source, [name]);
    if (!hasValue(value)) return null;
    return value === true || /^(1|Y|YES)$/i.test(String(value).trim());
  }

  function incidentCompletionTime(source) {
    var completedAt = pick(source, ["RPRQ_CRCM_CMPT_DTTM"]);
    if (hasValue(completedAt)) return completedAt;

    var actions = pick(source, ["ACDT_ACTN_LIST"]);
    if (!Array.isArray(actions)) return null;
    var completionRows = actions.map(function (row) {
      var codes = String(pick(row, ["ACDT_ACTN_CTNT_LLM"]) || "")
        .split(",")
        .map(function (code) { return String(code).trim().toUpperCase(); });
      var actionTime = pick(row, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]);
      return codes.indexOf("F") >= 0 && hasValue(actionTime) ? actionTime : null;
    }).filter(hasValue);

    completionRows.sort(function (left, right) {
      var leftDate = parseApiDate(left);
      var rightDate = parseApiDate(right);
      return (leftDate ? leftDate.getTime() : Number.MAX_SAFE_INTEGER)
        - (rightDate ? rightDate.getTime() : Number.MAX_SAFE_INTEGER);
    });
    return completionRows.length ? completionRows[0] : null;
  }

  function count(source, name) {
    var rawValue = pick(source, [name]);
    if (!hasValue(rawValue)) return null;
    var value = Number(rawValue);
    return Number.isFinite(value) && value >= 0 ? value : null;
  }

  function actionTimeline(etl) {
    var actions = pick(etl, ["ACDT_ACTN_LIST"]);
    var rows = Array.isArray(actions) ? actions.slice() : [];
    var codeTimes = {};
    var orderedCodes = [];
    var blockedLaneNumbers = [];
    var releasedLaneNumbers = [];
    var blockTime = "-";
    var releaseTime = "-";
    rows.sort(function (left, right) {
      var leftTime = parseApiDate(pick(left, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]));
      var rightTime = parseApiDate(pick(right, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]));
      return (leftTime ? leftTime.getTime() : Number.MAX_SAFE_INTEGER)
        - (rightTime ? rightTime.getTime() : Number.MAX_SAFE_INTEGER);
    });
    rows.forEach(function (row) {
      var value = pick(row, ["ACDT_ACTN_CTNT_LLM"]);
      if (!hasValue(value)) return;
      var actionTime = clock(pick(row, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]));
      String(value).split(",").forEach(function (rawCode) {
        var code = String(rawCode || "").trim().toUpperCase();
        if (!code) return;
        var numericCode = Number(code);
        if (/^\d+$/.test(code) && numericCode >= 100 && numericCode % 100 === 0) {
          var releasedLaneNumber = numericCode / 100;
          if (releasedLaneNumbers.indexOf(releasedLaneNumber) < 0) releasedLaneNumbers.push(releasedLaneNumber);
          if (releaseTime === "-" && actionTime !== "-") releaseTime = actionTime;
          return;
        }
        if (/^\d+$/.test(code) && numericCode >= 10 && numericCode < 100 && numericCode % 10 === 0) {
          var blockedLaneNumber = numericCode / 10;
          if (blockedLaneNumbers.indexOf(blockedLaneNumber) < 0) blockedLaneNumbers.push(blockedLaneNumber);
          if (blockTime === "-" && actionTime !== "-") blockTime = actionTime;
          return;
        }
        if (!codeTimes[code] && actionTime !== "-") {
          codeTimes[code] = actionTime;
          orderedCodes.push(code);
        }
      });
    });
    blockedLaneNumbers.sort(function (left, right) { return left - right; });
    releasedLaneNumbers.sort(function (left, right) { return left - right; });

    function agencyDetail(codeMap) {
      return codeMap.map(function (entry) {
        return codeTimes[entry.code] ? entry.label + " " + codeTimes[entry.code] : null;
      }).filter(Boolean).join("\n");
    }

    function firstCodeTime(codes) {
      for (var index = 0; index < orderedCodes.length; index += 1) {
        if (codes.indexOf(orderedCodes[index]) >= 0) return codeTimes[orderedCodes[index]];
      }
      return "-";
    }

    var dispatch = agencyDetail([
      { code: "B", label: "고순대" },
      { code: "C", label: "순찰차" },
      { code: "A", label: "구급차" },
      { code: "D", label: "견인차" }
    ]);
    var arrival = agencyDetail([
      { code: "P", label: "고순대" },
      { code: "Q", label: "순찰차" },
      { code: "O", label: "구급차" },
      { code: "R", label: "견인차" }
    ]);
    var dispatchTime = firstCodeTime(["A", "B", "C", "D"]);
    var arrivalTime = firstCodeTime(["O", "P", "Q", "R"]);
    return {
      hasRows: rows.length > 0,
      vmsTime: codeTimes.V || "-",
      messageTime: codeTimes.M || "-",
      trafficTime: firstCodeTime(["V", "M"]),
      blockedLaneNumbers: blockedLaneNumbers,
      releasedLaneNumbers: releasedLaneNumbers,
      blockTime: blockTime,
      releaseTime: releaseTime,
      dispatchDetail: dispatch,
      arrivalDetail: arrival,
      dispatchTime: dispatchTime,
      arrivalTime: arrivalTime,
      hasDispatch: dispatch !== "",
      hasArrival: arrival !== "",
      hasBlock: blockedLaneNumbers.length > 0,
      hasRelease: releasedLaneNumbers.length > 0
    };
  }

  function buildProcessingStages(etl) {
    var actions = actionTimeline(etl);
    var occurrence = pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]);
    var completion = incidentCompletionTime(etl);
    var trafficReflected = actions.vmsTime !== "-" || actions.messageTime !== "-";
    var actionLaneNumbers = actions.blockedLaneNumbers.length
      ? actions.blockedLaneNumbers : actions.releasedLaneNumbers;
    var hasLaneBlock = actions.hasBlock || actions.hasRelease;
    var completed = hasValue(completion);
    var directlyConfirmed = hasLaneBlock
      ? [hasValue(occurrence), trafficReflected, true, actions.hasDispatch,
        actions.hasArrival, actions.hasRelease, completed]
      : [hasValue(occurrence), trafficReflected, false, actions.hasDispatch,
        actions.hasArrival, completed];
    var stageCount = hasLaneBlock ? 7 : 6;
    var highestConfirmed = 0;
    directlyConfirmed.forEach(function (confirmed, index) {
      if (confirmed) highestConfirmed = index + 1;
    });
    highestConfirmed = completed ? stageCount : highestConfirmed;
    var currentStage = completed ? 0 : Math.min(stageCount, Math.max(1, highestConfirmed + 1));

    var blockedDetail = actionLaneNumbers.length ? actionLaneNumbers.join(",") + "차로 차단" : "";
    var releasedDetail = actions.releasedLaneNumbers.length
      ? actions.releasedLaneNumbers.join(",") + "차로 해제" : "";
    var occurrenceTime = clock(occurrence);
    var completionTime = clock(completion);
    var trafficLines = [];
    if (actions.vmsTime !== "-") trafficLines.push("VMS " + actions.vmsTime);
    if (actions.messageTime !== "-") trafficLines.push("문자 " + actions.messageTime);
    var trafficDetail = trafficLines.join("\n");
    var completionDetail = completionTime === "-" ? "" : "처리완료\n" + completionTime;
    var blockDetailText = blockedDetail
      + (blockedDetail && actions.blockTime !== "-" ? "\n" + actions.blockTime : "");
    var releaseDetail = releasedDetail
      + (releasedDetail && actions.releaseTime !== "-" ? "\n" + actions.releaseTime : "");
    var titles = hasLaneBlock
      ? ["발생", "교통정보표출", "차로차단", "현장출동요청", "현장도착", "차단해제", "처리완료"]
      : ["발생", "교통정보표출", "차로차단", "현장출동요청", "현장도착", "처리완료"];
    var occurrenceDetail = occurrenceTime === "-" ? "-" : "발생 " + occurrenceTime;
    var details = hasLaneBlock
      ? [occurrenceDetail, trafficDetail, blockDetailText || "해당없음", actions.dispatchDetail, actions.arrivalDetail,
        releaseDetail, completionDetail]
      : [occurrenceDetail, trafficDetail, "해당없음", actions.dispatchDetail, actions.arrivalDetail, completionDetail];
    var times = hasLaneBlock
      ? [occurrenceTime, actions.trafficTime, actions.blockTime,
        actions.dispatchTime, actions.arrivalTime, actions.releaseTime, completionTime]
      : [occurrenceTime, actions.trafficTime, "-",
        actions.dispatchTime, actions.arrivalTime, completionTime];
    var stages = details.map(function (detail, index) {
      var number = index + 1;
      var stateName = number <= highestConfirmed ? "done" : (number === currentStage ? "current" : "wait");
      var visibleDetail = stateName === "done" ? detail : "-";
      var visibleTime = stateName === "done" ? times[index] : "-";
      return {
        number: number,
        title: titles[index],
        state: stateName,
        detail: visibleDetail,
        time: visibleTime,
        status: stateName === "done" ? (number === 1 && visibleTime !== "-" ? visibleTime
          : (visibleTime !== "-" ? visibleTime + " 완료" : "완료"))
          : (stateName === "current" ? "진행 중" : "-")
      };
    });
    return {
      stages: stages,
      highestConfirmed: highestConfirmed,
      currentStage: currentStage,
      hasLaneBlock: hasLaneBlock
    };
  }

  function parseApiDate(value) {
    var str = String(value || "").trim();
    var match = str.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
    if (match) {
      return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), Number(match[4]), Number(match[5]), Number(match[6]));
    }
    var compactMatch = str.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/);
    if (compactMatch) {
      return new Date(Number(compactMatch[1]), Number(compactMatch[2]) - 1, Number(compactMatch[3]), Number(compactMatch[4]), Number(compactMatch[5]), Number(compactMatch[6]));
    }
    return null;
  }

  function actualMinutes(etl) {
    var provided = count(etl, "PROC_MIN");
    var occurredAt = parseApiDate(pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]));
    if (!occurredAt) return provided;
    var completedAt = parseApiDate(incidentCompletionTime(etl));
    var endTime = completedAt ? completedAt.getTime() : Date.now();
    return Math.max(0, Math.floor((endTime - occurredAt.getTime()) / 60000));
  }

  function incidentSubtitle(etl) {
    var cause = pick(etl, ["ACDT_CAUS_CTNT"]);
    var vehicles = pick(etl, ["ACDT_OCRN_VHCL_CTNT"]);
    if (hasValue(cause)) cause = String(cause).trim();
    if (hasValue(vehicles)) vehicles = String(vehicles).trim();
    if (hasValue(cause) && hasValue(vehicles)) return cause + " (" + vehicles + ")";
    return cause || vehicles || "-";
  }

  function shortIcName(value) {
    return String(value || "").replace(/\s*\((?:입구|출구)\)\s*/g, "").trim();
  }

  function modalBlockText(etl, result) {
    var location = String(pick(etl, ["ACDT_LOCT_CTNT"]) || "");
    var numberedLanes = location.match(/\d+\s*차로/g) || [];
    var lanes = [];
    numberedLanes.forEach(function (lane) {
      var normalized = lane.replace(/\s+/g, "");
      if (lanes.indexOf(normalized) < 0) lanes.push(normalized);
    });
    if (!lanes.length && /갓길/.test(location)) lanes.push("갓길");

    var fullBlock = flag(etl, "FRNT_BLCK_YN");
    var blockType = fullBlock === true ? "전면차단"
      : (pick(result, ["BLOCK_TYPE", "blockType", "MAR13"]) || (fullBlock === false ? "전면차단 아님" : null));
    var laneText = lanes.join("·");
    return laneText && hasValue(blockType) ? laneText + "(" + blockType + ")" : (laneText || blockType || "-");
  }

  function modalLocation(mapData, result, etl) {
    var distance = pick(etl, ["STPNT_DSTNC"]);
    if (!hasValue(distance)) distance = pick(result, ["MAR12", "ACDT_OCRN_DSTNC"]);
    var distanceText = hasValue(distance) ? String(distance).trim() : "-";
    if (distanceText !== "-" && !/km$/i.test(distanceText)) distanceText += "km";

    var inNames = (Array.isArray(mapData && mapData.inTgInfo) ? mapData.inTgInfo : []).map(function (item) {
      return shortIcName(pick(item, ["IC_NAME"]));
    }).filter(hasValue);
    var outNames = (Array.isArray(mapData && mapData.outTgInfo) ? mapData.outTgInfo : []).map(function (item) {
      return shortIcName(pick(item, ["IC_NAME"]));
    }).filter(hasValue);
    if (!inNames.length && !outNames.length) return distanceText;
    return distanceText + "(" + (inNames.length ? inNames.join("·") : "-")
      + "~" + (outNames.length ? outNames.join("·") : "-") + ")";
  }

  var processingProgressTimer = null;
  function setProcessingProgress(etl, predicted) {
    var occurredAt = pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]);
    var completedAt = incidentCompletionTime(etl);
    var elapsed = actualMinutes(etl);
    var predictedMinutes = Number(predicted);
    var completed = hasValue(completedAt);
    var progress = completed ? 100 : (elapsed !== null && Number.isFinite(predictedMinutes) && predictedMinutes > 0
      ? Math.min(100, Math.round(elapsed / predictedMinutes * 100)) : 0);

	// 20261027[추가] ykchoi: 사고목록 예측시간 실시간으로 반영
	// 기존 타이머 제거 (중복 실행 방지)
	if (processingProgressTimer !== null) {
	    clearInterval(processingProgressTimer);
	    processingProgressTimer = null;
	}

	// 1초마다 elapsed 다시 계산
	if (!completedAt) {
	  processingProgressTimer = setInterval(function() {
	  elapsed = actualMinutes(etl);

	  var elapsedElement = document.querySelector("#processing-elapsed");
	    if (elapsedElement) {
	      elapsedElement.textContent =
	      elapsed === null ? "-" : elapsed + "분";
	    }
	  }, 1000);
	}

    var progressCard = document.querySelector(".progress-card");
    if (progressCard) {
      setText(progressCard.querySelector(".progress-label"), "경과시간");
      setText(progressCard.querySelector(".progress-time"), elapsed === null ? "-" : elapsed + "분");
      var fill = progressCard.querySelector(".progress-fill");
      if (fill) fill.style.width = progress + "%";
    }

    var aiRows = document.querySelectorAll("#incident-modal .ai-stat-row");
    if (aiRows[0]) {
      setText(aiRows[0].querySelector("span"), "경과시간");
      setText(aiRows[0].querySelector("b"), elapsed === null ? "-" : elapsed + "분");
    }
    if (aiRows[1]) {
      var progressLabels = aiRows[1].querySelectorAll("span");
      if (progressLabels[1]) progressLabels[1].textContent = progress + "%";
    }
    var aiBar = document.querySelector("#incident-modal .ai-progress-bar");
    if (aiBar) aiBar.style.width = progress + "%";
    return { occurrence: occurredAt, completion: completedAt, minutes: elapsed, completed: completed };
  }

  function lineInfo(routeCode) {
    for (var index = 0; index < state.lines.length; index += 1) {
      if (String(pick(state.lines[index], ["LINE_CODE"])) === String(routeCode || "")) return state.lines[index];
    }
    return null;
  }

  function routeInfo(result) {
    var routeCode = String(pick(result, ["ROUTE_CD"]) || "");
    var zone = String(pick(result, ["CNZN_ID"]) || "");
    var directionMatch = zone.match(/CZ([ES])/i);
    var directionCode = String(pick(result, ["ROUTE_DRCT_CD"]) || (directionMatch ? directionMatch[1] : "")).toUpperCase();
    var line = lineInfo(routeCode);
    var lineName = line ? pick(line, ["LINE_NAME"]) : "";
    var directionName = line && directionCode ? pick(line, ["DIR_NAME_" + directionCode]) : "";
    var displayLineName = String(lineName || (routeCode ? "노선 " + routeCode : ""))
      .replace(/\s*\([^)]*\)\s*$/, "").trim();
    var displayDirection = directionName ? String(directionName).replace(/방향$/, "") + "방향" : "";
    return {
      code: routeCode,
      shield: routeCode ? routeCode.slice(0, 2) : "-",
      lineName: displayLineName || "-",
      directionName: displayDirection,
      name: [displayLineName, displayDirection].filter(Boolean).join(" ") || "-"
    };
  }

  //20261020[수정] minart
  function cardDistance(result, etl) {
	var acdtLoctCtnt =  pick(etl, ["ACDT_LOCT_CTNT"]);
	// console.log("acdtLoctCtnt : " + acdtLoctCtnt);
	var dstncKm = extractDistance(acdtLoctCtnt);
	// console.log("dstncKm : " + dstncKm);

    var distance = pick(etl, ["STPNT_DSTNC"]);
	// console.log("distance : " + distance);

	if(dstncKm == 0 ){
		if(distance == null || distance == "" || distance == 0 ){
			dstncKm=distance;
		}else{
			dstncKm=0;
		}
	}

	return dstncKm + "km";
	/*
    if (!hasValue(distance)) distance = pick(result, ["MAR12", "ACDT_OCRN_DSTNC"]);
    if (!hasValue(distance)) return "";
    var match = String(distance).replace(/,/g, "").match(/-?\d+(?:\.\d+)?/);
    if (!match) return "";
    var numericDistance = Number(match[0]);

	if(dstncKm !=0 && dstncKm != numericDistance){
		numericDistance = dstncKm;
	}
	*/
	//return Number.isFinite(numericDistance) ? numericDistance.toFixed(1) + "km" : "";
	//return Number.isFinite(numericDistance) ? numericDistance + "km" : "";

  }

  //20261020[추가] minart // 20261026[수정] ykchoi
  function extractDistance(titleStr) {
      const m = String(titleStr).match(/((\d+(?:\.\d+)?)\s*(?:km|㎞)?)/i);
      const withUnit = m ? m[2] + "km" : null;
      const numberOnly = m?.[2];
      if (!m || m[2] === undefined) {
          return 0;
      } else {
          return numberOnly;
      }
  }

  function routeDisplayTitle(route, distance) {
    return [route.lineName, distance, route.directionName ? "(" + route.directionName + ")" : ""]
      .filter(function (value) { return hasValue(value) && value !== "-"; }).join(" ") || "-";
  }

  function incidentListRouteTitle(route, distance) {
    return routeDisplayTitle(route, distance);
  }

  function incidentListDetail(detail) {
    return hasValue(detail) && detail !== "-" ? String(detail) : "-";
  }

  function setRouteTitle(route, distance) {
    var element = document.getElementById("card-title");
    if (!element) return;
    element.textContent = routeDisplayTitle(route, distance);
  }

  function setCardOffice(value) {
	value = value+"지사";
    var element = document.getElementById("card-office");
    if (!element) return;
    element.textContent = hasValue(value) ? String(value) : "";
    element.hidden = !hasValue(value);
  }

  function setStatus(message, status) {
    var element = document.getElementById("analysisApiStatus");
    if (!element) return;
    element.textContent = message || "";
    element.setAttribute("data-state", status || "idle");
  }

  function installAnalysisRefreshStatus() {
    if (document.getElementById("analysisApiStatus")) return;
    var target = document.querySelector(".progress-card .progress-ai");
    if (!target) return;
    var status = document.createElement("div");
    status.id = "analysisApiStatus";
    status.className = "analysis-refresh-status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    status.setAttribute("data-state", "idle");
    target.appendChild(status);
  }

  function installAnalysisBlocker() {
    if (document.getElementById("analysisPageBlocker")) return;
    var blocker = document.createElement("div");
    blocker.id = "analysisPageBlocker";
    blocker.className = "analysis-page-blocker";
    blocker.hidden = true;
    blocker.setAttribute("aria-live", "polite");
    blocker.setAttribute("aria-busy", "true");
    blocker.innerHTML = '<div class="analysis-loading-card" role="status">'
      + '<div class="analysis-loading-spinner" aria-hidden="true"></div>'
      + '<strong id="analysisLoadingTitle">사고 분석 중</strong>'
      + '<span id="analysisLoadingMessage">분석 결과를 불러오고 있습니다.</span>'
      + '</div>';
    document.body.appendChild(blocker);
  }

  function setAnalysisLoading(active, message, title) {
    var blocker = document.getElementById("analysisPageBlocker");
    if (!blocker) return;
    state.analysisLoading = Boolean(active);
    blocker.hidden = !active;
    blocker.setAttribute("aria-hidden", active ? "false" : "true");
    document.body.classList.toggle("analysis-loading", Boolean(active));
    var titleElement = document.getElementById("analysisLoadingTitle");
    if (titleElement && title) titleElement.textContent = title;
    var messageElement = document.getElementById("analysisLoadingMessage");
    if (messageElement && message) messageElement.textContent = message;
    var runButton = document.getElementById("analysisRunButton");
    if (runButton) runButton.disabled = Boolean(active);
  }

  function failAnalysis(message) {
    var detail = message || "분석 결과를 불러오지 못했습니다.";
    setAnalysisLoading(false);
    setStatus(detail, "error");
    window.alert("분석에 실패했습니다.\n" + detail);
  }

  function renderDetourRoute(mapData, detourName) {
    var routeElement = document.querySelector(".detour-panel .detour-route");
    if (!routeElement) return;

    var icon = routeElement.querySelector("img");
    var iconContainer = icon ? icon.parentNode : null;
    Array.prototype.slice.call(routeElement.children).forEach(function (child) {
      if (child !== iconContainer) routeElement.removeChild(child);
    });

    var inNames = (Array.isArray(mapData && mapData.inTgInfo) ? mapData.inTgInfo : []).map(function (item) {
      return shortIcName(pick(item, ["IC_NAME"]));
    }).filter(hasValue);
    var outNames = (Array.isArray(mapData && mapData.outTgInfo) ? mapData.outTgInfo : []).map(function (item) {
      return shortIcName(pick(item, ["IC_NAME"]));
    }).filter(hasValue);
    var entryLabel = inNames.length ? inNames.join("·") : "-";
    var exitLabel = "-";
    if (outNames.length === 1) exitLabel = outNames[0];
    else if (outNames.length > 1) exitLabel = outNames[0] + " " + outNames.slice(1).join("·");
    var nodes = [entryLabel, hasValue(detourName) ? detourName : "-", exitLabel];

    nodes.forEach(function (name, index) {
      if (index > 0) {
        var arrow = document.createElement("span");
        arrow.className = "route-arrow";
        arrow.textContent = "→";
        routeElement.appendChild(arrow);
      }
      var node = document.createElement("span");
      node.className = "route-node";
      node.textContent = name;
      routeElement.appendChild(node);
    });
  }

  function clearChart() {
    var canvas = document.getElementById("congestionChart");
    if (!canvas) return;
    var oldChart = typeof Chart !== "undefined" && typeof Chart.getChart === "function" ? Chart.getChart(canvas) : null;
    if (oldChart) oldChart.destroy();
    var context = canvas.getContext("2d");
    if (context) context.clearRect(0, 0, canvas.width, canvas.height);
  }

  function resetLiveDashboard() {
    // 라이브 화면은 분석이 끝나기 전까지 퍼블리싱 샘플 값을 분석 결과처럼 노출하지 않는다.
    setText(document.getElementById("card-title"), "-");
    setText(document.getElementById("card-sub"), "-");
    setCardOffice("");
    var card = document.getElementById("main-incident-card");
    // 값이 없어도 퍼블리싱 카드의 테두리·배경 구조는 유지한다.
    if (card) card.className = "incident-card grade-empty";
    var grade = document.getElementById("card-badge");
    if (grade) { grade.style.display = "none"; }
    document.querySelectorAll(".incident-card .tag, .incident-card .time-group span").forEach(function (element) {
      element.textContent = "-";
    });

    setText(document.querySelector(".progress-card .progress-time"), "-");
    setText(document.querySelector(".progress-card .progress-ai .val"), "-");
    var progressFill = document.querySelector(".progress-card .progress-fill");
    if (progressFill) progressFill.style.width = "0%";

    document.querySelectorAll(".seven-steps-layout > .step-cell[data-stage]").forEach(function (step) {
      step.classList.remove("is-done", "is-current");
      step.classList.add("is-wait");
      var status = step.querySelector(".step-status");
      if (status) status.className = "step-status status-wait";
      setStageStatus(status, "-");
      setStepDetail(step.querySelector(".step-bottom-time"), "-", false);
    });
    document.querySelectorAll(".seven-steps-layout [data-link-to]").forEach(function (link) {
      link.classList.remove("link-done", "link-current");
      link.classList.add("link-wait");
    });

    document.querySelectorAll(".chart-panel .head-tag, .chart-panel .chart-meta b").forEach(function (element) {
      element.textContent = "-";
    });
    var emptyChartGrade = document.querySelector(".chart-panel .head-tag.grade");
    if (emptyChartGrade) emptyChartGrade.style.display = "none";
    setText(document.querySelector(".chart-panel .trend-text"), "-");
    clearChart();

    document.querySelectorAll(".detour-panel .head-tag.route").forEach(function (element) { element.textContent = "-"; });
    renderDetourRoute({}, null);
    ["detour-diff-text", "main-time-text", "arrow-diff-val", "detour-time-text"].forEach(function (id) {
      setText(document.getElementById(id), "-");
    });
    setText(document.querySelector(".detour-panel .donut-block:last-child .donut-center span"), "-");

    setText(document.querySelector("#incident-modal .modal-id"), "-");
    document.querySelectorAll("#incident-modal .modal-badges > span").forEach(function (badgeElement) {
      badgeElement.hidden = true;
    });
    setText(document.querySelector("#incident-modal .modal-subbar"), "-");
    document.querySelectorAll("#incident-modal .info-table .info-val").forEach(function (element) { element.textContent = "-"; });
    document.querySelectorAll("#incident-modal .timeline-item").forEach(function (item, index) {
      setText(item.children[1], "-");
      var timelineTime = item.querySelector(".timeline-time-badge");
      if (timelineTime) timelineTime.classList.remove("curr");
      setText(timelineTime, "-");
      var timelineDot = item.querySelector(".timeline-dot");
      if (timelineDot) {
        timelineDot.className = "timeline-dot dot-wait";
        timelineDot.textContent = String(index + 1);
      }
    });
    var aiPrediction = document.querySelector("#incident-modal .ai-pred-flex");
    if (aiPrediction) {
      aiPrediction.querySelectorAll("b, .ai-stat-row span, .ai-donut-center span").forEach(function (element) {
        element.textContent = "-";
      });
      var aiBar = aiPrediction.querySelector(".ai-progress-bar");
      if (aiBar) aiBar.style.width = "0%";
    }
  }

  function clearPublishingSampleList() {
    var list = document.querySelector(".sidebar-panel .incident-list");
    if (!list) return;
    // 라이브 화면에는 퍼블리싱 확인용 PKID를 기본 사고 목록으로 사용하지 않는다.
    // 원본 더미 목록은 ?mock=1에서만 publishing-original.js와 함께 유지된다.
    list.textContent = "";
    var processingTab = document.querySelector('.sidebar-panel .tabs .tab[data-status-filter="processing"]');
    var completedTab = document.querySelector('.sidebar-panel .tabs .tab[data-status-filter="completed"]');
    if (processingTab) processingTab.textContent = "처리중(-)";
    if (completedTab) completedTab.textContent = "완료(-)";
  }

  function isIncidentCompleted(source) {
    return hasValue(incidentCompletionTime(source));
  }

  function analysisCompletedIncidents(items) {
    return (Array.isArray(items) ? items : []).filter(function (incident) {
      return flag(incident, "ANAL_COMP") === true;
    });
  }

  function updateIncidentTabCounts() {
    var items = Array.prototype.slice.call(document.querySelectorAll(".incident-list .incident-item"));
    var completedCount = items.filter(function (item) { return item.dataset.status === "completed"; }).length;
    var processingCount = items.filter(function (item) { return item.dataset.status === "processing"; }).length;
    var processingTab = document.querySelector('.sidebar-panel .tabs .tab[data-status-filter="processing"]');
    var completedTab = document.querySelector('.sidebar-panel .tabs .tab[data-status-filter="completed"]');
    if (processingTab) processingTab.textContent = "처리중(" + processingCount + ")";
    if (completedTab) completedTab.textContent = "완료(" + completedCount + ")";
  }

  function applyIncidentFilters() {
    var activeTab = document.querySelector(".sidebar-panel .tabs .tab.active");
    var statusFilter = activeTab ? activeTab.dataset.statusFilter : "processing";
    document.querySelectorAll(".incident-list .incident-item").forEach(function (item) {
      item.style.display = statusFilter === "all" || item.dataset.status === statusFilter ? "flex" : "none";
    });
  }

  function activateIncidentStatus(status) {
    var target = document.querySelector('.sidebar-panel .tabs .tab[data-status-filter="' + status + '"]');
    if (!target) return;
    document.querySelectorAll(".sidebar-panel .tabs .tab").forEach(function (tab) {
      tab.classList.toggle("active", tab === target);
    });
    applyIncidentFilters();
  }

  function bindIncidentFilters() {
    document.querySelectorAll(".sidebar-panel .tabs .tab").forEach(function (tab) {
      tab.addEventListener("click", function () {
        document.querySelectorAll(".sidebar-panel .tabs .tab").forEach(function (other) { other.classList.remove("active"); });
        tab.classList.add("active");
        applyIncidentFilters();
      });
    });
  }

  function incidentMapCoordinate(mapData) {
    var result = mapData && mapData.analResult ? mapData.analResult : {};
    // searchAnalMap은 LAT에 경도, LNG에 위도를 내려준다.
    var longitude = Number(pick(result, ["LAT"]));
    var latitude = Number(pick(result, ["LNG"]));
    if (!Number.isFinite(longitude) || !Number.isFinite(latitude)) return null;
    if (Math.abs(longitude) > 180 || Math.abs(latitude) > 90) return null;
    return [longitude, latitude];
  }

  function updateIncidentMarkerElement(element, pk) {
    if (!element) return;
    element.className = "ol-incident-marker marker-incident";
    element.title = "사고 ##" + pk;
    element.setAttribute("aria-label", element.title);
    var label = element.querySelector("span");
    if (label) label.textContent = "사고";
  }

  function addIncidentMarker(pk, coordinate) {
    if (!window.vmap || !window.ol || !coordinate) return false;
    var existing = state.incidentMarkers[pk];
    if (existing) {
      updateIncidentMarkerElement(existing.element, pk);
      existing.overlay.setPosition(ol.proj.fromLonLat(coordinate));
      return true;
    }

    var element = document.createElement("button");
    element.type = "button";
    element.innerHTML = "<span></span>";
    updateIncidentMarkerElement(element, pk);
    element.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      var item = document.querySelector('.incident-list .incident-item[data-pk="' + String(pk).replace(/"/g, "") + '"]');
      if (item) item.click();
      else runAnalysis(pk);
    });

    var marker = new ol.Overlay({
      element: element,
      position: ol.proj.fromLonLat(coordinate),
      positioning: "center-center",
      stopEvent: true
    });
    vmap.addOverlay(marker);
    state.incidentMarkers[pk] = { overlay: marker, element: element };
    return true;
  }

  function createIncidentItem(item, pk) {
    var route = routeInfo(item);
    var distance = cardDistance(item, item);
    var elapsed = actualMinutes(item);
    var incidentItem = document.createElement("div");
    incidentItem.className = "incident-item";
    incidentItem.dataset.pk = pk;
    incidentItem.dataset.status = isIncidentCompleted(item) ? "completed" : "processing";

    var office = document.createElement("div");
    office.className = "office-chip";
    office.textContent = pick(item, ["BRANCH_NAME"])+"지사" || "-";

    var main = document.createElement("div");
    main.className = "item-main";
    var road = document.createElement("div");
    road.className = "item-road";
    var roadText = document.createElement("span");
    roadText.className = "item-road-text";
    roadText.textContent = incidentListRouteTitle(route, distance);
    var cause = document.createElement("div");
    cause.className = "item-cause";
    cause.textContent = incidentListDetail(incidentSubtitle(item));
    road.appendChild(office);
    road.appendChild(roadText);
    main.appendChild(road);
    main.appendChild(cause);

    var time = document.createElement("div");
    time.className = "item-time";
    var elapsedElement = document.createElement("div");
    elapsedElement.className = "elapsed";
    elapsedElement.textContent = elapsed === null ? "-" : elapsed + "분";
    var eta = document.createElement("div");
    eta.className = "eta";
    var prediction = pick(item, ["FRCS_BLC_HOUR"]);
    eta.textContent = hasValue(prediction) ? "/" + minutes(prediction) : "/-";
    time.appendChild(elapsedElement);
    time.appendChild(eta);

    incidentItem.appendChild(main);
    incidentItem.appendChild(time);
    incidentItem.addEventListener("click", function () {
      document.querySelectorAll(".incident-list .incident-item").forEach(function (other) {
        other.classList.remove("selected", "sel-A", "sel-B", "sel-C");
      });
      incidentItem.classList.add("selected");
      runAnalysis(pk);
    });
    return incidentItem;
  }

  function renderIncidentList(items) {
    var list = document.querySelector(".sidebar-panel .incident-list");
    if (!list) return;
    list.textContent = "";
    state.incidents = Array.isArray(items) ? items : [];

    state.incidents.forEach(function (item) {
      var pk = String(pick(item, ["RPRQ_CRCM_SEQ", "PK", "PKID"]) || "");
      if (!pk) return;
      var incidentItem = createIncidentItem(item, pk);
      list.appendChild(incidentItem);
    });

    updateIncidentTabCounts();
    applyIncidentFilters();
  }

  function patchIncidentList(incidents) {
    var list = document.querySelector(".sidebar-panel .incident-list");
    if (!list) return;
    state.incidents = Array.isArray(incidents) ? incidents : [];
    var newPks = {};

    state.incidents.forEach(function (incident) {
      var pk = String(pick(incident, ["RPRQ_CRCM_SEQ", "PK", "PKID"]) || "");
      if (!pk) return;
      newPks[pk] = true;

      var route = routeInfo(incident);
      var distance = cardDistance(incident, incident);
      var elapsed = actualMinutes(incident);
      var existing = list.querySelector('.incident-item[data-pk="' + pk.replace(/"/g, "") + '"]');

      if (existing) {
        existing.dataset.status = isIncidentCompleted(incident) ? "completed" : "processing";

        setText(existing.querySelector(".item-road-text"), incidentListRouteTitle(route, distance));
        var cause = incidentSubtitle(incident);
        if (cause !== "-") {
          setText(existing.querySelector(".item-cause"), incidentListDetail(cause));
        }
        setText(existing.querySelector(".office-chip"), pick(incident, ["BRANCH_NAME"])+"지사" || "-");

        var elapsedElement = existing.querySelector(".elapsed");
        if (elapsedElement) {
          elapsedElement.textContent = elapsed === null ? "-" : elapsed + "분";
        }
        if (state.currentPk === pk) {
          existing.classList.add("selected");
        }

        var prediction = pick(incident, ["FRCS_BLC_HOUR"]);
        setText(existing.querySelector(".eta"), hasValue(prediction) ? "/" + minutes(prediction) : "/-");
      } else {
        var newItem = createIncidentItem(incident, pk);
        list.appendChild(newItem);
      }
    });

    Array.prototype.slice.call(list.querySelectorAll(".incident-item")).forEach(function (item) {
      var itemPk = String(item.dataset.pk || "");
      if (itemPk && !newPks[itemPk]) {
        item.remove();
      }
    });

    updateIncidentTabCounts();
    applyIncidentFilters();
  }

  function refreshIncidentList() {
    if (state.incidentListRefreshing) return;
    state.incidentListRefreshing = true;

    window.LockdownApi.post("getEtlDataList", {}).then(function (items) {
      var incidents = analysisCompletedIncidents(items);
      patchIncidentList(incidents);
    }).catch(function (error) {
      console.warn("사고 목록 자동 갱신 실패", error);
    }).then(function () {
      state.incidentListRefreshing = false;
    });
  }

  function startIncidentListPolling() {
    if (state.incidentListPollingStarted) return;
    state.incidentListPollingStarted = true;
    window.setInterval(refreshIncidentList, 60 * 1000);
  }

  function bindAsIsMapOverlayControls() {
    var vms = document.querySelector('#asisMapOverlays input[name="vms"]');
    var office = document.querySelector('#asisMapOverlays input[name="ic"]');
    if (vms) vms.addEventListener("click", function () { window.vmsClickHandler(this.checked); });
    if (office) office.addEventListener("click", function () { window.icClickHandler(this.checked); });
  }

  function renderAnalysedIncidentList(pk) {
	// 사고 목록 요소의 pk로 api를 조회하여 지정 우회도로의 Link_id를 받아야함
    document.querySelectorAll(".incident-list .incident-item").forEach(function (item) {
      item.classList.toggle("selected", String(item.dataset.pk) === String(pk));
    });
  }

  function setMainSteps(etl) {
    var flow = buildProcessingStages(etl);
    var layout = document.querySelector(".seven-steps-layout");
    if (layout) layout.classList.toggle("without-lane-release", !flow.hasLaneBlock);
    var steps = document.querySelectorAll(".seven-steps-layout > .step-cell[data-stage]");
    steps.forEach(function (step) {
      var domStageNumber = Number(step.getAttribute("data-stage"));
      var hideReleaseStage = !flow.hasLaneBlock && domStageNumber === 6;
      step.hidden = hideReleaseStage;
      if (hideReleaseStage) return;
      var flowIndex = !flow.hasLaneBlock && domStageNumber === 7 ? 5 : domStageNumber - 1;
      var value = flow.stages[flowIndex];
      if (!value) return;
      setText(step.querySelector(".step-title"), value.number + ". " + value.title);
      step.classList.remove("is-done", "is-current", "is-wait");
      step.classList.add("is-" + value.state);
      var status = step.querySelector(".step-status");
      if (status) {
        status.className = "step-status " + (value.state === "done" ? "status-done"
          : (value.state === "current" ? "status-progress" : "status-wait"));
      }
      setStageStatus(status, value.status);
      setStepDetail(step.querySelector(".step-bottom-time"), value.detail, value.number === 4 || value.number === 5);
    });
    document.querySelectorAll(".seven-steps-layout [data-link-to]").forEach(function (link) {
      var target = Number(link.getAttribute("data-link-to"));
      var hideReleaseLink = !flow.hasLaneBlock && target === 7;
      link.hidden = hideReleaseLink;
      if (hideReleaseLink) return;
      var linkState = target <= flow.highestConfirmed ? "done" : (target === flow.currentStage ? "current" : "wait");
      link.classList.remove("link-done", "link-current", "link-wait");
      link.classList.add("link-" + linkState);
    });
  }

  function incidentHash(pk) {
    var hash = 2166136261;
    String(pk || "").split("").forEach(function (character) {
      hash ^= character.charCodeAt(0);
      hash = Math.imul(hash, 16777619);
    });
    return hash >>> 0;
  }

  function seededRandom(seed) {
    var value = seed || 1;
    return function () {
      value ^= value << 13;
      value ^= value >>> 17;
      value ^= value << 5;
      return (value >>> 0) / 4294967296;
    };
  }

  function renderChart(maxCongestion, pk, completed) {
    var current = Number(maxCongestion);
    if (!Number.isFinite(current) || current <= 0 || typeof Chart === "undefined") return null;

    // 분석 API가 분 단위 예측값을 제공하지 않아 PKID 해시 기반의 재현 가능한 시연 추세를 만든다.
    var seed = incidentHash(pk);
    var random = seededRandom(seed);
    var direction = seed % 2 === 0 ? 1 : -1;
    var totalRate = completed ? 0.02 + random() * 0.04 : 0.12 + random() * 0.16;
    var volatility = completed ? 0.006 + random() * 0.01 : 0.025 + random() * 0.035;
    var curve = 0.75 + random() * 0.7;
    var values = [Math.round(current * 10) / 10];
    for (var index = 1; index < 6; index += 1) {
      var progress = index / 5;
      var drift = direction * current * totalRate * Math.pow(progress, curve);
      var wobble = current * volatility * (random() * 2 - 1) * Math.sin(Math.PI * progress);
      values.push(Math.round(Math.max(0, current + drift + wobble) * 10) / 10);
    }
    var expected = values[values.length - 1];
    var congestionLength = Math.round((Math.max(values[0], expected) - Math.min(values[0], expected)) * 10) / 10;
    var metaValues = document.querySelectorAll(".chart-panel .chart-meta b");
    setText(metaValues[0], values[0] + "km");
    setText(metaValues[1], expected + "km");
    var trendElement = document.querySelector(".chart-panel .trend-text");
    setText(trendElement, direction > 0 ? "↗ 증가중" : "↘ 감소중");
    if (trendElement) trendElement.style.color = direction > 0 ? "var(--accent-red)" : "var(--accent-blue)";
    var chartColor = getComputedStyle(document.documentElement)
      .getPropertyValue(direction > 0 ? "--accent-red" : "--accent-blue").trim() || (direction > 0 ? "#e0303f" : "#2f6fed");
    var canvas = document.getElementById("congestionChart");
    var oldChart = typeof Chart.getChart === "function" ? Chart.getChart(canvas) : null;
    if (oldChart) oldChart.destroy();
    new Chart(canvas.getContext("2d"), {
      type: "line",
      data: {
        labels: ["현재", "+1분", "+2분", "+3분", "+4분", "+5분"],
        datasets: [{ data: values, borderColor: chartColor, backgroundColor: chartColor, borderWidth: 2.5, pointRadius: 4, tension: 0.35 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
    });
    return { start: values[0], end: expected, length: congestionLength };
  }

  function setPredictionSummary(predicted) {
    var element = document.querySelector(".progress-card .progress-ai .val");
    var current = Number(predicted);
    if (!element || !Number.isFinite(current) || current <= 0) {
      setText(element, "-");
      return;
    }
    var rounded = Math.round(current);
    var hours = Math.floor(rounded / 60);
    var remainingMinutes = rounded % 60;
    element.textContent = "";
    var currentValue = document.createElement("b");
    currentValue.textContent = hours + "시간 " + (remainingMinutes < 10 ? "0" : "") + remainingMinutes + "분";
    element.appendChild(currentValue);
  }

  function setModal(mapData, route, pk, etl) {
    var result = mapData.analResult || {};
    var occurrence = pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]) || pick(result, ["MAR11"]);
    var processed = count(etl, "PROC_MIN");
    var location = modalLocation(mapData, result, etl);
    setText(document.querySelector("#incident-modal .modal-id"), "##" + pk);
    var badges = document.querySelectorAll("#incident-modal .modal-badges > span");
    if (badges[0]) {
      badges[0].hidden = true;
    }
    var deaths = count(etl, "DEATH_CNT");
    var injuries = count(etl, "INJURY_CNT");
    var hasCasualties = (deaths || 0) + (injuries || 0) > 0;
    if (badges[1]) {
      badges[1].hidden = !hasCasualties;
      if (hasCasualties) badges[1].textContent = "사망 " + (deaths || 0) + "명 · 부상 " + (injuries || 0) + "명";
    }
    if (badges[2]) badges[2].hidden = true;

    var subbar = document.querySelector("#incident-modal .modal-subbar");
    if (subbar) subbar.innerHTML = '<span class="route-icon">' + route.shield + '</span> ' + route.name
      + ' <span style="font-weight:300;color:var(--modal-subtext);font-size:20px;margin-left:6px;">' + location + '</span>';
    var rows = document.querySelectorAll("#incident-modal .info-table .info-row .info-val");
    setText(rows[0], incidentSubtitle(etl));
    setText(rows[1], modalBlockText(etl, result));
    setText(rows[2], occurrence ? clock(occurrence) + (processed !== null ? " (+" + processed + "분)" : "") : "-");
    setText(rows[3], location);
    setText(rows[4], "● 반영완료");
    if (rows[4]) rows[4].classList.add("val-green");

    var timeline = document.querySelectorAll("#incident-modal .timeline-item");
    var flow = buildProcessingStages(etl);
    timeline.forEach(function (item, index) {
      var hideReleaseStage = !flow.hasLaneBlock && index === 5;
      item.hidden = hideReleaseStage;
      if (hideReleaseStage) return;
      var description = item.children[1];
      var time = item.querySelector(".timeline-time-badge");
      var flowIndex = !flow.hasLaneBlock && index === 6 ? 5 : index;
      var value = flow.stages[flowIndex] || { number: flowIndex + 1, state: "wait", detail: "-", time: "-" };
      var left = item.querySelector(".timeline-left");
      if (left && value.title) {
        Array.prototype.slice.call(left.childNodes).forEach(function (node) {
          if (node.nodeType === 3) left.removeChild(node);
        });
        left.appendChild(document.createTextNode(value.title));
      }
      if (description) description.textContent = value.detail;
      if (time) {
        time.classList.toggle("curr", value.state === "current");
        time.textContent = value.state === "current" ? "진행중" : value.time;
      }
      var dot = item.querySelector(".timeline-dot");
      if (dot) {
        dot.className = "timeline-dot " + (value.state === "done" ? "dot-done"
          : (value.state === "current" ? "dot-curr" : "dot-wait"));
        dot.textContent = value.state === "done" ? "✓" : String(value.number);
      }
    });
  }

  function render(analysis, mapData, pk) {
    var analysisResult = analysis.analResult || {};
    var etl = mergedEtlData(analysis);
    var mapResult = mapData.analResult || {};
    var merged = Object.assign({}, analysisResult, mapResult);
    var route = routeInfo(merged);
    var blockType = flag(etl, "FRNT_BLCK_YN") === true ? "전면차단" : pick(merged, ["BLOCK_TYPE", "blockType", "MAR13"]);
    if (hasValue(blockType)) merged.BLOCK_TYPE = blockType;
    var predicted = pick(analysisResult, ["FRCS_BLC_HOUR"]);
    var maxCongestion = pick(analysisResult, ["MAX_CNGS_LNGT"]);
    var detour = pick(analysisResult, ["DETOUR_LINE_NAME"]);
    var occurrence = pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]) || pick(mapResult, ["MAR11"]);
    var selectedCoordinate = incidentMapCoordinate(mapData);
    if (selectedCoordinate) addIncidentMarker(String(pk), selectedCoordinate);

    // 분석 API가 제공하는 예상 소요시간만 표시한다.
    setPredictionSummary(predicted);
    // 상세 모달에서는 API로 확정 가능한 총 예상 소요시간만 실데이터로 교체한다.
    setText(document.querySelector("#incident-modal .ai-total-time"), minutes(predicted));
    setProcessingProgress(etl, predicted);

    setRouteTitle(route, cardDistance(merged, etl));
    setCardOffice(pick(etl, ["BRANCH_NAME"]));
    setText(document.getElementById("card-sub"), incidentSubtitle(etl));
    var completed = isIncidentCompleted(etl);
    var card = document.getElementById("main-incident-card");
    if (card) {
      card.className = "incident-card " + (completed ? "status-completed grade-C" : "status-processing grade-B");
    }
    setText(document.querySelector(".incident-card .tag.red"), blockType);
    setText(document.querySelector(".incident-card .time-group span"), occurrence ? "🕐 발생시각 " + clock(occurrence) : "-");
    setMainSteps(etl);

    setText(document.querySelector(".chart-panel .head-tag.route"), route.name);
    var congestionRange = renderChart(maxCongestion, pk, completed);
    setText(document.querySelector(".incident-card .tag.blue"), congestionRange
      ? "정체 구간 " + congestionRange.length.toFixed(1) + "km" : "-");

    document.querySelectorAll(".detour-panel .head-tag.route").forEach(function (element) { element.textContent = route.name; });
    var mainMinutes = Number(predicted);
    var shortcut = Number.isFinite(mainMinutes) ? Math.round(mainMinutes * 0.25) : null;
    var detourMinutes = shortcut === null ? null : Math.max(0, mainMinutes - shortcut);
    setText(document.getElementById("detour-diff-text"), shortcut === null ? "-" : shortcut + "분 단축");
    setText(document.getElementById("main-time-text"), Number.isFinite(mainMinutes) ? mainMinutes + "분" : "-");
    setText(document.getElementById("arrow-diff-val"), shortcut === null ? "-" : "-" + shortcut + "분");
    setText(document.getElementById("detour-time-text"), detourMinutes === null ? "-" : detourMinutes + "분");
    setText(document.querySelector(".detour-panel .donut-block:last-child .donut-center span"), detour);
    renderDetourRoute(mapData, detour);
    var testButton = document.querySelector(".detour-panel .test-btn");
    if (testButton) testButton.hidden = true;
    setModal(mapData, route, pk, etl);
    renderAnalysedIncidentList(pk);
    setStatus("", "idle");
  }

  function loadAnalysisMapData(pk, zone) {
    if (window.LOCKDOWN_MAP_AVAILABLE && window.vmap && typeof window.searchAnalMap === "function") {
      window.searchAnalMap(pk, zone || "");
      return;
    }
    window.LockdownApi.post("searchAnalMap", { pk: pk, cnzn_id: zone || "" })
      .then(function (mapData) {
        document.dispatchEvent(new CustomEvent("lockdown:searchAnalMap", { detail: mapData || {} }));
      })
      .catch(function (error) {
        document.dispatchEvent(new CustomEvent("lockdown:api-error", {
          detail: { endpoint: "searchAnalMap", error: error }
        }));
      });
  }

  function runAnalysis(pkValue, options) {
    options = options || {};
    var background = options.background === true;
    var pk = String(pkValue || "").trim();
    if (!pk) return failAnalysis("사고 목록에서 사고를 선택해 주세요.");
    if (background && state.analysisPolling) return;
    if (background) {
      state.analysisPolling = true;
      setStatus("", "refreshing");
    } else {
      state.analysisPolling = false;
    }
    state.currentPk = pk;
    if (!background) {
      setAnalysisLoading(true, "사고 기본정보와 분석 결과를 요청하고 있습니다.", "사고 분석 중");
      setStatus("분석 API 호출 중…", "running");
    }
    var etlRequest = window.LockdownApi.post("getEtlData", { pk: pk }).catch(function (error) {
      console.warn("getEtlData API 연결 실패", error);
      return null;
    });
    var analysisRequest = window.LockdownApi.post("execAnalysis", { pk: pk });
    Promise.all([
      analysisRequest,
      etlRequest
    ]).then(function (values) {
      if (state.currentPk !== pk) return;
      var analysis = values[0];
      if (values[1] && typeof values[1] === "object") analysis.etlData = values[1];
      state.analysis = analysis;
      var result = analysis.analResult || {};
      var zone = analysis.cnzn_id || pick(result, ["CNZN_ID"]);
      document.querySelector('input[name="acdt_no"]').value = pk;
      document.querySelector('input[name="cnzn_id"]').value = zone || "";
      if (!background) setAnalysisLoading(true, "분석 지도 데이터를 구성하고 있습니다.", "사고 분석 중");
      loadAnalysisMapData(pk, zone);
    }).catch(function (error) {
      state.analysisPolling = false;
      if (state.currentPk !== pk) return;
      if (background) {
        console.warn("사고 분석 자동 갱신 실패", error);
        setStatus("", "idle");
      } else {
        failAnalysis(error.message);
      }
    });
  }

  function startAnalysisPolling() {
    window.setInterval(function () {
      if (state.currentPk && !state.analysisLoading && !state.analysisPolling) {
        runAnalysis(state.currentPk, { background: true });
      }
    }, 3 * 60 * 1000);
  }

  document.addEventListener("lockdown:searchAnalMap", function (event) {
    if (!state.analysis || !state.currentPk) return;
    var backgroundRefresh = state.analysisPolling;
    try {
      render(state.analysis, event.detail || {}, state.currentPk);
      if (backgroundRefresh) {
        setStatus("", "idle");
      }
    } catch (error) {
      if (backgroundRefresh) {
        console.warn("사고 분석 자동 갱신 반영 실패", error);
        setStatus("", "idle");
      } else {
        failAnalysis(error.message || "분석 결과를 반영하지 못했습니다.");
      }
    } finally {
      if (backgroundRefresh) state.analysisPolling = false;
      setAnalysisLoading(false);
    }
  });
  document.addEventListener("lockdown:api-error", function (event) {
    var endpoint = event.detail && event.detail.endpoint;
    if (state.analysisPolling && (endpoint === "execAnalysis" || endpoint === "searchAnalMap")) {
      state.analysisPolling = false;
      setStatus("", "idle");
      return;
    }
    if (state.analysisLoading && (endpoint === "execAnalysis" || endpoint === "searchAnalMap")) {
      failAnalysis((event.detail && event.detail.error && event.detail.error.message) || "API 연결 실패");
    }
  });

  document.addEventListener("DOMContentLoaded", function () {
    installAnalysisBlocker();
    installAnalysisRefreshStatus();
    setAnalysisLoading(true, "사고 목록을 불러오고 있습니다.", "대시보드 준비 중");
    resetLiveDashboard();
    clearPublishingSampleList();
    bindIncidentFilters();
    bindAsIsMapOverlayControls();
    startAnalysisPolling();
    var listFailed = false;
    var incidentListRequest = window.LockdownApi.post("getEtlDataList", {}).catch(function (error) {
      listFailed = true;
      console.warn("getEtlDataList API 연결 실패", error);
      return [];
    });
    Promise.all([
      window.LockdownApi.post("getLineCode", {}),
      incidentListRequest
    ]).then(function (values) {
      state.lines = Array.isArray(values[0]) ? values[0] : [];
      var incidents = analysisCompletedIncidents(values[1]);
      renderIncidentList(incidents);
      startIncidentListPolling();

      var initialPk = new URLSearchParams(window.location.search).get("pk");
      var firstItem = document.querySelector('.incident-list .incident-item[data-status="processing"]')
        || document.querySelector(".incident-list .incident-item");
      var firstPk = firstItem ? String(firstItem.dataset.pk || "") : "";
      if (initialPk) {
        var initialItem = Array.prototype.slice.call(document.querySelectorAll(".incident-list .incident-item"))
          .filter(function (item) { return String(item.dataset.pk || "") === String(initialPk); })[0];
        if (initialItem) {
          initialItem.classList.add("selected");
          activateIncidentStatus(initialItem.dataset.status);
        }
        runAnalysis(initialPk);
      } else if (firstItem) {
        firstItem.classList.add("selected");
        setAnalysisLoading(true, "대시보드 데이터를 준비하고 있습니다.", "대시보드 준비 중");
        runAnalysis(firstPk);
      } else {
        setAnalysisLoading(false);
        if (listFailed) setStatus("사고 목록을 불러오지 못했습니다.", "error");
        else setStatus("사고 목록에 표시할 데이터가 없습니다.", "idle");
      }
    }).catch(function (error) {
      setAnalysisLoading(false);
      setStatus(error.message, "error");
    });
  });

  document.querySelector(".search-submit-btn").addEventListener("click", () => {
	var params = {
	    "page":"1",
	    "pageSize":"10",
	    "acdtGradCd":"",   // 사고등급 A,B,C
	    "startDate":"",    // 조회시작 연월일 "2026-10-01 00:00:00"
	    "endDate":"",      // 조회종료 연월일
	    "acdtLoct":""      // 사고위치 (텍스트. 예 : 강릉방향)
	}
	var startDate = document.getElementById("history-start-date").value;
	var endDate = document.getElementById("history-end-date").value;
	var grade = document.getElementById("history-grade-filter").value;
	var searchLocation = document.getElementById("history-search-input").value;
	console.log("startDate: ", startDate, " endDate: ", endDate, " grade: ", grade, " searchLocation: ", searchLocation);
	requestHistoryApi(params);
  });

  document.querySelector("#history-toggle-btn").addEventListener("click", () => {
	requestHistoryApi();
  })

  function requestHistoryApi(params) {
	window.LockdownApi.post("getTrafficList", params).then(function (items) {
		renderIncidentHistoryList(items)
    }).catch(function (error) {
      console.warn("과거 사고 이력 조회 실패", error);
    }).then(function () {

    });
  }

  function renderIncidentHistoryList(items) {
	var incidentCount = items.totCount;

	// 파라미터 사용자한테서 입력받아야함
	var currentPage = 1;
	var pageSize = 10;
	var totalPages = Math.ceil(incidentCount / pageSize);
	var countElement = document.querySelector(".incident-total-count");
	if (countElement) {
	    countElement.textContent = "총 " + incidentCount + "건 (페이지 " + currentPage + " / " + totalPages + ")";
	}
	var historyPanel = document.querySelector("#history-table-body");
	historyPanel.replaceChildren();

	items.data.forEach(function(item, idx) {
	    var tr = document.createElement("tr");
	    tr.className = "history-incident-table-body-tr";

	    // 등급
	    var td1 = document.createElement("td");
	    td1.style.textAlign = "center";
		var grade = ["A", "B", "C", "D", "E", "F"].includes(item.ACDT_GRAD_CD) ? item.ACDT_GRAD_CD : "";
	    var badge = document.createElement("span");
	    badge.className = "h-badge h-badge-" + grade;
	    badge.textContent = grade;
	    td1.appendChild(badge);

	    // 사고 위치
	    var td2 = document.createElement("td");
	    td2.style.whiteSpace = "nowrap";
	    td2.style.overflow = "hidden";
	    td2.style.textOverflow = "ellipsis";
	    td2.style.maxWidth = "300px";
	    var directionKm = document.createElement("span");
	    directionKm.className = "direction-km";
	    directionKm.textContent = item.RPRQ_CRCM_SEQ + " + " + item.ACDT_LOCT_CTNT;
	    td2.appendChild(directionKm);

	    // 발생 일시
	    var td3 = document.createElement("td");
	    var date = document.createElement("span");
	    date.className = "incident-history-date";
	    date.textContent = formatDateTime(item.RPRQ_CRCM_OCRN_DTTM);
	    td3.appendChild(date);

	    // 처리 시간
	    var td4 = document.createElement("td");
	    td4.style.color = "var(--accent-green)";
	    td4.style.fontWeight = "800";
	    var handleTime = document.createElement("span");
	    handleTime.className = "incident-hadle-time";
	    handleTime.textContent = formatDateTime(item.RPRQ_CRCM_CMPT_DTTM);
	    td4.appendChild(handleTime);

	    tr.append(td1, td2, td3, td4);
	    historyPanel.appendChild(tr);
	});
  }

  function formatDateTime(value) {
      if (!value) return "-";

      var date = new Date(value);
      if (isNaN(date.getTime())) return "-";

      var pad = (num) => String(num).padStart(2, "0");

      return (
          pad(date.getMonth() + 1) + "/" +
          pad(date.getDate()) + " " +
          pad(date.getHours()) + ":" +
          pad(date.getMinutes())
      );
  }


})();
