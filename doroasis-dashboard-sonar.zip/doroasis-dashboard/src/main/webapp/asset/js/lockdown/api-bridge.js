(function (window) {
  "use strict";

  function post(endpoint, body) {
    return fetch("/api/" + endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {})
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (json) {
        if (!response.ok || String(json.result || "").toUpperCase() === "ERROR") {
          throw new Error(json.message || json.result || endpoint + " API 호출 실패");
        }
        var payload = json.data !== undefined ? json.data : json;
        // execAnalysis의 etlExtractedData는 data와 같은 최상위에 내려오므로 분석 본문에 함께 보존한다.
        if (payload && typeof payload === "object" && json.etlExtractedData !== undefined) {
          payload.etlExtractedData = json.etlExtractedData;
        }

		// getTrafficList의 totCount는 data와 같은 최상위에 내려오므로 분석 본문에 함께 보존한다.
		/*if (payload && typeof payload === "object" && json.totCount !== undefined) {
		    payload.totCount = json.totCount;
		}*/

		if (endpoint === "getTrafficList") {
		    return json;
		}
        return payload;
      });
    });
  }

  function put(endpoint, body) {
    return fetch("/api/" + endpoint, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {})
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (json) {
        if (!response.ok || String(json.result || "").toUpperCase() === "ERROR") {
          throw new Error(json.message || json.result || endpoint + " API 호출 실패");
        }
        var payload = json.data !== undefined ? json.data : json;
        // execAnalysis의 etlExtractedData는 data와 같은 최상위에 내려오므로 분석 본문에 함께 보존한다.
        if (payload && typeof payload === "object" && json.etlExtractedData !== undefined) {
          payload.etlExtractedData = json.etlExtractedData;
        }

        return payload;
      });
    });
  }

  function withLowercaseAliases(source) {
    var target = {};
    Object.keys(source || {}).forEach(function (key) {
      target[key] = source[key];
      target[String(key).toLowerCase()] = source[key];
    });
    return target;
  }

  function adaptResponse(endpoint, data) {
    data = data || {};
    if (endpoint === "searchInitMap") {
      data.mVdsSpeedList = (data.mVdsSpeedList || []).map(withLowercaseAliases);
      data.mVmsList = (data.mVmsList || []).map(withLowercaseAliases);
      data.CODE = data.CODE || "S";
    } else if (endpoint === "searchAnalMap") {
      data.inTgInfo = (data.inTgInfo || []).map(withLowercaseAliases);
      data.outTgInfo = (data.outTgInfo || []).map(withLowercaseAliases);
      data.vmsAffectedList = (data.vmsAffectedList || []).map(withLowercaseAliases);
      data.CODE = data.CODE || "S";
    }
    return data;
  }

  function endpointFromUrl(url) {
    var match = String(url || "").match(/([^/]+?)(?:\.do)?$/);
    return match ? match[1] : "";
  }

  function requestBody(endpoint, param) {
    param = param || {};
    if (endpoint === "searchAnalMap") {
      return {
        pk: param.pk || param.acdt_no || "",
        cnzn_id: param.cnzn_id || ""
      };
    }
    if (endpoint === "searchInitMap" ||
		endpoint === "getSearch" ||
		endpoint === "getLineCode" ||
		endpoint === "getEtlDataList" ||
		endpoint === "getTrafficList" ||
		endpoint === "getEtlDataAcdtList" ||
		endpoint === "dv/getDvCcodeList"
	) {
      return {};
    }
    if (endpoint === "getEtlData" || endpoint === "execAnalysis") {
      return {
        pk: param.pk || param.acdt_no || ""
      };
    }
    return param;
  }

  window.LockdownApi = { post: post };
  window.readApi = { put: put };
  if (window.jQuery && !window.jQuery.fn.mCustomScrollbar) {
    window.jQuery.fn.mCustomScrollbar = function () { return this; };
  }
  window.showLoaderAll = window.showLoaderAll || function () {};
  window.showNotification = window.showNotification || function () {};
  window.callService = function (option) {
    var endpoint = endpointFromUrl(option && option.url);
    post(endpoint, requestBody(endpoint, option && option.param))
      .then(function (rawData) {
        var data = adaptResponse(endpoint, rawData);
        if (option && typeof option.callback === "function") option.callback({ data: data });
        document.dispatchEvent(new CustomEvent("lockdown:" + endpoint, { detail: data }));
      })
      .catch(function (error) {
        console.error(endpoint + " API 연결 실패", error);
        document.dispatchEvent(new CustomEvent("lockdown:api-error", {
          detail: { endpoint: endpoint, error: error }
        }));
      });
  };
})(window);
