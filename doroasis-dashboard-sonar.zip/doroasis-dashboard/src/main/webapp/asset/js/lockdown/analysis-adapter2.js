(function () {
  "use strict";

  var state = {
    lines: [], incidents: [], analysis: null,
    currentPk: "", analysisLoading: false, analysisPolling: false,
    incidentMarkers: {},
    incidentListRefreshing: false, incidentListPollingStarted: false
  };

  function hasValue(value) {
    return value !== undefined && value !== null && String(value).trim() !== "";
  }

  function pick(source, names) {
    source = source || {};
    var keys = Object.keys(source);
    for (var index = 0; index < names.length; index += 1) {
      var target = String(names[index]).toUpperCase();
      for (var keyIndex = 0; keyIndex < keys.length; keyIndex += 1) {
        if (String(keys[keyIndex]).toUpperCase() === target) return source[keys[keyIndex]];
      }
    }
    return null;
  }

  function setText(element, value) {
    if (element) element.textContent = hasValue(value) ? String(value) : "-";
  }

  function setStageStatus(element, value) {
    if (!element) return;
    element.textContent = "";
    var dot = document.createElement("span");
    dot.className = "dot-mark";
    element.appendChild(dot);
    element.appendChild(document.createTextNode(hasValue(value) ? String(value) : "-"));
  }

  function setStepDetail(element, value, agencyGrid) {
    if (!element) return;
    var useGrid = agencyGrid && hasValue(value) && value !== "-";
    element.classList.toggle("agency-times", useGrid);
    if (!useGrid) {
      element.textContent = !hasValue(value) || value === "-" ? "" : String(value);
      return;
    }
    element.textContent = "";
    String(value).split("\n").forEach(function (line) {
      var item = document.createElement("span");
      item.textContent = line;
      element.appendChild(item);
    });
  }

  function clock(value) {
    var str = String(value || "").trim();
    var match = str.match(/\b(\d{2}:\d{2})(?::\d{2})?\b/);
    if (match) return match[1];
    var compactMatch = str.match(/^\d{8}(\d{2})(\d{2})/);
    if (compactMatch) return compactMatch[1] + ":" + compactMatch[2];
    return "-";
  }

  function getClockHMS(value) {
      var str = String(value || "").trim();
      var match = str.match(/\b(\d{2}:\d{2}:\d{2})\b/);
      if (match) return match[1];
      var compactMatch = str.match(/^\d{8}(\d{2})(\d{2})(\d{2})/);
      if (compactMatch) {
          return compactMatch[1] + ":" + compactMatch[2] + ":" + compactMatch[3];
      }
      return "-";
  }

  function minutes(value) {
    return hasValue(value) ? String(value).replace(/분$/, "") + "분" : "-";
  }

  function extractedData(analysis) {
    var data = pick(analysis, ["etlExtractedData"]);
    return data && typeof data === "object" ? data : {};
  }

  function mergedEtlData(analysis) {
    var raw = pick(analysis, ["etlData"]);
    var merged = Object.assign({}, raw && typeof raw === "object" ? raw : {});
    var extracted = extractedData(analysis);
    Object.keys(extracted).forEach(function (key) {
      var val = extracted[key];
      if (hasValue(val)) {
        merged[key] = val;
      } else if (!(key in merged)) {
        merged[key] = val;
      }
    });
    return merged;
  }

  function flag(source, name) {
    var value = pick(source, [name]);
    if (!hasValue(value)) return null;
    return value === true || /^(1|Y|YES)$/i.test(String(value).trim());
  }

  function incidentCompletionTime(source) {
    var completedAt = pick(source, ["RPRQ_CRCM_CMPT_DTTM"]);
    if (hasValue(completedAt)) return completedAt;

    var actions = pick(source, ["ACDT_ACTN_LIST"]);
    if (!Array.isArray(actions)) return null;
    var completionRows = actions.map(function (row) {
      var codes = String(pick(row, ["ACDT_ACTN_CTNT_LLM"]) || "")
        .split(",")
        .map(function (code) { return String(code).trim().toUpperCase(); });
      var actionTime = pick(row, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]);
      return codes.indexOf("F") >= 0 && hasValue(actionTime) ? actionTime : null;
    }).filter(hasValue);

    completionRows.sort(function (left, right) {
      var leftDate = parseApiDate(left);
      var rightDate = parseApiDate(right);
      return (leftDate ? leftDate.getTime() : Number.MAX_SAFE_INTEGER)
        - (rightDate ? rightDate.getTime() : Number.MAX_SAFE_INTEGER);
    });
    return completionRows.length ? completionRows[0] : null;
  }

  function count(source, name) {
    var rawValue = pick(source, [name]);
    if (!hasValue(rawValue)) return null;
    var value = Number(rawValue);
    return Number.isFinite(value) && value >= 0 ? value : null;
  }

  function actionTimeline(etl) {
    var actions = pick(etl, ["ACDT_ACTN_LIST"]);
    var rows = Array.isArray(actions) ? actions.slice() : [];
    var codeTimes = {};
    var orderedCodes = [];
    var blockedLaneNumbers = [];
    var releasedLaneNumbers = [];
    var blockTime = "-";
    var releaseTime = "-";
    rows.sort(function (left, right) {
      var leftTime = parseApiDate(pick(left, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]));
      var rightTime = parseApiDate(pick(right, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]));
      return (leftTime ? leftTime.getTime() : Number.MAX_SAFE_INTEGER)
        - (rightTime ? rightTime.getTime() : Number.MAX_SAFE_INTEGER);
    });
    rows.forEach(function (row) {
      var value = pick(row, ["ACDT_ACTN_CTNT_LLM"]);
      if (!hasValue(value)) return;
      var actionTime = clock(pick(row, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]));
      String(value).split(",").forEach(function (rawCode) {
        var code = String(rawCode || "").trim().toUpperCase();
        if (!code) return;
        var numericCode = Number(code);
        if (/^\d+$/.test(code) && numericCode >= 100 && numericCode % 100 === 0) {
          var releasedLaneNumber = numericCode / 100;
          if (releasedLaneNumbers.indexOf(releasedLaneNumber) < 0) releasedLaneNumbers.push(releasedLaneNumber);
          if (releaseTime === "-" && actionTime !== "-") releaseTime = actionTime;
          return;
        }
        if (/^\d+$/.test(code) && numericCode >= 10 && numericCode < 100 && numericCode % 10 === 0) {
          var blockedLaneNumber = numericCode / 10;
          if (blockedLaneNumbers.indexOf(blockedLaneNumber) < 0) blockedLaneNumbers.push(blockedLaneNumber);
          if (blockTime === "-" && actionTime !== "-") blockTime = actionTime;
          return;
        }
        if (!codeTimes[code] && actionTime !== "-") {
          codeTimes[code] = actionTime;
          orderedCodes.push(code);
        }
      });
    });
    blockedLaneNumbers.sort(function (left, right) { return left - right; });
    releasedLaneNumbers.sort(function (left, right) { return left - right; });

    function agencyDetail(codeMap) {
      return codeMap.map(function (entry) {
        return codeTimes[entry.code] ? entry.label + " " + codeTimes[entry.code] : null;
      }).filter(Boolean).join("\n");
    }

    function firstCodeTime(codes) {
      for (var index = 0; index < orderedCodes.length; index += 1) {
        if (codes.indexOf(orderedCodes[index]) >= 0) return codeTimes[orderedCodes[index]];
      }
      return "-";
    }

    var dispatch = agencyDetail([
      { code: "B", label: "고순대" },
      { code: "C", label: "순찰차" },
      { code: "A", label: "구급차" },
      { code: "D", label: "견인차" }
    ]);
    var arrival = agencyDetail([
      { code: "P", label: "고순대" },
      { code: "Q", label: "순찰차" },
      { code: "O", label: "구급차" },
      { code: "R", label: "견인차" }
    ]);
    var dispatchTime = firstCodeTime(["A", "B", "C", "D"]);
    var arrivalTime = firstCodeTime(["O", "P", "Q", "R"]);
    return {
      hasRows: rows.length > 0,
      vmsTime: codeTimes.V || "-",
      messageTime: codeTimes.M || "-",
      trafficTime: firstCodeTime(["V", "M"]),
      blockedLaneNumbers: blockedLaneNumbers,
      releasedLaneNumbers: releasedLaneNumbers,
      blockTime: blockTime,
      releaseTime: releaseTime,
      dispatchDetail: dispatch,
      arrivalDetail: arrival,
      dispatchTime: dispatchTime,
      arrivalTime: arrivalTime,
      hasDispatch: dispatch !== "",
      hasArrival: arrival !== "",
      hasBlock: blockedLaneNumbers.length > 0,
      hasRelease: releasedLaneNumbers.length > 0
    };
  }

  function buildProcessingStages(etl) {
    var actions = actionTimeline(etl);
    var occurrence = pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]);
    var completion = incidentCompletionTime(etl);
    var trafficReflected = actions.vmsTime !== "-" || actions.messageTime !== "-";
    var actionLaneNumbers = actions.blockedLaneNumbers.length
      ? actions.blockedLaneNumbers : actions.releasedLaneNumbers;
    var hasLaneBlock = actions.hasBlock || actions.hasRelease;
    var completed = hasValue(completion);
    var directlyConfirmed = hasLaneBlock
      ? [hasValue(occurrence), trafficReflected, true, actions.hasDispatch,
        actions.hasArrival, actions.hasRelease, completed]
      : [hasValue(occurrence), trafficReflected, false, actions.hasDispatch,
        actions.hasArrival, completed];
    var stageCount = hasLaneBlock ? 7 : 6;
    var highestConfirmed = 0;
    directlyConfirmed.forEach(function (confirmed, index) {
      if (confirmed) highestConfirmed = index + 1;
    });
    highestConfirmed = completed ? stageCount : highestConfirmed;
    var currentStage = completed ? 0 : Math.min(stageCount, Math.max(1, highestConfirmed + 1));

    var blockedDetail = actionLaneNumbers.length ? actionLaneNumbers.join(",") + "차로 차단" : "";
    var releasedDetail = actions.releasedLaneNumbers.length
      ? actions.releasedLaneNumbers.join(",") + "차로 해제" : "";
    var occurrenceTime = clock(occurrence);
    var completionTime = clock(completion);
    var trafficLines = [];
    if (actions.vmsTime !== "-") trafficLines.push("VMS " + actions.vmsTime);
    if (actions.messageTime !== "-") trafficLines.push("문자 " + actions.messageTime);
    var trafficDetail = trafficLines.join("\n");
    var completionDetail = completionTime === "-" ? "" : "처리완료\n" + completionTime;
    var blockDetailText = blockedDetail
      + (blockedDetail && actions.blockTime !== "-" ? "\n" + actions.blockTime : "");
    var releaseDetail = releasedDetail
      + (releasedDetail && actions.releaseTime !== "-" ? "\n" + actions.releaseTime : "");
    var titles = hasLaneBlock
      ? ["발생", "교통정보표출", "차로차단", "현장출동요청", "현장도착", "차단해제", "처리완료"]
      : ["발생", "교통정보표출", "차로차단", "현장출동요청", "현장도착", "처리완료"];
    var occurrenceDetail = occurrenceTime === "-" ? "-" : "발생 " + occurrenceTime;
    var details = hasLaneBlock
      ? [occurrenceDetail, trafficDetail, blockDetailText || "해당없음", actions.dispatchDetail, actions.arrivalDetail,
        releaseDetail, completionDetail]
      : [occurrenceDetail, trafficDetail, "해당없음", actions.dispatchDetail, actions.arrivalDetail, completionDetail];
    var times = hasLaneBlock
      ? [occurrenceTime, actions.trafficTime, actions.blockTime,
        actions.dispatchTime, actions.arrivalTime, actions.releaseTime, completionTime]
      : [occurrenceTime, actions.trafficTime, "-",
        actions.dispatchTime, actions.arrivalTime, completionTime];
    var stages = details.map(function (detail, index) {
      var number = index + 1;
      var stateName = number <= highestConfirmed ? "done" : (number === currentStage ? "current" : "wait");
      var visibleDetail = stateName === "done" ? detail : "-";
      var visibleTime = stateName === "done" ? times[index] : "-";
      return {
        number: number,
        title: titles[index],
        state: stateName,
        detail: visibleDetail,
        time: visibleTime,
        status: stateName === "done" ? (number === 1 && visibleTime !== "-" ? visibleTime
          : (visibleTime !== "-" ? visibleTime + " 완료" : "완료"))
          : (stateName === "current" ? "진행 중" : "-")
      };
    });
    return {
      stages: stages,
      highestConfirmed: highestConfirmed,
      currentStage: currentStage,
      hasLaneBlock: hasLaneBlock
    };
  }

  function parseApiDate(value) {
    var str = String(value || "").trim();
    var match = str.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);
    if (match) {
      return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), Number(match[4]), Number(match[5]), Number(match[6]));
    }
    var compactMatch = str.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/);
    if (compactMatch) {
      return new Date(Number(compactMatch[1]), Number(compactMatch[2]) - 1, Number(compactMatch[3]), Number(compactMatch[4]), Number(compactMatch[5]), Number(compactMatch[6]));
    }
    return null;
  }

  function actualMinutes(etl) {
    var provided = count(etl, "PROC_MIN");
    var occurredAt = parseApiDate(pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]));
    if (!occurredAt) return provided;
    var completedAt = parseApiDate(incidentCompletionTime(etl));
    var endTime = completedAt ? completedAt.getTime() : Date.now();
    return Math.max(0, Math.floor((endTime - occurredAt.getTime()) / 60000));
  }

  function incidentSubtitle(etl) {
    var cause = pick(etl, ["ACDT_CAUS_CTNT"]);
    var vehicles = pick(etl, ["ACDT_OCRN_VHCL_CTNT"]);
    if (hasValue(cause)) cause = String(cause).trim();
    if (hasValue(vehicles)) vehicles = String(vehicles).trim();
    if (hasValue(cause) && hasValue(vehicles)) return cause + " (" + vehicles + ")";
    return cause || vehicles || "-";
  }

  function shortIcName(value) {
    return String(value || "").replace(/\s*\((?:입구|출구)\)\s*/g, "").trim();
  }

  function modalBlockText(etl, result) {
    var location = String(pick(etl, ["ACDT_LOCT_CTNT"]) || "");
    var numberedLanes = location.match(/\d+\s*차로/g) || [];
    var lanes = [];
    numberedLanes.forEach(function (lane) {
      var normalized = lane.replace(/\s+/g, "");
      if (lanes.indexOf(normalized) < 0) lanes.push(normalized);
    });
    if (!lanes.length && /갓길/.test(location)) lanes.push("갓길");

    var fullBlock = flag(etl, "FRNT_BLCK_YN");
    var blockType = fullBlock === true ? "전면차단"
      : (pick(result, ["BLOCK_TYPE", "blockType", "MAR13"]) || (fullBlock === false ? "전면차단 아님" : null));
    var laneText = lanes.join("·");
    return laneText && hasValue(blockType) ? laneText + "(" + blockType + ")" : (laneText || blockType || "-");
  }

  function modalLocation(mapData, result, etl) {
    var distance = pick(etl, ["STPNT_DSTNC"]);
    if (!hasValue(distance)) distance = pick(result, ["MAR12", "ACDT_OCRN_DSTNC"]);
    var distanceText = hasValue(distance) ? String(distance).trim() : "-";
    if (distanceText !== "-" && !/km$/i.test(distanceText)) distanceText += "km";

    var inNames = (Array.isArray(mapData && mapData.inTgInfo) ? mapData.inTgInfo : []).map(function (item) {
      return shortIcName(pick(item, ["IC_NAME"]));
    }).filter(hasValue);
    var outNames = (Array.isArray(mapData && mapData.outTgInfo) ? mapData.outTgInfo : []).map(function (item) {
      return shortIcName(pick(item, ["IC_NAME"]));
    }).filter(hasValue);
    if (!inNames.length && !outNames.length) return distanceText;
    return distanceText + "(" + (inNames.length ? inNames.join("·") : "-")
      + "~" + (outNames.length ? outNames.join("·") : "-") + ")";
  }

  var processingProgressTimer = null;
  function setProcessingProgress(etl, predicted) {
    var occurredAt = pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]);
    var completedAt = incidentCompletionTime(etl);
    var elapsed = actualMinutes(etl);
    var predictedMinutes = Number(predicted);
    var completed = hasValue(completedAt);
    var progress;
	// 20261027[추가] ykchoi: 사고목록 예측시간 실시간으로 반영
	// 기존 타이머 제거 (중복 실행 방지)
	if (processingProgressTimer !== null) {
	    clearInterval(processingProgressTimer);
	    processingProgressTimer = null;
	}

	// 1초마다 elapsed 다시 계산
	if (!completedAt) {
	  processingProgressTimer = setInterval(function() {
	  elapsed = actualMinutes(etl);

	  var elapsedElement = document.querySelector("#processing-elapsed");
	    if (elapsedElement) {
	      elapsedElement.textContent =
	      elapsed === null ? "-" : elapsed + "분";
	    }
	  }, 1000);
	}

	var element = document.querySelector(".info-card-bottom .pred-time");
    var current = Number(predicted);
    if (!element || !Number.isFinite(current) || current <= 0) {
      setText(element, "-");
      return;
    }

    var progressCard = document.querySelector(".info-card-bottom");
	if (progressCard) {
		var isCompeleted = document.querySelector('.list-item.selected[data-status="completed"]');
		setText(progressCard.querySelector(".pass-time"), elapsed === null ? "-" : elapsed + "분");
		var progress = elapsed === null ? 0 : (Number(elapsed) / current) * 100;
		progress = Math.min(100, Math.max(0, progress));
		var fill = progressCard.querySelector(".progress-bar");
		if (fill) {
			fill.style.width = isCompeleted ? "0%" : progress + "%";
			document.querySelector(".progress-fill").textContent = isCompeleted ? "-" : Math.round(progress) + "%";
		}
	}

	var rounded = Math.round(current);
	element.textContent = rounded + "분";

    var aiRows = document.querySelectorAll("#incident-modal .ai-stat-row");
    if (aiRows[0]) {
      setText(aiRows[0].querySelector("span"), "경과시간");
      setText(aiRows[0].querySelector("b"), elapsed === null ? "-" : elapsed + "분");
    }
    if (aiRows[1]) {
      var progressLabels = aiRows[1].querySelectorAll("span");
      if (progressLabels[1]) progressLabels[1].textContent = progress + "%";
    }
    var aiBar = document.querySelector("#incident-modal .ai-progress-bar");
    if (aiBar) aiBar.style.width = progress + "%";
    return { occurrence: occurredAt, completion: completedAt, minutes: elapsed, completed: completed };
  }

  function lineInfo(routeCode) {
    for (var index = 0; index < state.lines.length; index += 1) {
      if (String(pick(state.lines[index], ["LINE_CODE"])) === String(routeCode || "")) return state.lines[index];
    }
    return null;
  }

  function routeInfo(result) {
    var routeCode = String(pick(result, ["ROUTE_CD"]) || "");
    var zone = String(pick(result, ["CNZN_ID"]) || "");
    var directionMatch = zone.match(/CZ([ES])/i);
    var directionCode = String(pick(result, ["ROUTE_DRCT_CD"]) || (directionMatch ? directionMatch[1] : "")).toUpperCase();
    var line = lineInfo(routeCode);
    var lineName = line ? pick(line, ["LINE_NAME"]) : "";
    var directionName = line && directionCode ? pick(line, ["DIR_NAME_" + directionCode]) : "";
    var displayLineName = String(lineName || (routeCode ? "노선 " + routeCode : ""))
      .replace(/\s*\([^)]*\)\s*$/, "").trim();
    var displayDirection = directionName ? String(directionName).replace(/방향$/, "") + "방향" : "";
    return {
      code: routeCode,
      shield: routeCode ? routeCode.slice(0, 2) : "-",
      lineName: displayLineName || "-",
      directionName: displayDirection,
      name: [displayLineName, displayDirection].filter(Boolean).join(" ") || "-"
    };
  }

  //20261020[수정] minart
  function cardDistance(result, etl) {
	var acdtLoctCtnt =  pick(etl, ["ACDT_LOCT_CTNT"]);
	var dstncKm = extractDistance(acdtLoctCtnt);
    var distance = pick(etl, ["STPNT_DSTNC"]);

	if(dstncKm == 0 ){
		if(distance == null || distance == "" || distance == 0 ){
			dstncKm=distance;
		}else{
			dstncKm=0;
		}
	}

	return dstncKm + "km";
	/*
    if (!hasValue(distance)) distance = pick(result, ["MAR12", "ACDT_OCRN_DSTNC"]);
    if (!hasValue(distance)) return "";
    var match = String(distance).replace(/,/g, "").match(/-?\d+(?:\.\d+)?/);
    if (!match) return "";
    var numericDistance = Number(match[0]);

	if(dstncKm !=0 && dstncKm != numericDistance){
		numericDistance = dstncKm;
	}
	*/
	//return Number.isFinite(numericDistance) ? numericDistance.toFixed(1) + "km" : "";
	//return Number.isFinite(numericDistance) ? numericDistance + "km" : "";

  }

  //20261020[추가] minart // 20261026[수정] ykchoi
  function extractDistance(titleStr) {
      const m = String(titleStr).match(/((\d+(?:\.\d+)?)\s*(?:km|㎞)?)/i);
      const withUnit = m ? m[2] + "km" : null;
      const numberOnly = m?.[2];
      if (!m || m[2] === undefined) {
          return 0;
      } else {
          return numberOnly;
      }
  }

  let reportData = null;
  function searchCallback(data) {
      reportData = data;
      setOneClickReport(reportData);
  }

  document.querySelector(".report-sort-select").addEventListener("change", function() {
    setOneClickReport(reportData);
  });

  function setOneClickReport(etl) {
	var reportSortSelect = document.querySelector(".report-sort-select").value;
	var reportList = document.querySelector(".report-list");
	var list = etl["ACDT_ACTN_LIST"];
	const dataList = reportSortSelect === "latest"
	    ? [...list].reverse()
	    : list;

	// 기존 자식 요소 모두 삭제
    reportList.replaceChildren();

	document.querySelector(".report-count > strong").textContent = dataList.length + "건";
	dataList.forEach((item, index) => {
	    const reportItem = document.createElement("div");
	    reportItem.className = "report-item";

	    if (index === 0) {
	        reportItem.classList.add("highlight");
	    }

	    const reportTime = document.createElement("div");
	    reportTime.className = "report-time";
	    reportTime.textContent = clock(item["LSTTM_ALTR_DTTM"]);

	    const reportText = document.createElement("div");
	    reportText.className = "report-text";
		reportText.textContent = item["ACDT_ACTN_CTNT"];

	    reportItem.appendChild(reportTime);
	    reportItem.appendChild(reportText);
	    reportList.appendChild(reportItem);
	});
  }

  function routeDisplayTitle(route, distance) {
    return [route.lineName, distance, route.directionName ? "(" + route.directionName + ")" : ""]
      .filter(function (value) { return hasValue(value) && value !== "-"; }).join(" ") || "-";
  }

  function incidentListRouteTitle(route, distance) {
    return routeDisplayTitle(route, distance);
  }

  function incidentListDetail(detail) {
    return hasValue(detail) && detail !== "-" ? String(detail) : "-";
  }

  function setRouteTitle(route, distance) {
    var element = document.querySelector(".info-title");
    if (!element) return;
    element.textContent = route["lineName"] + "("  + route["directionName"].replace("방향", "") + ")" +  " " + (Number(distance).toFixed(1)) + "km";
  }

  function setInOutIC(detourBest) {
    var element = document.querySelector(".info-sub");
    if (!element) return;
    element.textContent = "(" + detourBest["IN_IC"] + "~" + detourBest["OUT_IC"] + ")";
  }

  function setTopIncidentInfo(etl) {
	var progressStatus = pick(etl, ["LIVS_DAMG_CTNT"]).replace(/[()]/g, "");
	var badgeCasualtyLarge = document.querySelector(".badge-casualty-large");
	badgeCasualtyLarge.className = "badge-casualty-large";
	if (progressStatus === "없음") {
	    badgeCasualtyLarge.classList.add("no");
	} else if (progressStatus === "조사중") {
	    badgeCasualtyLarge.classList.add("checking");
	} else {
	    badgeCasualtyLarge.classList.add("yes");
	}
    badgeCasualtyLarge.textContent = "인명사고 " + progressStatus;
	badgeCasualtyLarge.insertAdjacentHTML("afterbegin", `
		<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
			<circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/>
		</svg>
	`);

	var vehicleCountLarge = document.querySelector(".vehicle-count-large");
    vehicleCountLarge.textContent = pick(etl, ["ACDT_OCRN_VHCL_CTNT"]);
	vehicleCountLarge.insertAdjacentHTML("afterbegin", `
		<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
			<path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
		</svg>
	`);
  }

  function setStatus(message, status) {
    var element = document.getElementById("analysisApiStatus");
    if (!element) return;
    element.textContent = message || "";
    element.setAttribute("data-state", status || "idle");
  }

  function installAnalysisRefreshStatus() {
    if (document.getElementById("analysisApiStatus")) return;
    var target = document.querySelector(".info-card-bottom .progress-ai");
    if (!target) return;
    var status = document.createElement("div");
    status.id = "analysisApiStatus";
    status.className = "analysis-refresh-status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    status.setAttribute("data-state", "idle");
    target.appendChild(status);
  }

  function installAnalysisBlocker() {
    if (document.getElementById("analysisPageBlocker")) return;
    var blocker = document.createElement("div");
    blocker.id = "analysisPageBlocker";
    blocker.className = "analysis-page-blocker";
    blocker.hidden = true;
    blocker.setAttribute("aria-live", "polite");
    blocker.setAttribute("aria-busy", "true");
    blocker.innerHTML = '<div class="analysis-loading-card" role="status">'
      + '<div class="analysis-loading-spinner" aria-hidden="true"></div>'
      + '<strong id="analysisLoadingTitle">사고 분석 중</strong>'
      + '<span id="analysisLoadingMessage">분석 결과를 불러오고 있습니다.</span>'
      + '</div>';
    document.body.appendChild(blocker);
  }

  function setAnalysisLoading(active, message, title) {
    var blocker = document.getElementById("analysisPageBlocker");
    if (!blocker) return;
    state.analysisLoading = Boolean(active);
    blocker.hidden = !active;
    blocker.setAttribute("aria-hidden", active ? "false" : "true");
    document.body.classList.toggle("analysis-loading", Boolean(active));
    var titleElement = document.getElementById("analysisLoadingTitle");
    if (titleElement && title) titleElement.textContent = title;
    var messageElement = document.getElementById("analysisLoadingMessage");
    if (messageElement && message) messageElement.textContent = message;
    var runButton = document.getElementById("analysisRunButton");
    if (runButton) runButton.disabled = Boolean(active);
  }

  function failAnalysis(message) {
    var detail = message || "분석 결과를 불러오지 못했습니다.";
    setAnalysisLoading(false);
    setStatus(detail, "error");
    window.alert("분석에 실패했습니다.\n" + detail);
  }

  function resetLiveDashboard() {
    // 라이브 화면은 분석이 끝나기 전까지 퍼블리싱 샘플 값을 분석 결과처럼 노출하지 않는다.
    setText(document.querySelector(".info-title"), "-");
    setText(document.querySelector(".badge-region-large"), "-");
    var card = document.getElementById("main-incident-card");
    // 값이 없어도 퍼블리싱 카드의 테두리·배경 구조는 유지한다.
    if (card) card.className = "incident-card grade-empty";
    var grade = document.getElementById("card-badge");
    if (grade) { grade.style.display = "none"; }
    document.querySelector(".occur-time").textContent = "-";
    document.querySelector(".info-receipt").textContent = "-";

    setText(document.querySelector(".info-card-bottom .pass-time"), "-");
    setText(document.querySelector(".info-card-bottom .pred-time"), "-");
    setText(document.querySelector(".info-card-bottom .progress-fill"), "-");
    var progressBar = document.querySelector(".info-card-bottom .progress-bar");
    if (progressBar) progressBar.style.width = "0%";

    document.querySelectorAll(".seven-steps-layout > .step-cell[data-stage]").forEach(function (step) {
      step.classList.remove("is-done", "is-current");
      step.classList.add("is-wait");
      var status = step.querySelector(".step-status");
      if (status) status.className = "step-status status-wait";
      setStageStatus(status, "-");
      setStepDetail(step.querySelector(".step-bottom-time"), "-", false);
    });
    document.querySelectorAll(".seven-steps-layout [data-link-to]").forEach(function (link) {
      link.classList.remove("link-done", "link-current");
      link.classList.add("link-wait");
    });

	// 정체길이 현황 값 초기화
    document.querySelector(".c-value").textContent = "-";
    document.querySelector(".c-bar-fill").style.width = "0%";

    setText(document.querySelector("#incident-modal .modal-id"), "-");
    document.querySelectorAll("#incident-modal .modal-badges > span").forEach(function (badgeElement) {
      badgeElement.hidden = true;
    });
    setText(document.querySelector("#incident-modal .modal-subbar"), "-");
    document.querySelectorAll("#incident-modal .info-table .info-val").forEach(function (element) { element.textContent = "-"; });
    document.querySelectorAll("#incident-modal .timeline-item").forEach(function (item, index) {
      setText(item.children[1], "-");
      var timelineTime = item.querySelector(".timeline-time-badge");
      if (timelineTime) timelineTime.classList.remove("curr");
      setText(timelineTime, "-");
      var timelineDot = item.querySelector(".timeline-dot");
      if (timelineDot) {
        timelineDot.className = "timeline-dot dot-wait";
        timelineDot.textContent = String(index + 1);
      }
    });
    var aiPrediction = document.querySelector("#incident-modal .ai-pred-flex");
    if (aiPrediction) {
      aiPrediction.querySelectorAll("b, .ai-stat-row span, .ai-donut-center span").forEach(function (element) {
        element.textContent = "-";
      });
      var aiBar = aiPrediction.querySelector(".ai-progress-bar");
      if (aiBar) aiBar.style.width = "0%";
    }
  }

  function clearPublishingSampleList() {
    var list = document.querySelector(".left-panel .tab-content");
    if (!list) return;
    // 라이브 화면에는 퍼블리싱 확인용 PKID를 기본 사고 목록으로 사용하지 않는다.
    // 원본 더미 목록은 ?mock=1에서만 publishing-original.js와 함께 유지된다.
    list.textContent = "";
    var processingTab = document.querySelector('.left-panel .tab-group .tab[data-status-filter="processing"]');
    var completedTab = document.querySelector('.left-panel .tab-group .tab[data-status-filter="completed"]');
    if (processingTab) processingTab.textContent = "처리중(-)";
    if (completedTab) completedTab.textContent = "완료(-)";
  }

  function isIncidentCompleted(source) {
    return hasValue(incidentCompletionTime(source));
  }

  function analysisCompletedIncidents(items) {
    return (Array.isArray(items) ? items : []).filter(function (incident) {
      return flag(incident, "ANAL_COMP") === true;
    });
  }

  function updateIncidentTabCounts() {
    var items = Array.prototype.slice.call(document.querySelectorAll(".tab-content .list-item"));
    var completedCount = items.filter(function (item) { return item.dataset.status === "completed"; }).length;
    var processingCount = items.filter(function (item) { return item.dataset.status === "processing"; }).length;
    var processingTab = document.querySelector('.left-panel .tab-group .tab[data-status-filter="processing"]');
    var completedTab = document.querySelector('.left-panel .tab-group .tab[data-status-filter="completed"]');
    if (processingTab) processingTab.textContent = "처리중(" + processingCount + ")";
    if (completedTab) completedTab.textContent = "완료(" + completedCount + ")";
  }

  function applyIncidentFilters() {
    var activeTab = document.querySelector(".left-panel .tab-group .tab.active");
    var statusFilter = activeTab ? activeTab.dataset.statusFilter : "processing";
    document.querySelectorAll(".tab-content .list-item").forEach(function (item) {
      item.style.display = statusFilter === "all" || item.dataset.status === statusFilter ? "flex" : "none";
    });
	/*var isCasualty = Array.from(document.querySelectorAll('.tab-content.active .list-item.casualty-alert')).some(item => getComputedStyle(item).display === "flex");
	document.querySelector(".legend").style.display = isCasualty ? "block" : "none";*/
  }

  function activateIncidentStatus(status) {
    var target = document.querySelector('.left-panel .tab-group .tab[data-status-filter="' + status + '"]');
    if (!target) return;
    document.querySelectorAll(".left-panel .tab-group .tab").forEach(function (tab) {
      tab.classList.toggle("active", tab === target);
    });
    applyIncidentFilters();
  }

  function bindIncidentFilters() {
    document.querySelectorAll(".left-panel .tab-group .tab").forEach(function (tab) {
      tab.addEventListener("click", function () {
        document.querySelectorAll(".left-panel .tab-group .tab").forEach(function (other) { other.classList.remove("active"); });
        tab.classList.add("active");
        applyIncidentFilters();
      });
    });
  }

function setCodeOption() {
	window.LockdownApi.post("dv/getDvCcodeList", {codeType:"4"})
	.then(function (items) {
		items.forEach(function(item) {
			var option = document.createElement("option");
			option.value = item.CODE;
			option.textContent = item.CODE_NAME;
			select.appendChild(option);
		});
    }).catch(function (error) {
      console.warn("접보유형코드 조회 실패", error);
    });
	var select = document.querySelector("#accident-code");
	select.value = "B";
}

  function incidentMapCoordinate(mapData) {
    var result = mapData && mapData.analResult ? mapData.analResult : {};
    // searchAnalMap은 LAT에 경도, LNG에 위도를 내려준다.
    var longitude = Number(pick(result, ["LAT"]));
    var latitude = Number(pick(result, ["LNG"]));
    if (!Number.isFinite(longitude) || !Number.isFinite(latitude)) return null;
    if (Math.abs(longitude) > 180 || Math.abs(latitude) > 90) return null;
    return [longitude, latitude];
  }

  function updateIncidentMarkerElement(element, pk) {
	console.log("element: ", element, " pk: ", pk);
    if (!element) return;
    element.className = "ol-incident-marker marker-incident";
    element.title = "사고 ##" + pk;
    element.setAttribute("aria-label", element.title);
    var label = element.querySelector("span");
    if (label) label.textContent = "사고";
  }

  function addIncidentMarker(pk, coordinate) {
    if (!window.vmap || !window.ol || !coordinate) return false;
    var existing = state.incidentMarkers[pk];
    if (existing) {
      updateIncidentMarkerElement(existing.element, pk);
      existing.overlay.setPosition(ol.proj.fromLonLat(coordinate));
      return true;
    }

    var element = document.createElement("div");
    // element.type = "button";
    /*element.innerHTML = `<svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="
	"><g filter="url(#filter0_d_318_4484)"><rect x="28" y="28" width="44" height="44" rx="22" fill="#E1252F"></rect><rect x="29.5" y="29.5" width="41" height="41" rx="20.5" stroke="white" stroke-width="3"></rect><path d="M50.0001 37.9584L36.9668 60.625H63.0335L50.0001 37.9584Z" stroke-width="0.99" stroke-linecap="round" stroke-linejoin="round" stroke="white"></path><path d="M46.2944 56.4159L44.4665 57.1993L45.0226 55.1465L42.4505 54.3869L44.6166 53.0031L43.5428 50.6991L46.1946 51.1252L46.6345 48.6914L48.319 50.5074" stroke-width="0.392857" stroke="white"></path><use xlink:href="#stroke0_318_4484" fill="white"></use><mask id="stroke1_318_4484" fill="white"><use xlink:href="#stroke0_318_4484"></use></mask><path d="M56.4228 53.2421L55.7798 51.1798C55.6865 50.8795 55.5071 50.6184 55.2671 50.4333C55.027 50.2483 54.7385 50.1489 54.4426 50.1492H50.157C49.8611 50.1489 49.5726 50.2483 49.3325 50.4333C49.0925 50.6184 48.9131 50.8795 48.8198 51.1798L48.1768 53.2421C48.0058 53.3186 47.8598 53.4474 47.7571 53.6123C47.6544 53.7773 47.5996 53.971 47.5996 54.1692V56.6817C47.5996 57.0525 47.7895 57.3731 48.0696 57.5475V58.0026C48.0696 58.1358 48.1191 58.2636 48.2073 58.3579C48.2954 58.4521 48.415 58.5051 48.5396 58.5051H49.0097C49.1343 58.5051 49.2539 58.4521 49.342 58.3579C49.4302 58.2636 49.4797 58.1358 49.4797 58.0026V57.6867H55.1199V58.0026C55.1199 58.1358 55.1694 58.2636 55.2576 58.3579C55.3457 58.4521 55.4653 58.5051 55.5899 58.5051H56.0599C56.1846 58.5051 56.3042 58.4521 56.3923 58.3579C56.4804 58.2636 56.53 58.1358 56.53 58.0026V57.5475C56.6726 57.4601 56.7911 57.334 56.8736 57.182C56.9561 57.03 56.9997 56.8574 57 56.6817V54.1692C57 53.971 56.9452 53.7773 56.8425 53.6123C56.7398 53.4474 56.5938 53.3186 56.4228 53.2421ZM50.157 51.1542H54.4421C54.6447 51.1542 54.8243 51.2919 54.8882 51.4979L55.408 53.1642H49.1916L49.7109 51.4979C49.7421 51.3978 49.802 51.3107 49.882 51.249C49.9621 51.1873 50.0583 51.1541 50.157 51.1542ZM49.2447 56.1792C49.1521 56.1792 49.0604 56.1596 48.9748 56.1217C48.8892 56.0838 48.8115 56.0282 48.746 55.9582C48.6806 55.8881 48.6287 55.805 48.5932 55.7135C48.5578 55.622 48.5396 55.524 48.5396 55.4249C48.5397 55.3259 48.558 55.2279 48.5934 55.1364C48.6289 55.0449 48.6809 54.9618 48.7464 54.8918C48.8119 54.8219 48.8897 54.7663 48.9752 54.7285C49.0608 54.6906 49.1525 54.6712 49.2451 54.6712C49.4322 54.6713 49.6116 54.7508 49.7438 54.8922C49.876 55.0337 49.9502 55.2255 49.9502 55.4254C49.9501 55.6254 49.8757 55.8172 49.7434 55.9585C49.6111 56.0999 49.4317 56.1793 49.2447 56.1792ZM55.3549 56.1792C55.2623 56.1792 55.1706 56.1596 55.085 56.1217C54.9995 56.0838 54.9218 56.0282 54.8563 55.9582C54.7908 55.8881 54.7389 55.805 54.7035 55.7135C54.6681 55.622 54.6499 55.524 54.6499 55.4249C54.6499 55.3259 54.6682 55.2279 54.7037 55.1364C54.7391 55.0449 54.7911 54.9618 54.8566 54.8918C54.9221 54.8219 54.9999 54.7663 55.0855 54.7285C55.1711 54.6906 55.2628 54.6712 55.3554 54.6712C55.5424 54.6713 55.7218 54.7508 55.854 54.8922C55.9862 55.0337 56.0605 55.2255 56.0604 55.4254C56.0604 55.6254 55.986 55.8172 55.8537 55.9585C55.7214 56.0999 55.542 56.1793 55.3549 56.1792Z" stroke-width="3.81944" stroke="white" mask="url(#stroke1_318_4484)"></path></g><defs><filter id="filter0_d_318_4484" x="0" y="0" width="100" height="100" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"></feColorMatrix><feMorphology radius="6" operator="dilate" in="SourceAlpha" result="effect1_dropShadow_318_4484"></feMorphology><feOffset></feOffset><feGaussianBlur stdDeviation="11"></feGaussianBlur><feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 0.29 0 0 0 0 0.33 0 0 0 0.6 0"></feColorMatrix><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_318_4484"></feBlend><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_318_4484" result="shape"></feBlend></filter><path id="stroke0_318_4484" d="M56.4228 53.2421L55.7798 51.1798C55.6865 50.8795 55.5071 50.6184 55.2671 50.4333C55.027 50.2483 54.7385 50.1489 54.4426 50.1492H50.157C49.8611 50.1489 49.5726 50.2483 49.3325 50.4333C49.0925 50.6184 48.9131 50.8795 48.8198 51.1798L48.1768 53.2421C48.0058 53.3186 47.8598 53.4474 47.7571 53.6123C47.6544 53.7773 47.5996 53.971 47.5996 54.1692V56.6817C47.5996 57.0525 47.7895 57.3731 48.0696 57.5475V58.0026C48.0696 58.1358 48.1191 58.2636 48.2073 58.3579C48.2954 58.4521 48.415 58.5051 48.5396 58.5051H49.0097C49.1343 58.5051 49.2539 58.4521 49.342 58.3579C49.4302 58.2636 49.4797 58.1358 49.4797 58.0026V57.6867H55.1199V58.0026C55.1199 58.1358 55.1694 58.2636 55.2576 58.3579C55.3457 58.4521 55.4653 58.5051 55.5899 58.5051H56.0599C56.1846 58.5051 56.3042 58.4521 56.3923 58.3579C56.4804 58.2636 56.53 58.1358 56.53 58.0026V57.5475C56.6726 57.4601 56.7911 57.334 56.8736 57.182C56.9561 57.03 56.9997 56.8574 57 56.6817V54.1692C57 53.971 56.9452 53.7773 56.8425 53.6123C56.7398 53.4474 56.5938 53.3186 56.4228 53.2421ZM50.157 51.1542H54.4421C54.6447 51.1542 54.8243 51.2919 54.8882 51.4979L55.408 53.1642H49.1916L49.7109 51.4979C49.7421 51.3978 49.802 51.3107 49.882 51.249C49.9621 51.1873 50.0583 51.1541 50.157 51.1542ZM49.2447 56.1792C49.1521 56.1792 49.0604 56.1596 48.9748 56.1217C48.8892 56.0838 48.8115 56.0282 48.746 55.9582C48.6806 55.8881 48.6287 55.805 48.5932 55.7135C48.5578 55.622 48.5396 55.524 48.5396 55.4249C48.5397 55.3259 48.558 55.2279 48.5934 55.1364C48.6289 55.0449 48.6809 54.9618 48.7464 54.8918C48.8119 54.8219 48.8897 54.7663 48.9752 54.7285C49.0608 54.6906 49.1525 54.6712 49.2451 54.6712C49.4322 54.6713 49.6116 54.7508 49.7438 54.8922C49.876 55.0337 49.9502 55.2255 49.9502 55.4254C49.9501 55.6254 49.8757 55.8172 49.7434 55.9585C49.6111 56.0999 49.4317 56.1793 49.2447 56.1792ZM55.3549 56.1792C55.2623 56.1792 55.1706 56.1596 55.085 56.1217C54.9995 56.0838 54.9218 56.0282 54.8563 55.9582C54.7908 55.8881 54.7389 55.805 54.7035 55.7135C54.6681 55.622 54.6499 55.524 54.6499 55.4249C54.6499 55.3259 54.6682 55.2279 54.7037 55.1364C54.7391 55.0449 54.7911 54.9618 54.8566 54.8918C54.9221 54.8219 54.9999 54.7663 55.0855 54.7285C55.1711 54.6906 55.2628 54.6712 55.3554 54.6712C55.5424 54.6713 55.7218 54.7508 55.854 54.8922C55.9862 55.0337 56.0605 55.2255 56.0604 55.4254C56.0604 55.6254 55.986 55.8172 55.8537 55.9585C55.7214 56.0999 55.542 56.1793 55.3549 56.1792Z"></path></defs></svg>`;*/
	// element.innerHTML = `<svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g filter="url(#filter0_d_318_4484)"><rect x="28" y="28" width="44" height="44" rx="22" fill="#E1252F"/><rect x="29.5" y="29.5" width="41" height="41" rx="20.5" stroke="white" stroke-width="3"/><path d="M50.0001 37.9584L36.9668 60.625H63.0335L50.0001 37.9584Z" stroke-width="0.99" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M46.2944 56.4159L44.4665 57.1993L45.0226 55.1465L42.4505 54.3869L44.6166 53.0031L43.5428 50.6991L46.1946 51.1252L46.6345 48.6914L48.319 50.5074" stroke-width="0.392857" stroke="white"/><use xlink:href="#stroke0_318_4484" fill="white"/><mask id="stroke1_318_4484" fill="white"><use xlink:href="#stroke0_318_4484"/></mask><path d="M56.4228 53.2421L55.7798 51.1798C55.6865 50.8795 55.5071 50.6184 55.2671 50.4333C55.027 50.2483 54.7385 50.1489 54.4426 50.1492H50.157C49.8611 50.1489 49.5726 50.2483 49.3325 50.4333C49.0925 50.6184 48.9131 50.8795 48.8198 51.1798L48.1768 53.2421C48.0058 53.3186 47.8598 53.4474 47.7571 53.6123C47.6544 53.7773 47.5996 53.971 47.5996 54.1692V56.6817C47.5996 57.0525 47.7895 57.3731 48.0696 57.5475V58.0026C48.0696 58.1358 48.1191 58.2636 48.2073 58.3579C48.2954 58.4521 48.415 58.5051 48.5396 58.5051H49.0097C49.1343 58.5051 49.2539 58.4521 49.342 58.3579C49.4302 58.2636 49.4797 58.1358 49.4797 58.0026V57.6867H55.1199V58.0026C55.1199 58.1358 55.1694 58.2636 55.2576 58.3579C55.3457 58.4521 55.4653 58.5051 55.5899 58.5051H56.0599C56.1846 58.5051 56.3042 58.4521 56.3923 58.3579C56.4804 58.2636 56.53 58.1358 56.53 58.0026V57.5475C56.6726 57.4601 56.7911 57.334 56.8736 57.182C56.9561 57.03 56.9997 56.8574 57 56.6817V54.1692C57 53.971 56.9452 53.7773 56.8425 53.6123C56.7398 53.4474 56.5938 53.3186 56.4228 53.2421ZM50.157 51.1542H54.4421C54.6447 51.1542 54.8243 51.2919 54.8882 51.4979L55.408 53.1642H49.1916L49.7109 51.4979C49.7421 51.3978 49.802 51.3107 49.882 51.249C49.9621 51.1873 50.0583 51.1541 50.157 51.1542ZM49.2447 56.1792C49.1521 56.1792 49.0604 56.1596 48.9748 56.1217C48.8892 56.0838 48.8115 56.0282 48.746 55.9582C48.6806 55.8881 48.6287 55.805 48.5932 55.7135C48.5578 55.622 48.5396 55.524 48.5396 55.4249C48.5397 55.3259 48.558 55.2279 48.5934 55.1364C48.6289 55.0449 48.6809 54.9618 48.7464 54.8918C48.8119 54.8219 48.8897 54.7663 48.9752 54.7285C49.0608 54.6906 49.1525 54.6712 49.2451 54.6712C49.4322 54.6713 49.6116 54.7508 49.7438 54.8922C49.876 55.0337 49.9502 55.2255 49.9502 55.4254C49.9501 55.6254 49.8757 55.8172 49.7434 55.9585C49.6111 56.0999 49.4317 56.1793 49.2447 56.1792ZM55.3549 56.1792C55.2623 56.1792 55.1706 56.1596 55.085 56.1217C54.9995 56.0838 54.9218 56.0282 54.8563 55.9582C54.7908 55.8881 54.7389 55.805 54.7035 55.7135C54.6681 55.622 54.6499 55.524 54.6499 55.4249C54.6499 55.3259 54.6682 55.2279 54.7037 55.1364C54.7391 55.0449 54.7911 54.9618 54.8566 54.8918C54.9221 54.8219 54.9999 54.7663 55.0855 54.7285C55.1711 54.6906 55.2628 54.6712 55.3554 54.6712C55.5424 54.6713 55.7218 54.7508 55.854 54.8922C55.9862 55.0337 56.0605 55.2255 56.0604 55.4254C56.0604 55.6254 55.986 55.8172 55.8537 55.9585C55.7214 56.0999 55.542 56.1793 55.3549 56.1792Z" stroke-width="3.81944" stroke="white" mask="url(#stroke1_318_4484)"/></g><defs><filter id="filter0_d_318_4484" x="0" y="0" width="100" height="100" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feMorphology radius="6" operator="dilate" in="SourceAlpha" result="effect1_dropShadow_318_4484"/><feOffset/><feGaussianBlur stdDeviation="11"/><feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 0.29 0 0 0 0 0.33 0 0 0 0.6 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_318_4484"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_318_4484" result="shape"/></filter><path id="stroke0_318_4484" d="M56.4228 53.2421L55.7798 51.1798C55.6865 50.8795 55.5071 50.6184 55.2671 50.4333C55.027 50.2483 54.7385 50.1489 54.4426 50.1492H50.157C49.8611 50.1489 49.5726 50.2483 49.3325 50.4333C49.0925 50.6184 48.9131 50.8795 48.8198 51.1798L48.1768 53.2421C48.0058 53.3186 47.8598 53.4474 47.7571 53.6123C47.6544 53.7773 47.5996 53.971 47.5996 54.1692V56.6817C47.5996 57.0525 47.7895 57.3731 48.0696 57.5475V58.0026C48.0696 58.1358 48.1191 58.2636 48.2073 58.3579C48.2954 58.4521 48.415 58.5051 48.5396 58.5051H49.0097C49.1343 58.5051 49.2539 58.4521 49.342 58.3579C49.4302 58.2636 49.4797 58.1358 49.4797 58.0026V57.6867H55.1199V58.0026C55.1199 58.1358 55.1694 58.2636 55.2576 58.3579C55.3457 58.4521 55.4653 58.5051 55.5899 58.5051H56.0599C56.1846 58.5051 56.3042 58.4521 56.3923 58.3579C56.4804 58.2636 56.53 58.1358 56.53 58.0026V57.5475C56.6726 57.4601 56.7911 57.334 56.8736 57.182C56.9561 57.03 56.9997 56.8574 57 56.6817V54.1692C57 53.971 56.9452 53.7773 56.8425 53.6123C56.7398 53.4474 56.5938 53.3186 56.4228 53.2421ZM50.157 51.1542H54.4421C54.6447 51.1542 54.8243 51.2919 54.8882 51.4979L55.408 53.1642H49.1916L49.7109 51.4979C49.7421 51.3978 49.802 51.3107 49.882 51.249C49.9621 51.1873 50.0583 51.1541 50.157 51.1542ZM49.2447 56.1792C49.1521 56.1792 49.0604 56.1596 48.9748 56.1217C48.8892 56.0838 48.8115 56.0282 48.746 55.9582C48.6806 55.8881 48.6287 55.805 48.5932 55.7135C48.5578 55.622 48.5396 55.524 48.5396 55.4249C48.5397 55.3259 48.558 55.2279 48.5934 55.1364C48.6289 55.0449 48.6809 54.9618 48.7464 54.8918C48.8119 54.8219 48.8897 54.7663 48.9752 54.7285C49.0608 54.6906 49.1525 54.6712 49.2451 54.6712C49.4322 54.6713 49.6116 54.7508 49.7438 54.8922C49.876 55.0337 49.9502 55.2255 49.9502 55.4254C49.9501 55.6254 49.8757 55.8172 49.7434 55.9585C49.6111 56.0999 49.4317 56.1793 49.2447 56.1792ZM55.3549 56.1792C55.2623 56.1792 55.1706 56.1596 55.085 56.1217C54.9995 56.0838 54.9218 56.0282 54.8563 55.9582C54.7908 55.8881 54.7389 55.805 54.7035 55.7135C54.6681 55.622 54.6499 55.524 54.6499 55.4249C54.6499 55.3259 54.6682 55.2279 54.7037 55.1364C54.7391 55.0449 54.7911 54.9618 54.8566 54.8918C54.9221 54.8219 54.9999 54.7663 55.0855 54.7285C55.1711 54.6906 55.2628 54.6712 55.3554 54.6712C55.5424 54.6713 55.7218 54.7508 55.854 54.8922C55.9862 55.0337 56.0605 55.2255 56.0604 55.4254C56.0604 55.6254 55.986 55.8172 55.8537 55.9585C55.7214 56.0999 55.542 56.1793 55.3549 56.1792Z"/></defs></svg>`;
    updateIncidentMarkerElement(element, pk);
    element.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      var item = document.querySelector('.tab-content .list-item[data-pk="' + String(pk).replace(/"/g, "") + '"]');
      if (item) item.click();
      else runAnalysis(pk);
    });

    var marker = new ol.Overlay({
      element: element,
      position: ol.proj.fromLonLat(coordinate),
      positioning: "center-center",
      stopEvent: true
    });
    vmap.addOverlay(marker);
    state.incidentMarkers[pk] = { overlay: marker, element: element };
    return true;
  }

  function createIncidentItem(item, pk) {
    var route = routeInfo(item);
    var distance = cardDistance(item, item);
    var elapsed = actualMinutes(item);

    var listItem = document.createElement("div");
    listItem.className = "list-item";
    listItem.dataset.pk = pk;
    listItem.dataset.status = isIncidentCompleted(item) ? "completed" : "processing";

	if(listItem.dataset.status === "processing" && elapsed > 300) {
		listItem.dataset.status = "completed";
	}

	var listItemContent = document.createElement("div");
    listItemContent.className = "list-item-content";
	listItem.appendChild(listItemContent);

	var listTopRow = document.createElement("div");
    listTopRow.className = "list-top-row";
	listItemContent.appendChild(listTopRow);

    var office = document.createElement("span");
    office.className = "badge-region";
    office.textContent = pick(item, ["BRANCH_NAME"])+"지사" || "-";
    listTopRow.appendChild(office);

    var listTitle = document.createElement("div");
    listTitle.className = "list-title";
    listItemContent.appendChild(listTitle);

	var occTime = document.createElement("span");
    occTime.className = "occ-time";
    occTime.textContent = formatDateTime(pick(item, ["RPRQ_CRCM_OCRN_DTTM"])).slice(-5);
    listTitle.appendChild(occTime);

	var listTitleSpan = document.createElement("span");
    listTitleSpan.textContent = route["lineName"] + "("
		+ route["directionName"].replace("방향", "") + ") " + (Number(pick(item, ["KM_VAL"]))).toFixed(1) + "km";
	listTitle.appendChild(listTitleSpan);

    var listDesc = document.createElement("div");
    listDesc.className = "list-desc";
    listItemContent.appendChild(listDesc);

	var badgeCasualty = document.createElement("span");
	var progressStatus = pick(item, ["LIVS_DAMG_CTNT"]).replace(/[()]/g, "");
    badgeCasualty.className = "badge-casualty";
	if (progressStatus === "없음") {
	    badgeCasualty.classList.add("no");
	} else if (progressStatus === "조사중") {
	    badgeCasualty.classList.add("checking");
	} else {
	    badgeCasualty.classList.add("yes");
		listItem.classList.add("casualty-alert");
	}
    badgeCasualty.textContent = "인명사고 " + progressStatus;
	badgeCasualty.insertAdjacentHTML("afterbegin", `
		<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
			<circle cx="12" cy="4" r="2"/><path d="M15.89 8.11C15.5 7.72 14.83 7 13.53 7h-3.06c-1.3 0-1.97.72-2.36 1.11L4 12.25l1.41 1.41L9 10.08V22h2v-6h2v6h2V10.08l3.59 3.58L20 12.25l-4.11-4.14z"/>
		</svg>
	`);
    listDesc.appendChild(badgeCasualty);

	var vehicleCount = document.createElement("span");
    vehicleCount.className = "vehicle-count";
    vehicleCount.textContent = "관련차량 " + sumCount(pick(item, ["ACDT_OCRN_VHCL_CTNT"]));
	vehicleCount.insertAdjacentHTML("afterbegin", `
		<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
			<path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
		</svg>
	`);
    listDesc.appendChild(vehicleCount);

    var listItemRight = document.createElement("div");
    listItemRight.className = "list-item-right";
	listItem.appendChild(listItemRight);

	var timeDiv = document.createElement("div");
	timeDiv.style = "text-align: right;";
	listItemRight.appendChild(timeDiv);

    var elapsedElement = document.createElement("div");
    elapsedElement.className = "time-large";
    elapsedElement.textContent = elapsed === null ? "-" : elapsed + "분";
    timeDiv.appendChild(elapsedElement);

    var timeSmall = document.createElement("div");
    var prediction = pick(item, ["FRCS_BLC_HOUR"]);
    timeSmall.className = "time-small";
    timeSmall.textContent = hasValue(prediction) ? "/" + minutes(prediction) : "/-";
    timeDiv.appendChild(timeSmall);

	if (elapsedElement) {
      elapsedElement.textContent = elapsed === null ? "-" : elapsed + "분";
	  // if(elapsed > prediction) elapsedElement.classList.add("red")
    }

	var arrowIcon = document.createElement("span");
	arrowIcon.className = "arrow-icon";
	arrowIcon.textContent = "❯";
	listItemRight.appendChild(arrowIcon);

    listItem.addEventListener("click", function () {
      document.querySelectorAll(".tab-content .list-item").forEach(function (other) {
        other.classList.remove("selected", "sel-A", "sel-B", "sel-C");
      });
      listItem.classList.add("selected");
      runAnalysis(pk);
    });
    return listItem;
  }

  function renderIncidentList(items) {
    var list = document.querySelector(".left-panel .tab-content");
    if (!list) return;
    list.textContent = "";
    state.incidents = Array.isArray(items) ? items : [];

    state.incidents.forEach(function (item) {
      var pk = String(pick(item, ["RPRQ_CRCM_SEQ", "PK", "PKID"]) || "");
      if (!pk) return;
      var incidentItem = createIncidentItem(item, pk);
      list.appendChild(incidentItem);
    });

    updateIncidentTabCounts();
    applyIncidentFilters();
  }

  function patchIncidentList(incidents) {
    var list = document.querySelector(".left-panel .tab-content");
    if (!list) return;
    state.incidents = Array.isArray(incidents) ? incidents : [];
    var newPks = {};

    state.incidents.forEach(function (incident) {
      var pk = String(pick(incident, ["RPRQ_CRCM_SEQ", "PK", "PKID"]) || "");
      if (!pk) return;
      newPks[pk] = true;

      var route = routeInfo(incident);
      var distance = cardDistance(incident, incident);
      var elapsed = actualMinutes(incident);
      var existing = list.querySelector('.list-item[data-pk="' + pk.replace(/"/g, "") + '"]');

      if (existing) {
        existing.dataset.status = isIncidentCompleted(incident) ? "completed" : "processing";

		if(existing.dataset.status === "processing" && elapsed > 300) {
			existing.dataset.status = "completed";
		}

        setText(existing.querySelector(".item-road-text"), incidentListRouteTitle(route, distance));
        var cause = incidentSubtitle(incident);
        if (cause !== "-") {
          setText(existing.querySelector(".item-cause"), incidentListDetail(cause));
        }
        setText(existing.querySelector(".badge-region"), pick(incident, ["BRANCH_NAME"])+"지사" || "-");

        var elapsedElement = existing.querySelector(".time-large");
        if (elapsedElement) {
          elapsedElement.textContent = elapsed === null ? "-" : elapsed + "분";
        }
        if (state.currentPk === pk) {
          existing.classList.add("selected");
        }

        var prediction = pick(incident, ["FRCS_BLC_HOUR"]);
        setText(existing.querySelector(".timeSmall"), hasValue(prediction) ? "/" + minutes(prediction) : "/-");
      } else {
        var newItem = createIncidentItem(incident, pk);
        list.appendChild(newItem);
      }
    });

    Array.prototype.slice.call(list.querySelectorAll(".list-item")).forEach(function (item) {
      var itemPk = String(item.dataset.pk || "");
      if (itemPk && !newPks[itemPk]) {
        item.remove();
      }
    });

    updateIncidentTabCounts();
    applyIncidentFilters();
  }

  function refreshIncidentList() {
    if (state.incidentListRefreshing) return;
    state.incidentListRefreshing = true;

    window.LockdownApi.post("getEtlDataList", {}).then(function (items) {
      var incidents = analysisCompletedIncidents(items);
      patchIncidentList(incidents);
	  setIncidentAlarmList(incidents);
    }).catch(function (error) {
      console.warn("사고 목록 자동 갱신 실패", error);
    }).then(function () {
      state.incidentListRefreshing = false;
    });
  }

  function startIncidentListPolling() {
    if (state.incidentListPollingStarted) return;
    state.incidentListPollingStarted = true;
    window.setInterval(refreshIncidentList, 60 * 1000);
  }

  function bindAsIsMapOverlayControls() {
    var vms = document.querySelector('input[name="vms"]');
    var office = document.querySelector('input[name="ic"]');
    if (vms) vms.addEventListener("click", function () { window.vmsClickHandler(this.checked); });
    if (office) office.addEventListener("click", function () { window.icClickHandler(this.checked); });
  }

  function renderAnalysedIncidentList(pk) {
	// 사고 목록 요소의 pk로 api를 조회하여 지정 우회도로의 Link_id를 받아야함
    document.querySelectorAll(".tab-content .list-item").forEach(function (item) {
      item.classList.toggle("selected", String(item.dataset.pk) === String(pk));
    });
  }

  function getStepIcon(number) {
      var icons = {
		// 사고발생
		1: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M13.1351 22.1325L11.6378 22.7742L12.0933 21.0927L9.98635 20.4704L11.7607 19.3368L10.8812 17.4495L13.0534 17.7985L13.4138 15.8048L14.7936 17.2924" stroke-width="0.571429" stroke="white"/><use xlink:href="#stroke0_20_991" fill="white"/><mask id="stroke1_20_991" fill="white"><use xlink:href="#stroke0_20_991"/></mask><path d="M21.4322 19.5329L20.9055 17.8435C20.8291 17.5976 20.6822 17.3836 20.4855 17.232C20.2889 17.0805 20.0526 16.999 19.8101 16.9993H16.2995C16.0571 16.999 15.8208 17.0805 15.6241 17.232C15.4275 17.3836 15.2805 17.5976 15.2041 17.8435L14.6774 19.5329C14.5373 19.5955 14.4177 19.701 14.3336 19.8362C14.2495 19.9713 14.2046 20.13 14.2046 20.2923V22.3505C14.2046 22.6543 14.3601 22.9169 14.5896 23.0597V23.4325C14.5896 23.5417 14.6302 23.6464 14.7024 23.7236C14.7746 23.8008 14.8725 23.8441 14.9746 23.8441H15.3597C15.4618 23.8441 15.5597 23.8008 15.6319 23.7236C15.7041 23.6464 15.7447 23.5417 15.7447 23.4325V23.1738H20.365V23.4325C20.365 23.5417 20.4055 23.6464 20.4777 23.7236C20.5499 23.8008 20.6479 23.8441 20.75 23.8441H21.135C21.2371 23.8441 21.3351 23.8008 21.4073 23.7236C21.4795 23.6464 21.52 23.5417 21.52 23.4325V23.0597C21.6368 22.9881 21.7339 22.8848 21.8015 22.7603C21.8691 22.6358 21.9048 22.4945 21.9051 22.3505V20.2923C21.9051 20.13 21.8602 19.9713 21.776 19.8362C21.6919 19.701 21.5723 19.5955 21.4322 19.5329ZM16.2995 17.8225H19.8098C19.9757 17.8225 20.1228 17.9353 20.1751 18.1041L20.601 19.4691H15.5087L15.9341 18.1041C15.9597 18.0221 16.0087 17.9508 16.0743 17.9002C16.1399 17.8497 16.2187 17.8225 16.2995 17.8225ZM15.5522 21.9389C15.4763 21.9388 15.4012 21.9228 15.3311 21.8918C15.261 21.8607 15.1973 21.8152 15.1437 21.7578C15.0901 21.7004 15.0476 21.6323 15.0185 21.5574C14.9895 21.4824 14.9746 21.4021 14.9746 21.321C14.9747 21.2399 14.9896 21.1596 15.0187 21.0846C15.0477 21.0097 15.0903 20.9416 15.144 20.8843C15.1977 20.827 15.2614 20.7815 15.3315 20.7505C15.4016 20.7195 15.4767 20.7035 15.5526 20.7035C15.7058 20.7036 15.8527 20.7687 15.961 20.8846C16.0693 21.0005 16.1301 21.1576 16.1301 21.3214C16.13 21.4852 16.0691 21.6423 15.9607 21.7581C15.8524 21.8739 15.7054 21.9389 15.5522 21.9389ZM20.5575 21.9389C20.4816 21.9388 20.4065 21.9228 20.3364 21.8918C20.2663 21.8607 20.2026 21.8152 20.149 21.7578C20.0954 21.7004 20.0529 21.6323 20.0238 21.5574C19.9948 21.4824 19.9799 21.4021 19.9799 21.321C19.98 21.2399 19.9949 21.1596 20.024 21.0846C20.053 21.0097 20.0956 20.9416 20.1493 20.8843C20.203 20.827 20.2667 20.7815 20.3368 20.7505C20.4069 20.7195 20.482 20.7035 20.5579 20.7035C20.7111 20.7036 20.858 20.7687 20.9663 20.8846C21.0746 21.0005 21.1354 21.1576 21.1354 21.3214C21.1353 21.4852 21.0744 21.6423 20.966 21.7581C20.8577 21.8739 20.7107 21.9389 20.5575 21.9389Z" stroke-width="5.55556" stroke="white" mask="url(#stroke1_20_991)"/><path d="M16.1904 4.85693L3.92371 26.1903H28.457L16.1904 4.85693Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><defs><path id="stroke0_20_991" d="M21.4322 19.5329L20.9055 17.8435C20.8291 17.5976 20.6822 17.3836 20.4855 17.232C20.2889 17.0805 20.0526 16.999 19.8101 16.9993H16.2995C16.0571 16.999 15.8208 17.0805 15.6241 17.232C15.4275 17.3836 15.2805 17.5976 15.2041 17.8435L14.6774 19.5329C14.5373 19.5955 14.4177 19.701 14.3336 19.8362C14.2495 19.9713 14.2046 20.13 14.2046 20.2923V22.3505C14.2046 22.6543 14.3601 22.9169 14.5896 23.0597V23.4325C14.5896 23.5417 14.6302 23.6464 14.7024 23.7236C14.7746 23.8008 14.8725 23.8441 14.9746 23.8441H15.3597C15.4618 23.8441 15.5597 23.8008 15.6319 23.7236C15.7041 23.6464 15.7447 23.5417 15.7447 23.4325V23.1738H20.365V23.4325C20.365 23.5417 20.4055 23.6464 20.4777 23.7236C20.5499 23.8008 20.6479 23.8441 20.75 23.8441H21.135C21.2371 23.8441 21.3351 23.8008 21.4073 23.7236C21.4795 23.6464 21.52 23.5417 21.52 23.4325V23.0597C21.6368 22.9881 21.7339 22.8848 21.8015 22.7603C21.8691 22.6358 21.9048 22.4945 21.9051 22.3505V20.2923C21.9051 20.13 21.8602 19.9713 21.776 19.8362C21.6919 19.701 21.5723 19.5955 21.4322 19.5329ZM16.2995 17.8225H19.8098C19.9757 17.8225 20.1228 17.9353 20.1751 18.1041L20.601 19.4691H15.5087L15.9341 18.1041C15.9597 18.0221 16.0087 17.9508 16.0743 17.9002C16.1399 17.8497 16.2187 17.8225 16.2995 17.8225ZM15.5522 21.9389C15.4763 21.9388 15.4012 21.9228 15.3311 21.8918C15.261 21.8607 15.1973 21.8152 15.1437 21.7578C15.0901 21.7004 15.0476 21.6323 15.0185 21.5574C14.9895 21.4824 14.9746 21.4021 14.9746 21.321C14.9747 21.2399 14.9896 21.1596 15.0187 21.0846C15.0477 21.0097 15.0903 20.9416 15.144 20.8843C15.1977 20.827 15.2614 20.7815 15.3315 20.7505C15.4016 20.7195 15.4767 20.7035 15.5526 20.7035C15.7058 20.7036 15.8527 20.7687 15.961 20.8846C16.0693 21.0005 16.1301 21.1576 16.1301 21.3214C16.13 21.4852 16.0691 21.6423 15.9607 21.7581C15.8524 21.8739 15.7054 21.9389 15.5522 21.9389ZM20.5575 21.9389C20.4816 21.9388 20.4065 21.9228 20.3364 21.8918C20.2663 21.8607 20.2026 21.8152 20.149 21.7578C20.0954 21.7004 20.0529 21.6323 20.0238 21.5574C19.9948 21.4824 19.9799 21.4021 19.9799 21.321C19.98 21.2399 19.9949 21.1596 20.024 21.0846C20.053 21.0097 20.0956 20.9416 20.1493 20.8843C20.203 20.827 20.2667 20.7815 20.3368 20.7505C20.4069 20.7195 20.482 20.7035 20.5579 20.7035C20.7111 20.7036 20.858 20.7687 20.9663 20.8846C21.0746 21.0005 21.1354 21.1576 21.1354 21.3214C21.1353 21.4852 21.0744 21.6423 20.966 21.7581C20.8577 21.8739 20.7107 21.9389 20.5575 21.9389Z"/></defs></svg>`,
		// 비상방송
		2: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.66663 12.6666V19.3333H8.93329L18.6666 25.3333V6.66663L8.93329 12.6666H4.66663Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M23.0667 12C23.6342 12.5004 24.0887 13.116 24.4 13.8056C24.7113 14.4953 24.8723 15.2433 24.8723 16C24.8723 16.7566 24.7113 17.5046 24.4 18.1943C24.0887 18.884 23.6342 19.4995 23.0667 20M26.1333 8.66663C27.1256 9.61294 27.9156 10.7508 28.4553 12.0113C28.995 13.2718 29.2733 14.6288 29.2733 16C29.2733 17.3712 28.995 18.7281 28.4553 19.9886C27.9156 21.2491 27.1256 22.387 26.1333 23.3333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 교통정보표출
		3: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 4.66663H26C27.1046 4.66663 28 5.56206 28 6.66663V16C28 17.1045 27.1046 18 26 18H6C4.89543 18 4 17.1045 4 16V6.66663C4 5.56206 4.89543 4.66663 6 4.66663Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M16 18V27.3333M16 27.3333H10.6666M16 27.3333H21.3333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M8.66663 11.4667C9.99996 9.86672 11.3333 9.86672 12.6666 11.4667C14 13.0667 15.3333 13.0667 16.6666 11.4667C18 9.86672 19.3333 9.86672 20.6666 11.4667" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 차단막 하강
		4: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 4.66663H28" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M9.33333 4.66663H22.6667C23.403 4.66663 24 5.26358 24 5.99996V15.3333C24 16.0697 23.403 16.6666 22.6667 16.6666H9.33333C8.59695 16.6666 8 16.0697 8 15.3333V5.99996C8 5.26358 8.59695 4.66663 9.33333 4.66663Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M16 20V28M20 24L16 28L12 24" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 제트팬 작동
		5: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28 16C28 22.6274 22.6274 28 16 28C9.37258 28 4 22.6274 4 16C4 9.37258 9.37258 4 16 4C22.6274 4 28 9.37258 28 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M18.1334 16C18.1334 17.1782 17.1782 18.1334 16 18.1334C14.8218 18.1334 13.8667 17.1782 13.8667 16C13.8667 14.8218 14.8218 13.8667 16 13.8667C17.1782 13.8667 18.1334 14.8218 18.1334 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M16 13.8666C14.6667 9.46662 16.2667 6.79995 19.4667 7.33329M17.8667 17.0666C22.1334 18.8 23.4667 21.6 21.2 23.7333M14 16.8C10.2667 19.4666 7.33338 18.9333 6.80005 15.7333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 차로차단
		6: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.7333 4H18.2667L24 24H8L13.7333 4Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M11.0666 12.6666H20.9333M9.59998 18H22.4" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M4.66663 28H27.3333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 현장출동
		7: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.33337 22V12H16V22" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M16 14.6666H21.3333L26 18.9333V22H16" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M10.9334 23.3333C10.9334 24.5852 9.91854 25.6 8.66669 25.6C7.41485 25.6 6.40002 24.5852 6.40002 23.3333C6.40002 22.0815 7.41485 21.0667 8.66669 21.0667C9.91854 21.0667 10.9334 22.0815 10.9334 23.3333Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M23.6 23.3333C23.6 24.5852 22.5852 25.6 21.3333 25.6C20.0815 25.6 19.0667 24.5852 19.0667 23.3333C19.0667 22.0815 20.0815 21.0667 21.3333 21.0667C22.5852 21.0667 23.6 22.0815 23.6 23.3333Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M9.60004 14.4V16.6667M9.60004 16.6667V18.9334M9.60004 16.6667H7.33337M9.60004 16.6667H11.8667" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M18.6666 7.33329H27.3333M24.6666 9.99996L27.3333 7.33329L24.6666 4.66663" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 현장도착
		8: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 28C16 28 7.33337 20.2667 7.33337 14C7.33337 11.7015 8.24647 9.4971 9.87178 7.87178C11.4971 6.24647 13.7015 5.33337 16 5.33337C18.2986 5.33337 20.503 6.24647 22.1283 7.87178C23.7536 9.4971 24.6667 11.7015 24.6667 14C24.6667 20.2667 16 28 16 28Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M12.4 14.1333L14.9334 16.6666L19.7334 11.7333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 차단막 해제
		9: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 4.66663H28" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M9.33333 4.66663H22.6667C23.403 4.66663 24 5.26358 24 5.99996V9.33329C24 10.0697 23.403 10.6666 22.6667 10.6666H9.33333C8.59695 10.6666 8 10.0697 8 9.33329V5.99996C8 5.26358 8.59695 4.66663 9.33333 4.66663Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M16 28V16M20 20L16 16L12 20" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 제트팬 해제
		10: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28 16C28 22.6274 22.6274 28 16 28C9.37258 28 4 22.6274 4 16C4 9.37258 9.37258 4 16 4C22.6274 4 28 9.37258 28 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M18.1334 16C18.1334 17.1782 17.1782 18.1334 16 18.1334C14.8218 18.1334 13.8667 17.1782 13.8667 16C13.8667 14.8218 14.8218 13.8667 16 13.8667C17.1782 13.8667 18.1334 14.8218 18.1334 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M16 13.8666C14.6667 9.46662 16.2667 6.79995 19.4667 7.33329M17.8667 17.0666C22.1334 18.8 23.4667 21.6 21.2 23.7333M14 16.8C10.2667 19.4666 7.33338 18.9333 6.80005 15.7333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M7.46667 7.46667L24.5333 24.5333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 차단해제
		11: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.66663 28L10.6666 4M25.3333 28L21.3333 4" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M16 24V10.6666M20 14.6666L16 10.6666L12 14.6666" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`,
		// 완료
		12: `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28 16C28 22.6274 22.6274 28 16 28C9.37258 28 4 22.6274 4 16C4 9.37258 9.37258 4 16 4C22.6274 4 28 9.37258 28 16Z" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M10.4 16.2666L14.2667 20.1333L21.7334 12.1333" stroke-width="1.44" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg>`
      };
      return icons[number] || "";
  }

function setMainSteps(etl) {
    var stepList = pick(etl, ["ACDT_ACTN_LIST"]) || [];
    var atl = actionTimeline(etl);
    var layout = document.querySelector("#processGridContainer");

	// console.log("atl: ", atl)
    if (!layout) return;
    if (!Array.isArray(stepList)) stepList = [];

    // 기존 단계 초기화
    layout.querySelectorAll(".process-row").forEach(function(el) {
        el.replaceChildren();
    });

    var iconTitles = {
        1: "사고발생",
        2: "비상방송",
        3: "교통정보표출",
        4: "차단막 하강",
        5: "제트팬 작동",
        6: "차로차단",
        7: "현장출동요청",
        8: "현장도착",
        9: "차단막 해제",
        10: "제트팬 해제",
        11: "차단해제",
        12: "완료"
    };

    // 처리 코드별 아이콘 번호
    function getIconNumber(code) {
        code = String(code || "").trim().toUpperCase();
        switch (code) {
            case "V":
            case "M":
                return 3;
            case "A":
            case "B":
            case "C":
            case "D":
                return 7;
            case "O":
            case "P":
            case "Q":
            case "R":
                return 8;
            case "F":
                return 12;
        }
        var number = Number(code);
        if (/^\d+$/.test(code)) {
            // 차단해제
            if (number >= 100 && number % 100 === 0) {
                return 11;
            }

            // 차로차단
            if (number >= 10 &&
                number < 100 &&
                number % 10 === 0) {
                return 6;
            }
        }
        return null;
    }

    // 시간 값 가져오기
    function getItemTime(item) {
        return pick(item, ["LSTTM_ALTR_DTTM", "FSTTM_RGST_DTTM"]);
    }

    function getTimeNumber(value) {
        var date = parseApiDate(value);
        return date ? date.getTime() : Number.MAX_SAFE_INTEGER;
    }

    var stageTimes = {};
    var occurrenceDetails = [];
    var occurrenceTime = "-";
    var occurrenceNumber = Number.MAX_SAFE_INTEGER;

    // 데이터 시간순 정렬
    var sortedList = stepList.slice().sort(function(a, b) {
        return getTimeNumber(getItemTime(a))- getTimeNumber(getItemTime(b));
    });

    // 각 카테고리 최초 발생 시간 추출
    sortedList.forEach(function(item) {
        var content = String(item["ACDT_ACTN_CTNT"] || "");
        var codeValue = String(item["ACDT_ACTN_CTNT_LLM"] || "");
        var rawTime = getItemTime(item);
        var timeNumber = getTimeNumber(rawTime);

        // 사고발생
        if (content.includes("접수")) {
            var result = content.match(/(\S+)접수/);
            if (timeNumber < occurrenceNumber) {
                occurrenceNumber = timeNumber;
                occurrenceTime = clock(rawTime);
            }
            var description = "접보 " + (result ? result[1] : "");
            if (!occurrenceDetails.includes(description)) {
                occurrenceDetails.push(description);
            }
        }

        // 처리 코드별 시간 추출
        codeValue.split(",").forEach(function(rawCode) {
            var code = rawCode.trim().toUpperCase();
            if (!code) return;
            var iconNum = getIconNumber(code);
            if (iconNum === null) return;
            if (stageTimes[iconNum] === undefined ||
                timeNumber < stageTimes[iconNum]) {
                stageTimes[iconNum] = timeNumber;
            }
        });
    });

    // 카테고리별 데이터
    var stageMap = {};

    function addStage(iconNum, time, detail) {
        if (!detail || detail === "-") return;
        stageMap[iconNum] = {
            iconNum: iconNum,
            time: time || "-",
            detail: detail,
            timeNumber: stageTimes[iconNum] !== undefined
                ? stageTimes[iconNum]
                : Number.MAX_SAFE_INTEGER
        };
    }

    // 1. 사고발생
    if (occurrenceDetails.length > 0) {
        stageMap[1] = {
            iconNum: 1,
            time: occurrenceTime,
            detail: occurrenceDetails.join("\n"),
            timeNumber: occurrenceNumber
        };
    }

    // 3. 교통정보표출
    var trafficDetails = [];
    if (atl.vmsTime !== "-") trafficDetails.push("VMS " + atl.vmsTime);
    if (atl.messageTime !== "-") trafficDetails.push("문자 " + atl.messageTime);
    if (trafficDetails.length > 0) addStage( 3, atl.trafficTime, sortDetail(trafficDetails.join("\n")));

    // 6. 차로차단
    if (atl.hasBlock) {
        var blockDetail = atl.blockedLaneNumbers
            .map(function(number) {
                return number + "차로 차단";
            })
            .join("\n");

        if (atl.blockTime !== "-") {
            blockDetail += "\n" + atl.blockTime;
        }
        addStage(6, atl.blockTime, sortDetail(blockDetail));
    }

    // 7. 현장출동
	var lastDispatchTime = (atl.dispatchDetail?.match(/\b\d{2}:\d{2}\b/g) || []).sort().pop() || "-";
    if (atl.hasDispatch) addStage(7, lastDispatchTime, sortDetail(atl.dispatchDetail));

    // 8. 현장도착
	var lastArrivalTime = (atl.arrivalDetail?.match(/\b\d{2}:\d{2}\b/g) || []).sort().pop() || "-";
    if (atl.hasArrival) addStage(8, lastArrivalTime, sortDetail(atl.arrivalDetail));

    // 11. 차단해제
    if (atl.hasRelease) {
        var releaseDetail = atl.releasedLaneNumbers
            .map(function(number) {
                return number + "차로 해제";
            })
            .join("\n");
        if (atl.releaseTime !== "-") {
            releaseDetail += "\n" + atl.releaseTime;
        }
        addStage(11, atl.releaseTime, sortDetail(releaseDetail));
    }

    // 12. 사고처리완료
    var completion = incidentCompletionTime(etl);
    var isCompleted = hasValue(completion);

    if (isCompleted) {
        var completionNumber = getTimeNumber(completion);
        stageMap[12] = {
            iconNum: 12,
            time: clock(completion),
            detail: "사고처리완료",
            timeNumber: completionNumber
        };
    } else if (stageTimes[12] !== undefined) {
        var completionItem = sortedList.find(function(item) {
            return String(
                item["ACDT_ACTN_CTNT_LLM"] || ""
            ).split(",").some(function(code) {
                return code.trim().toUpperCase() === "F";
            });
        });
        if (completionItem) {
            addStage(12, clock(getItemTime(completionItem)), "사고처리완료");
            isCompleted = true;
        }
    }
    // 카테고리를 배열로 변환
    var filteredList = Object.values(stageMap);

    // 사고발생은 첫 번째 고정, 나머지는 시간순
    filteredList.sort(function(a, b) {
        if (a.iconNum === 1 && b.iconNum !== 1) return -1;
        if (b.iconNum === 1 && a.iconNum !== 1) return 1;
        return a.timeNumber - b.timeNumber;
    });

	function sortDetail(detail) {
		if(!detail || detail === "-") return detail;

		return detail.split("\n").sort(function(a, b) {
			var timeA = a.match(/\b\d{2}:\d{2}\b/)?.[0] || "99:99";
			var timeB = b.match(/\b\d{2}:\d{2}\b/)?.[0] || "99:99";

			return timeA.localeCompare(timeB);
		}).join("\n");
	}

    // 상태 결정
    // 사고발생: red
    // 완료된 처리 단계: green
    // 마지막 진행 단계: amber
    var lastIndex = filteredList.length - 1;

    function getStepColor(index, iconNum) {
        if (iconNum === 1) return "red";
        if (isCompleted) return "green";
        if (index === lastIndex) return "amber";
        return "green";
    }

    /*console.log("actionTimeline:", atl);
    console.log("filteredList:", filteredList);
    console.log("isCompleted:", isCompleted);*/

    // 총 12칸 생성
    for (var i = 0; i < 12; i++) {
        var data = filteredList[i];
        var rowNumber = Math.floor(i / 4) + 1;
        var targetRow = layout.querySelector(".row-" + rowNumber);

        if (!targetRow) continue;

        var processStep = document.createElement("div");
        processStep.className = "process-step";

        // 데이터가 있는 경우에만 내부 HTML 생성
        if (data) {
            var iconNum = data.iconNum;
            var stepColor = getStepColor(i, iconNum);
            processStep.setAttribute("data-stage", i);
            processStep.classList.add("is-" + i);

            // 화살표 생성
            if (i > 0) {
                var stepArrowWrap = document.createElement("div");
                if (i % 4 === 0) {
                    stepArrowWrap.className = "step-arrow-60 " + stepColor;
                    stepArrowWrap.innerHTML = `
                        <svg width="60" height="16"
                             viewBox="0 0 60 16"
                             fill="none"
                             xmlns="http://www.w3.org/2000/svg">
                            <path d="M0 8H58M50 1L58.5 8L50 15"
                                  stroke-width="3"
                                  stroke-linecap="round"
                                  stroke-linejoin="round"/>
                        </svg>`;
                } else {
                    stepArrowWrap.className = "step-arrow-175 " + stepColor;
                    stepArrowWrap.innerHTML = `
                        <svg width="175" height="16"
                             viewBox="0 0 175 16"
                             fill="none"
                             xmlns="http://www.w3.org/2000/svg">
                            <path d="M0 8H173M165 1L173.5 8L165 15"
                                  stroke-width="3"
                                  stroke-linecap="round"
                                  stroke-linejoin="round"/>
                        </svg>`;
                }
                processStep.appendChild(stepArrowWrap);
            }

            // 단계명
            var stepLabel = document.createElement("span");
            stepLabel.className = "step-label";
            stepLabel.textContent = (i + 1) + ". " + iconTitles[iconNum];

            // 아이콘
            var stepIcon = document.createElement("div");
            stepIcon.className = "step-icon " + stepColor;
            stepIcon.innerHTML = getStepIcon(iconNum);

            // 시간
            var timePill = document.createElement("div");
            timePill.className = "time-pill " + stepColor;
            timePill.textContent = data.time;

            // 상세 설명
            var stepDesc = document.createElement("span");
            stepDesc.className = "step-desc";
            stepDesc.style.whiteSpace = "pre-line";

            var descB = document.createElement("b");
            descB.textContent = data.detail;
            stepDesc.appendChild(descB);

            // HTML 추가
            processStep.appendChild(stepLabel);
            processStep.appendChild(stepIcon);
            processStep.appendChild(timePill);
            processStep.appendChild(stepDesc);
        }
        // 데이터가 없으면 빈칸 유지
        targetRow.appendChild(processStep);
    }
}

  function render(analysis, mapData, pk) {
    var analysisResult = analysis.analResult || {};
    var etl = mergedEtlData(analysis);
    var mapResult = mapData.analResult || {};
    var merged = Object.assign({}, analysisResult, mapResult);
    var route = routeInfo(merged);
    var blockType = flag(etl, "FRNT_BLCK_YN") === true ? "전면차단" : pick(merged, ["BLOCK_TYPE", "blockType", "MAR13"]);
    if (hasValue(blockType)) merged.BLOCK_TYPE = blockType;
    var predicted = pick(analysisResult, ["FRCS_BLC_HOUR"]);
    var maxCongestion = pick(mapResult, ["MAR22"]);
    var detour = pick(analysisResult, ["DETOUR_LINE_NAME"]);
    var occurrence = pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]) || pick(mapResult, ["MAR11"]);
    var selectedCoordinate = incidentMapCoordinate(mapData);
    if (selectedCoordinate) addIncidentMarker(String(pk), selectedCoordinate);

    // 상세 모달에서는 API로 확정 가능한 총 예상 소요시간만 실데이터로 교체한다.
    setText(document.querySelector("#incident-modal .ai-total-time"), minutes(predicted));
    setProcessingProgress(etl, predicted);
    setOneClickReport(etl);
	searchCallback(etl)
    setRouteTitle(route, pick(etl, ["KM_VAL"]));
	setInOutIC(mapData.detourBest, route);
	setTopIncidentInfo(etl);

    setText(document.querySelector(".badge-region-large"), pick(etl, ["BRANCH_NAME"])+"지사" || "-");
    var completed = isIncidentCompleted(etl);
    var card = document.getElementById("main-incident-card");
    if (card) {
      card.className = "incident-card " + (completed ? "status-completed grade-C" : "status-processing grade-B");
    }
    setText(document.querySelector(".incident-card .tag.red"), blockType);
    setText(document.querySelector(".occur-time"), occurrence ? getClockHMS(occurrence) : "-");
    setText(document.querySelector(".info-receipt"), occurrence ? "접수번호 " + pick(etl, ["RPRQ_CRCM_SEQ"]) : "-");
    setMainSteps(etl);

	// 사고 정체길이 현황
	setText(document.querySelector(".c-value"), maxCongestion);
	var time = pick(etl, ["RPRQ_CRCM_OCRN_DTTM"]);
	// var time2 = pick(mapResult, ["MAR23"]);
	var resolveTime = pick(mapResult, ["CNGS_HOUR"]);
	var date = new Date(time.replace(" ", "T"));
	date.setMinutes(date.getMinutes() + resolveTime);
	setText(document.querySelector(".c-time-huge"), clock(formatDateTime(date)));

	var percentValue = 49;
	var trafficLengthBar = document.querySelector(".c-bar-fill");
	trafficLengthBar.style.width = percentValue + "%";
	if(percentValue === 100) {
		trafficLengthBar.classList.remove("amber");
		trafficLengthBar.classList.add("green");
		trafficLengthBar.style.background = "green";
	} else {
		trafficLengthBar.classList.remove("green");
		trafficLengthBar.classList.add("amber");
	}

	// 우회도로 안내 값 세팅
    setText(document.querySelector(".detour-start"), pick(mapData.detourBest, ["IN_IC"]));
    setText(document.querySelector(".detour-road"), pick(mapData.detourBest, ["DETR_RDNM"]));
    setText(document.querySelector(".detour-end"), pick(mapData.detourBest, ["OUT_IC"]));

	// 본선 소요시간
	var mainMinutes = pick(mapData.detourBest, ["MAINLINE_TRAVEL_MIN"])
    setText(document.querySelector(".d-donut.red .d-donut-val"), Number.isFinite(mainMinutes) ? Math.trunc(mainMinutes) : "-");

	// 우회 총 소요시간
	var detourTravelMin = pick(mapData.detourBest, ["DETOUR_TRAVEL_MIN"])
    setText(document.querySelector(".d-donut.blue .d-donut-val"), Number.isFinite(detourTravelMin) ? Math.trunc(detourTravelMin) : "-");
	setText(document.querySelector(".d-donut.blue .d-donut-desc"), pick(mapData.detourBest, ["DETR_RDNM"]));

	// 소요시간 뒤에 분 붙이기
	var bun = document.createElement("span");
	bun.textContent = "분";
	document.querySelectorAll(".d-donut-val").forEach(function(el) {
	    el.appendChild(bun.cloneNode(true));
	});

	function setDonutPercent(element, percent) {
	    percent = Math.max(0, Math.min(100, Number(percent)));

	    var color = element.classList.contains("red")
	        ? "var(--status-red)"
	        : "var(--brand-blue)";

	    element.style.background = `conic-gradient(
	        ${color} 0% ${percent}%,
	        var(--chart-track) ${percent}% 100%
	    )`;
	}

	var redDonut = document.querySelector(".d-donut.red");
	var blueDonut = document.querySelector(".d-donut.blue");
	setDonutPercent(redDonut, 35);
	setDonutPercent(blueDonut, 75);

	var arrowDirection = document.querySelector(".d-badge-arrow");

	var calcTime = Math.trunc(mainMinutes) - Math.trunc(detourTravelMin);
	if(calcTime > 0) {
		setText(document.querySelector(".d-badge.calc-time"), calcTime + "분 단축");
		setText(document.querySelector(".d-recommend"), "우회권장");
		arrowDirection.textContent = ">";
	} else if(calcTime == 0) {
		setText(document.querySelector(".d-badge.calc-time"), calcTime + "분 단축");
		setText(document.querySelector(".d-recommend"), "우회권장");
		arrowDirection.textContent = "=";
	} else {
		setText(document.querySelector(".d-badge.calc-time"), Math.abs(calcTime) + "분 연장");
		setText(document.querySelector(".d-recommend"), "본선권장");
		arrowDirection.textContent = "<";
	}

    renderAnalysedIncidentList(pk);
    setStatus("", "idle");
  }

  function loadAnalysisMapData(pk, zone) {
    if (window.LOCKDOWN_MAP_AVAILABLE && window.vmap && typeof window.searchAnalMap === "function") {
      window.searchAnalMap(pk, zone || "");
      return;
    }
    window.LockdownApi.post("searchAnalMap", { pk: pk, cnzn_id: zone || "" })
      .then(function (mapData) {
        document.dispatchEvent(new CustomEvent("lockdown:searchAnalMap", { detail: mapData || {} }));
      })
      .catch(function (error) {
        document.dispatchEvent(new CustomEvent("lockdown:api-error", {
          detail: { endpoint: "searchAnalMap", error: error }
        }));
      });
  }

  function runAnalysis(pkValue, options) {
    options = options || {};
    var background = options.background === true;
    var pk = String(pkValue || "").trim();
    if (!pk) return failAnalysis("사고 목록에서 사고를 선택해 주세요.");
    if (background && state.analysisPolling) return;
    if (background) {
      state.analysisPolling = true;
      setStatus("", "refreshing");
    } else {
      state.analysisPolling = false;
    }
    state.currentPk = pk;
    if (!background) {
      setAnalysisLoading(true, "사고 기본정보와 분석 결과를 요청하고 있습니다.", "사고 분석 중");
      setStatus("분석 API 호출 중…", "running");
    }
    var etlRequest = window.LockdownApi.post("getEtlData", { pk: pk }).catch(function (error) {
      console.warn("getEtlData API 연결 실패", error);
      return null;
    });
    var analysisRequest = window.LockdownApi.post("execAnalysis", { pk: pk });
    Promise.all([
      analysisRequest,
      etlRequest
    ]).then(function (values) {
      if (state.currentPk !== pk) return;
      var analysis = values[0];
      if (values[1] && typeof values[1] === "object") analysis.etlData = values[1];
      state.analysis = analysis;
      var result = analysis.analResult || {};
      var zone = analysis.cnzn_id || pick(result, ["CNZN_ID"]);
      document.querySelector('input[name="acdt_no"]').value = pk;
      document.querySelector('input[name="cnzn_id"]').value = zone || "";
      if (!background) setAnalysisLoading(true, "분석 지도 데이터를 구성하고 있습니다.", "사고 분석 중");
      loadAnalysisMapData(pk, zone);

    }).catch(function (error) {
      state.analysisPolling = false;
      if (state.currentPk !== pk) return;
      if (background) {
        console.warn("사고 분석 자동 갱신 실패", error);
        setStatus("", "idle");
      } else {
        failAnalysis(error.message);
      }
    });
  }

  function startAnalysisPolling() {
    window.setInterval(function () {
      if (state.currentPk && !state.analysisLoading && !state.analysisPolling) {
        runAnalysis(state.currentPk, { background: true });
      }
    }, 3 * 60 * 1000);
  }

  document.addEventListener("lockdown:searchAnalMap", function (event) {
    if (!state.analysis || !state.currentPk) return;
    var backgroundRefresh = state.analysisPolling;
    try {
      render(state.analysis, event.detail || {}, state.currentPk);
      if (backgroundRefresh) {
        setStatus("", "idle");
      }
    } catch (error) {
      if (backgroundRefresh) {
        console.warn("사고 분석 자동 갱신 반영 실패", error);
        setStatus("", "idle");
      } else {
        failAnalysis(error.message || "분석 결과를 반영하지 못했습니다.");
      }
    } finally {
      if (backgroundRefresh) state.analysisPolling = false;
      setAnalysisLoading(false);
    }
  });

  document.addEventListener("lockdown:api-error", function (event) {
    var endpoint = event.detail && event.detail.endpoint;
    if (state.analysisPolling && (endpoint === "execAnalysis" || endpoint === "searchAnalMap")) {
      state.analysisPolling = false;
      setStatus("", "idle");
      return;
    }
    if (state.analysisLoading && (endpoint === "execAnalysis" || endpoint === "searchAnalMap")) {
      failAnalysis((event.detail && event.detail.error && event.detail.error.message) || "API 연결 실패");
    }
  });

  document.addEventListener("DOMContentLoaded", function () {
    installAnalysisBlocker();
    installAnalysisRefreshStatus();
    setAnalysisLoading(true, "사고 목록을 불러오고 있습니다.", "대시보드 준비 중");
    resetLiveDashboard();
    clearPublishingSampleList();
    bindIncidentFilters();
	setCodeOption();
    bindAsIsMapOverlayControls();
    startAnalysisPolling();
    var listFailed = false;
    var incidentListRequest = window.LockdownApi.post("getEtlDataList", {}).catch(function (error) {
      listFailed = true;
      console.warn("getEtlDataList API 연결 실패", error);
      return [];
    });
    Promise.all([
      window.LockdownApi.post("getLineCode", {}),
      incidentListRequest
    ]).then(function (values) {
      state.lines = Array.isArray(values[0]) ? values[0] : [];
      var incidents = analysisCompletedIncidents(values[1]);
      renderIncidentList(incidents);
	  setIncidentAlarmList(incidents);
      startIncidentListPolling();

      var initialPk = new URLSearchParams(window.location.search).get("pk");
      var firstItem = document.querySelector('.tab-content .list-item[data-status="processing"]')
        || document.querySelector(".tab-content .list-item");
      var firstPk = firstItem ? String(firstItem.dataset.pk || "") : "";
      if (initialPk) {
        var initialItem = Array.prototype.slice.call(document.querySelectorAll(".tab-content .list-item"))
          .filter(function (item) { return String(item.dataset.pk || "") === String(initialPk); })[0];
        if (initialItem) {
          initialItem.classList.add("selected");
          activateIncidentStatus(initialItem.dataset.status);
        }
        runAnalysis(initialPk);
      } else if (firstItem) {
        firstItem.classList.add("selected");
        setAnalysisLoading(true, "대시보드 데이터를 준비하고 있습니다.", "대시보드 준비 중");
        runAnalysis(firstPk);
      } else {
        setAnalysisLoading(false);
        if (listFailed) setStatus("사고 목록을 불러오지 못했습니다.", "error");
        else setStatus("사고 목록에 표시할 데이터가 없습니다.", "idle");
      }
    }).catch(function (error) {
      setAnalysisLoading(false);
      setStatus(error.message, "error");
    });
  });

  var today = new Date();
  var weekAgo = new Date(today);

  weekAgo.setDate(today.getDate() - 7);

  function formatDate(date) {
      var year = date.getFullYear();
      var month = String(date.getMonth() + 1).padStart(2, "0");
      var day = String(date.getDate()).padStart(2, "0");

      return `${year}-${month}-${day}`;
  }

  document.querySelector("#history-start-date").value = formatDate(weekAgo);
  document.querySelector("#history-end-date").value = formatDate(today);

  document.querySelector("#history-start-date").addEventListener("click", function() {
      this.showPicker();
  });

  document.querySelector("#history-end-date").addEventListener("click", function() {
      this.showPicker();
  });

document.querySelector(".hist-btn-white").addEventListener("click", () => {
	var today = new Date();
  	var weekAgo = new Date(today);
	weekAgo.setDate(today.getDate() - 7);
  	document.querySelector("#history-start-date").value = formatDate(weekAgo);
	document.querySelector("#history-end-date").value = formatDate(today);
	document.getElementById("incident-num").value = "";
	document.querySelector("#accident-code").selectedIndex = 0;

	setFilterElement()
	requestHistoryApi(params);
});

  var params = {};
  document.querySelector(".hist-btn-blue").addEventListener("click", () => {
	currentPage = 1;
	isLoading = true;
    params = {
        "page": String(currentPage),
        "pageSize": String(pageSize),
	    "startDate": "",    // 조회시작 연월일 "2026-10-01 00:00:00"
	    "endDate": "",      // 조회종료 연월일
	    "rprqCrcmSeq": "",   // 사고접수번호
	    "rprqCrcmTypeCd": "" // 접보유형코드
	}
	setFilterElement()
	requestHistoryApi(params);
  });

  function setFilterElement() {
      var startDate = document.getElementById("history-start-date").value;
      var endDate = document.getElementById("history-end-date").value;
      var incidentNum = document.getElementById("incident-num").value;
      var accidentCode = document.getElementById("accident-code").value;

      params.startDate = startDate ? startDate + " 00:00:00" : "";
      params.endDate = endDate ? endDate + " 23:59:59" : "";
      params.rprqCrcmSeq = incidentNum ? incidentNum : "";
      params.rprqCrcmTypeCd = accidentCode ? accidentCode : "";
  }

  document.querySelector(".btn-history").addEventListener("click", () => {
	currentPage = 1;
    params = {
        "page": String(currentPage),
        "pageSize": String(pageSize),
	    "startDate": "",    // 조회시작 연월일 "2026-10-01 00:00:00"
	    "endDate": "",      // 조회종료 연월일
	    "rprqCrcmSeq": "",   // 사고접수번호
	    "rprqCrcmTypeCd": "" // 접보유형코드
	}
	setFilterElement()
	requestHistoryApi(params);
  })

  function requestHistoryApi(params) {
	window.LockdownApi.post("getTrafficList", params).then(function (items) {
		renderIncidentHistoryList(items)
    }).catch(function (error) {
      console.warn("과거 사고 이력 조회 실패", error);
    }).then(function () {

    });
  }

  var currentPage = 1;
  var pageSize = 10;
  var totalPages = 0;
  var isLoading = false;

  function renderIncidentHistoryList(items) {
  	var incidentCount = Number(items.totCount) || 0;
  	totalPages = Math.ceil(incidentCount / pageSize);
  	document.querySelector(".hist-footer-info").textContent = "조회기간: " + formatDate(weekAgo) + " ~ " + formatDate(today) + "  |  전체 " + incidentCount + "건";
  	var countElement = document.querySelector(".text-blue");
  	if (countElement) {
  	    countElement.textContent = incidentCount + "건";
  	}

  	var histTable = document.querySelector(".hist-table");
      var histTableTbody = histTable.querySelector("tbody");
      if(currentPage === 1) {
          if(histTableTbody) histTableTbody.remove();
          histTableTbody = document.createElement("tbody");
          histTable.appendChild(histTableTbody);
      }

      if(!histTableTbody) {
          histTableTbody = document.createElement("tbody");
          histTable.appendChild(histTableTbody);
      }

  	(items.data || []).forEach(function(item, idx) {
  		var mainRow = document.createElement("tr");
  	    mainRow.className = "main-row";
  		mainRow.id = "row-" + ((currentPage - 1) * pageSize + idx + 1);
  		var td1 = document.createElement("td");
  		td1.textContent =  ((currentPage - 1) * pageSize + idx + 1);
  		mainRow.appendChild(td1);

		// 사고접수번호
		var td2 = document.createElement("td");
		td2.textContent = item.RPRQ_CRCM_SEQ;
		mainRow.appendChild(td2);

		// 발생 일시
	    var td3 = document.createElement("td");
	    td3.textContent = formatDateTime(item.RPRQ_CRCM_OCRN_DTTM);
	    mainRow.appendChild(td3);

		// 사고 위치
	    var td4 = document.createElement("td");
		td4.style.textAlign = "left";
		td4.style.paddingLeft = "20px";
	    td4.textContent = item.ACDT_LOCT_CTNT;
	    mainRow.appendChild(td4);

	    var td5 = document.createElement("td");
	    var sokboButton = document.createElement("button");
		sokboButton.className = "badge-sokbo";
		sokboButton.textContent = "속보 " + item.NEW_CNT + "건";

		var sokboButtonSpan = document.createElement("span");
		sokboButtonSpan.innerHTML = `
			<span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"></path></svg></span>
		`;
		sokboButton.appendChild(sokboButtonSpan);
		var histSubList = document.createElement("div");
		histSubList.className = "hist-sub-list";

		sokboButton.onclick = function() {
			mainRow.classList.toggle("active");
			subRow.classList.toggle("open");
			sokboButton.classList.toggle("active");
			if (sokboButton.classList.contains("active")) sokboButtonSpan.innerHTML = `<span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 8.75L7 5.25L10.5 8.75" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="white"/></svg></span>`;
			else sokboButtonSpan.innerHTML = `<span><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 5.25L7 8.75L10.5 5.25" stroke-width="0.63" stroke-linecap="round" stroke-linejoin="round" stroke="#1E5FD9"></path></svg></span>`;

			window.LockdownApi.post("getEtlDataAcdtList", {pk: item.RPRQ_CRCM_SEQ}).then(function (list) {
				var accdtList = list.ACDT_ACTN_LIST;
				accdtList.forEach(item => {
					var histSubItem = document.createElement("div");
					histSubItem.className = "hist-sub-item";
					histSubList.appendChild(histSubItem);

					var badgeTime = document.createElement("span");
					badgeTime.className = "badge-time";
					badgeTime.textContent = (item.LSTTM_ALTR_DTTM).substring(5);
					histSubItem.appendChild(badgeTime);

					var sokboText = document.createElement("span");
					sokboText.textContent = item.ACDT_ACTN_CTNT;
					histSubItem.appendChild(sokboText);
				})
		    }).catch(function (error) {
		      console.warn("속보 세팅 실패", error);
		    }).then(function () {

		    });
		};
	    td5.appendChild(sokboButton);
	    mainRow.appendChild(td5);

	    var subRow = document.createElement("tr");
	    subRow.className = "sub-row";
		subRow.id = "sub-row-" + (idx+1);

		var colspanTd = document.createElement("td");
		colspanTd.colSpan = "5";
		subRow.appendChild(colspanTd);

		var histSubContainer = document.createElement("div");
		histSubContainer.className = "hist-sub-container";
		histSubContainer.appendChild(histSubList);
		colspanTd.appendChild(histSubContainer);

		histTableTbody.appendChild(mainRow)
		histTableTbody.appendChild(subRow)
	});
	isLoading = false;
	checkIncidentScroll();
	// 페이징 버튼 생성
    // renderIncidentPagination(Math.ceil(items.totCount / pageSize));
  }

  function changeIncidentPage(page) {
      currentPage = page;

      // 기존 검색 조건 유지하고 페이지 번호만 변경
      params.page = String(page);

      // API 재요청
      requestHistoryApi(params);
  }

  function initIncidentInfiniteScroll() {
  	var scrollContainer = document.querySelector(".hist-table-wrap");
  	if(!scrollContainer) return;
  	scrollContainer.addEventListener("scroll", function() {
  		if(isLoading || currentPage >= totalPages) {
  			return;
  		}

  		if(scrollContainer.scrollTop + scrollContainer.clientHeight >= scrollContainer.scrollHeight - 30) {
  			isLoading = true;
  			currentPage++;
  			params.page = String(currentPage);
  			requestHistoryApi(params);
  		}
  	});
  }
  initIncidentInfiniteScroll();

  function checkIncidentScroll() {
  	var scrollContainer = document.querySelector(".hist-table-wrap");
  	if(isLoading || currentPage >= totalPages) return;
  	if(scrollContainer.scrollHeight <= scrollContainer.clientHeight) {
  		isLoading = true;
  		currentPage++;
  		params.page = String(currentPage);
  		requestHistoryApi(params);
  	}
  }

  function renderIncidentPagination(totalPages) {
      var pagination = document.querySelector(".hist-footer .pagination");
      pagination.innerHTML = "";
      var maxVisiblePages = 5;
      var startPage = Math.floor((currentPage - 1) / maxVisiblePages) * maxVisiblePages + 1;
      var endPage = Math.min(startPage + maxVisiblePages - 1, totalPages);

      function addButton(text, page, disabled, active) {
          var button = document.createElement("button");
          button.type = "button";
          button.className = "page-btn";
          button.textContent = text;
          button.disabled = disabled;
          if (active)  button.classList.add("active");
		  button.addEventListener("click", function() {
		      if (disabled || currentPage === page) return;
		      changeIncidentPage(page);
		  });
          pagination.appendChild(button);
      }
      addButton("«", 1, currentPage === 1, false);
      addButton("‹", currentPage - 1, currentPage === 1, false);
      for (var i = startPage; i <= endPage; i++) {
          addButton(String(i), i, false, currentPage === i);
      }
      addButton("›", currentPage + 1, currentPage >= totalPages, false);
      addButton("»", totalPages, currentPage >= totalPages, false);
  }

  function formatDateTime(value) {
      if (!value) return "-";
      var date = new Date(value);
      if (isNaN(date.getTime())) return "-";
      var pad = (num) => String(num).padStart(2, "0");
      return (
          pad(date.getMonth() + 1) + "/" +
          pad(date.getDate()) + " " +
          pad(date.getHours()) + ":" +
          pad(date.getMinutes())
      );
  }

  function sumCount(value) {
      var matches = value.match(/\d+(?=대)/g);
      if (!matches) return "없음";
      return matches.reduce((sum, num) => sum + Number(num), 0) + "대";
  }

  function setIncidentAlarmList(incidents) {
	var newIncidents = incidents.filter(item => item["NEW_YN"] === "Y");
	var totalCount = newIncidents.length;
	if(totalCount > 0) {
		document.getElementById("btnAlarm").classList.add("new-accident");
		document.getElementById("alarmCountPill").style.display = "block";
	} else {
		document.getElementById("btnAlarm").classList.remove("new-accident");
		document.getElementById("alarmCountPill").style.display = "none";
	}
	document.getElementById("alarmBadge").textContent = totalCount;
	document.getElementById("alarmCountPill").textContent = totalCount;
	document.querySelectorAll("#alarmList .alarm-item").forEach(item => item.remove());
	var alarmList = document.querySelector(".alarm-list");
	newIncidents.forEach(item => {
		var alarmItem = document.createElement("div");
		alarmItem.setAttribute("data-pk", item.RPRQ_CRCM_SEQ);
		alarmItem.className = "alarm-item"
		alarmList.appendChild(alarmItem);

		var alarmItemLeft = document.createElement("div");
		alarmItemLeft.className = "alarm-item-left"
		alarmItem.appendChild(alarmItemLeft);

		var unreadDot = document.createElement("span");
		unreadDot.className = "unread-dot"
		alarmItemLeft.appendChild(unreadDot);

		var alarmItemInfo = document.createElement("div");
		alarmItemInfo.className = "alarm-item-info"
		alarmItemLeft.appendChild(alarmItemInfo);

		var alarmItemTitle = document.createElement("div");
		alarmItemTitle.className = "alarm-item-title"
		alarmItemTitle.textContent =
			item["BRANCH_NAME"] + " / " +
			item["ACDT_LOCT_CTNT"] + " / "
			item["KM_VAL"] + " / "
			item["ACDT_LOCT_CTNT"];
		alarmItemInfo.appendChild(alarmItemTitle);

		var alarmItemTime = document.createElement("div");
		alarmItemTime.className = "alarm-item-time"
		alarmItemTime.textContent = clock(item["RPRQ_CRCM_OCRN_DTTM"]) + " 발생 · " + timeAgo(item["RPRQ_CRCM_OCRN_DTTM"]);
		alarmItemInfo.appendChild(alarmItemTime);

		var alarmItemArrow = document.createElement("span");
		alarmItemArrow.className = "alarm-item-arrow"
		alarmItemArrow.textContent = "❯";
		alarmItem.appendChild(alarmItemArrow);

		alarmItem.addEventListener("click", function (el) {
			// 읽음 처리 및 카운트 갱신
		    el.currentTarget.classList.add('read')
		    updateAlarmCount();
		    // document.getElementById('alarmDropdown').classList.remove('active');
			putReadInfo(item.RPRQ_CRCM_SEQ)
			runAnalysis(item.RPRQ_CRCM_SEQ);
		});
	});
  }

  function putReadInfo(pk) {
	window.readApi.put("setReadInfo", {pk: pk})
	.then(function (items) {
		console.log("setReadInfo: ", items);
    }).catch(function (error) {
      console.warn("setReadInfo 실패", error);
    }).then(function () {

    });
  }

  function timeAgo(value) {
  	var date = new Date(value.replace(" ", "T"));
  	var now = new Date();
  	var diff = Math.floor((now - date) / 1000);
  	if (isNaN(diff)) return "-";
  	if (diff < 60) return "방금 전";
  	if (diff < 3600) return Math.floor(diff / 60) + "분 전";
  	if (diff < 86400) return Math.floor(diff / 3600) + "시간 전";
  	if (diff < 2592000) return Math.floor(diff / 86400) + "일 전";
  	if (diff < 31536000) return Math.floor(diff / 2592000) + "개월 전";
  	return Math.floor(diff / 31536000) + "년 전";
  }


})();
