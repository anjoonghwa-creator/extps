var vmap;
var _layers;
const _sysKey = 'TIS';
var vectorLayer_link;
var vectorLayer_detour;
var hour = document.getElementById('hour');
var pop = null ;
var xy = [14148697.445280691, 4476589.251449499];
var acdtMarkerLayer;
var icjcAddMarkerLayer;
// var vmsAddMarkerLayer;
var vms2AddMarkerLayer;
var vmsAnalAddMarkerLayer;
var mVmsList = [];
var vmsList = [];
var tooltip = document.getElementById('info');
// var pixel = [0,0];
var overlay = window.ol && ol.Overlay ? new ol.Overlay({
	element: tooltip,
	offset: [10, 0],
	positioning: 'bottom-left'
}) : null;
var _center = [14148697.445280691, 4476589.251449499];
var _zoom = 3;
var mapRefreshInProgress = false;
var mapRefreshStatusTimer = null;
window.LOCKDOWN_MAP_AVAILABLE = false;

function markMapUnavailable(error) {
	window.LOCKDOWN_MAP_AVAILABLE = false;
	var panel = document.getElementById('mapLiveStatus');
	var label = document.getElementById('mapRefreshLabel');
	var time = document.getElementById('mapRefreshTime');
	var button = document.getElementById('mapRefreshButton');
	if (panel) panel.setAttribute('data-refresh-state', 'error');
	if (label) label.textContent = '지도 로딩 실패';
	if (time) time.textContent = '';
	if (button) button.disabled = true;
	document.querySelectorAll('#asisMapOverlays input[type="checkbox"]').forEach(function(input) {
		input.disabled = true;
	});
	console.warn('지도 라이브러리를 불러오지 못해 데이터 화면만 표시합니다.', error || 'map library unavailable');
}

function bindSafeVWorldHomeControl() {
	var homeImage = document.querySelector('.ol-zoom-init > img');
	if (!homeImage || homeImage.getAttribute('data-safe-home') === 'true') return;

	// VWorld 기본 초기화는 사용자 벡터 source까지 clear하므로 이벤트가 없는 복제본으로 교체한다.
	var safeHomeImage = homeImage.cloneNode(true);
	safeHomeImage.setAttribute('data-safe-home', 'true');
	safeHomeImage.setAttribute('title', '초기 위치');
	homeImage.parentNode.replaceChild(safeHomeImage, homeImage);
	safeHomeImage.addEventListener('click', function(event) {
		event.preventDefault();
		event.stopPropagation();
		event.stopImmediatePropagation();
		if (!vmap || !vmap.getView) return;
		vmap.getView().setCenter(_center.slice());
		vmap.getView().setZoom(_zoom);
	});
}

//function initMap() {
$(document).ready(function() {
	var isReal = true;
	if($('input[name="host_addr"]').val() == '127.0.0.1'){
		isReal = false;
		_zoom = 9
	} else {
		isReal = true;
	}
	var providerReady = isReal
		? !!(window.ol && window.himap && himap.layer && himap.Map)
		: !!(window.ol && window.vw && vw.ol3 && vw.ol3.Map);
	if (!providerReady || !overlay) {
		markMapUnavailable();
		return;
	}
	// isReal = false;
	// _zoom = 9;
	try {
	if(isReal){
		_layers = [
			new himap.layer.vworld.Base({visible:true, sysKey:_sysKey})
		];
		vmap = new himap.Map({
			sysKey: _sysKey,
			target: 'vmap',
			layers: _layers,
			center: _center,
			zoom: _zoom
		});

	} else {
		vw.ol3.CameraPosition.center = _center;
		vw.ol3.CameraPosition.zoom = _zoom;
		vw.ol3.MapOptions = {
			basemapType : vw.ol3.BasemapType.GRAPHIC,//도로맵
			controlDensity : vw.ol3.DensityType.BASIC,
			interactionDensity : vw.ol3.DensityType.BASIC,
			controlsAutoArrange : true,
			homePosition : vw.ol3.CameraPosition,
			initPosition : vw.ol3.CameraPosition,
		};
		vmap = new vw.ol3.Map("vmap", vw.ol3.MapOptions);
		bindSafeVWorldHomeControl();

	}
	window.LOCKDOWN_MAP_AVAILABLE = true;
	$("#hider").hide();
	$('div#vw-zoombar.vw-zoombar').css('top', '10px');
	$('div#vw-zoombar.vw-zoombar').css('right', '10px');
	$('div#vw-zoombar.vw-zoombar').css('display', 'none');
	vmap.addOverlay(overlay);
	// vmap.on('pointermove', displayTooltip);
	vmap.on('singleclick', displayPopup);
	var mapRefreshButton = document.getElementById('mapRefreshButton');
	if (mapRefreshButton) mapRefreshButton.addEventListener('click', function(event) {
		event.preventDefault();
		event.stopPropagation();
		fnRefreshSpeed();
	});
	fnMapSearch();
	} catch (error) {
		markMapUnavailable(error);
	}
});

function updateMapRefreshTime() {
	var timeElement = document.getElementById('mapRefreshTime');
	if (!timeElement) return;
	var now = new Date();
	function pad(value) { return String(value).padStart(2, '0'); }
	timeElement.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
}

function setMapRefreshState(state) {
	var panel = document.getElementById('mapLiveStatus');
	var label = document.getElementById('mapRefreshLabel');
	var button = document.getElementById('mapRefreshButton');
	if (!panel || !label || !button) return;
	if (mapRefreshStatusTimer) {
		clearTimeout(mapRefreshStatusTimer);
		mapRefreshStatusTimer = null;
	}
	panel.setAttribute('data-refresh-state', state);
	panel.setAttribute('aria-busy', state === 'loading' ? 'true' : 'false');
	button.disabled = state === 'loading';
	label.textContent = state === 'loading' ? '업데이트 중…'
		: (state === 'success' ? '업데이트 완료' : (state === 'error' ? '업데이트 실패' : '최종 갱신'));
	if (state === 'success' || state === 'error') {
		mapRefreshStatusTimer = setTimeout(function() {
			if (!mapRefreshInProgress) setMapRefreshState('idle');
		}, state === 'success' ? 1200 : 2400);
	}
}

function finishMapRefresh(success) {
	mapRefreshInProgress = false;
	if (success) updateMapRefreshTime();
	setMapRefreshState(success ? 'success' : 'error');
}

document.addEventListener('lockdown:api-error', function(event) {
	var endpoint = event.detail && event.detail.endpoint;
	if (mapRefreshInProgress && endpoint === 'searchInitMap') finishMapRefresh(false);
});

function displayTooltip(evt) {
    var pixel = evt.pixel;
    var feature = vmap.forEachFeatureAtPixel(pixel, function(feature) { return feature; });
    tooltip.style.display = feature ? '' : 'none';
	tooltip.innerHTML = '';
    if (feature && feature.get('LBL_NAME')) {
        overlay.setPosition(evt.coordinate);
        tooltip.innerHTML = "&nbsp;"+feature.get('LBL_NAME')+" "+ (feature.get('GUBUN')=='1'?" IC":" JC")+"&nbsp;";
    } else if (feature && feature.get('VMS_ID') && vmsTitObject.vmsTitList.filter(item=>item.VMS_ID == feature.get('VMS_ID'))[0] != undefined) {
        overlay.setPosition(evt.coordinate);
        tooltip.innerHTML = vmsTitObject.vmsTitList.filter(item=>item.VMS_ID == feature.get('VMS_ID'))[0].VMS_TIT + "<br/>[VMS ID : "+feature.get('VMS_ID')+"]";
    } else if (feature && feature.get('VMS_ID') && feature.get('MARKER') == 'TRUE') {
		overlay.setPosition(evt.coordinate);
		if(vmsTitObject.vmsTitList.filter(item=>item.VMS_ID == feature.get('VMS_ID')).length>0)
        	tooltip.innerHTML = vmsTitObject.vmsTitList.filter(item=>item.VMS_ID == feature.get('VMS_ID'))[0].VMS_TIT + "<br/>[VMS ID : "+feature.get('VMS_ID')+"]";
		else
        	tooltip.innerHTML =  "[VMS ID : "+feature.get('VMS_ID')+"]";
		// } else if (feature && feature.get('KEY')) {
			//     overlay.setPosition(evt.coordinate);
			// 	tooltip.innerHTML = '';
			// tooltip.innerHTML = `${$('select[name="route_cd"] option:selected').text()} / ${$('select[name="drct_cd"] option:selected').text()} / ${$('input[name="acdt_ocrn_dstnc"]').val()}km`;
	} else if (feature && feature.get('name') ) {
		overlay.setPosition(evt.coordinate);
		// 현재 대시보드에는 AS-IS의 .summary-item이 없으므로 feature 자체 명칭을 사용한다.
		tooltip.textContent = String(feature.get('name') || '');
    }
}

function displayPopup(evt) {//클릭 했을 때
	var ff = vmap.hasFeatureAtPixel(evt.pixel); //클릭한 pixel에 마커가 있으면 true, 없으면 false
	if(ff) //있으면 openPopup() 실행
		popOpen(evt);
}

function popOpen(evt) {
    var pixel = evt.pixel;
    var feature = vmap.forEachFeatureAtPixel(pixel, function(feature) { return feature; });
    var vmsType2Pop = $('#vmsType2Pop');
	if( vmsList.map(item=>item.vms_id).includes(feature.get('VMS_ID')) ){
		$(vmsType2Pop).show();
		$("#hider").show();
		$('.header_title').text(vmsTitObject.vmsTitList.filter(item=>item.VMS_ID == feature.get('VMS_ID'))[0].VMS_TIT);
		$('#vmsTxt').text($('select[name="alfc_blc_yn"]').val() == 'Y' ? '전면차단 우회 이용' : '사고발생 정체 주의');
	}
	$('.road_info_name').css('height', '0');
	$('.road_info_name').css('padding', '7px 20px');
	$('.ic_mark').css('background', "url('')");
	$('.road_name').css('height', '0');
	$('.vms_txt_shorts').css('color', '#000');
	$('#vmsTxt2').text('');
}

function popClose() {
	var vmsType2Pop = $('#vmsType2Pop');
	$(vmsType2Pop).hide();
	$("#hider").hide();
}

// VMS/VDS 실시간 교통상황을 5분마다 갱신한다.
setInterval(function() {
	if (window.LOCKDOWN_MAP_AVAILABLE) fnRefreshSpeed();
}, 60000 * 5);
/* 조회 */
function fnRefreshSpeed(){
	if (mapRefreshInProgress) return;
	mapRefreshInProgress = true;
	setMapRefreshState('loading');
	var option = {
		url      : "lockdown/ac/searchInitMap.do",
		param	 : {},
		callback : fnRefreshSpeedCallback
	}
	showLoaderAll(true);
	callService(option);
}

/* 조회 callback */
function fnRefreshSpeedCallback(json){
	var data = json.data;
	var code = data.CODE;
	if (code == "S") {
		try {
			showLoaderAll(false);
			mVmsList = data.mVmsList;
			fnDrawRealtimeMap(data);
			lineNoAddMarker(lineObject);
			if($('input[name="acdt_no"]').val() != '' && $('input[name="cnzn_id"]').val() != '')
				refreshInoutInfo($('input[name="acdt_no"]').val(), $('input[name="cnzn_id"]').val());
			finishMapRefresh(true);
		} catch (error) {
			finishMapRefresh(false);
			throw error;
		}
	} else {
		showLoaderAll(false);
		finishMapRefresh(false);
	}
}

function refreshInoutInfo(acdtNo, cnznId) {
	var option = {
		url: "lockdown/ac/searchAnalMap.do",
		param: {
			pk: acdtNo,
			cnzn_id: cnznId
		},
		callback: refreshInoutInfoCallback
	};
	showLoaderAll(true);
	callService(option);
}
function refreshInoutInfoCallback(json) {
	var code = json.data.CODE;
	var inTgInfo = json.data.inTgInfo;
	var outTgInfo = json.data.outTgInfo;
	$('.traffic-volume').remove();
	setTimeout(() => {
		inoutIcAddPopup(inTgInfo, outTgInfo);
	}, 200);
	showLoaderAll(false);
}
/* 조회 */
function fnMapSearch(){
	var option = {
		url      : "lockdown/ac/searchInitMap.do",
		param	 : {},
		callback : fnMapSearchCallback
	}
	callService(option);
}

/* 조회 callback */
function fnMapSearchCallback(json){
	resetMap();
	var data = json.data;
	var code = data.CODE;
	if (code == "S") {
		mVmsList = data.mVmsList;
		fnDrawRealtimeMap(data);
		lineNoAddMarker(lineObject);
		updateMapRefreshTime();
	}
	var milepost = $('input[name="acdt_ocrn_dstnc"]');
	if(milepost.val() != '' && $('input[name="acdt_no"]').val() != '' && $('input[name="cnzn_id"]').val()){
		searchAnalMap($('input[name="acdt_no"]').val(), $('input[name="cnzn_id"]').val());
	} else {
		milepost.focus();
	}
}

function searchAnalMap(acdtNo, cnznId) {
	var option = {
		url: "lockdown/ac/searchAnalMap.do",
		param: {
			pk: acdtNo,
			cnzn_id: cnznId
		},
		callback: searchAnalMapCallback
	};
	clearAnalMap();
	showLoaderAll(true);
	callService(option);
}

function searchAnalMapCallback(json) {
	var code = json.data.CODE;
	var analResult = json.data.analResult;//vds_id, blockType
	var inTgInfo = json.data.inTgInfo;
	var outTgInfo = json.data.outTgInfo;
	vmsList = (json.data.vmsAffectedList).map(item => {item.vms_id = item.vms_id; return item;});
	var detourList = json.data.stndLinkList
	var btn = document.querySelector(".d-btn");
	if(!detourList || detourList.length === 0) {
		document.querySelector(".d-btn").style.display = "none";
	} else {
		document.querySelector(".d-btn").disabled = !detourList || detourList.length === 0;
		document.querySelector(".d-btn").style.display = "block";
	}
	searchDetourMap(detourList)

	$('span[data-info=mar11]').html(analResult.MAR11);
	$('span[data-info=mar12]').html(analResult.MAR12);
	$('span[data-info=mar13]').html(analResult.MAR13);
	$('span[data-info=mar21]').html(analResult.MAR21);
	$('span[data-info=mar22]').html(analResult.MAR22);
	$('span[data-info=mar23]').html(analResult.MAR23);
	$('span[data-info=mar24]').html(analResult.MAR24);
	$('.popup').css('width', '178px');

	setTimeout(() => {
		if(!$('input[name=ic]').prop('checked'))
			$('input[name=ic]').trigger('click');
	}, 100);
	setTimeout(() => {
		if(!$('input[name=vms]').prop('checked'))
			$('input[name=vms]').trigger('click');
	}, 150);
	setTimeout(() => {
		inoutIcAddPopup(inTgInfo, outTgInfo);
	}, 200);
	setTimeout(() => {
		vmsAnalAddMarker(json.data.vmsAffectedList, 'ico_vms2');//ㄷㅗㅣㅁ
	}, 250);
		// vmsAddMarker(json.data.vmsAffectedList, 'ico_vms2');//안됨
		// vmsAnalAddMarker(mVmsList, 'ico_vms2');//nope
		// inoutIcAddPopupBak(inTgInfo, outTgInfo);
		// vmsAddPopup(vmsList);

	setTimeout(() => {
		acdtAddMarker(analResult.VDS_ID, analResult.BLOCK_TYPE, gtmObject, analResult.LAT, analResult.LNG);
	}, 300);
	$('div#popup.vw-popup').each(function() {
		$(this).removeClass('vw-popup');
	});
	showLoaderAll(false);
}

function clearAnalMap() {
	$('div#popup.vw-popup').each(function() {
		$(this).html('');
	});
	$('span[data-info=mar11]').html('');
	$('span[data-info=mar12]').html('');
	$('span[data-info=mar13]').html('');
	$('span[data-info=mar21]').html('');
	$('span[data-info=mar22]').html('');
	$('span[data-info=mar23]').html('');
	$('span[data-info=mar24]').html('');

	if(icjcAddMarkerLayer)
		vmap.removeLayer(icjcAddMarkerLayer);
	$('input[name=ic]').prop('checked', false);
	if(vms2AddMarkerLayer)
		vmap.removeLayer(vms2AddMarkerLayer);
	$('input[name=vms]').prop('checked', false);

	$('div.traffic-overlay').each(function(index){
      $(this).parent().html('');
    });
	$('.traffic-volume').remove();
	if(acdtMarkerLayer)
		vmap.removeLayer(acdtMarkerLayer);
}

function resetMap() {
	$('div#popup.vw-popup').each(function() {
		$(this).html('');
	});
	$('input[name="acdt_no"]').val('');
	$('input[name="acdt_ocrn_dstnc"]').val('');

	$('span[data-info=mar11]').html('');
	$('span[data-info=mar12]').html('');
	$('span[data-info=mar13]').html('');
	$('span[data-info=mar21]').html('');
	$('span[data-info=mar22]').html('');
	$('span[data-info=mar23]').html('');
	$('span[data-info=mar24]').html('');

	$('.result-value').text('부분 차단');
	$('.result-time-value').text('');
	$('.result-time-date').text('');
	$('.result-value-wide').text('');
	$('.result-value.road').text('');
	$('.vms-content').text('');
	$('.vms-table-row').each(function() {
		$(this).find('.vms-table-cell').each(function() {
			$(this).html('');
		});
	});
	if(vmsAnalAddMarkerLayer)
		vmap.removeLayer(vmsAnalAddMarkerLayer);
	if(icjcAddMarkerLayer)
		vmap.removeLayer(icjcAddMarkerLayer);
	$('input[name=ic]').prop('checked', false);
	if(vms2AddMarkerLayer)
		vmap.removeLayer(vms2AddMarkerLayer);
	$('input[name=vms]').prop('checked', false);


	$('div.traffic-overlay').each(function(index){
      $(this).parent().html('');
    });
	$('.traffic-volume').remove();
	if(acdtMarkerLayer)
		vmap.removeLayer(acdtMarkerLayer);
}

function inoutIcAddPopup(inTgInfo, outTgInfo){
	var coordinate ;
	var hdms ;
	var content;
	var tgInfo = inTgInfo.concat(outTgInfo);
	$('.traffic-volume').remove();
	inTgInfo.forEach((item, idx) =>{
		// <div class="traffic-volume" style="top: ${(idx+1)*100}px; left: 10px; z-index: 5;">
		var _top = (idx+1)*125 + 48;
		$('#mapAnalysisOverlayAnchor').after(`
		<div class="traffic-volume" style="top: ${_top}px; left: 856px; z-index: 5;">
			<div class="traffic-volume-header">${item.ic_name}</div>
			<div class="traffic-volume-content">
				<div class="traffic-volume-label">교<br />통<br />량</div>
				<div class="traffic-volume-data">
					<div class="traffic-data">
						<div class="traffic-number">${item.tcs_avg_v}</div>
						<div class="traffic-bar blue"></div>
						<div class="traffic-type">전주</div>
					</div>
				</div>
				<div class="traffic-volume-data">
					<div class="traffic-data">
						<div class="traffic-number">${item.tcs_month_avg_v}</div>
						<div class="traffic-bar green"></div>
						<div class="traffic-type">평균</div>
					</div>
				</div>
				<div class="traffic-volume-data">
					<div class="traffic-data">
						<div class="traffic-number">${item.tcs_v}</div>
						<div class="traffic-bar orange"></div>
						<div class="traffic-type current">현재</div>
					</div>
				</div>
			</div>
		</div>`);
			$('div#popup.vw-popup').css("min-width", "0px");
		});

		// var breakHtml = `<div class="traffic-volume" style="top: 200px;left: 10px;z-index: 5;width: 185px;">
		// <p>a</p>
		// </div>`;
		// $('#mapAnalysisOverlayAnchor').after(breakHtml);

		var inTgLength = inTgInfo.length+1;
		outTgInfo.forEach((item, idx) =>{
			var _top = (idx+1+inTgLength)*125 - 20;
			$('#mapAnalysisOverlayAnchor').after(`
			<div class="traffic-volume" style="top: ${_top}px; left: 856px; z-index: 5;">
				<div class="traffic-volume-header">${item.ic_name}</div>
				<div class="traffic-volume-content">
					<div class="traffic-volume-label">교<br />통<br />량</div>
					<div class="traffic-volume-data">
						<div class="traffic-data">
							<div class="traffic-number">${item.tcs_avg_v}</div>
							<div class="traffic-bar blue"></div>
							<div class="traffic-type">전주</div>
						</div>
					</div>
					<div class="traffic-volume-data">
						<div class="traffic-data">
							<div class="traffic-number">${item.tcs_month_avg_v}</div>
							<div class="traffic-bar green"></div>
							<div class="traffic-type">평균</div>
						</div>
					</div>
					<div class="traffic-volume-data">
						<div class="traffic-data">
							<div class="traffic-number">${item.tcs_v}</div>
							<div class="traffic-bar orange"></div>
							<div class="traffic-type current">현재</div>
						</div>
					</div>
				</div>
			</div>`);
			$('div#popup.vw-popup').css("min-width", "0px");
	});
	$('.traffic-volume').css('width', '255px');
	$('.traffic-number').css('font-size', '20px');
	mapRefresh();
}

function vmsAddPopup(vmsList){
	var vmsFeatures = new ol.format.GeoJSON().readFeatures(vmsObject, {
		featureProjection: 'EPSG:3857'
	});
	var filterFeatures;
	let data_arr =  vmsList.map(item =>item.vms_id);
	vmsFeatures = vmsFeatures.filter( feature =>
		data_arr.includes(	feature.getProperties().VMS_ID)
	);



	// filterFeatures[0].getGeometry().flatCoordinates[1]
	// filterFeatures.forEach(function(feature) {
    //   var geom = feature.getGeometry();
    //   geom.translate(deltaX, deltaY);
    // //   feature.setGeometry(geom);
    // });


	var coordinate ;
	var hdms ;
	var content;
	let vmsContent = $('.vms-content').text();
	vmsList.forEach(item =>{
		filterFeatures = vmsFeatures.filter( feature => { return feature.getProperties()['VMS_ID'] == item.vms_id } );
		// coordinate = epsg4326ToEpsg3857(item.xcord, item.ycord);
		if(filterFeatures.length>0){
			coordinate = [filterFeatures[0].getGeometry().flatCoordinates[0], filterFeatures[0].getGeometry().flatCoordinates[1]];
			hdms = "";
			content = hdms ;
			pop = new vw.ol3.popup.Popup();
			pop.title = "";
			//   pop.content = "오픈 API 2.0 WEB";
			pop._element.innerHTML = `<div class="traffic-overlay">
				<div class="traffic-title">${item.jj_name} ${item.jc_name}구간</div>
				<div class="traffic-status">${vmsContent}</div>
				</div>`;
				pop.autoFan = false;
			vmap.addOverlay(pop);
			pop.show(content,coordinate);
			$('div#popup.vw-popup').css("min-width", "0px");
			// if(vmsList.length)
			// 	$('input[name=vms]').prop('checked', true);
		}
	});
}

/* 실시간 체크 여부 */
function is_checked(){
    var isChecked = $('#realTime').is(':checked');

	if(isChecked){
		$(".ui-datepicker-trigger").attr("disabled", true);
		$("#searchDate").val("").attr("disabled", true);
		$("#hour").val("none").attr("disabled", true);
		$("#min").val("none").attr("disabled", true);
		$("#realTime").val("true")
	}else{
		$(".ui-datepicker-trigger").attr("disabled", false);
		$("#searchDate").attr("disabled", false);
		$("#hour").val("none").attr("disabled", false);
		$("#min").val("none").attr("disabled", false);
		$("#realTime").val("false")
	}
}

/* 실시간 VDS 지도 */
function fnDrawRealtimeMap(data){
	// callback data
	var data_vds_id = data.mVdsSpeedList.map(item =>item.vds_id);
	var data_dsrc_id = data.mVdsSpeedList.map(item =>item.dsrc_link_id);
	var data_congzone_id = data.mVdsSpeedList.map(item =>item.congzone_id);
	//var data_node_id = data.mVdsSpeedList.map(item => item.node_id);
	var vdsStyle = {};
	var dsrcStyle = {};
	var congzoneStyle = {};
	var mVdsSpeedList = data.mVdsSpeedList;
	mVdsSpeedList.forEach(item =>{
		if(item.vds_id) vdsStyle[item.vds_id] = item.vds_s;
		if(item.dsrc_link_id) dsrcStyle[item.dsrc_link_id] = item.dsrc_s;
		if(item.congzone_id) congzoneStyle[item.congzone_id] = item.con_s;
	});

    var styles = {
        'MultiLineString' : [
		    new ol.style.Style({
		        stroke: new ol.style.Stroke({
		            color: '#C8C8C8',
		            width: 8,
					lineJoin: 'miter',
					lineCap: 'miter'
		        })
		    }),
            new ol.style.Style({
                stroke : new ol.style.Stroke({
                    color : '#076828',
                    width : 7,
					lineJoin: 'miter',
					lineCap: 'miter'
                })
            })
        ],
		'gray': [
	        new ol.style.Style({
	            stroke: new ol.style.Stroke({
	                color: '#808080',
	                width: 7,
					lineJoin: 'miter',
					lineCap: 'miter'
	            })
	        })
	    ]
    };

	function setStyle(speed){
		if(speed >= 80){
			// return '#076828'
			return 'rgba(7, 104, 40, 0.5)';
		}else if(speed >= 40 && speed < 80){
//			return '#FFFF00'
			// return '#ffbc00'
			return 'rgba(255, 188, 0, 0.5)';
		// }else if(speed >= 20 && speed < 40){
		// 	return '#ff8a00'
		}else if(speed > 0 && speed < 40){
			// return '#ff000d'
			return 'rgba(255, 0, 13, 0.5)';
		// }else if(speed > 0 && speed <= 10){
		// 	return '#000';
		}else{
			// return '#747474';
			return 'rgba(116, 116, 116, 0.5)';
		}
	}

    var styleFunction = function(feature){
		var feature_vds_id = feature.getProperties().vds_id;
		var feature_dsrc_id = feature.getProperties().dsrc_link_id;
		var feature_congzone_id = feature.getProperties().congzone_id;
		//var feature_node_id = feature.getProperties().node_id;

		if(feature_vds_id && !data_vds_id.includes(feature_vds_id)
			&& feature_dsrc_id && !data_dsrc_id.includes(feature_dsrc_id)
		    //&& feature_node_id && !data_node_id.includes(feature_node_id)
			&& feature_congzone_id && !data_congzone_id.includes(feature_congzone_id)){
			return styles['gray'];
		}

		var vds_s = vdsStyle[feature_vds_id];
		var dsrc_s = dsrcStyle[feature_dsrc_id];
		var con_s = congzoneStyle[feature_congzone_id];

		var color;
        if (vds_s !== undefined) {
            color = setStyle(vds_s);
        } else if (dsrc_s !== undefined) {
            color = setStyle(dsrc_s);
        } else if (con_s !== undefined) {
            color = setStyle(con_s);
        } else {
            color = '#C8C8C8';
        }

		return [
            new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: '#C8C8C8',
                    width: 8,
                    lineJoin: 'miter',
                    lineCap: 'miter'
                })
            }),
            new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: color,
                    width: 7,
                    lineJoin: 'miter',
                    lineCap: 'miter'
                })
            })
        ];
    };
    function createVectorLayer(geoJsonObject, styleFunction) {
		var data_line_code = data.mVdsSpeedList.map(item=>item.line_code);

		var filterFeatures = new ol.format.GeoJSON().readFeatures(geoJsonObject, {
			featureProjection: 'EPSG:3857'
		}).filter(feature => {
			var feature_line_code = feature.getProperties().route_id;
			return data_line_code.includes(feature_line_code);
		});
		var tp = 'typeVds';//document.getElementById('type').value;
		var selectObj = tp == 'typeVds' ? 'vds_id'
		: tp == 'typeDsrc' ? 'dsrc_link_id'
		: tp == 'typeCongzone' ? 'congzone_id'
		//: tp == 'typeNode' ? 'node_id'
		: 'vds_id';
		filterFeatures = filterFeatures.filter( feature => { return !(feature.getProperties()[selectObj] == '' || feature.getProperties()[selectObj] == null) } );

        var vectorSource = new ol.source.Vector({
            features: filterFeatures
        });

        return new ol.layer.Vector({
			name: 'createVectorLayer',
            source: vectorSource,
            style: styleFunction
        });
    }
	function createVectorLayerLine(geoJsonObject, styleFunction2) {
		var data_line_code = data.mVdsSpeedList.map(item=>item.line_code);

		var filterFeatures = new ol.format.GeoJSON().readFeatures(geoJsonObject, {
			featureProjection: 'EPSG:3857'
		});
		// var filterFeatures = new ol.format.GeoJSON().readFeatures(geoJsonObject, {
		// 	featureProjection: 'EPSG:3857'
		// }).filter(feature => {
		// 	var feature_line_code = feature.getProperties().KEY.substr(0,4);
		// 	return data_line_code.includes(feature_line_code);
		// });
		var tp = 'typeVds';//document.getElementById('type').value;
		var selectObj = tp == 'typeVds' ? 'CONG_ZONE'
		: tp == 'typeDsrc' ? 'dsrc_link_id'
		: tp == 'typeCongzone' ? 'congzone_id'
		//: tp == 'typeNode' ? 'node_id'
		: 'vds_id';
		filterFeatures = filterFeatures.filter( feature => { return !(feature.getProperties()[selectObj] == '' || feature.getProperties()[selectObj] == null) } );

		var vectorSource = new ol.source.Vector({
			features: filterFeatures
		});

		return new ol.layer.Vector({
			name: 'createVectorLayerLine',
			source: vectorSource,
			style: styleFunction2
		});
	}
	//사고지점
	// function createVectorLayerPoint(geoJsonObject, styleFunction) {
	// 	var filterFeatures = new ol.format.GeoJSON().readFeatures(geoJsonObject, {
    //     // featureProjection: 'EPSG:4326'
    //     featureProjection: 'EPSG:3857'
	// 	}).filter(feature => {
	// 		return (feature.getProperties().LINE_CODE+"") != '999';
	// 		// return (feature.getProperties().NAME+"") != '39';
	// 	});
	// 	// filterFeatures = filterFeatures.filter( feature => { return  (feature.getProperties()['route_id'] == '0500'
	// 	// 	||feature.getProperties()['route_id'] == '0010'
	// 	// 	||feature.getProperties()['route_id'] == '0600'
	// 	// 	||feature.getProperties()['route_id'] == '0150'
	// 	// ) });
	// 	// filterFeatures = filterFeatures.filter( feature => { return feature.getProperties().link_type === 1.0; } );

	// 	var vectorSource = new ol.source.Vector({
	// 		features: filterFeatures
	// 	});

	// 	return new ol.layer.Vector({
	// 		source: vectorSource,
	// 		style: styleFunction
	// 	});
	// }
	var styleFunctionLine = function(feature){
			var feature_vds_id = feature.getProperties().KEY;
			var feature_dsrc_id = feature.getProperties().dsrc_link_id;
			var feature_congzone_id = feature.getProperties().congzone_id;
			//var feature_node_id = feature.getProperties().node_id;

			if(feature_vds_id && !data_vds_id.includes(feature_vds_id)
				&& feature_dsrc_id && !data_dsrc_id.includes(feature_dsrc_id)
			    //&& feature_node_id && !data_node_id.includes(feature_node_id)
				&& feature_congzone_id && !data_congzone_id.includes(feature_congzone_id)){
				return styles['gray'];
			}

			var vds_s = vdsStyle[feature_vds_id];
			var dsrc_s = dsrcStyle[feature_dsrc_id];
			var con_s = congzoneStyle[feature_congzone_id];

			var color;
	        if (vds_s !== undefined) {
	            color = setStyle(vds_s);
	        } else if (dsrc_s !== undefined) {
	            color = setStyle(dsrc_s);
	        } else if (con_s !== undefined) {
	            color = setStyle(con_s);
	        } else {
	            color = '#C8C8C8';
	        }

			return [
	            new ol.style.Style({
	                stroke: new ol.style.Stroke({
	                    color: '#C8C8C8',
	                    width: 1,
	                    lineJoin: 'miter',
	                    lineCap: 'miter'
	                })
	            }),
	            new ol.style.Style({
	                stroke: new ol.style.Stroke({
	                    color: color,
	                    width: 1,
	                    lineJoin: 'miter',
	                    lineCap: 'miter'
	                }),
					fill: new ol.style.Fill({
						color: color, // 선의 내부 색상
					})
	            }),
			]
	    };
	var styleFunctionPoint = function(feature){
		return new ol.style.Style({
					image: new ol.style.Circle({
						radius: 6, // 원의 반지름
						fill: new ol.style.Fill({
							color: 'rgba(255, 0, 0, 0.7)'
						}),
						stroke: new ol.style.Stroke({
							color: 'rgba(255, 127, 80, 0.5)',
							width: 1          // 테두리 두께
						})
					})
				});  // 기본 스타일 적용
	}
    if (vectorLayer_link) {
        vmap.removeLayer(vectorLayer_link);
    }

	vectorLayer_link = createVectorLayerLine(gtmObject, styleFunctionLine);
	vmap.addLayer(vectorLayer_link);
}

function searchDetourMap(detourList) {
    var ids = detourList.map(function(item) {
        return String(item.STND_LINK_ID);
    });

    if (vectorLayer_detour) {
        vmap.removeLayer(vectorLayer_detour);
    }

    vectorLayer_detour = createDetourLayer(detourObject, ids);
    vmap.addLayer(vectorLayer_detour);
}

function createDetourLayer(geoJsonObject, ids) {
    var features = new ol.format.GeoJSON().readFeatures(geoJsonObject, {
        dataProjection: 'EPSG:3857',
        featureProjection: 'EPSG:3857'
    });

    var filteredFeatures = features.filter(function(feature) {
        return ids.includes(String(feature.get('LINK_ID')));
    });

    return new ol.layer.Vector({
        name: 'detourLayer',
        source: new ol.source.Vector({
            features: filteredFeatures
        }),
        style: new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: '#0066FF',
                width: 3
            }),
            fill: new ol.style.Fill({
                color: 'rgba(0, 102, 255, 0.2)'
            })
        })
    });
}

 function searchDetourMapCallback(json) {
    searchDetourMap(json.data);
}

// function vmsAddMarker(arr, pngFileName){ //경도 위도 이름값(마커들을 구분하기위해)
// 	var filterFeatures = new ol.format.GeoJSON().readFeatures(vmsObject, {
// 		featureProjection: 'EPSG:3857'
// 	});
// 	let data_arr =  arr.map(item =>item.vms_id);
// 	filterFeatures = filterFeatures.filter( feature =>
// 		data_arr.includes(	feature.getProperties().VMS_ID)
// 	);
// 	var styleFunctionPoint = function(feature){
// 			return new ol.style.Style({
// 	    	        image: new ol.style.Icon({ //마커 이미지
// 	    	        	opacity: 0.7, //투명도 1=100%
// 	    	        	scale: 0.30, //크기 1=100%
// 	    	            src: '/asset/images/lockdown/ico_vms.png'
// 	    	        }),
// 	    	        zindex: 7,
// 				});  // 기본 스타일 적용
// 		}
// 	var vectorSource = new ol.source.Vector({
// 		features: filterFeatures
// 	});

// 	vmsAddMarkerLayer = new ol.layer.Vector({
// 			source: vectorSource,
// 			style: styleFunctionPoint
// 		});
// 	//지도에 마커가 그려진 레이어 추가
// 	vmap.addLayer(	vmsAddMarkerLayer);

// }

function vmsAnalAddMarker(arr, pngFileName){ //경도 위도 이름값(마커들을 구분하기위해)
	var filterFeatures = new ol.format.GeoJSON().readFeatures(vmsObject, {
		featureProjection: 'EPSG:3857'
	});
	let data_arr =  arr.map(item =>item.vms_id);
	filterFeatures = filterFeatures.filter( feature =>
		data_arr.includes(	feature.getProperties().VMS_ID)
	);
	var styleFunctionPoint = function(feature){
			return new ol.style.Style({
	    	        image: new ol.style.Icon({ //마커 이미지
	    	        	opacity: 1, //투명도 1=100%
	    	        	scale: 0.55, //크기 1=100%
	    	            src: '/asset/images/lockdown/ico_vms2.png'
	    	        }),
	    	        zindex: 8,
				});  // 기본 스타일 적용
		}
	var vectorSource = new ol.source.Vector({
		features: filterFeatures
	});
	if(vmsAnalAddMarkerLayer)
		vmap.removeLayer(vmsAnalAddMarkerLayer)

	vmsAnalAddMarkerLayer = new ol.layer.Vector({
		name: 'vmsAnalAddMarker',
			source: vectorSource,
			style: styleFunctionPoint,
		});
	vmsAnalAddMarkerLayer.setZIndex(8);
	//지도에 마커가 그려진 레이어 추가
	vmap.addLayer(vmsAnalAddMarkerLayer);

}

var mapView; //맵 뷰 선언 : 보여지는 지도 부분 설정
var hover=null; //마우스 이벤트에 사용될 변수
function icjcAddMarker(){ //경도 위도 이름값(마커들을 구분하기위해)
	var filterFeatures = new ol.format.GeoJSON().readFeatures(lblNameObject, {
		featureProjection: 'EPSG:3857'
	});
	var selectObj = 'LBL_NAME';
	filterFeatures = filterFeatures.filter( feature => {
		return !(feature.getProperties()[selectObj] == '' || feature.getProperties()[selectObj] == null)
	} );
	var styleFunctionPoint = function(feature){
		return new ol.style.Style({
	        image: new ol.style.Icon({ //마커 이미지
	        	opacity: 0.8, //투명도 1=100%
	        	scale: 0.35, //크기 1=100%
	            src: (feature.getProperties().GUBUN == 1?'/asset/images/lockdown/ico_ic.png':'/asset/images/lockdown/ico_jc.png')
	        }),
	        zindex: 7
		});  // 기본 스타일 적용
	}
	var vectorSource = new ol.source.Vector({
		features: filterFeatures
	});
	icjcAddMarkerLayer = new ol.layer.Vector({
		name: 'icjcAddMarker',
		source: vectorSource,
		style: styleFunctionPoint
	});
	//지도에 마커가 그려진 레이어 추가
	vmap.addLayer(icjcAddMarkerLayer);

}
function vms2AddMarker(){ //경도 위도 이름값(마커들을 구분하기위해)
	var filterFeatures = new ol.format.GeoJSON().readFeatures(vms2Object, {
		featureProjection: 'EPSG:3857'
	});
	var selectObj = 'VMS_ID';
	filterFeatures = filterFeatures.filter( feature => {
		return !(feature.getProperties()[selectObj] == '' || feature.getProperties()[selectObj] == null)
	});
	var styleFunctionPoint = function(feature){
			return new ol.style.Style({
    	        image: new ol.style.Icon({ //마커 이미지
    	        	opacity: 0.8, //투명도 1=100%
    	        	scale: 0.35, //크기 1=100%
    	            src: '/asset/images/lockdown/ico_vms.png'
    	        }),
    	        zindex: 1
			});  // 기본 스타일 적용
		}
	var vectorSource = new ol.source.Vector({
		features: filterFeatures
	});
	if(vms2AddMarkerLayer)
		vmap.removeLayer(	vms2AddMarkerLayer);
	vms2AddMarkerLayer = new ol.layer.Vector({
		name: 'vms2AddMarker',
		source: vectorSource,
		style: styleFunctionPoint
	});
	// vms2AddMarkerLayer.setZIndex(0);

	//지도에 마커가 그려진 레이어 추가
	vmap.addLayer(vms2AddMarkerLayer);

}
function lineNoAddMarker(){ //노선번호방패 (마커들을 구분하기위해)
	var filterFeatures = new ol.format.GeoJSON().readFeatures(lineObject, {
		featureProjection: 'EPSG:3857'
	});
	var selectObj = 'NAME';
	filterFeatures = filterFeatures.filter( feature => {
		return !(feature.getProperties()[selectObj] == '' || feature.getProperties()[selectObj] == null)
	} );
	var styleFunctionPoint = function(feature){
			return new ol.style.Style([{
	    	        image: new ol.style.Icon({ //마커 이미지
	    	        	opacity: 1, //투명도 1=100%
	    	        	scale: 0.4, //크기 1=100%
	    	            src: (feature.getProperties().GUBUN == 1?'/asset/images/lockdown/ico_ic.png':'/asset/images/lockdown/ico_way.png')
	    	        }),
	    	        zindex: 10
					},{
	    	        image: new ol.style.Icon({ //마커 이미지
	    	        	opacity: 1, //투명도 1=100%
	    	        	scale: 0.6, //크기 1=100%
	    	            src: (feature.getProperties().GUBUN == 1?'/asset/images/lockdown/ico_ic.png':'/asset/images/lockdown/ico_way.png')
	    	        }),
	    	        zindex: 10
					}]);  // 기본 스타일 적용
		}
	var vectorSource = new ol.source.Vector({
		features: filterFeatures
	});
	//지도에 마커가 그려진 레이어 추가
	vmap.addLayer(	new ol.layer.Vector({
		name: 'lineNoAddMarker',
			source: vectorSource,
			style: styleFunctionPoint
		}));
}

function epsg3857ToEpsg4326(x, y) {
	const lon = x * 180 / 20037508.34;
	let lat = y * 180 / 20037508.34;
	lat = 180 / Math.PI * (2 * Math.atan(Math.exp(lat * Math.PI / 180)) - Math.PI / 2);
	return [lon, lat];
}
function epsg4326ToEpsg3857(lon, lat) {
	let x = (lon * 20037508.34) / 180;
	let y = Math.log(Math.tan(((90 + lat) * Math.PI) / 360)) /
	(Math.PI / 180);
	y = (y * 20037508.34) / 180;
	return [x, y];
}

function acdtAddMarker(vdsId, name, geoJsonObject, _lat, _lng){ //경도 위도 이름값(마커들을 구분하기위해)

	var features = new ol.format.GeoJSON().readFeatures(geoJsonObject, {
		featureProjection: 'EPSG:3857'
	});
	feature = features.filter( feature => { return feature.getProperties()['KEY'] == vdsId } );
	let lat = 0, lng = 0, x = 0, y = 0;
	if(_lat && _lng) {
		lat = _lat;
		lng = _lng;
		[x, y] = epsg4326ToEpsg3857(lat, lng);
	} else {
		if(feature.length > 0) {
			x = feature[0].getProperties().x;
			y = feature[0].getProperties().y;
			[lat, lng] = epsg3857ToEpsg4326(x, y);
		}

	}
	// 예시 사용법:
	// console.log(lat, lng);
	// 마커 feature 설정
	var feature = new ol.Feature({
		geometry: new ol.geom.Point(ol.proj.fromLonLat([lat, lng])), //경도 위도에 포인트 설정
		name: name
	});

	var svg = `<svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g filter="url(#filter0_d_318_4484)"><rect x="28" y="28" width="44" height="44" rx="22" fill="#E1252F"/><rect x="29.5" y="29.5" width="41" height="41" rx="20.5" stroke="white" stroke-width="3"/><path d="M50.0001 37.9584L36.9668 60.625H63.0335L50.0001 37.9584Z" stroke-width="0.99" stroke-linecap="round" stroke-linejoin="round" stroke="white"/><path d="M46.2944 56.4159L44.4665 57.1993L45.0226 55.1465L42.4505 54.3869L44.6166 53.0031L43.5428 50.6991L46.1946 51.1252L46.6345 48.6914L48.319 50.5074" stroke-width="0.392857" stroke="white"/><use xlink:href="#stroke0_318_4484" fill="white"/><mask id="stroke1_318_4484" fill="white"><use xlink:href="#stroke0_318_4484"/></mask><path d="M56.4228 53.2421L55.7798 51.1798C55.6865 50.8795 55.5071 50.6184 55.2671 50.4333C55.027 50.2483 54.7385 50.1489 54.4426 50.1492H50.157C49.8611 50.1489 49.5726 50.2483 49.3325 50.4333C49.0925 50.6184 48.9131 50.8795 48.8198 51.1798L48.1768 53.2421C48.0058 53.3186 47.8598 53.4474 47.7571 53.6123C47.6544 53.7773 47.5996 53.971 47.5996 54.1692V56.6817C47.5996 57.0525 47.7895 57.3731 48.0696 57.5475V58.0026C48.0696 58.1358 48.1191 58.2636 48.2073 58.3579C48.2954 58.4521 48.415 58.5051 48.5396 58.5051H49.0097C49.1343 58.5051 49.2539 58.4521 49.342 58.3579C49.4302 58.2636 49.4797 58.1358 49.4797 58.0026V57.6867H55.1199V58.0026C55.1199 58.1358 55.1694 58.2636 55.2576 58.3579C55.3457 58.4521 55.4653 58.5051 55.5899 58.5051H56.0599C56.1846 58.5051 56.3042 58.4521 56.3923 58.3579C56.4804 58.2636 56.53 58.1358 56.53 58.0026V57.5475C56.6726 57.4601 56.7911 57.334 56.8736 57.182C56.9561 57.03 56.9997 56.8574 57 56.6817V54.1692C57 53.971 56.9452 53.7773 56.8425 53.6123C56.7398 53.4474 56.5938 53.3186 56.4228 53.2421ZM50.157 51.1542H54.4421C54.6447 51.1542 54.8243 51.2919 54.8882 51.4979L55.408 53.1642H49.1916L49.7109 51.4979C49.7421 51.3978 49.802 51.3107 49.882 51.249C49.9621 51.1873 50.0583 51.1541 50.157 51.1542ZM49.2447 56.1792C49.1521 56.1792 49.0604 56.1596 48.9748 56.1217C48.8892 56.0838 48.8115 56.0282 48.746 55.9582C48.6806 55.8881 48.6287 55.805 48.5932 55.7135C48.5578 55.622 48.5396 55.524 48.5396 55.4249C48.5397 55.3259 48.558 55.2279 48.5934 55.1364C48.6289 55.0449 48.6809 54.9618 48.7464 54.8918C48.8119 54.8219 48.8897 54.7663 48.9752 54.7285C49.0608 54.6906 49.1525 54.6712 49.2451 54.6712C49.4322 54.6713 49.6116 54.7508 49.7438 54.8922C49.876 55.0337 49.9502 55.2255 49.9502 55.4254C49.9501 55.6254 49.8757 55.8172 49.7434 55.9585C49.6111 56.0999 49.4317 56.1793 49.2447 56.1792ZM55.3549 56.1792C55.2623 56.1792 55.1706 56.1596 55.085 56.1217C54.9995 56.0838 54.9218 56.0282 54.8563 55.9582C54.7908 55.8881 54.7389 55.805 54.7035 55.7135C54.6681 55.622 54.6499 55.524 54.6499 55.4249C54.6499 55.3259 54.6682 55.2279 54.7037 55.1364C54.7391 55.0449 54.7911 54.9618 54.8566 54.8918C54.9221 54.8219 54.9999 54.7663 55.0855 54.7285C55.1711 54.6906 55.2628 54.6712 55.3554 54.6712C55.5424 54.6713 55.7218 54.7508 55.854 54.8922C55.9862 55.0337 56.0605 55.2255 56.0604 55.4254C56.0604 55.6254 55.986 55.8172 55.8537 55.9585C55.7214 56.0999 55.542 56.1793 55.3549 56.1792Z" stroke-width="3.81944" stroke="white" mask="url(#stroke1_318_4484)"/></g><defs><filter id="filter0_d_318_4484" x="0" y="0" width="100" height="100" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feMorphology radius="6" operator="dilate" in="SourceAlpha" result="effect1_dropShadow_318_4484"/><feOffset/><feGaussianBlur stdDeviation="11"/><feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 0.29 0 0 0 0 0.33 0 0 0 0.6 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_318_4484"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_318_4484" result="shape"/></filter><path id="stroke0_318_4484" d="M56.4228 53.2421L55.7798 51.1798C55.6865 50.8795 55.5071 50.6184 55.2671 50.4333C55.027 50.2483 54.7385 50.1489 54.4426 50.1492H50.157C49.8611 50.1489 49.5726 50.2483 49.3325 50.4333C49.0925 50.6184 48.9131 50.8795 48.8198 51.1798L48.1768 53.2421C48.0058 53.3186 47.8598 53.4474 47.7571 53.6123C47.6544 53.7773 47.5996 53.971 47.5996 54.1692V56.6817C47.5996 57.0525 47.7895 57.3731 48.0696 57.5475V58.0026C48.0696 58.1358 48.1191 58.2636 48.2073 58.3579C48.2954 58.4521 48.415 58.5051 48.5396 58.5051H49.0097C49.1343 58.5051 49.2539 58.4521 49.342 58.3579C49.4302 58.2636 49.4797 58.1358 49.4797 58.0026V57.6867H55.1199V58.0026C55.1199 58.1358 55.1694 58.2636 55.2576 58.3579C55.3457 58.4521 55.4653 58.5051 55.5899 58.5051H56.0599C56.1846 58.5051 56.3042 58.4521 56.3923 58.3579C56.4804 58.2636 56.53 58.1358 56.53 58.0026V57.5475C56.6726 57.4601 56.7911 57.334 56.8736 57.182C56.9561 57.03 56.9997 56.8574 57 56.6817V54.1692C57 53.971 56.9452 53.7773 56.8425 53.6123C56.7398 53.4474 56.5938 53.3186 56.4228 53.2421ZM50.157 51.1542H54.4421C54.6447 51.1542 54.8243 51.2919 54.8882 51.4979L55.408 53.1642H49.1916L49.7109 51.4979C49.7421 51.3978 49.802 51.3107 49.882 51.249C49.9621 51.1873 50.0583 51.1541 50.157 51.1542ZM49.2447 56.1792C49.1521 56.1792 49.0604 56.1596 48.9748 56.1217C48.8892 56.0838 48.8115 56.0282 48.746 55.9582C48.6806 55.8881 48.6287 55.805 48.5932 55.7135C48.5578 55.622 48.5396 55.524 48.5396 55.4249C48.5397 55.3259 48.558 55.2279 48.5934 55.1364C48.6289 55.0449 48.6809 54.9618 48.7464 54.8918C48.8119 54.8219 48.8897 54.7663 48.9752 54.7285C49.0608 54.6906 49.1525 54.6712 49.2451 54.6712C49.4322 54.6713 49.6116 54.7508 49.7438 54.8922C49.876 55.0337 49.9502 55.2255 49.9502 55.4254C49.9501 55.6254 49.8757 55.8172 49.7434 55.9585C49.6111 56.0999 49.4317 56.1793 49.2447 56.1792ZM55.3549 56.1792C55.2623 56.1792 55.1706 56.1596 55.085 56.1217C54.9995 56.0838 54.9218 56.0282 54.8563 55.9582C54.7908 55.8881 54.7389 55.805 54.7035 55.7135C54.6681 55.622 54.6499 55.524 54.6499 55.4249C54.6499 55.3259 54.6682 55.2279 54.7037 55.1364C54.7391 55.0449 54.7911 54.9618 54.8566 54.8918C54.9221 54.8219 54.9999 54.7663 55.0855 54.7285C55.1711 54.6906 55.2628 54.6712 55.3554 54.6712C55.5424 54.6713 55.7218 54.7508 55.854 54.8922C55.9862 55.0337 56.0605 55.2255 56.0604 55.4254C56.0604 55.6254 55.986 55.8172 55.8537 55.9585C55.7214 56.0999 55.542 56.1793 55.3549 56.1792Z"/></defs></svg>`;

	// 마커 스타일 설정
	var markerStyle = new ol.style.Style({
		image: new ol.style.Icon({ //마커 이미지
			opacity: 1, //투명도 1=100%
			scale: 1, //크기 1=100%
			src: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg)
		}),
		zindex: 10
	});

	// 마커 레이어에 들어갈 소스 생성
	var markerSource = new ol.source.Vector({
		features: [feature] //feature의 집합
	});

	// 마커 레이어 생성
	acdtMarkerLayer = new ol.layer.Vector({
		name: 'acdtAddMarker',
		source: markerSource, //마커 feacture들
		style: markerStyle //마커 스타일
	});


	// vmap.getView().setCenter([x, y]);
	// 지도에 마커가 그려진 레이어 추가
	vmap.addLayer(acdtMarkerLayer);
	vmap.getView().setCenter([x, y]);
	xy = [x, y];
	vmap.getView().setZoom(_zoom+2);
//    vmap.getView().setZoom(13);
}
function mapRefresh(){
	const isLeftCollapsed = document.getElementById('left-panel').classList.contains("collapsed");
	const isMiddleCollapsed = document.getElementById('middle-panel').classList.contains("collapsed");
	setTimeout(function() {
		vmap.updateSize();
	}, 500);
	if(!isLeftCollapsed && !isMiddleCollapsed) {
		$('div.traffic-volume').each(function() {
			$(this).css('left', '856px');
		});
	} else if(!isLeftCollapsed && isMiddleCollapsed) {
		$('div.traffic-volume').each(function() {
			$(this).css('left', '533px');
		});
	} else if(isLeftCollapsed && !isMiddleCollapsed) {
		$('div.traffic-volume').each(function() {
			$(this).css('left', '498px');
		});
	} else if(isLeftCollapsed && isMiddleCollapsed) {
		$('div.traffic-volume').each(function() {
			$(this).css('left', '175px');
		});
	}
	// oo 1137 856px
	// ox 1460 533px togglePanel('middle-panel')
	// xo 1495 498px togglePanel('left-panel')
	// xx 1818 175px

}

function vmsClickHandler(_checked) {
	if(_checked)
		vms2AddMarker();
	else
		vmap.removeLayer(vms2AddMarkerLayer);

}
function icClickHandler(_checked) {
	if(_checked)
		icjcAddMarker();
	else
		vmap.removeLayer(icjcAddMarkerLayer);
}
(function($){
	$(".layer_toggle_button").click(function(){
// 		$(".map_information_layer_wrap").toggleClass("layerOpen");
// 		map.events.register("zoomend", this, function (e) {
//     if (map.getZoom() === this.mapMaxZoom) {
//         // Don't cluster at this level. No matter what.
//         this.vector.strategies[0].threshold = 1000;
//         console.log("setting the clustering strategy to 1000");
//     }
// });
	});
	$("#btnExec").click(function(){
		//fnExecAnalysis();
	});
    $(window).on("load",function(){
        $(".sc_btm").mCustomScrollbar({
            theme:"dark"
        });
    });


})(jQuery);
