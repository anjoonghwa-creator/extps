﻿﻿$.support.cors = true;
jQuery.support.cors = true;
function info(str) {if (typeof console != "undefined") {console.info(str);}}

var himap = {};
himap.source = {};
himap.tilegrid = {};
himap.interaction = {};

himap.url = {};
try {
  himap.url.SERVER_MODE = comLib.getServerInfo('server.mode');
  if(himap.url.SERVER_MODE == null) himap.url.SERVER_MODE = 'R';
} catch(e) {
  himap.url.SERVER_MODE = 'R';
}
himap.url.SERVER_IP = 'ngeoapi.ex.co.kr:8443'; // 맵서버 IP
//himap.url.SERVER_IP = 'geoapi.ex.co.kr'; //개발
if(himap.url.SERVER_MODE == 'R') {
  var hrefSplit = location.href.split("//");
  var mapUrl = hrefSplit[1].substring(0, hrefSplit[1].indexOf("/"));
  var ip_166_66 = 'spa.ex.co.kr:8443||ngeoapi.ex.co.kr:8443||rom.ex.co.kr:5001||spa.ex.co.kr:5003||trs.ex.co.kr:5002||ock.ex.co.kr:5003';
  var ip_167_66 = '172.16.167.150:5003||dsboard.ex.co.kr:5001||opt.ex.co.kr:5001||slope.ex.co.kr:5003';
  var ip_166_67 = ''; //건설(전자종합상황도, 모바일 전자종합상황도) -> 기존 소스 사용
  var ip_167_67 = 'big.ex.co.kr:5005||pave.ex.co.kr:5002||ter.ex.co.kr:5001||str.ex.co.kr:5001||fac.ex.co.kr:5004||smart.ex.co.kr:5001||elec.ex.co.kr:5002';

  if(ip_166_66.indexOf(mapUrl) >= 0) himap.url.SERVER_IP = 'ngeoapi.ex.co.kr:8443';
  else if(ip_167_66.indexOf(mapUrl) >= 0) himap.url.SERVER_IP = 'ngeoapi.ex.co.kr:8443';
  else if(ip_167_67.indexOf(mapUrl) >= 0) himap.url.SERVER_IP = 'ngeoapi.ex.co.kr:8443';
  else himap.url.SERVER_IP = 'ngeoapi.ex.co.kr:8443';
}

himap.url.SERVER_PATH = 'https://ngeoapi.ex.co.kr:8443/geoserver/EX_GGTM/wms';
himap.url.TILE_HANDLER = 'https://ngeoapi.ex.co.kr:8443/himap2021/VDSTIME?';
himap.url.BASE_TILE_PATH = 'https://ngeoapi.ex.co.kr:8443/Pretile/Dmapbase'; //도로공사 수치지도
himap.url.AIR_PATH = 'https://ngeoapi.ex.co.kr:8443/Pretile/Airphoto';
himap.url.VWORLD_PROXY = 'https://ngeoapi.ex.co.kr:8443/proxy/';

// 시스템 별 할당된 시스템키(공간정보 현황관리 참조)
var sysKeys_ = new ol.Object({
	'DEM': 'DEM_01', //재난
	'ELE': 'ELE_01||ELE_02', //전기시설물
	'FAC': 'FAC_01', //부대시설
	'IOT': 'IOT_01', //IoT
	'LMC': 'LMC_01', //차선유지(포장 하위)
	'MAP': 'MAP_01', //유지관리 전자지도
	'MOF': 'MOF_01||MOF_02||MOF_03', //모바일
	'OCK': 'OCK_01||OCK_02', //원클릭
	'OCT': 'OCT_01||OCT_02', //광통신
	'PAV': 'PAV_01', //포장
	'REV': 'REV_01', //스마트제한차량
	'ROM': 'ROM_01', //도로
	'SPA': 'SPA_01||SPA_02||SPA_03', //공간정보
	'SSM': 'SSM_01', //사면
	'STR': 'STR_01', //구조물
	'TER': 'TER_01||TER_02', //터널
	'TRS': 'TRS_01', //교통
	'BDS': 'BDS_01||BDS_02', //빅데이터
	'BRG': 'BRG_01||BRG_02', //교량 변위
	'TIS': 'TIS_01||TIS_02'  //교통분석지원시스템
});
var sysKeysAll_ = ol.obj.getValues(sysKeys_.getProperties()).join('||');

//OpenAPI 접속로그 저장
var openApiLogArr = [];
var openApiLogUrl = '';

try {
	const spaDomain = comLib.getAppKey('spa.domain');
    openApiLogUrl = spaDomain == -1 ? 'https://nspa.ex.co.kr:8443' : spaDomain;
	openApiLogUrl += '/open/map/updateOapiCnncLog.do';
} catch(e) {
	openApiLogUrl = 'https://nspa.ex.co.kr:8443/open/map/updateOapiCnncLog.do';
}

updateOapiCnncLog = function() {
	if(openApiLogArr.length > 0) {
		$.ajax({
			type: "POST",
			url: openApiLogUrl,
			data: { openApiLogs: openApiLogArr.join('!') },
			async: true,
			cache: false,
			error: function(xhr, status, error) {
				//alert("updateOapiCnncLog Error : \n\n" + xhr.responseText);
			}
		});
		openApiLogArr = [];
	}
};
setInterval('updateOapiCnncLog()', 60 * 1000); //1분마다 OpenAPI 접속로그 저장;

// 필요한 MapGuideMap 레이어를 추가하여 사용(임시, 추후 DB 내용으로 세팅)
var mapguidemapLayers_ = new ol.Object({
  // 지도명 : IP||mapdefinition
  'CommonTile': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/CommonTile.MapDefinition', //기본
  'RoadView': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/RoadView.MapDefinition', //파노라마
  'Default': himap.url.SERVER_IP+'||Library://GGTM/DEFAULT/Maps/Default.MapDefinition', //기본
  'DEM': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition', //재난
  'RoadKill': himap.url.SERVER_IP+'||Library://GGTM/FAC/Maps/RoadKill.MapDefinition', //로드킬 통계정보
  'IOT': himap.url.SERVER_IP+'||Library://GGTM/IOT/Maps/IOT.MapDefinition', //IOT
  'LMC': himap.url.SERVER_IP+'||Library://GGTM/LMC/Maps/LMC.MapDefinition', //차선유지
  'Man_Mgmt': himap.url.SERVER_IP+'||Library://GGTM/MAP/Maps/Man_Mgmt.MapDefinition', //유지관리
  'OneClick': himap.url.SERVER_IP+'||Library://GGTM/OCK/Maps/OneClick.MapDefinition', //원클릭
  'OCT_Manhole': himap.url.SERVER_IP+'||Library://GGTM/OCT/Maps/OCT_Manhole.MapDefinition', //광통신 맨홀
  'PMS': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS.MapDefinition', //포장 메인
  'PMS_0000': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_0000.MapDefinition', //준공측정
  'PMS_2012': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2012.MapDefinition', //포장 메인 2012
  'PMS_2013': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2013.MapDefinition', //포장 메인 2013
  'PMS_2014': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2014.MapDefinition', //포장 메인 2014
  'PMS_2015': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2015.MapDefinition', //포장 메인 2015
  'PMS_2016': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2016.MapDefinition', //포장 메인 2016
  'PMS_2017': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2017.MapDefinition', //포장 메인 2017
  'SmartOvms': himap.url.SERVER_IP+'||Library://GGTM/REV/Maps/SmartOvms.MapDefinition', //스마트 제한차량
  'NPRP': himap.url.SERVER_IP+'||Library://GGTM/ROM/Maps/NPRP.MapDefinition', //비점오염 저감시설
  'Slope': himap.url.SERVER_IP+'||Library://GGTM/SSM/Maps/Slope.MapDefinition', //사면 메인
  'Yeolhwa': himap.url.SERVER_IP+'||Library://GGTM/STR/Maps/Yeolhwa.MapDefinition', //열화지도분석시스템
  'TIS': himap.url.SERVER_IP+'||Library://GGTM/TIS/Maps/TIS.MapDefinition', //교통분석지원시스템
  'YongJiDo': himap.url.SERVER_IP+'||Library://GGTM/ETC/YongJiDo/Map/YongJiDo.MapDefinition' //용지도
  
});
// 없는 타일 레이어를 추가하여 사용(임시, 추후 DB 내용으로 세팅)
var tileLayers_ = new ol.Object({
  // 레이어명 : IP||mapdefinition||basemaplayergroupname||minzoom||maxzoom
  'Speed_Vdszone': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/CommonTile.MapDefinition||Speed_Vdszone||6||13', /* VDS 속도정보 *//* 기존 VDS */
  'Speed_Conzone': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/CommonTile.MapDefinition||Speed_Conzone||6||13', /* 콘존 속도정보 *//* 기존 CNZ */
  'Weather_Conzone': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/CommonTile.MapDefinition||Weather_Conzone||6||13', /* 콘존 기상 *//* 기존 CNZG */
  'Panorama': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/RoadView.MapDefinition||RoadViewLine||6||N', /* 파노라마 */
  'GEO': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/CommonTile.MapDefinition||Geology||N||N', /* 지질도 */
  'GEO_DTL': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/CommonTile.MapDefinition||Geology_Detail||N||N', /* 상세 지질도 */
  'RainMap': himap.url.SERVER_IP+'||Library://GGTM/Common/Maps/CommonTile.MapDefinition||RainMap||N||N', /* 빗물지도 */
  'ROADLINE': himap.url.SERVER_IP+'||Library://GGTM/DEFAULT/Maps/Default.MapDefinition||Road_Line||N||N', /* 도로선형 */
  'Bound': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Bound||6||13',
  'Boundary': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Boundary||N||N',
  'Weather_Mtnof': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Weather_Mtnof||6||13', /* 지사날씨(점형) */
  'Removing': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Removing||N||N',
  'Remove': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Remove||N||N',
  'RemovingRamp': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||RemovingRamp||N||N',
  'RemoveRamp': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||RemoveRamp||N||N',
  'Special_News': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Special_News||N||N',
  'Flooding_1': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Flooding_1||N||N',
  'Flooding_2': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Flooding_2||N||N',
  'Flooding_3': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Flooding_3||N||N',
  'Flooding_4': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Flooding_4||N||N',
  'Flooding_5': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||Flooding_5||N||N',
  'AWS_GRID': himap.url.SERVER_IP+'||Library://GGTM/DEM/Maps/DEM.MapDefinition||AWS_GRID||N||N',
  'SU_0000' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_0000.MapDefinition||SU||6||13',
  'AK_0000' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_0000.MapDefinition||AK||6||13',
  'RD_0000' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_0000.MapDefinition||RD||6||13',
  'SD_0000' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_0000.MapDefinition||SD||6||13',
  'IRI_0000': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_0000.MapDefinition||IRI||6||13',
  'PCI_0000': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_0000.MapDefinition||PCI||6||13',
  'SU_2012' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2012.MapDefinition||SU||6||13',
  'AK_2012' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2012.MapDefinition||AK||6||13',
  'RD_2012' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2012.MapDefinition||RD||6||13',
  'SD_2012' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2012.MapDefinition||SD||6||13',
  'IRI_2012': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2012.MapDefinition||IRI||6||13',
  'PCI_2012': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2012.MapDefinition||PCI||6||13',
  'SU_2013' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2013.MapDefinition||SU||6||13',
  'AK_2013' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2013.MapDefinition||AK||6||13',
  'RD_2013' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2013.MapDefinition||RD||6||13',
  'SD_2013' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2013.MapDefinition||SD||6||13',
  'IRI_2013': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2013.MapDefinition||IRI||6||13',
  'PCI_2013': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2013.MapDefinition||PCI||6||13',
  'SU_2014' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2014.MapDefinition||SU||6||13',
  'AK_2014' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2014.MapDefinition||AK||6||13',
  'RD_2014' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2014.MapDefinition||RD||6||13',
  'SD_2014' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2014.MapDefinition||SD||6||13',
  'IRI_2014': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2014.MapDefinition||IRI||6||13',
  'PCI_2014': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2014.MapDefinition||PCI||6||13',
  'SU_2015' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2015.MapDefinition||SU||6||13',
  'AK_2015' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2015.MapDefinition||AK||6||13',
  'RD_2015' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2015.MapDefinition||RD||6||13',
  'SD_2015' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2015.MapDefinition||SD||6||13',
  'IRI_2015': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2015.MapDefinition||IRI||6||13',
  'PCI_2015': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2015.MapDefinition||PCI||6||13',
  'SU_2016' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2016.MapDefinition||SU||6||13',
  'AK_2016' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2016.MapDefinition||AK||6||13',
  'RD_2016' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2016.MapDefinition||RD||6||13',
  'SD_2016' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2016.MapDefinition||SD||6||13',
  'IRI_2016': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2016.MapDefinition||IRI||6||13',
  'PCI_2016': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2016.MapDefinition||PCI||6||13',
  'SU_2017' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2017.MapDefinition||SU||6||13',
  'AK_2017' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2017.MapDefinition||AK||6||13',
  'RD_2017' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2017.MapDefinition||RD||6||13',
  'SD_2017' : himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2017.MapDefinition||SD||6||13',
  'IRI_2017': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2017.MapDefinition||IRI||6||13',
  'PCI_2017': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2017.MapDefinition||PCI||6||13',
  'JOSA_0000': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_0000.MapDefinition||JOSA||6||13',
  'JOSA_2012': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2012.MapDefinition||JOSA||6||13',
  'JOSA_2013': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2013.MapDefinition||JOSA||6||13',
  'JOSA_2014': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2014.MapDefinition||JOSA||6||13',
  'JOSA_2015': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2015.MapDefinition||JOSA||6||13',
  'JOSA_2016': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2016.MapDefinition||JOSA||6||13',
  'JOSA_2017': himap.url.SERVER_IP+'||Library://GGTM/PAV/Maps/PMS_2017.MapDefinition||JOSA||6||13'
});

himap.interaction.defaults = function(opt_options) {
  var options = opt_options ? opt_options : {};
  var interactions = new ol.Collection();
  var kinetic = new ol.Kinetic(-0.005, 0.05, 0);
  var altShiftDragRotate = options.altShiftDragRotate !== undefined ? options.altShiftDragRotate : true;
  if (altShiftDragRotate) {interactions.push(new ol.interaction.DragRotate());}
  var doubleClickZoom = options.doubleClickZoom !== undefined ? options.doubleClickZoom : true;
  if (doubleClickZoom) {interactions.push(new ol.interaction.DoubleClickZoom({delta: options.zoomDelta, duration: options.zoomDuration}));}
  var dragPan = options.dragPan !== undefined ? options.dragPan : true;

  if (dragPan) {
    interactions.push(new ol.interaction.DragPan({
      kinetic: kinetic,
      condition: function(mapBrowserEvent) {
        var originalEvent = mapBrowserEvent.originalEvent;
        return !originalEvent.altKey && !(originalEvent.metaKey || originalEvent.ctrlKey) && !originalEvent.shiftKey && originalEvent.button != 1 && originalEvent.button != 2;
      }
    }));
  }

  var pinchRotate = options.pinchRotate !== undefined ? options.pinchRotate : true;
  if (pinchRotate) {interactions.push(new ol.interaction.PinchRotate());}
  var pinchZoom = options.pinchZoom !== undefined ? options.pinchZoom : true;
  if (pinchZoom) {interactions.push(new ol.interaction.PinchZoom({duration: options.zoomDuration}));}
  var keyboard = options.keyboard !== undefined ? options.keyboard : true;
  if (keyboard) {interactions.push(new ol.interaction.KeyboardPan()); interactions.push(new ol.interaction.KeyboardZoom({delta: options.zoomDelta, duration: options.zoomDuration}));}
  var mouseWheelZoom = options.mouseWheelZoom !== undefined ? options.mouseWheelZoom : true;
  if (mouseWheelZoom) {interactions.push(new ol.interaction.MouseWheelZoom({duration: options.zoomDuration}));}
  var shiftDragZoom = options.shiftDragZoom !== undefined ? options.shiftDragZoom : true;
  if (shiftDragZoom) {interactions.push(new ol.interaction.DragZoom({duration: options.zoomDuration}));}

  return interactions;
};


himap.source.MapGuide = function(options) {
  ol.source.Image.call(this, {extent: options.extent, projection: options.projection, resolutions: options.resolutions});
  this.crossOrigin_ = options.crossOrigin !== undefined ? options.crossOrigin : null;
  this.displayDpi_ = options.displayDpi !== undefined ? options.displayDpi : 96;
  this.params_ = options.params || {};
  this.url_ = options.url;
  this.imageLoadFunction_ = options.imageLoadFunction !== undefined ? options.imageLoadFunction : ol.source.Image.defaultImageLoadFunction;
  this.hidpi_ = options.hidpi !== undefined ? options.hidpi : true;
  this.metersPerUnit_ = options.metersPerUnit !== undefined ? options.metersPerUnit : 1;
  this.ratio_ = options.ratio !== undefined ? options.ratio : 1;
  this.useOverlay_ = options.useOverlay !== undefined ? options.useOverlay : false;
  this.image_ = null;
  this.renderedRevision_ = 0;
};
ol.inherits(himap.source.MapGuide, ol.source.Image);

himap.source.MapGuide.prototype.getParams = function() {
  return this.params_;
};

himap.source.MapGuide.prototype.getImageInternal = function(extent, resolution, pixelRatio, projection) {
  resolution = this.findNearestResolution(resolution);
  pixelRatio = this.hidpi_ ? pixelRatio : 1;

  var image = this.image_;
  if (image && this.renderedRevision_ == this.getRevision() && image.getResolution() == resolution && image.getPixelRatio() == pixelRatio && ol.extent.containsExtent(image.getExtent(), extent)) {
    return image;
  }
  if (this.ratio_ != 1) {
    extent = extent.slice();
    ol.extent.scaleFromCenter(extent, this.ratio_);
  }
  var width = ol.extent.getWidth(extent) / resolution;
  var height = ol.extent.getHeight(extent) / resolution;
  var size = [width * pixelRatio, height * pixelRatio];

  if (this.url_ !== undefined) {
    var imageUrl = this.getUrl(this.url_, this.params_, extent, size, projection);
    image = new ol.Image(extent, resolution, pixelRatio, this.getAttributions(), imageUrl, this.crossOrigin_, this.imageLoadFunction_);
    ol.events.listen(image, ol.events.EventType.CHANGE, this.handleImageChange, this);
  } else {
    image = null;
  }
  this.image_ = image;
  this.renderedRevision_ = this.getRevision();

  return image;
};

himap.source.MapGuide.prototype.getImageLoadFunction = function() {
  return this.imageLoadFunction_;
};

himap.source.MapGuide.getScale = function(extent, size, metersPerUnit, dpi) {
  var mcsW = ol.extent.getWidth(extent);
  var mcsH = ol.extent.getHeight(extent);
  var devW = size[0];
  var devH = size[1];
  var mpp = 0.0254 / dpi;
  if (devH * mcsW > devW * mcsH) {
    return mcsW * metersPerUnit / (devW * mpp); // width limited
  } else {
    return mcsH * metersPerUnit / (devH * mpp); // height limited
  }
};

himap.source.MapGuide.prototype.updateParams = function(params) {
  ol.obj.assign(this.params_, params);
  this.changed();
};

/**
 * @return {string} The mapagent map image request URL.
 */
himap.source.MapGuide.prototype.getUrl = function(baseUrl, params, extent, size, projection) {
  var scale = ol.source.ImageMapGuide.getScale(extent, size, this.metersPerUnit_, this.displayDpi_);
  var center = ol.extent.getCenter(extent);
  var baseParams = {'OPERATION':this.useOverlay_ ? 'GETDYNAMICMAPOVERLAYIMAGE' : 'GETMAPIMAGE', 'VERSION':'2.0.0', 'LOCALE':'en', 'CLIENTAGENT':'himap.source.MapGuide source', 'CLIP':'1', 'SETDISPLAYDPI':this.displayDpi_, 'SETDISPLAYWIDTH':Math.round(size[0]), 'SETDISPLAYHEIGHT':Math.round(size[1]), 'SETVIEWSCALE':scale, 'SETVIEWCENTERX':center[0], 'SETVIEWCENTERY':center[1], "_t":himap.util.tick()};

  ol.obj.assign(baseParams, params);
  return ol.uri.appendParams(baseUrl, baseParams);
};

/**
 * @param {ol.ImageLoadFunctionType} imageLoadFunction Image load function.
 */
himap.source.MapGuide.prototype.setImageLoadFunction = function(imageLoadFunction) {
  this.image_ = null;
  this.imageLoadFunction_ = imageLoadFunction;
  this.changed();
};

/**
 * @constructor
 * @extends {ol.tilegrid.TileGrid}
 */
himap.tilegrid.MapGuideTile = function(options) {
  ol.tilegrid.TileGrid.call(this, {
    minZoom: options.minZoom,
    maxZoom: options.maxZoom,
    resolutions: options.resolutions,
    tileSize: options.tileSize,
    extent: options.extent,
    origin: options.origin
  });
};
ol.inherits(himap.tilegrid.MapGuideTile, ol.tilegrid.TileGrid);

/**
 * @constructor
 * @extends {ol.source.TileImage}
 * @param {himap.source.MapGuideTile}
 */
himap.source.MapGuideTile = function(options) {
  this.useHttpTile = options.useHttpTile || false;
  this.format = options.format || "png";
  this.tileRowsPerFolder = 30;
  this.tileColumnsPerFolder = 30;

  this.tileParams = {
    mapdefinition: options.mapdefinition,
    basemaplayergroupname: options.basemaplayergroupname,
    VERSION: '1.2.0',
    session: options.session,
    agentUrl: options.agentUrl
  };

  var tileGrid = new himap.tilegrid.MapGuideTile({
    minZoom: options.minZoom,
    maxZoom: options.maxZoom,
    resolutions: options.resolutions,
    tileSize: options.tileSize,
    extent: options.extent,
    origin: [options.extent[0], options.extent[3], options.extent[2], options.extent[1]],
  });

  ol.source.TileImage.call(this, {
    attributions: options.attributions,
    cacheSize: options.cacheSize,
    crossOrigin: options.crossOrigin,
    logo: options.logo,
    opaque: options.opaque,
    projection: options.projection || ol.proj.get('EPSG:3857'),
    reprojectionErrorThreshold: options.reprojectionErrorThreshold,
    tileGrid: tileGrid,
    tileLoadFunction: options.tileLoadFunction,
    tilePixelRatio: options.tilePixelRatio,
    tileUrlFunction: options.tileUrlFunction,
    url: this.createUrl(),
    urls: options.urls,
    wrapX: false
  });
};
ol.inherits(himap.source.MapGuideTile, ol.source.TileImage);

/**
 * @param {string} template Template.
 * @param {ol.tilegrid.TileGrid} tileGrid Tile grid.
 * @return {ol.TileUrlFunctionType} Tile URL function.
 */
himap.source.MapGuideTile.prototype.createFromTemplate = function(template, tileGrid) {
  var zRegEx = /\{z\}/g;
  var xRegEx = /\{x\}/g;
  var yRegEx = /\{y\}/g;
  var dashYRegEx = /\{-y\}/g;
  return (
      function(tileCoord, pixelRatio, projection) {
        if (!tileCoord) {
          return undefined;
        } else {
        	if (!this.useHttpTile) {
        	  return template.replace(zRegEx, (tileGrid.getMaxZoom() - tileCoord[0]).toString()).replace(xRegEx, tileCoord[1].toString()).replace(yRegEx, function() {
                var y = -tileCoord[2] - 1;
                return y.toString();
              }).replace(dashYRegEx, function() {
                var z = tileCoord[0];
                var range = tileGrid.getFullTileRange(z);
                ol.asserts.assert(range, 55); // The {-y} placeholder requires a tile grid with extent
                var y = range.getHeight() + tileCoord[2];
                return y.toString();
              });
            } else {
              return this.getHttpTilePath(tileGrid, tileCoord);
            }
        }
      });
};

/**
 * @param {Array.<string>} templates Templates.
 * @param {ol.tilegrid.TileGrid} tileGrid Tile grid.
 * @return {ol.TileUrlFunctionType} Tile URL function.
 */
himap.source.MapGuideTile.prototype.createFromTemplates = function(templates, tileGrid) {
  var len = templates.length;
  var tileUrlFunctions = new Array(len);
  for (var i = 0; i < len; ++i) {
    tileUrlFunctions[i] = this.createFromTemplate(templates[i], tileGrid);
  }
  return ol.TileUrlFunction.createFromTileUrlFunctions(tileUrlFunctions);
};

himap.source.MapGuideTile.prototype.getHttpTilePath = function(tileGrid, tileCoord) {
  var tileRowGroup = "";
  var tileColGroup = "";
  var tileCoordY = -tileCoord[2] - 1;

  if (tileCoordY < 0) tileRowGroup =  '-';
  if (tileCoordY == 0 ) tileRowGroup += '0';
  else tileRowGroup += Math.floor(Math.abs(tileCoordY/this.tileRowsPerFolder)) * this.tileRowsPerFolder;

  if (tileCoord[1] < 0) tileColGroup =  '-';
  if (tileCoord[1] == 0) tileColGroup += '0';
  else tileColGroup += Math.floor(Math.abs(tileCoord[1]/this.tileColumnsPerFolder)) * this.tileColumnsPerFolder;

  var tilePath = '/S' + Math.floor(tileGrid.getMaxZoom() - tileCoord[0])
          + '/' + this.tileParams.basemaplayergroupname
          + '/R' + tileRowGroup
          + '/C' + tileColGroup
          + '/' + (tileCoordY % this.tileRowsPerFolder)
          + '_' + (tileCoord[1] % this.tileColumnsPerFolder)
          + '.' + this.format;
  return this.tileParams.agentUrl + tilePath;
};

/**
 * @param {ol.TileUrlFunctionType} tileUrlFunction Tile URL function.
 * @param {string=} opt_key Optional new tile key for the source.
 */
himap.source.MapGuideTile.prototype.setTileUrlFunction = function(tileUrlFunction, opt_key) {
  this.tileUrlFunction = tileUrlFunction;
  if (typeof opt_key !== 'undefined') this.setKey(opt_key);
  else this.changed();
};

/**
 * @param {string} url URL.
 */
himap.source.MapGuideTile.prototype.setUrl = function(url) {
  var urls = this.urls = ol.TileUrlFunction.expandUrl(url);
  this.setTileUrlFunction(this.fixedTileUrlFunction ? this.fixedTileUrlFunction.bind(this) : this.createFromTemplates(urls, this.tileGrid), url);
};

/**
 * @param {Array.<string>} urls URLs.
 */
himap.source.MapGuideTile.prototype.setUrls = function(urls) {
  this.urls = urls;
  var key = urls.join('\n');
  this.setTileUrlFunction(this.fixedTileUrlFunction ? this.fixedTileUrlFunction.bind(this) : this.createFromTemplates(urls, this.tileGrid), key);
};

himap.source.MapGuideTile.prototype.createUrl = function() {
  if (!this.useHttpTile) {
    var baseParams = {
      operation: 'GETTILEIMAGE',
      mapdefinition: this.tileParams.mapdefinition,
      basemaplayergroupname: this.tileParams.basemaplayergroupname,
      session: this.tileParams.session,
      VERSION: '1.2.0',
      CLIENTAGENT: 'himap.source.MapGuideTile',
      _t: himap.util.tick()
    };
    return ol.uri.appendParams(this.tileParams.agentUrl, baseParams) + '&tilecol={x}&tilerow={y}&scaleindex={z}';
  } else {
    return this.tileParams.agentUrl;
  }
};

himap.NexmanServerResolutions = [
	156543.03392804097, 78271.51696402048, 39135.75848201024, 19567.87924100512, 9783.93962050256, 4891.96981025128, 2445.98490512564, 1222.99245256282,
	611.49622628141, 305.748113140705, 152.8740565703525, 76.43702828517625, 38.21851414258813, 19.109257071294063, 9.554628535647031, 4.777314267823516,
	2.388657133911758, 1.194328566955879, 0.5971642834779395, 0.29858214173896974, 0.14929107086948487
];
himap.maxzoom = himap.NexmanServerResolutions.length - 1;
himap.ViewResolutions = [
	2445.98490512564, 1222.99245256282, 611.49622628141, 305.748113140705, 152.8740565703525, 76.43702828517625, 38.21851414258813, 19.109257071294063,
	9.554628535647031, 4.777314267823516, 2.388657133911758, 1.194328566955879, 0.5971642834779395, 0.29858214173896974
];
himap.ViewExtent =   [13867518.905289, 3911131.974575, 14625774.635093, 4764781.167161];
himap.NexmanExtent = [13920000,4020000,14540000,4600000];

himap.util = {};
himap.util.tick = function () {
  return new Date().getTime();
};

himap.util.createPolygonWKTWithCoordinate = function(map, coordnate, dist) {
  var pixel = map.getPixelFromCoordinate(coordnate);
  return himap.util.createPolygonWKTWithPixel(map, pixel, dist);
};

himap.util.createPolygonWKTWithPixel = function(map, pixel, dist) {
  var p1 = map.getCoordinateFromPixel([pixel[0] - dist, pixel[1] - dist]);
  var p2 = map.getCoordinateFromPixel([pixel[0] + dist, pixel[1] - dist]);
  var p3 = map.getCoordinateFromPixel([pixel[0] + dist, pixel[1] + dist]);
  var p4 = map.getCoordinateFromPixel([pixel[0] - dist, pixel[1] + dist]);

  p1 = ("" + p1).replace(',', ' ');
  p2 = ("" + p2).replace(',', ' ');
  p3 = ("" + p3).replace(',', ' ');
  p4 = ("" + p4).replace(',', ' ');

  return "POLYGON((" + p1 + ", " + p2 + ", " + p3 + ", " + p4 + ", " + p1 + "))";
};

himap.Map = function (options) {
  options = options || {};
  var name = 'himap.Map';
  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(name, '100||himap.Map 맵의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}

  var layers = options.layers || [];
  var viewResolutions = options.viewResolutions || himap.ViewResolutions;
  var projection = options.projection || ol.proj.get('EPSG:3857');
  var viewExtent = options.viewExtent || himap.ViewExtent;
  var center = options.center || [14269851.204829251, 4318535.083732101]; // 도로공사본사
  var zoom = options.zoom !== undefined ? options.zoom : 1;
  var target = options.target !== undefined ? document.getElementById(options.target) : null;
  var viewPointIndicator = options.viewPointIndicator !== undefined ? options.viewPointIndicator : true;
  var controls = options.controls !== undefined ? options.controls : [new ol.control.Zoom()];

  if(errFlag) {
    var errMsg = this.getErrorMsg(name);
    ol.DEBUG && console.assert(errFlag === false, errMsg);
    alert(errMsg);
  } else {
    ol.Map.call(this, {
	  target: target,
	  renderer: ol.renderer.Type.CANVAS,
	  layers: layers,
	  logo: false,
	  controls: controls,
	  interactions: himap.interaction.defaults({doubleClickZoom:false}),
	  view: new ol.View({projection : projection, extent: viewExtent, center: center, resolutions : viewResolutions, zoom: zoom})
    });
    if (viewPointIndicator) {ol.events.listen(this, ol.pointer.EventType.POINTERUP, this.handlePointerUp_, this, false);}
  }
};
ol.inherits(himap.Map, ol.Map);

himap.Map.prototype.handlePointerUp_ = function(event) {
  new himap.render.PointIndicator({map: this, pixel: event.pixel});
};

//레이어 이름에 해당하는 레이어 반환
himap.Map.prototype.getLayer = function(name) {
  var returnLayer = null;
  $(this.getLayers().getArray()).each(function(i, layer) {
    if (name == layer.get('name')) {
      returnLayer = layer;
      return false;
    }
  });

  return returnLayer;
};

//레이어 이름에 해당하는 레이어의 인덱스 반환
himap.Map.prototype.getLayerIndex = function(name) {
  var returnIdx = -1;
  $(this.getLayers().getArray()).each(function(i, layer) {
    if (name == layer.get('name')) {
      returnIdx = i;
      return false;
    }
  });

  return returnIdx;
};

himap.Map.prototype.forEachFeatureAtPixel = function(pixel, callback, opt_options) {
  if (!this.frameState_) {return;}
  var coordinate = this.getCoordinateFromPixel(pixel);
  opt_options = opt_options !== undefined ? opt_options : {};
  var hitTolerance = opt_options.hitTolerance !== undefined ? opt_options.hitTolerance * this.frameState_.pixelRatio : 0;
  var layerFilter = opt_options.layerFilter !== undefined ? opt_options.layerFilter : ol.functions.TRUE;
  var thisArg = opt_options.opt_this !== undefined ? opt_options.opt_this : null;
  var thisArg2 = opt_options.opt_this2 !== undefined ? opt_options.opt_this2 : null;

  return this.renderer_.forEachFeatureAtCoordinate(coordinate, this.frameState_, hitTolerance, callback, thisArg, layerFilter, thisArg2);
};

himap.layer = {};

himap.layer.Tile = function(options) {
  options = options || {};
  var name  = options.name !== undefined ? options.name : 'himap.layer.Tile';

  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(name, '100||' + name + ' 레이어의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}
  if(!errFlag && name == 'himap.layer.Tile') {errFlag = true; this.setErr(name, '300||' + name + ' 레이어의 필수 입력인 name이 없습니다.');}

  var visible = options.visible !== undefined ? options.visible : true;
  var agentUrl = options.agentUrl !== undefined ? options.agentUrl : "";
  var mapdefinition = options.mapdefinition !== undefined ? options.mapdefinition : "";
  var basemaplayergroupname = options.basemaplayergroupname !== undefined ? options.basemaplayergroupname : "";
  var format = options.format !== undefined ? options.format : "png";
  var minZoom = options.minZoom !== undefined ? options.minZoom : 0;
  var maxZoom = options.maxZoom !== undefined ? options.maxZoom : himap.maxzoom;
  var useHttpTile = options.useHttpTile !== undefined ? options.useHttpTile : false;
  var removeTileRangeFunction = !!options.removeTileRangeFunction;
  var m_extent = options.extent !== undefined ? options.extent : [13920000, 4020000, 14540000, 4650000];
  var defaultSource = new himap.source.MapGuideTile({
    resolutions: himap.NexmanServerResolutions,
    extent: m_extent,
    tileSize: 300,
    agentUrl: agentUrl,
    mapdefinition: mapdefinition,
    basemaplayergroupname: basemaplayergroupname,
    format: format,
    minZoom: minZoom,
    maxZoom: maxZoom,
    useHttpTile: useHttpTile
  });

  if(errFlag) {
    ol.layer.Tile.call(this, {});
    ol.DEBUG && console.assert(errFlag === false, this.getErrorMsg(name));
  } else {
	  var source_ = options.source !== undefined ? options.source : defaultSource;
	  ol.layer.Tile.call(this, {name: name, source: source_, visible: visible});
  }

  if (!errFlag && removeTileRangeFunction) {
    this.getSource().getTileGrid().getTileCoordChildTileRange = function () {return null;};
    this.getSource().getTileGrid().forEachTileCoordParentTileRange = function () {return false;};
  }
};
ol.inherits(himap.layer.Tile, ol.layer.Tile);

himap.layer.Tile.prototype.refresh = function () {
  this.getSource().refresh();
};

himap.demExtent = [13500000, 3608000, 14772000, 4943000]; //재난

// User가 호출해서 사용
himap.layer.Tile.Layer = function(options) {
  options = options || {};
  var visible = options.visible !== undefined ? options.visible : true;
  var extent = options.extent;
  var removeTileRangeFunction = options.removeTileRangeFunction !== undefined ? options.removeTileRangeFunction : true;

  var info_ = tileLayers_.get(options.name);
  if(info_) {
	  info_ = info_.split('||');
	  var ip = info_[0];
	  var mapdefinition = info_[1];
	  var basemaplayergroupname = info_[2];
	  var minZoom = info_[3] == 'N' ? 0 : info_[3];
	  var maxZoom = info_[4] == 'N' ? himap.maxzoom : info[4];
	  var handlerUrl = options.handlerUrl !== undefined ? options.handlerUrl : himap.url.TILE_HANDLER.replace('{ip}', ip);

	  if(mapdefinition.indexOf('DEM.MapDefinition') > -1) { extent = himap.demExtent; }

	  himap.layer.Tile.call(this, {
	    sysKey: options.sysKey,
	    name: options.name,
	    extent: extent,
	    agentUrl: handlerUrl,
	    mapdefinition: mapdefinition,
	    basemaplayergroupname: basemaplayergroupname,
	    minZoom: minZoom,
	    maxZoom: maxZoom,
	    useHttpTile: false,
	    visible: visible,
	    removeTileRangeFunction: removeTileRangeFunction
	  });

	  openApiLogArr.push('01|5');
  } else {
	  himap.layer.Tile.call(this, {sysKey: options.sysKey, name: options.name});
  }
};
ol.inherits(himap.layer.Tile.Layer, himap.layer.Tile);

//User가 호출해서 사용
himap.layer.Tile.PMSLayer = function(options) {
  himap.layer.Tile.Layer.call(this, options);
  openApiLogArr.push('01|7');
};
ol.inherits(himap.layer.Tile.PMSLayer, himap.layer.Tile.Layer);

/* 공사 수치지도 */
himap.layer.Base = function(options) {
  options = options || {};
  var visible = options.visible !== undefined ? options.visible : true;

  himap.layer.Tile.call(this, {
    name: 'Base',
    sysKey: options.sysKey,
    agentUrl: himap.url.BASE_TILE_PATH,
    basemaplayergroupname: 'BASE',
    minZoom: 7,
    useHttpTile: true,
    visible: visible,
    extent : himap.NexmanExtent
  });
};
ol.inherits(himap.layer.Base, himap.layer.Tile);

/* 항공사진 */
himap.layer.Air = function(options) {
  options = options || {};
  var year = options.year !== undefined ? options.year : '2009';
  var visible = options.visible !== undefined ? options.visible : true;

  var name = 'Air' + year;
  var agentUrl = himap.url.AIR_PATH + year;
  var groupNm = 'Air' + year;
  groupNm = groupNm.indexOf('_') > -1 ? groupNm.substr(0, groupNm.indexOf('_')) : groupNm;

  himap.layer.Tile.call(this, {
    sysKey: options.sysKey,
	name: name,
	agentUrl: agentUrl,
	basemaplayergroupname: groupNm,
	minZoom: 7,
	useHttpTile: true,
	visible: visible,
	extent : himap.NexmanExtent
  });
};
ol.inherits(himap.layer.Air, himap.layer.Tile);

/* 용지도 항공시진.*/
himap.layer.YJDAir = function(options) {
	  options = options || {};
	  var year = options.year !== undefined ? options.year : '2018';
	  var visible = options.visible !== undefined ? options.visible : true;
	
	  var agentUrl = himap.url.AIR_PATH + year;
	  
	  himap.layer.Tile.call(this, {
	    sysKey: options.sysKey,
		name: options.name,
		agentUrl: 'http://ngeoapi.ex.co.kr:8443/Pretile/Yongjido/'+year+"/" ,		
		basemaplayergroupname: options.name,
		minZoom: 7,
		useHttpTile: true,
		visible: true,
		extent : [13920000,4020000,14540000,4650000]
	  });
};
ol.inherits(himap.layer.YJDAir, himap.layer.Tile);

/* 기상청 레이더 분석 영상 */
himap.layer.Radar = function(options) {
  options = options || {};
  var name  = options.name !== undefined ? options.name : 'Radar';
  var visible = options.visible !== undefined ? options.visible : true;
  var url = options.url !== undefined ? options.url : "";
  var extent = options.extent !== undefined ? options.extent : [13444976.2193, 3564136.9149, 15104441.1833, 4923013.41582];
  var imageSize = options.imageSize !== undefined ? options.imageSize : [640, 640];

  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(name, '100||' + name + ' 레이어의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}

  var pixelProjection = new ol.proj.Projection({
    code: 'pixel', units: 'pixels', extent: extent
  });

  if(errFlag) {
    ol.layer.Image.call(this, {});
    ol.DEBUG && console.assert(errFlag === false, this.getErrorMsg(name));
  } else {
    var source_ = new ol.source.ImageStatic({
      url: url,
      imageSize: imageSize,
      projection: pixelProjection,
      imageExtent: extent
    });

    ol.layer.Image.call(this, {name: name, source: source_, visible: visible});
  }
};
ol.inherits(himap.layer.Radar, ol.layer.Image);

himap.layer.Radar.prototype.setUrl = function(url) {
  this.getSource().image_.src_ = url;
  this.getSource().image_.image_.src = url;
  this.changed();
};

/*
(AIMS의 맵을 표시하기 위한 레이어)
*/
var mapapiSession_ = '';
var secondMapGuideMap_ = '';
himap.layer.MapGuideMap = function (options) {
  options = options || {};
  var errName = options.name || 'MapGuideMap';
  var name = options.name || 'MapGuideMap' + himap.util.tick();

  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(errName, '100||' + errName + ' 레이어의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}
  if(!errFlag && !options.name) {errFlag = true; this.setErr(errName, '300||' + errName + ' 레이어의 필수 입력인 name이 없습니다.');}
  this.optionVisible_ = options.visible !== undefined ? options.visible : true;
  this.projection = options.projection !== undefined ? options.projection : 'EPSG:3857';
  this.session = options.session !== undefined ? options.session : '';
  this.mapName = options.mapName !== undefined ? options.mapName : '';
  this.mapDefinition = options.mapDefinition !== undefined ? options.mapDefinition : '';
  this.handleMapLoaded = options.onMapLoaded !== undefined ? options.onMapLoaded : function() {};
  this.keepSession = options.keepSession !== undefined ? options.keepSession : true;
  this.selection_ = null;
  this.loadedMapInfo;
  this.groups = [];
  this.layers = [];
  var format = options.format || 'PNG';

  this.serverPath = options.serverPath !== undefined ? options.serverPath : himap.url.SERVER_PATH;
  if (this.serverPath[this.serverPath.length - 1] != '/') {this.serverPath += '/';}
  this.agentUrl_ = this.serverPath + 'mapagent/mapagent.fcgi?';
  if(errFlag) {
    ol.layer.Image.call(this, {});
    ol.DEBUG && console.assert(errFlag == false, this.getErrorMsg(errName));
  } else {
    ol.layer.Image.call(this, {
      name: name,
      source: new himap.source.MapGuide({
          extent: [0, 0, 0, 0],
          projection: this.projection,
          url: this.agentUrl_,
          useOverlay: true,
          metersPerUnit: 1,
          params: {mapName: this.mapName, session: this.session, format: format, behavior: 7, SELECTIONCOLOR: '0xFFFF00FF'}
		  }),
		  visible: false
    });

    if (this.session == '') {
console.log(this.session);
    	
      //as.jeong cookie session 
      if (name == 'Default') {
this.checkSession();	
}	
      else {
    	  secondMapGuideMap_ = this;
    	  this.createSessionWait(); //Default 맵이 세션 생성할 때까지 대기
      }
    } else {
      this.createRunTimeMap();
    }
  }

  this.autoRefreshInterval_ = options.autoRefreshInterval !== undefined ? options.autoRefreshInterval : 0;
};
ol.inherits(himap.layer.MapGuideMap, ol.layer.Image);

himap.layer.MapGuideMap.prototype.createSessionWait = function() {
  var sessWaitTimerID = setTimeout('himap.layer.MapGuideMap.prototype.createSessionWait()', 100);

  if(mapapiSession_ != '') {
    secondMapGuideMap_.session = mapapiSession_;
    clearTimeout(sessWaitTimerID);
    secondMapGuideMap_.createRunTimeMap();
  }
};

//as.jeong cookie session 
himap.layer.MapGuideMap.prototype.checkSession = function()
{
	var _session = this.getCookie(himap.url.SERVER_IP);
	if(_session)
	{
		  console.log("====> checkSession :"+_session);
		  
		  /*
		  [HIST]
		  $.ajax({
			    type: "get",
			    url: this.agentUrl_,
			    data: {OPERATION:'GETSESSIONTIMEOUT', VERSION:'1.0.0', SESSION:_session, CLIENTAGENT:'himap.source.MapGuide source'},
			    dataType: "text",
			    async: true,
			    cache: false,
			    success: function(code)
			    {
			    	//console.log("====> session_time :"+code);
			    	

			    	if(code == "600" || code == "1200")
			    	{
				    	//console.log("====> session OK :"+_session);
				    	this.MapGuideMap.session = _session;
				    	mapapiSession_ = _session;
				    	this.MapGuideMap.createRunTimeMap();			    		
			    	}
			    	else
			    	{
			    		//console.log("====> session check Error(1)");
			    		this.MapGuideMap.createSession();
			    	}
			    },
			    error: function(xhr,status,error) 
			    {
			    	//console.log("====> session check Error(2)");
			    	this.MapGuideMap.createSession();
			    },
			    MapGuideMap : this
			  });
		/**/
		  $.ajax({
			    type: "get",
			    url:"/route/map/selectExtraHttpClient.do",
				data: {
						URL: this.agentUrl_
						,OPERATION:'TIMEOUT'
						,SESSION:_session
					},
			    dataType: "text",
			    async: true,
			    cache: false,
			    success: function(code)
			    {
			    	//console.log("====> session_time :"+code);
			    	

			    	if(code == "600" || code == "1200")
			    	{
				    	//console.log("====> session OK :"+_session);
				    	this.MapGuideMap.session = _session;
				    	mapapiSession_ = _session;
				    	this.MapGuideMap.createRunTimeMap();			    		
			    	}
			    	else
			    	{
			    		//console.log("====> session check Error(1)");
			    		this.MapGuideMap.createSession();
			    	}
			    },
			    error: function(xhr,status,error) 
			    {
			    	//console.log("====> session check Error(2)");
			    	this.MapGuideMap.createSession();
			    },
			    MapGuideMap : this
			  });
	}
	else
		this.createSession();
	
	
};


himap.layer.MapGuideMap.prototype.createSession = function() {
	/*
  $.ajax({
    type: "get",
    url: this.agentUrl_,
    data: {OPERATION:'CREATESESSION', VERSION:'1.0.0', USERNAME:'Anonymous', CLIENTAGENT:'himap.source.MapGuide source'},
    dataType: "text",
    async: true,
    cache: false,
    success: this.handleCreateSession_.bind(this),
    error: function(xhr,status,error) 
    {
    	//alert("CreateSession Error : \n\n" + xhr.responseText);
    	info("CreateSession Error : \n\n" + xhr.responseText);
    }
  });
  /**/
	
	 $.ajax({
		 
		type: "get",
		url:"/route/map/selectExtraHttpClient.do",
		data: {URL: this.agentUrl_,OPERATION:'SESSION'
			},
		dataType: "text",
		async: true,
		cache: false,
		success: this.handleCreateSession_.bind(this)	,
		error: function(xhr,status,error) 
		{
			//alert("CreateSession Error : \n\n" + xhr.responseText);
			info("CreateSession Error : \n\n" + xhr.responseText);
		}
		 
		 
	 });
	
};

//as.jeong cookie session 
himap.layer.MapGuideMap.prototype.setCookie = function(name, value, expiredays) {
    var today = new Date();
    today.setDate(today.getDate() + expiredays);
    document.cookie = name + "=" + escape(value) + "; path=/; expires=" + today.toGMTString() + ";";
};

//as.jeong cookie session 
himap.layer.MapGuideMap.prototype.getCookie = function(name) {
    var cook = document.cookie + ";";
    var idx = cook.indexOf(name, 0);
    var val = "";
    if (idx != -1) {
        cook = cook.substring(idx, cook.length);
        begin = cook.indexOf("=", 0) + 1;
        end = cook.indexOf(";", begin);
        val = unescape(cook.substring(begin, end));
    }
    return val;
};

himap.layer.MapGuideMap.prototype.handleCreateSession_ = function(json) {
  this.session = json;
  mapapiSession_ = json;
  
  this.setCookie(himap.url.SERVER_IP, this.session, 1); //as.jeong cookie session 
  
  this.createRunTimeMap();
};

himap.layer.MapGuideMap.prototype.createRunTimeMap = function() {
	/*
	 [HIST]
   $.ajax({type: "get",
	  url: this.agentUrl_,
	  data: { OPERATION:'CREATERUNTIMEMAP', VERSION:'2.6.0', mapdefinition:this.mapDefinition, requestedfeatures:1|2|4, iconsperscalerange:20, format:"application/json", SESSION:this.session},
      dataType: "json",
	  async: true,
	  cache: false,
	  success: this.handleLoadMap_.bind(this),
	  error: function(xhr,status,error) 
	  {
		  //alert("LoadMap Error  : \n\n" + xhr.responseText);
		  info("LoadMap Error  : \n\n" + xhr.responseText);
	  }
     });
     /**/
	
	$.ajax({type: "get",
		  
		  url:"/route/map/selectExtraHttpClient.do",
			data: {
				URL: this.agentUrl_,
				OPERATION:'RUNTIMEMAP',
				SESSION:this.session
			},
		  
		  
		  dataType: "json",
		  async: true,
		  cache: false,
		  success: this.handleLoadMap_.bind(this),
		  error: function(xhr,status,error) 
		  {
			  //alert("LoadMap Error  : \n\n" + xhr.responseText);
			  info("LoadMap Error  : \n\n" + xhr.responseText);
		  }
	     });
	
};

himap.layer.MapGuideMap.prototype.handleLoadMap_ = function(json) {
  this.loadedMapInfo = json.RuntimeMap;
/*
  info('this.loadedMapInfo,Name : ' + this.loadedMapInfo.Name[0]);
  info('this.loadedMapInfo.Group : ' + jsonLib.stringify(this.loadedMapInfo.Group));
  info('this.loadedMapInfo.Layer : ' + jsonLib.stringify(this.loadedMapInfo.Layer));
*/
  this.mapName = this.loadedMapInfo.Name[0];
  this.getSource().updateParams({session: this.session, mapName: this.mapName});
  this.setExtent(this.loadedMapInfo.extent);
  if(this.optionVisible_) this.setVisible(true);

  if(this.autoRefreshInterval_) {
     setTimeout(this.refresh.bind(this), this.autoRefreshInterval_);
  }

  if(this.keepSession) this.getSessionTimeout_();
  this.updateLayers_(this.loadedMapInfo);
  this.handleMapLoaded(this.loadedMapInfo);
};

himap.layer.MapGuideMap.prototype.updateLayers_ = function(json) {
  if(json.Group){
      for (var i = 0; i < json.Group.length; i++){
         this.groups[i] = {groupName: json.Group[i].Name[0], visible: json.Group[i].Visible[0] =="true" ? true:false, uniqueId: json.Group[i].ObjectId[0]};
   //      info('this.groupName ==> ' + this.groups[i].groupName + ' visible = ' + this.groups[i].visible + ' uniqueId = ' + this.groups[i].uniqueId);
      }
  }

  if(json.Layer){
      for (i = 0; i < json.Layer.length; i++){
         this.layers[i] = {layerName: json.Layer[i].Name[0], visible: json.Layer[i].Visible[0] =="true" ? true:false, uniqueId: json.Layer[i].ObjectId[0]};
         //info('this.layerName ==> ' + this.layers[i].layerName + ' visible = ' + this.layers[i].visible + ' uniqueId = ' + this.layers[i].uniqueId);
      }
  }
};

himap.layer.MapGuideMap.prototype.getSessionTimeout_ = function() {

	/* [HIST]
$.ajax({
    type: "get",
    url: this.agentUrl_,
    dataType: "text",
    async: true,
    cache: false,
    data: {operation: 'GETSESSIONTIMEOUT', session: this.session, version: '1.0.0'},
    success: this.handleGetSessionTimeout_.bind(this),
    error: function(req) 
    {	
    	//alert("getSessionTimeout_ Error : \n\n" + req.responseText);
    	info("getSessionTimeout_ Error : \n\n" + req.responseText);
    }
  });
  /**/
	$.ajax({
	    type: "get",
	    url:"/route/map/selectExtraHttpClient.do",
	    dataType: "text",
	    async: true,
	    cache: false,
	    data: {
			URL: this.agentUrl_
			,OPERATION:'TIMEOUT'
			,SESSION:this.session
		},
	    success: this.handleGetSessionTimeout_.bind(this),
	    error: function(req) 
	    {	
	    	//alert("getSessionTimeout_ Error : \n\n" + req.responseText);
	    	info("getSessionTimeout_ Error : \n\n" + req.responseText);
	    }
	  });
};

himap.layer.MapGuideMap.prototype.handleGetSessionTimeout_ = function(sessionTimeout) {
  if (this.keepSession) {
    var sessionTimeout_ = parseFloat(sessionTimeout) * 1000;
    setTimeout(this.getSessionTimeout_.bind(this), sessionTimeout_);
  }
};

himap.layer.MapGuideMap.prototype.queryMapFeature = function(options, listener) {
  var layers = options.layers !== undefined ? options.layers : "";
  var geometry = options.geometry !== undefined ? options.geometry : "";
  var layerAttributeFilter = options.layerAttributeFilter !== undefined ? options.layerAttributeFilter : "3";
  var maxFeatures = options.maxFeatures !== undefined ? options.maxFeatures : "1";
  var persist = options.persist !== undefined ? options.persist : "0";

  var queryData = {
    OPERATION: 'QUERYMAPFEATURES',
    VERSION: '2.6.0',
    PERSIST: persist,
    MAPNAME: this.mapName,
    SESSION: this.session,
    LAYERNAMES: layers,
    GEOMETRY: geometry,
    SELECTIONVARIANT: 'INTERSECTS',
    MAXFEATURES: maxFeatures,
    LAYERATTRIBUTEFILTER: layerAttributeFilter,
    REQUESTDATA : '1',
    CLIENTAGENT: 'himap.layer.MapGuideMap'
  };

  $.ajax({
    type: "get",
    url : this.agentUrl_,
    data : queryData,
    dataType: "xml",
    async: true,
    cache: false,
    success: function (data, textStatus, jqXHR) {listener(jqXHR.responseXML);},
    error: function(req) 
    {
    	//alert("queryMapFeature Error : \n\n" + req.responseText);
    	info("queryMapFeature Error : \n\n" + req.responseText);
    }
  });
};

himap.layer.MapGuideMap.prototype.queryMapFeatureJson = function(options, listener) {
    var layers = options.layers !== undefined ? options.layers : "";
    var geometry = options.geometry !== undefined ? options.geometry : "";
    var layerAttributeFilter = options.layerAttributeFilter !== undefined ? options.layerAttributeFilter : "3";
    var maxFeatures = options.maxFeatures !== undefined ? options.maxFeatures : "1";
    var persist = options.persist !== undefined ? options.persist : "0";
    var requestdata = options.requestdata !== undefined ? options.requestdata : "1";

    var queryData = {
	    OPERATION: 'QUERYMAPFEATURES',
	    VERSION: '2.6.0',
	    PERSIST: persist,
	    MAPNAME: this.mapName,
	    SESSION: this.session,
	    LAYERNAMES: layers,
	    GEOMETRY: geometry,
	    SELECTIONVARIANT: 'INTERSECTS',
	    MAXFEATURES: maxFeatures,
	    LAYERATTRIBUTEFILTER: layerAttributeFilter,
	    REQUESTDATA : requestdata,
	    FORMAT: 'application/json',
	    CLIENTAGENT: 'himap.layer.MapGuideMap'
    };

    $.ajax({type: "get",
	    url : this.agentUrl_,
	    data : queryData,
	    dataType: "json",
	    async: true,
	    cache: false,
	    success: function(json) {listener(json);},
	    error: function(req) 
	    {
	    	//alert("queryMapFeature Error : \n\n" + req.responseText);
	    	info("queryMapFeature Error : \n\n" + req.responseText);
	    }
    });
};

himap.layer.MapGuideMap.prototype.queryMapFeatures = function(options, listener, mergeSelection, applySelection) {
  var layers = options.layers !== undefined ? options.layers : "";
  var geometry = options.geometry !== undefined ? options.geometry : "";
  var layerAttributeFilter = options.layerAttributeFilter !== undefined ? options.layerAttributeFilter : "3";
  var maxFeatures = options.maxFeatures !== undefined ? options.maxFeatures : "1";
  var persist = options.persist !== undefined ? options.persist : "0";
  var requestdata = options.requestdata !== undefined ? options.requestdata : "1";
  mergeSelection = mergeSelection !== undefined ? mergeSelection : false;
  applySelection = applySelection !== undefined ? applySelection : false;

  var queryData = {
    OPERATION: 'QUERYMAPFEATURES',
    VERSION: '2.6.0',
    PERSIST: persist,
    MAPNAME: this.mapName,
    SESSION: this.session,
    LAYERNAMES: layers,
    GEOMETRY: geometry,
    SELECTIONVARIANT: 'INTERSECTS',
    MAXFEATURES: maxFeatures,
    LAYERATTRIBUTEFILTER: layerAttributeFilter,
    FORMAT: 'application/json',
    CLIENTAGENT: 'himap.layer.MapGuideMap',
    REQUESTDATA: requestdata
  };

  $.ajax({
    type: "get",
    url : this.agentUrl_,
    data : queryData,
    dataType: "json",
    async: true,
    cache: false,
    success: this.processQueryMapFeatures_.bind(this, [listener, mergeSelection, applySelection]),
    error: function(req) {
      //alert("queryMapFeatures Error : \n\n" + req.responseText);
      //alert("지도 로딩 중입니다.");
    }
  });
};

himap.layer.MapGuideMap.prototype.processQueryMapFeatures_ = function(args, data) {
  info('himap.layer.MapGuideMap.prototype.processQueryMapFeatures_  data  ==> ' + jsonLib.stringify(data));
  var listener = args[0];
  var mergeSelection = args[1];
//  var applySelection = args[2];

  var newSelection = new himap.MapGuideSimpleSelectionObject(data);
  if (mergeSelection) {newSelection.merge(this.selection_);}

  this.selection_ = newSelection;

  var selText = newSelection.getSelectionXml();
  info('selText : ' + selText);
  if(selText != "" && selText != null) {
      this.selection_.layers = convertSelectedFeatureInfo(data);
      if (typeof listener !== "undefined") listener.call(this, this.selection_);
  } else {
      this.clearSelection();
      listener.call(this, this.selection_);
  }
};

himap.layer.MapGuideMap.prototype.clearSelection = function() {
  if (this.selection_ != null) {this.selection_.clear();}

  $.ajax({
    type: "get",
    url: this.serverPath + 'fusion/layers/MapGuide/php/ClearSelection.php',
    data : {'mapname': this.mapName, 'session': this.session},
    dataType: "text",
    async: true,
    cache: false,
    success: function(text){this.refresh();}.bind(this),
    error: function(xhr,status,error) {alert("clearSelection Error : \n\n" + xhr.responseText);}
  });
};

himap.layer.MapGuideMap.prototype.getLayerById = function(id) {
  var layer = null;
  for (var i = 0; i < this.layers.length; i++) {
    if (this.layers[i].uniqueId == id) {
      layer = this.layers[i];
      break;
    }
  }
  return layer;
};

himap.layer.MapGuideMap.prototype.getLayerByName = function(name) {
  var layer = null;
  for (var i = 0; i < this.layers.length; i++) {
      if (this.layers[i].layerName == name) {
          layer = this.layers[i];
          break;
      }
  }
  return layer;
};

himap.layer.MapGuideMap.prototype.getGroupById = function(id) {
  var group = null;
  for (var i = 0; i < this.groups.length; i++) {
    if (this.groups[i].uniqueId == id) {
      group = this.groups[i];
      break;
    }
  }
  return group;
};

himap.layer.MapGuideMap.prototype.getGroupByName = function(name) {
  var group = null;
  for (var i = 0; i < this.groups.length; i++) {
      if (this.groups[i].groupName == name) {
          group = this.groups[i];
          break;
      }
  }
  return group;
};

himap.layer.MapGuideMap.prototype.setLayerVisible = function(layers, layersOrVisible) {
  var layerIds = [];
  var hideLayerIds = [];
  var params = {SHOWLAYERS:"", HIDELAYERS:"", SHOWGROUPS:"", HIDEGROUPS : ""};

  if (typeof layers == "string") {
    layers = layers.split(",");
  }

  for (var i = 0; i < layers.length; i++) {
    var layer = this.getLayerByName(layers[i]);
    if (layer != null) {
      layerIds.push(layer.uniqueId);
    }
  }

  if (typeof layersOrVisible == "boolean") {
    if (layersOrVisible) {
      params.SHOWLAYERS = layerIds.join(",");
      params.HIDELAYERS = "";
    } else {
      params.SHOWLAYERS = "";
      params.HIDELAYERS = layerIds.join(",");
    }
  } else {
    if (typeof layersOrVisible == "string") {
      layersOrVisible = layersOrVisible.split(",");
    }

    for (var i = 0; i < layersOrVisible.length; i++) {
      var layer = this.getLayerByName(layersOrVisible[i]);
      if (layer != null) {
        hideLayerIds.push(layer.uniqueId);
      }
    }

    params.SHOWLAYERS = layerIds.join(",");
    params.HIDELAYERS = hideLayerIds.join(",");
  }

  this.getSource().updateParams(params);
};

/**
 * as.jeong
 * 한번에 setLayerVisible를 2번이상 호출시 동작안하는 문제를 해결하기 위해
 * 보여줄레이어, 안보여줄 레이어를 한번에 받아서 처리하는 구문 추가
 * @param vlayers
 * @param nlayers
 */
himap.layer.MapGuideMap.prototype.setLayerVisible2 = function(vlayers, nlayers) {
  var showlayerIds = [];
  var hideLayerIds = [];
  var params = {SHOWLAYERS:"", HIDELAYERS:"", SHOWGROUPS:"", HIDEGROUPS : ""};

  if (typeof vlayers == "string") vlayers = vlayers.split(",");
  if (typeof nlayers == "string") nlayers = nlayers.split(",");

  for (var i = 0; i < vlayers.length; i++) {
     var layer = this.getLayerByName(vlayers[i]);
     if (layer != null) showlayerIds.push(layer.uniqueId);
  }

  for (var i = 0; i < nlayers.length; i++) {
     var layer = this.getLayerByName(nlayers[i]);
     if (layer != null) hideLayerIds.push(layer.uniqueId);
  }

  params.SHOWLAYERS = showlayerIds.join(",");
  params.HIDELAYERS = hideLayerIds.join(",");

  this.getSource().updateParams(params);
};

himap.layer.MapGuideMap.prototype.setGroupVisible = function(groups, groupsOrVisible) {
  var groupIds = [];
  var hideGroupIds = [];
  var params = {SHOWLAYERS:"", HIDELAYERS:"", SHOWGROUPS:"", HIDEGROUPS : ""};

  if (typeof groups == "string") {
    groups = groups.split(",");
  }

  for (var i = 0; i < groups.length; i++) {
    var group = this.getGroupByName(groups[i]);
    if (group != null) groupIds.push(group.uniqueId);
  }

  if (typeof groupsOrVisible == "boolean") {
    if (groupsOrVisible) {
      params.SHOWGROUPS = groupIds.join(",");
      params.HIDEGROUPS = "";
    } else {
      params.SHOWGROUPS = "";
      params.HIDEGROUPS = groupIds.join(",");
    }
  } else {
    if (typeof groupsOrVisible == "string") {
      groupsOrVisible = groupsOrVisible.split(",");
    }

    for (var i = 0; i < groupsOrVisible.length; i++) {
      var group = this.getLayerByName(groupsOrVisible[i]);
      if (group != null) {
        hideGroupIds.push(group.uniqueId);
      }
    }

    params.SHOWGROUPS = groupIds.join(",");
    params.HIDEGROUPS = hideGroupIds.join(",");
  }

  this.getSource().updateParams(params);
};

/**
 * group의 View 여부를 한꺼번에 처리(2번 이상 호출시 동작안하는 문제 해결)
 * @param vgroups 보여줄 레이어
 * @param ngroups 숨길 레이어 그룹
 */
himap.layer.MapGuideMap.prototype.setGroupVisible2 = function(vgroups, ngroups) {
  var showGroupIds = [];
  var hideGroupIds = [];
  var params = {SHOWLAYERS:"", HIDELAYERS:"", SHOWGROUPS:"", HIDEGROUPS : ""};

  if (typeof vgroups == "string") vgroups = vgroups.split(",");
  if (typeof ngroups == "string") ngroups = ngroups.split(",");

  for (var i = 0; i < vgroups.length; i++) {
    var group = this.getGroupByName(vgroups[i]);
    if (group != null) showGroupIds.push(group.uniqueId);
  }
  for (var i = 0; i < ngroups.length; i++) {
    var group = this.getGroupByName(ngroups[i]);
    if (group != null) hideGroupIds.push(group.uniqueId);
  }

  params.SHOWGROUPS = showGroupIds.join(",");
  params.HIDEGROUPS = hideGroupIds.join(",");

  this.getSource().updateParams(params);
};

/**
 * layer, group의 View 여부를 한꺼번에 처리
 * @param vlayers 보여줄 레이어
 * @param nlayers 숨길 레이어 그룹
 * @param vgroups 보여줄 레이어
 * @param ngroups 숨길 레이어 그룹
 */
himap.layer.MapGuideMap.prototype.setLayerGroupVisible = function(vlayers, nlayers, vgroups, ngroups) {
  var showLayerIds = [];
  var hideLayerIds = [];
  var showGroupIds = [];
  var hideGroupIds = [];
  var params = {SHOWLAYERS:"", HIDELAYERS:"", SHOWGROUPS:"", HIDEGROUPS : ""};

  if (typeof vlayers == "string") vlayers = vlayers.split(",");
  if (typeof nlayers == "string") nlayers = nlayers.split(",");
  if (typeof vgroups == "string") vgroups = vgroups.split(",");
  if (typeof ngroups == "string") ngroups = ngroups.split(",");

  for (var i = 0; i < vlayers.length; i++) {
     var layer = this.getLayerByName(vlayers[i]);
     if (layer != null) showLayerIds.push(layer.uniqueId);
  }
  for (var i = 0; i < nlayers.length; i++) {
     var layer = this.getLayerByName(nlayers[i]);
     if (layer != null) hideLayerIds.push(layer.uniqueId);
  }

  for (var i = 0; i < vgroups.length; i++) {
    var group = this.getGroupByName(vgroups[i]);
    if (group != null) showGroupIds.push(group.uniqueId);
  }
  for (var i = 0; i < ngroups.length; i++) {
    var group = this.getGroupByName(ngroups[i]);
    if (group != null) hideGroupIds.push(group.uniqueId);
  }

  params.SHOWLAYERS = showLayerIds.join(",");
  params.HIDELAYERS = hideLayerIds.join(",");
  params.SHOWGROUPS = showGroupIds.join(",");
  params.HIDEGROUPS = hideGroupIds.join(",");

  this.getSource().updateParams(params);
};

himap.layer.MapGuideMap.prototype.refresh = function() {
  this.getSource().refresh();
};

himap.layer.MapGuideMap.prototype.updateParams = function(params) {
  this.getSource().updateParams(params);
};

/*
himap.layer.MapGuideMap.Map (ol.layer.MapGuideMap 상속)
*/
himap.layer.MapGuideMap.Map = function (options) {
  options = options || {};
  var visible = options.visible !== undefined ? options.visible : true;
  var autoRefreshInterval = options.autoRefreshInterval !== undefined ? options.autoRefreshInterval : 0;

  var info_ = mapguidemapLayers_.get(options.name);
  if(info_) {
    info_ = info_.split('||');
    var ip = info_[0];
    var mapdefinition = info_[1];
    var serverPath = himap.url.SERVER_PATH.replace('{ip}', ip);
    if(himap.url.SERVER_MODE != 'R' && serverPath.indexOf(himap.url.SERVER_IP) > -1) { serverPath = serverPath.replace('8808', '8008'); }

    ol.obj.assign(options, {
      sysKey: options.sysKey,
      name: options.name,
      autoRefreshInterval: autoRefreshInterval,
      serverPath: serverPath,
      mapDefinition: mapdefinition,
      visible: visible
    });
  }

  himap.layer.MapGuideMap.call(this, options);
};
ol.inherits(himap.layer.MapGuideMap.Map, himap.layer.MapGuideMap);


himap.layer.vworld = {};

//브이월드 수치지도 배경
himap.layer.vworld.Base = function(opt_options) {
  options = opt_options !== undefined ? opt_options : {};
  var proxy = options.proxy !== undefined ? options.proxy : himap.url.VWORLD_PROXY;
  //var tileUrl = "http://xdworld.vworld.kr:8080/2d/Base/201612/{z}/{x}/{y}.png";
  //var tileUrl = "http://api.vworld.kr/req/wmts/1.0.0/88A3DFA4-B355-30BB-85EA-7314FCDDA8DE/Base/{z}/{y}/{x}.png";
 // var tileUrl = "http://xdworld.vworld.kr:8080/2d/gray/202002/{z}/{x}/{y}.png";
  var tileUrl = "http://api.vworld.kr/req/wmts/1.0.0/88A3DFA4-B355-30BB-85EA-7314FCDDA8DE/Base/{z}/{y}/{x}.png";
  if (proxy != "") tileUrl = proxy + "?" + tileUrl;

  options.name = 'vworld.Base';
  options.source = new ol.source.XYZ({url: tileUrl, maxZoom: 18, minZoom: 6});

  openApiLogArr.push('01|4');

  himap.layer.Tile.call(this, options);
};
ol.inherits(himap.layer.vworld.Base, himap.layer.Tile);

himap.layer.vworld.Satellite = function(opt_options) {
  options = opt_options !== undefined ? opt_options : {};
  var proxy = options.proxy !== undefined ? options.proxy : himap.url.VWORLD_PROXY;
  var tileUrl = "http://api.vworld.kr/req/wmts/1.0.0/88A3DFA4-B355-30BB-85EA-7314FCDDA8DE/Satellite/{z}/{y}/{x}.jpeg";
  if (proxy != "") tileUrl = proxy + "?" + tileUrl;

  options.name = 'vworld.Satellite';
  options.source = new ol.source.XYZ({url: tileUrl, maxZoom: 18, minZoom: 6});

  openApiLogArr.push('01|6');

  himap.layer.Tile.call(this, options);
};
ol.inherits(himap.layer.vworld.Satellite, himap.layer.Tile);

himap.layer.vworld.Hybrid = function(opt_options) {
  options = opt_options !== undefined ? opt_options : {};
  var proxy = options.proxy !== undefined ? options.proxy : himap.url.VWORLD_PROXY;
  var tileUrl = "http://xdworld.vworld.kr:8080/2d/Hybrid/201512/{z}/{x}/{y}.png";
  if (proxy != "") tileUrl = proxy + "?" + tileUrl;

  options.name = 'vworld.Hybrid';
  options.source = new ol.source.XYZ({url: tileUrl, maxZoom: 18, minZoom: 6});

  himap.layer.Tile.call(this, options);
};
ol.inherits(himap.layer.vworld.Hybrid, himap.layer.Tile);

himap.wmsLayer = {
  "지적도":"LP_PA_CBND_BUBUN,LP_PA_CBND_BONBUN",
  "도시지역":"LT_C_UQ111", "관리지역":"LT_C_UQ112", "농림지역":"LT_C_UQ113", "자연환경보전지역":"LT_C_UQ114",
  "경관지구":"LT_C_UQ121", "미관지구":"LT_C_UQ122", "고도지구":"LT_C_UQ123", "방화지구":"LT_C_UQ124", "방재지구":"LT_C_UQ125", "보존지구":"LT_C_UQ126", "시설보호지구":"LT_C_UQ127", "취락지구":"LT_C_UQ128", "개발진흥지구":"LT_C_UQ129", "특정용도제한구역":"LT_C_UQ130",
  "국토계획구역":"LT_C_UQ141", "도시자연공원구역":"LT_C_UQ162", "개발제한구역":"LT_C_UD801"
};
/*
* @param options.name
*     { 지적도
*       용도지역도: 도시지역,관리지역,농림지역,자연환경보전지역
*       용도지구도: 경관지구,미관지구,고도지구,방화지구,방재지구, 보존지구,시설보호지구,취락지구,개발진흥지구,특정용도제한구역
*       용도구역도: 국토계획구역,도시자연공원구역,개발제한구역
*     }
*/
himap.layer.vworld.TileWMS = function(options) {
  options = options || {};
  var name = options.name !== undefined ? options.name : 'himap.layer.vworld.TileWMS';
  var layers = himap.wmsLayer[name];
  var apiKey = options.apiKey !== undefined ? options.apiKey : '5B8A5583-4E19-346B-B617-C426DD02E3E5';//http://spa.ex.co.kr:5003

  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(name, '100||' + name + ' 레이어의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}
  if(!errFlag && name == 'himap.layer.vworld.TileWMS') {errFlag = true; this.setErr(name, '300||' + name + ' 레이어의 필수 입력인 name이 없습니다.');}
  if(!errFlag && layers === undefined) {errFlag = true; this.setErr(name, '400||' + name + ' 레이어는 제공되지 않는 기능입니다.');}

  var visible = options.visible !== undefined ? options.visible : true;
  var proxy = options.proxy !== undefined ? options.proxy : himap.url.VWORLD_PROXY;
  var tileUrl = "http://map.vworld.kr/js/wms.do?";
  if (proxy != "") { tileUrl = proxy + "?" + tileUrl; }

  if(errFlag) {
    ol.layer.Tile.call(this, {});
    ol.DEBUG && console.assert(errFlag === false, this.getErrorMsg(name));
  } else {
    ol.layer.Tile.call(this, {
      name: name,
      source: new ol.source.TileWMS({
        url: tileUrl,
        params: {LAYERS: layers, STYLES: layers, TILED: true, FORMAT: 'image/png', WIDTH: 256, HEIGHT: 256, TRANSPARENT: true, CRS: 'EPSG:900913', EXCEPTIONS:'text/xml', APIKEY: apiKey}
      }),
      visible: visible
    });
    openApiLogArr.push('01|2');
  }
};
ol.inherits(himap.layer.vworld.TileWMS, ol.layer.Tile);


himap.MiniMap = function(options) {
  options = options || {};
  var controls = options.controls !== undefined ? options.controls : [];
  var session = options.session !== undefined ? options.session : "";
  var keepSession = options.keepSession !== undefined ? options.keepSession : true;
  var layers = [
    new himap.layer.MapGuideMap({
      name: 'minimap_nexman',
      serverpath: himap.url.SERVER_PATH,
      mapDefinition: 'Library://GoogleTM/MINI_MAP/Maps/Nex_Man_MiniMap.MapDefinition',
      autoRefreshInterval: 3 * 60 * 1000,
      session: session,
      keepSession: keepSession,
      visible: true
    })
  ];
  var viewResolutions = [4891.96981025128];
  var zoom = 0;
  var map = options.map !== undefined ? options.map : null;
  this.map_ = null;
  this.polygonFeature_ = null;

  this.setMap(map);

  var target = options.target !== undefined ? document.getElementById(options.target) : null;

  himap.Map.call(this, {
    name: "MINIMAP",
    target: target,
    renderer: ol.RendererHint.CANVAS,
    layers: layers,
    ol3Logo: false,
    controls: [],
    interactions: [],
    zoom: zoom,
    viewResolutions: viewResolutions
  });

  this.getInteractions().clear();
  this.getControls().clear();

  controls.forEach(function(control) {
    this.addControl(control);
  }, this);

  this.featureOverlay_ = new ol.FeatureOverlay({
    style: new ol.style.Style({
      stroke: new ol.style.Stroke({color:[255, 0, 0, 1], width:2})
    })
  });

  this.featureOverlay_.setMap(this);
};
ol.inherits(himap.MiniMap, himap.Map);

himap.MiniMap.prototype.setMap = function(map) {
  this.unBindEvent_();

  if (map) {
    this.map_ = map;
    this.bindEvent_();
  } else {
    this.map_ = null;
  }
};

himap.MiniMap.prototype.bindEvent_ = function() {
  ol.events.listen(this.map_, 'moveend', this.handleMapMoveEnd, this, false);
  ol.events.listen(this.map_.getView(), 'change:resolution', this.handleViewResolutionchange, this, false);
};

himap.MiniMap.prototype.unBindEvent_ = function() {
  if (this.map_) {
    ol.events.unlisten(this.map_, 'moveend', this.handleMapMoveEnd, this, false);
    ol.events.unlisten(this.map_.getView(), 'change:resolution', this.handleViewResolutionchange, this, false);
  }
};

himap.MiniMap.prototype.handleMapMoveEnd = function(event) {
  var map = event.map;
  var extent = map.getView().calculateExtent(map.getSize());

  var coordinates = [];
  coordinates[0] = [extent[0], extent[1]];
  coordinates[1] = [extent[0], extent[3]];
  coordinates[2] = [extent[2], extent[3]];
  coordinates[3] = [extent[2], extent[1]];
  coordinates[4] = [extent[0], extent[1]];

  if (!this.polygonFeature_) {
    this.polygonFeature_ = new ol.Feature(new ol.geom.Polygon([coordinates]));
    this.featureOverlay_.addFeature(this.polygonFeature_);
  } else {
    this.polygonFeature_.getGeometry().setCoordinates([coordinates]);
  }
};

himap.MiniMap.prototype.handleViewResolutionchange = function(event) {
};

himap.MapGuideSimpleSelectionObject = function(featureInfoResponse) {
  this.aLayers  = [];
  this.nLayers = 0;

  try {
    var layers = featureInfoResponse.FeatureInformation.FeatureSet[0].Layer;
    if (layers != null) {
      for(var i = 0; i < layers.length; i++) {
        var layerId = layers[i]['@id'][0];

        info('layerId : ' + layerId);

        var classElt = layers[i]['Class'][0];
        var className = layers[i]['Class'][0]['@id'][0];
        var layer = new himap.MapGuideSimpleSelectionObject.Layer(layerId, className);
        this.addLayer(layer);

        var features = classElt.ID;
        for(var j=0; j < features.length; j++) {
          layer.addFeature(features[j]);
        }
      }
    }
  }
  catch(e) {alert(e.message);}
};

himap.MapGuideSimpleSelectionObject.prototype.addLayer = function(layer) {
  this.aLayers[this.nLayers] = layer;
  this.nLayers++;
};

himap.MapGuideSimpleSelectionObject.prototype.getNumLayers = function() {
  return this.nLayers;
};

himap.MapGuideSimpleSelectionObject.prototype.getLayerByName = function(name) {
  var oLayer = null;
  for (var i=0; i<this.nLayers; i++) {
    if (this.aLayers[i].getName() == name) {
      oLayer = this.aLayers[i];
      break;
    }
  }
  return oLayer;
};

himap.MapGuideSimpleSelectionObject.prototype.getLayer = function(iIndice) {
  if (iIndice >= 0 && iIndice < this.nLayers) {
    return this.aLayers[iIndice];
  } else {
    return null;
  }
};

himap.MapGuideSimpleSelectionObject.prototype.getSelectionXml = function() {
  var xmlSelection = "";
  if(this.nLayers > 0) {
    xmlSelection = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<FeatureSet>\n";
    for(var i = 0; i < this.nLayers; i++) {
      var layer = this.aLayers[i];
      xmlSelection += "<Layer id=\"" + layer.getName() + "\">\n";
      xmlSelection += "<Class id=\"" + layer.getClassName() + "\">\n";
      for(var j = 0; j < layer.getNumFeatures(); j++) {
        var featId = layer.featIds[j];
        xmlSelection += "<ID>" +  featId + "</ID>\n";
      }
      xmlSelection += "</Class>\n</Layer>\n";
    }
    xmlSelection += "</FeatureSet>\n";
  }
  return xmlSelection;
};

himap.MapGuideSimpleSelectionObject.prototype.merge = function(previousSelection) {
  if (previousSelection != null && previousSelection.nLayers > 0) {
    for (var prevSelIndex = 0; prevSelIndex < previousSelection.nLayers; prevSelIndex++) {
      var prevSelLayer = previousSelection.aLayers[prevSelIndex];

      // find the previously selected layer name in the current selection
      var currentLayer = this.getLayerByName(prevSelLayer.getName());
      if (currentLayer != null) {
        // add the previously selected features for this layer
        for (var j = 0; j < prevSelLayer.getNumFeatures(); j++) {
          var prevSelFeatureIndexes = himapFindArrayIndexes(currentLayer.featIds, prevSelLayer.featIds[j]);
          if (prevSelFeatureIndexes == null) {
        	  currentLayer.addFeature(prevSelLayer.featIds[j]);
          } else {
            // the feature was previously selected, so toggle it off when selected again
            currentLayer.removeFeatures(prevSelFeatureIndexes);
          }
        }
        if (currentLayer.featIds.length == 0) {
          this.clear();
        }
      } else {
        // the current selection does not include this previously selected layer

        // need to add this previously selected layer and its features
        var missingLayer = new himap.MapGuideSimpleSelectionObject.Layer(prevSelLayer.getName(), prevSelLayer.getClassName());
        for (var k = 0; k < prevSelLayer.getNumFeatures(); k++) {
          missingLayer.addFeature(prevSelLayer.featIds[k]);
        }
        this.addLayer(missingLayer);
      }
    }
  }
};

himap.MapGuideSimpleSelectionObject.prototype.clear = function() {
  this.aLayers = [];
  this.nLayers = 0;
};

himap.MapGuideSimpleSelectionObject.Layer = function(layerName, className) {
  this.name =  layerName;
  this.className = className;
  this.nFeatures = 0;
  this.featIds =  [];
};

himap.MapGuideSimpleSelectionObject.Layer.prototype.addFeature = function (featId) {
  this.featIds[this.nFeatures] = featId;
  this.nFeatures++;
};

himap.MapGuideSimpleSelectionObject.Layer.prototype.getName = function() {
  return this.name;
};

himap.MapGuideSimpleSelectionObject.Layer.prototype.getClassName = function() {
  return this.className;
};

himap.MapGuideSimpleSelectionObject.Layer.prototype.getNumFeatures = function() {
  return this.nFeatures;
};

himap.MapGuideSimpleSelectionObject.Layer.prototype.removeFeatures = function (featureIndexes) {
  var numIndexes = featureIndexes.length;
  for (var featIndex = 0; featIndex < numIndexes; featIndex++) {
    this.featIds.remove(featureIndexes[featIndex]);
    this.nFeatures--;
  }
};

// 표준 Array.prototype.find를 덮어쓰지 않는다. HiMap 내부의 인덱스 검색만 별도 함수로 격리한다.
function himapFindArrayIndexes(sourceArray, searchStr) {
  var returnArray = null;
  for (var i=0; i<sourceArray.length; i++) {
    if (searchStr && typeof(searchStr.test) == 'function') {
      if (searchStr.test(sourceArray[i])) {
        if (!returnArray) { returnArray = []; }
        returnArray.push(i);
      }
    } else {
      if (sourceArray[i]===searchStr) {
        if (!returnArray) { returnArray = []; }
        returnArray.push(i);
      }
    }
  }
  return returnArray;
}

Array.prototype.remove = function(indexToRemove) {
  this.splice(indexToRemove, 1);
};

convertSelectedFeatureInfo = function(efi) {
  var result =[];
  if (efi.FeatureInformation.SelectedFeatures) {
    var selLayers = efi.FeatureInformation.SelectedFeatures[0].SelectedLayer;
	for (var i = 0; i < selLayers.length; i++) {
      var selLayer = selLayers[i];
	  var selFeatures = selLayer.Feature || [];
	  var layerName = selLayer["@name"];
	  result[layerName] = [];

	  var metaProperty = [];
	  if (selLayer.LayerMetadata) {
        var layerMeta = selLayer.LayerMetadata[0];
        for (var j = 0; j < layerMeta.Property.length; j++) {
          var metaProp = layerMeta.Property[j];
          metaProperty[j] = metaProp.Name[0];
        }
      }

      for (var j = 0; j < selFeatures.length; j++) {
        var feat = selFeatures[j];
        result[layerName][j] = [];
        result[layerName][j].values = [];
        if (feat.Property) {
          for (var k = 0; k < feat.Property.length; k++) {
            result[layerName][j].values[k] ={};
            result[layerName][j].values[k].value = feat.Property[k].Value == null ? "" :feat.Property[k].Value[0];
            result[layerName][j].values[k].name =  metaProperty[k];
          }
        }
        if (feat.Bounds) {
          var bounds = feat.Bounds[0].split(" "); //minx miny maxx maxy
          result[layerName][j].zoom = {minx :parseFloat(bounds[0]), miny :parseFloat(bounds[1]), maxx :parseFloat(bounds[2]), maxy :parseFloat(bounds[3])};
        }
      }
    }
  }
  return result;
};

/*
 * 추정중량, 물동량 레이어
 */
himap.layer.OvmsLayer = function(options) {
	options = options || {};
	var errFlag = false;
	var errMsg = "";;
	var name = options.name !== undefined ? options.name : 'himap.layer.OvmsLayer';
	if(!options.sysKey) {errFlag = true; errMsg = '100||' + name + ' 레이어의 필수 입력인 sysKey가 없습니다.';}
	else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}

	if(errFlag) {
		alert(errMsg);
		return;
	}
	var map = options.map !== undefined ? options.map : null;
	this.layerType = options.layerType !== undefined ? options.layerType : "weight";
	this.setMap(map);

	openApiLogArr.push('01|3');
};

himap.layer.OvmsLayer.prototype.setMap = function(map) {
    this.map_ = map;
    this.view_ = map.getView();
    //레이어생성
    this.init();
    this.featuresById_ = {};
    this.extent_ = ol.extent.createEmpty();//[Infinity, Infinity, -Infinity, -Infinity];
    this.loadedCount_ = 0;
};

//추정중량 레이어 생성
himap.layer.OvmsLayer.prototype.init = function(map) {
	this.layers_ = [];
	this.layers_.push(
        new ol.layer.Vector({
            name: 'roadLayer1',
            source: new ol.source.Vector({}),
            minResolution: 0,
            maxResolution: 20,
            visible: true
        })
    );

	this.layers_.push(
        new ol.layer.Vector({
            name: 'roadLayer2',
            source: new ol.source.Vector({}),
            minResolution: 20,
            maxResolution: 200,
            visible: true
        })
    );

	this.layers_.push(
        new ol.layer.Vector({
            name: 'roadLayer3',
            source: new ol.source.Vector({}),
            minResolution: 200,
            visible: true
        })
    );

	//구간별 색상을 지정
	this.colors_ = {};
	if (this.layerType == "weight") {//추정중량
		this.colors_["c_0"] = "rgba(214, 214, 214, 1)";
	    this.colors_["c_1"] = "rgba(  0, 128,   0, 1)";
	    this.colors_["c_2"] = "rgba(  1, 217,  71, 1)";
	    this.colors_["c_3"] = "rgba(172, 255,   0, 1)";
	    this.colors_["c_4"] = "rgba(255, 255,   0, 1)";
	    this.colors_["c_5"] = "rgba(255, 165,   0, 1)";
	    this.colors_["c_6"] = "rgba(255,  82,   0, 1)";
	    this.colors_["c_7"] = "rgba(255,   0,   0, 1)";
	//물동량 (todo - 구간별 색상 업무팀에서 확정되면 수정하세요!)
	} else {
		this.colors_["c_0"] = "rgba(214, 214, 214, 1)";
	    this.colors_["c_1"] = "rgba(  0, 128,   0, 1)";
	    this.colors_["c_2"] = "rgba(  1, 217,  71, 1)";
	    this.colors_["c_3"] = "rgba(0, 255,   0, 1)";
	    this.colors_["c_4"] = "rgba(0, 255,   0, 1)";
	    this.colors_["c_5"] = "rgba(0, 165,   0, 1)";
	    this.colors_["c_6"] = "rgba(0,  82,   0, 1)";
	    this.colors_["c_7"] = "rgba(0,   0,   0, 1)";
	}

    this.styleCache_ = {};
    var styleFunction = (function(feature, resolution) {
        if (feature.weight < 0) {
            return null;
        }

        var name;
        if (this.layerType == "weight") {//추정중량
        	name = "c_" + this.getColorIndex_(feature.weightType, feature.weight);
        } else {//물동량
        	name = "c_" + this.getColorIndexQuantity_(feature.weightType, feature.weight);
        }
        if (!this.styleCache_[name]) {
            info("new styleCahce : " + name);
            this.styleCache_[name] = new ol.style.Style({
                stroke: new ol.style.Stroke({color: 'rgba(180, 180, 180, 1)', width: 1}),
                fill: new ol.style.Fill({color: this.colors_[name]})
            });
        };

        return [this.styleCache_[name]];
    }).bind(this);

    for (var i = 0, len = this.layers_.length; i < len; i++ ) {
        var layer = this.layers_[i];
        layer.setStyle(styleFunction);
        this.map_.addLayer(layer);
    }
};

himap.layer.OvmsLayer.prototype.loadFeature = function () {
	//레이어그리기
	if (this.layerType == "weight") {//추정중량
		this.drawFeature(this.layers_[2], himap.smartdata.weight3);
		this.drawFeature(this.layers_[1], himap.smartdata.weight2);
		this.drawFeature(this.layers_[0], himap.smartdata.weight1);
    } else {//물동량 (todo 업무팀에서 물동량 데이터 적용 하세요!)
    	this.drawFeature(this.layers_[2], himap.smartdata.weight3);
    	this.drawFeature(this.layers_[1], himap.smartdata.weight2);
    	this.drawFeature(this.layers_[0], himap.smartdata.weight1);
    }
};

himap.layer.OvmsLayer.prototype.drawFeature = function (vectorLayer, json) {
	var wkt = new ol.format.WKT();
    for (var i = 0; i < json.length; i++) {
        var feature = wkt.readFeature(json[i]["Geometry"]);
        if (feature) {
            vectorLayer.getSource().addFeature(feature);
            var linkId = json[i]["LINK_ID"];
            feature.linkId = linkId;
            feature.weightType = "";
            feature.weight = -1;

            // 3단계 레이어별 동일 linkId Feature 모음
            if (!this.isDef(this.featuresById_[linkId])) {
            	this.featuresById_[linkId] = [feature];
            } else {
            	this.featuresById_[linkId].push(feature);
            }
        }
    }
    this.loadedCount_++;
};

himap.layer.OvmsLayer.prototype.clearData = function() {
    // 레이어의 중량정보 초기화
    for (var i = 0, len = this.layers_.length; i < len; i++) {
        var layer = this.layers_[i];
        var features = layer.getSource().getFeatures();
        for (var ii = 0, len2 = features.length; ii < len2; ii++) {
            features[ii].weight = -1;
        }
    }
    ol.extent.createOrUpdateEmpty(this.extent_);
};

himap.layer.OvmsLayer.prototype.setDataArray = function(type, data) {
	for (var i = 0, len = data.length; i < len; i++ ) {
		this.setData(type, data[i][0], data[i][1]);
	}
};

himap.layer.OvmsLayer.prototype.setData = function(type, linkId, weight) {
    if (!this.getLoaded()) {
        return;
    }
    var features = this.featuresById_[linkId];
    for (var i = 0, len = features.length; i < len; i++ ) {
        var feature = features[i];
        feature.weightType = type;
        feature.weight = weight;
        ol.extent.extend(this.extent_, feature.getGeometry().getExtent());
    }
};

himap.layer.OvmsLayer.prototype.getLoaded = function() {
	return this.loadedCount_ == 3;
};

himap.layer.OvmsLayer.prototype.redraw = function(isFitExtent) {
    this.layers_.forEach(function(layer) {
        layer.setStyle(layer.getStyle());
    });

    isFitExtent = this.isDef(isFitExtent) ? isFitExtent : true;
    if (isFitExtent) {
        this.fitExtent();
    }
};

himap.layer.OvmsLayer.prototype.fitExtent = function() {
    if (ol.extent.getWidth(this.extent_) != 0) {
    	this.prepareAnimation(this.map_);
        this.view_.fit(this.extent_, this.map_.getSize());
    }
};

himap.layer.OvmsLayer.prototype.prepareAnimation = function(map) {
    map.getView().animate({
	    resolution: map.getView().getMaxResolution(),
	    easing: ol.easing.easeOut,
	    anchor: this.lastAnchor_,
	    duration: 500
    });
};

himap.layer.OvmsLayer.prototype.getColorIndex_ = function(type, weight) {
    var colorIndex = 0;
    if (type == "year") {
        if (weight <= 0) { colorIndex = 0; }
        else if (weight <= 138600) { colorIndex = 1; }
        else if (weight <= 277200) { colorIndex = 2; }
        else if (weight <= 415800) { colorIndex = 3; }
        else if (weight <= 554400) { colorIndex = 4; }
        else if (weight <= 693000) { colorIndex = 5; }
        else if (weight <= 831600) { colorIndex = 6; }
        else if (weight > 831600) { colorIndex = 7; }
    } else if (type == "month") {
        if (weight <= 0) { colorIndex = 0; }
        else if (weight <= 48600) { colorIndex = 1; }
        else if (weight <= 97200) { colorIndex = 2; }
        else if (weight <= 145800) { colorIndex = 3; }
        else if (weight <= 194400) { colorIndex = 4; }
        else if (weight <= 243000) { colorIndex = 5; }
        else if (weight <= 291600) { colorIndex = 6; }
        else if (weight > 291600) { colorIndex = 7; }
    }  else if (type == "week") {
        if (weight <= 0) { colorIndex = 0; }
        else if (weight <= 13300) { colorIndex = 1; }
        else if (weight <= 16600) { colorIndex = 2; }
        else if (weight <= 29900) { colorIndex = 3; }
        else if (weight <= 33200) { colorIndex = 4; }
        else if (weight <= 46500) { colorIndex = 5; }
        else if (weight <= 50000) { colorIndex = 6; }
        else if (weight > 50000) { colorIndex = 7; }
    }  else if (type == "date") {
        if (weight <= 0) { colorIndex = 0; }
        else if (weight <= 1900) { colorIndex = 1; }
        else if (weight <= 3800) { colorIndex = 2; }
        else if (weight <= 5700) { colorIndex = 3; }
        else if (weight <= 7600) { colorIndex = 4; }
        else if (weight <= 9500) { colorIndex = 5; }
        else if (weight <= 11400) { colorIndex = 6; }
        else if (weight > 11400) { colorIndex = 7; }
    }
    return colorIndex;
};

//todo 업무팀에서 물동량 구간별 색상적용하세요!
himap.layer.OvmsLayer.prototype.getColorIndexQuantity_ = function(type, weight) {
    var colorIndex = 0;
    if (type == "year") {
        if (weight <= 0) { colorIndex = 0; }
        else if (weight <= 138600) { colorIndex = 1; }
        else if (weight <= 277200) { colorIndex = 2; }
        else if (weight <= 415800) { colorIndex = 3; }
        else if (weight <= 554400) { colorIndex = 4; }
        else if (weight <= 693000) { colorIndex = 5; }
        else if (weight <= 831600) { colorIndex = 6; }
        else if (weight > 831600) { colorIndex = 7; }
    } else if (type == "month") {
        if (weight <= 0) { colorIndex = 0; }
        else if (weight <= 48600) { colorIndex = 1; }
        else if (weight <= 97200) { colorIndex = 2; }
        else if (weight <= 145800) { colorIndex = 3; }
        else if (weight <= 194400) { colorIndex = 4; }
        else if (weight <= 243000) { colorIndex = 5; }
        else if (weight <= 291600) { colorIndex = 6; }
        else if (weight > 291600) { colorIndex = 7; }
    }  else if (type == "week") {
        if (weight <= 0) { colorIndex = 0; }
        else if (weight <= 13300) { colorIndex = 1; }
        else if (weight <= 16600) { colorIndex = 2; }
        else if (weight <= 29900) { colorIndex = 3; }
        else if (weight <= 33200) { colorIndex = 4; }
        else if (weight <= 46500) { colorIndex = 5; }
        else if (weight <= 50000) { colorIndex = 6; }
        else if (weight > 50000) { colorIndex = 7; }
    }  else if (type == "date") {
        if (weight <= 0) { colorIndex = 0; }
        else if (weight <= 1900) { colorIndex = 1; }
        else if (weight <= 3800) { colorIndex = 2; }
        else if (weight <= 5700) { colorIndex = 3; }
        else if (weight <= 7600) { colorIndex = 4; }
        else if (weight <= 9500) { colorIndex = 5; }
        else if (weight <= 11400) { colorIndex = 6; }
        else if (weight > 11400) { colorIndex = 7; }
    }
    return colorIndex;
};

himap.layer.OvmsLayer.prototype.isDef = function (obj) {
    return typeof obj !== "undefined";
};
