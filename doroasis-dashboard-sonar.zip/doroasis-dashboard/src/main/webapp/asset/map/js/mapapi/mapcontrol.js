himap.control = {};
himap.overlay = {};
himap.render = {};
himap.search = {};
himap.search.FacSearch = {};
himap.search.VworldSearch = {};

/*  파노라마 연동을 위한 컨트롤
- 지도상단 파노라마맵 시작 버튼
- 마우스 이동, 드래그, 클릭시 아이콘 변경
- 파노라마맵 조회 후 파노라마쪽으로 연동
- 아이콘 방향전환
*/
himap.control.Panorama = function(opt_options) {
  this.name = 'himap.control.Panorama';
  var options = opt_options !== undefined ? opt_options : {};

  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(this.name, '100||' + this.name + ' 레이어의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}

  if(errFlag) {
    ol.control.Control.call(this, {element: document.createElement('DIV'), target: null});
    ol.DEBUG && console.assert(errFlag === false, this.getErrorMsg(this.name));
  } else {
    this.className = options.className !== undefined ? options.className : 'hi-pano';

    var element = document.createElement('DIV');
    element.className = this.className + '-start' + ' ol-unselectable';
    element.setAttribute('unselectable', 'on');

    ol.control.Control.call(this, {element: element, target: null});

    this.activate_ = false;
    this.layer_ = new himap.layer.Tile.Layer({sysKey: options.sysKey, name: 'Panorama', visible: true});
    this.queryLayer_ = new himap.layer.MapGuideMap.Map({
      sysKey: options.sysKey,
      name: 'RoadView',
      autoRefreshInterval: 3 * 60 * 1000,
      session: options.session,
      keepSession: options.keepSession,
      visible: true
    });

    this.actorOverlay_ = null;
    this.lastActorPositon_ = null;
    this.mouseDownPixel_ = null;
    this.iconTimeoutId_ = 0;
    this.iconStopInterval_ = 500;

    this.isIconDragMoved_;
	this.iconDragListenerKeys_ = [];
	this.iconPreviousX_;
	this.iconPreviousY_;

	this.baseDragListenerKeys_ = [];

    this.dragPanIntervalId_ = 0;
    this.dragPanInterval_ = 250;
    this.dragDirection_;

    this.lastQueryId_;
    this.mode_; // search, panoview

    this.iconClassPrefix_ = "d";
    this.baseClassPrefix_ = "s";
    this.lastAngle_ = 0;

    ol.events.listen(element, 'click', this.handlePanoStartClick_, this, false);

    var onActivateChange = options.onActivateChange !== undefined ? options.onActivateChange : function () {};
    this.onActivateChange = onActivateChange;
  }
};
ol.inherits(himap.control.Panorama, ol.control.Control);

himap.control.Panorama.prototype.getName = function() {
  return this.name;
};

himap.control.Panorama.prototype.setMode = function(mode) {
  this.mode_ = mode;

  if (mode == "panoview") {
    ol.events.unlisten(this.getMap(), 'pointermove', this.handlePointerMove_, this, false);
  }
};

himap.control.Panorama.prototype.createActorOverlay_ = function(mapEvent) {
  this.actor_ = document.createElement('DIV');
  this.actor_.className = this.className + '-actor-hide' + ' ol-unselectable';

  this.icon_ = document.createElement('DIV');
  this.icon_.className = 'icon ' + this.iconClassPrefix_ + '00';
  this.icon_.setAttribute('unselectable', 'on');

  this.base_ = document.createElement('DIV');
  this.base_.className = 'base ' + this.baseClassPrefix_ + '00';
  this.base_.setAttribute('unselectable', 'on');

  this.actor_.appendChild(this.icon_);
  this.actor_.appendChild(this.base_);

  this.actorOverlay_ = new ol.Overlay({position: this.getMap().getView().getCenter(), positioning: 'center-center', element: this.actor_, stopEvent: true});
  this.actorOverlay_.setProperties({name: 'panoramaActor'});

  ol.events.listen(this.icon_, ol.pointer.EventType.POINTERDOWN, this.handleIconDragStart_, this);
  ol.events.listen(this.base_, ol.pointer.EventType.POINTERDOWN, this.handleBaseDragStart_, this);
};

himap.control.Panorama.prototype.handleIconMouseDown_ = function(browserEvent) {
  if (browserEvent.button != 0) { return; }

  var map = this.getMap();
  var vPosition = map.getViewport().getBoundingClientRect();
  var ePosition = browserEvent.changedTouches ? browserEvent.changedTouches[0] : browserEvent;
  var coordinate = map.getCoordinateFromPixel([ePosition.clientX - vPosition.left, ePosition.clientY - vPosition.top + 10]); // click 이벤트 발생위해 + 10

  this.setActorPosition(coordinate, false, 'front');
};

himap.control.Panorama.prototype.handleIconClick_ = function(browserEvent) {
  if (this.icon_.iconState_ != 'dragged') {
    var map = this.getMap();
    ol.events.listen(map, 'pointermove', this.handlePointerMove_, this, false);
    this.icon_.iconState_ = 'moving';
  }
};

himap.control.Panorama.prototype.handleBaseMouseDown_ = function(browserEvent) {
  var x1 = browserEvent.target.clientWidth / 2;
  var y1 = browserEvent.target.clientHeight / 2;
  var x2 = browserEvent.offsetX;
  var y2 = browserEvent.offsetY;

  this.setAngle_(x1, y1, x2, y2);
};

himap.control.Panorama.prototype.setAngle_ = function(x1, y1, x2, y2) {
  var angle = ol.math.modulo(ol.math.toDegrees(Math.atan2(y2 - y1, x2 - x1)), 360) + 90;
  angle = angle % 360;

  this.setPanoramaRotation(angle, false);
  var viewAngle = ol.math.toDegrees(this.getMap().getView().getRotation());
  this.setAngleFunction((angle - viewAngle) % 360);
};

himap.control.Panorama.prototype.getDragDirection_ = function(position) {
  var map = this.getMap();
  var width = map.getViewport().clientWidth;
  var height = map.getViewport().clientHeight;
  var x = position.x;
  var y = position.y;

  var direction = {x:0, y:0};

  if (x < 0) { direction.x = -1; }
  else if (x > width) { direction.x = 1; }
  else { direction.x = 0; }

  if (y < 0) { direction.y = 1; }
  else if (y > height) { direction.y = -1; }
  else { direction.y = 0; }

  return direction;
};

himap.control.Panorama.prototype.setDragPanInterval_ = function() {
  if (this.dragPanIntervalId_ == 0) {
    this.setActorClass("hide");
    clearTimeout(this.iconTimeoutId_);
    this.iconTimeoutId_ = 0;
    this.dragPan_();
    this.dragPanIntervalId_ = setInterval(this.dragPan_.bind(this), this.dragPanInterval_);
  }
};

himap.control.Panorama.prototype.clearDragPanInterval_ = function() {
  if (this.dragPanIntervalId_ != 0) {
    clearInterval(this.dragPanIntervalId_);
    this.dragPanIntervalId_ = 0;
  }
};

himap.control.Panorama.prototype.dragPan_ = function() {
  var map = this.getMap();
  var view = map.getView();
  var extent = view.calculateExtent(map.getSize());
  var dist = (this.mode_ == "search" ? 10 : 5);

  var distX = (extent[2] - extent[0]) / dist;
  var distY = (extent[3] - extent[1]) / dist;

  var delta = [this.dragDirection_.x * distX, this.dragDirection_.y * distY];

  ol.interaction.Interaction.pan(map, view, delta, this.dragPanInterval_);
};

himap.control.Panorama.prototype.saveActorPosition_ = function() {
  this.actorOverlay_.savedPosition_ = this.actorOverlay_.getPosition();
};

himap.control.Panorama.prototype.getSavedActorPosition = function() {
  return this.actorOverlay_.savedPosition_;
};

himap.control.Panorama.prototype.setToSavedPosition_ = function() {
  this.setActorPosition(this.getSavedActorPosition(), false, "view");
};

himap.control.Panorama.prototype.handlePanoStartClick_ = function(browserEvent) {
  this.panoStart();
};

himap.control.Panorama.prototype.panoStart = function() {
  if (!this.activate_) { this.activate(); }
  else { this.deactivate(); }
};

himap.control.Panorama.prototype.activate = function() {
  if (!this.activate_) {
    var map = this.getMap();

    $(this.element).addClass("hi-pano-start-on");

    if (this.actorOverlay_ == null) {
      this.createActorOverlay_();
    }

    this.mode_ = "search";
    map.addOverlay(this.actorOverlay_);
    map.addLayer(this.queryLayer_);
    map.addLayer(this.layer_);

    this.layer_.setVisible(true);
    this.listenEvent_(true);
    this.activate_ = true;
    this.onActivateChange.call(this, this.activate_);
  }
};

himap.control.Panorama.prototype.deactivate = function() {
  if (this.activate_) {
    var map = this.getMap();

    $(this.element).removeClass("hi-pano-start-on");
    this.setActorClass("hide");

    map.removeOverlay(this.actorOverlay_);
    map.removeLayer(this.queryLayer_);
    map.removeLayer(this.layer_);

    this.listenEvent_(false);
    this.activate_ = false;
    this.onActivateChange.call(this, this.activate_);
  }
};

himap.control.Panorama.prototype.listenEvent_ = function(isListen) {
  var map = this.getMap();

  if (isListen) {
    ol.events.listen(map, 'pointermove', this.handlePointerMove_, this, false);
    ol.events.listen(map, 'pointerdown', this.handlePointerDown_, this, false);
    ol.events.listen(map, 'pointerup', this.handlePointerUp_, this, false);
    ol.events.listen(map.getView(), 'change:rotation', this.handleViewRotationChange_, this, false);
    ol.events.listen(this.icon_, 'click', this.handleIconClick_, this, false);
    ol.events.listen(this.icon_, 'mousedown', this.handleIconMouseDown_, this, false);
    ol.events.listen(this.base_, 'mousedown', this.handleBaseMouseDown_, this, false);
  } else {
    ol.events.unlisten(map, 'pointermove', this.handlePointerMove_, this, false);
    ol.events.unlisten(map, 'pointerdown', this.handlePointerDown_, this, false);
    ol.events.unlisten(map, 'pointerup', this.handlePointerUp_, this, false);
    ol.events.unlisten(map.getView(), 'change:rotation', this.handleViewRotationChange_, this, false);
    ol.events.unlisten(this.icon_, 'click', this.handleIconClick_, this, false);
    ol.events.unlisten(this.icon_, 'mousedown', this.handleIconMouseDown_, this, false);
    ol.events.unlisten(this.base_, 'mousedown', this.handleBaseMouseDown_, this, false);
  }
};

himap.control.Panorama.prototype.handleIconDragStart_ = function(event) {
  var map = this.getMap();
  var viewportPosition = map.getViewport().getBoundingClientRect();
  this.iconPreviousX_ = event.clientX - viewportPosition.left;
  this.iconPreviousY_ = event.clientY - viewportPosition.top;
  this.isIconDragMoved_ = false;

  if (this.iconDragListenerKeys_.length === 0) {
    var drag = this.handleIconDrag_;
    var end = this.handleIconDragEnd_;

    this.iconDragListenerKeys_.push(
      ol.events.listen(document, ol.events.EventType.MOUSEMOVE, drag, this),
      ol.events.listen(document, ol.events.EventType.MOUSEUP, end, this)
    );
  }
};

himap.control.Panorama.prototype.handleIconDrag_ = function(event) {
  var map = this.getMap();
  var viewportPosition = map.getViewport().getBoundingClientRect();
  var position = {'x': event.clientX - viewportPosition.left, 'y': event.clientY - viewportPosition.top};

  if (!this.isIconDragMoved_ && this.iconPreviousX_ == position.x && this.iconPreviousY_ == position.y) {
    return;
  }

  this.isIconDragMoved_ = true;
  this.dragDirection_ = this.getDragDirection_([position.x, position.y]);

  if (this.dragDirection_.x != 0 || this.dragDirection_.y != 0) {
    this.setDragPanInterval_();
  } else {
    this.clearDragPanInterval_();

    var coordinate = map.getCoordinateFromPixel([position.x, position.y]);
    this.setActorPosition(coordinate);
    this.decideIconDirection_(position.x);
  }

  this.iconPreviousX_ = position.x;
  this.iconPreviousY_ = position.y;
};

himap.control.Panorama.prototype.handleIconDragEnd_ = function(event) {
  if (this.isIconDragMoved_) {
    this.clearDragPanInterval_();
    this.isIconDragMoved_ = false;

    var map = this.getMap();
    var viewportPosition = map.getViewport().getBoundingClientRect();
    var position = {'x': event.clientX - viewportPosition.left, 'y': event.clientY - viewportPosition.top};
    var pixel = [position.x, position.y];
    var coordinate = map.getCoordinateFromPixel(pixel);

    this.setActorPosition(coordinate, false, 'pinned');
    this.icon_.iconState_ = 'pinned';
    this.requestPanoramaInfo_(pixel);
  }

  this.iconPreviousX_ = undefined;
  this.iconPreviousY_ = undefined;
  this.iconDragListenerKeys_.forEach(ol.events.unlistenByKey);
  this.iconDragListenerKeys_.length = 0;
};

himap.control.Panorama.prototype.handleBaseDragStart_ = function(event) {
  if (this.baseDragListenerKeys_.length === 0) {
    var drag = this.handleBaseDrag_;
    var end = this.handleBaseDragEnd_;
    this.baseDragListenerKeys_.push(
      ol.events.listen(document, ol.events.EventType.MOUSEMOVE, drag, this),
      ol.events.listen(document, ol.events.EventType.MOUSEUP, end, this)
    );
  }
};
himap.control.Panorama.prototype.handleBaseDrag_ = function(event) {
  var divWidth = this.getMap().getTargetElement().clientWidth;
  var elementRight = $(this.element).css('right').replace('px', '');
  var elementTop = $(this.element).css('top').replace('px', '');

  var x1 = divWidth - elementRight - this.element.clientWidth/2;
  var y1 = eval(elementTop) + this.element.clientHeight;
  var x2 = event.clientX;
  var y2 = event.clientY;

  this.setAngle_(x1, y1, x2, y2);
};
himap.control.Panorama.prototype.handleBaseDragEnd_ = function(event) {
  this.baseDragListenerKeys_.forEach(ol.events.unlistenByKey);
  this.baseDragListenerKeys_.length = 0;
};

himap.control.Panorama.prototype.getActivate = function() {
  return this.activate_;
};

himap.control.Panorama.prototype.handlePointerMove_ = function(event) {
  this.setActorPosition(event.coordinate);
  this.decideIconDirection_(event.pixel[0]);
};

himap.control.Panorama.prototype.handlePointerStop_ = function() {
  this.setActorClass("front");
};

himap.control.Panorama.prototype.handlePointerDown_ = function(event) {
  if (event.originalEvent.button != 0) { return; }
  this.mouseDownPixel_ = event.pixel;
};

himap.control.Panorama.prototype.handlePointerUp_ = function(event) {
  if (event.originalEvent.button != 0 || this.mouseDownPixel_ == null) { return; }

  var map = this.getMap();
  var mouseUpPixel = event.pixel;

  if (this.mouseDownPixel_[0] == mouseUpPixel[0] && this.mouseDownPixel_[1] == mouseUpPixel[1]) {
    ol.events.unlisten(map, 'pointermove', this.handlePointerMove_, this, false);

    this.mouseDownPixel_ = null;
    var coordinate = event.coordinate;

    this.setActorPosition(coordinate, false, "pinned");
    this.icon_.iconState_ = 'pinned';
    this.requestPanoramaInfo_(mouseUpPixel);
  }
};

himap.control.Panorama.prototype.requestPanoramaInfo_ = function (pixel) {
  var map = this.getMap();
  var wkt = himap.util.createPolygonWKTWithPixel(map, pixel, 20);
  var coordinate = map.getCoordinateFromPixel(pixel);

  var this_ = this;
  var queryId = himap.util.tick();

  this_.lastQueryId_ = queryId;

  var queryData = {
    layers : 'roadViewPO_ggtm',
    geometry : wkt,
    layerAttributeFilter : '2',
    persist : '0',
    maxFeatures : '2'
  };

  this.queryLayer_.queryMapFeatureJson(queryData, function(json) {
    if (queryId != this_.lastQueryId_) return;
    this_.parseQuery(convertSelectedFeatureInfo(json)["roadViewPO_ggtm"], coordinate);
  });
};

himap.control.Panorama.prototype.parseQueryXML_ = function (xmlDoc, coordinate) {
  var props = xmlDoc.getElementsByTagName('Property');
  var nosun = "", direction = "", lane = "", ijung = "";

  for (var i = 0; i < props.length; i++ ) {
    propName = xmlDoc.getElementsByTagName('Property')[i].getAttribute('name');
    propValue = xmlDoc.getElementsByTagName('Property')[i].getAttribute('value');

    if (propName == "NOSUN") { nosun = propValue; }
    else if (propName == "BHCODE") { direction = propValue; }
    else if (propName == "IJUNG") { ijung = propValue; }
    else if (propName == "LANE") { lane = propValue; }
  }

  if (nosun != "" && direction != "" && ijung != "" && lane != "") {
    if (this.mode_ == "search") {
      this.panToCenter(coordinate);
      this.getMap().getView().setZoom(11);
    }

    this.showPanorama(nosun, direction, lane, ijung);
  } else {
    if (this.mode_ == "search") {
      this.panToCenter(coordinate);
    } else if (this.mode_ == "panoview") {
      setTimeout((function() { this.setToSavedPosition_(); }).bind(this), 150);
    }
  }
};


himap.control.Panorama.prototype.parseQuery = function (result, coordinate) {
  var nosun = "", direction = "", lane = "", ijung = "";
  if(result && result.length > 0) {
     var values = result[0].values;
     for(var i=0; i<values.length; i++){
        if(values[i].name == "NOSUN") nosun = values[i].value ;
        else if(values[i].name == "BHCODE") direction = values[i].value;
        else if(values[i].name == "IJUNG") ijung = values[i].value;
        else if(values[i].name == "LANE") lane = values[i].value;
     }
  }

  if (nosun != "" && direction != "" && ijung != "" && lane != "") {
     if (this.mode_ == "search") {
        this.panToCenter(coordinate);
        this.getMap().getView().setZoom(11);
    }
    this.showPanorama(nosun, direction, lane, ijung);
  } else {
     if (this.mode_ == "search") this.panToCenter(coordinate);
     else if (this.mode_ == "panoview"){
        setTimeout((function() { this.setToSavedPosition_(); }).bind(this), 150);
    }
  }
};

himap.control.Panorama.prototype.showPanorama = function(nosun, direction, lane, ijung) {
  this.mode_ = "panoview";
  this.setActorClass('view'); //actor base 보이기
  this.showPanoramaFunction(nosun, direction, lane, ijung); //파노라마 보기
};

himap.control.Panorama.prototype.showPanoramaFunction = function() {};
himap.control.Panorama.prototype.setAngleFunction = function() {};

himap.control.Panorama.prototype.hidePanorama = function() {
  this.mode_ = "search";
  this.setActorClass('pinned');
};

himap.control.Panorama.prototype.setActorClass = function(name) {
  if (this.activate_) {
    var className = this.className + "-actor-" + name + " ol-unselectable";
    this.actor_.className = className;
    this.actorOverlay_.updatePixelPosition();
  }
};

himap.control.Panorama.prototype.setActorPosition = function(coordinate, toCenter, className, isSave) {
  if (this.iconTimeoutId_ != 0) {
    clearTimeout(this.iconTimeoutId_);
    this.iconTimeoutId_ = 0;
  }
  toCenter = typeof toCenter == 'undefined' ? false : toCenter;
  isSave = typeof isSave == 'undefined' ? false : isSave;

  if (className !== undefined) { this.setActorClass(className); }
  this.actorOverlay_.setPosition(coordinate);
  if (isSave) { this.saveActorPosition_(); }
  if (toCenter) { this.panToCenter(coordinate); }
};

himap.control.Panorama.prototype.decideIconDirection_ = function(x) {
  var  className = "";
  if (this.lastActorPositon_ > x) { className = "left"; }
  else if (this.lastActorPositon_ < x) { className = "right";}

  if (className != "") { this.setActorClass(className); }

  this.iconTimeoutId_ = setTimeout(this.handlePointerStop_.bind(this), this.iconStopInterval_);
  this.lastActorPositon_ = x;
};

himap.control.Panorama.prototype.handleViewRotationChange_ = function(event) {
  this.setPanoramaRotation(this.lastAngle, true);
};

himap.control.Panorama.prototype.setPonorataRotation = function(angle, applyViewAngle) {
  this.setPanoramaRotation(angle, applyViewAngle);
};

himap.control.Panorama.prototype.setPanoramaRotation = function(angle, applyViewAngle) {
  this.lastAngle = angle;

  var tempAngle = angle + 11.25;

  if (typeof applyViewAngle === "undefined") {
    applyViewAngle = true;
  }

  if (applyViewAngle) {
      var viewAngle = ol.math.toDegrees(this.getMap().getView().getRotation());
      tempAngle += viewAngle;
  }

  tempAngle = tempAngle % 360;
  tempAngle = tempAngle < 0 ? tempAngle + 360 : tempAngle;

  var idx = Math.floor( tempAngle / 22.5 );
  idx = idx < 10 ? "0" + idx : "" + idx;

  this.changeIconClassIndex_(idx);
  this.changeBaseClassIndex_(idx);
};

himap.control.Panorama.prototype.changeIconClassIndex_ = function(idx) {
  if (this.icon_ !== undefined) {
    var classes = this.icon_.className.split(" ");
    classes[1] = this.iconClassPrefix_ + idx;
    this.icon_.className = classes.join(' ');
  }
};

himap.control.Panorama.prototype.changeBaseClassIndex_ = function(idx) {
  if (this.base_ !== undefined) {
    var classes = this.base_.className.split(" ");
    classes[1] = this.baseClassPrefix_ + idx;
    this.base_.className = classes.join(' ');
  }
};

himap.control.Panorama.prototype.changeBaseClassPrefix = function(prefix) {
  this.baseClassPrefix_ = prefix;
  if (this.base_ !== undefined) {
    var classes = this.base_.className.split(" ");
    classes[1] = this.baseClassPrefix_ + classes[1].substr(1);
    this.base_.className = classes.join(' ');
  }
};

himap.control.Panorama.prototype.panToCenter = function(coordinate) {
  this.getMap().getView().animate({duration: 200, center: coordinate});
};

himap.control.Panorama.prototype.setMap = function(map) {
  if (!map) {
    map.removeOverlay(this.actorOverlay_);

    map.removeLayer(this.queryLayer_);
    map.removeLayer(this.layer_);

    this.listenEvent_(false);
  }

  ol.control.Control.prototype.setMap.call(this, map);
};

himap.control.Panorama.prototype.isTargetEvent_ = function(e) {
  return true;
};


himap.control.ZoomSlider = function(opt_options) {
  var options = opt_options !== undefined ? opt_options : {};
  this.name = options.name !== undefined ? options.name : 'himap.control.ZoomSlider';

  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(this.name, '100||ZoomSlider 컨트롤의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}

  ol.control.ZoomSlider.call(this, options);

  if(errFlag) {
    ol.events.unlisten(this.dragger_, ol.pointer.EventType.POINTERDOWN, this.handleDraggerStart_, this);
    ol.events.unlisten(this.dragger_, ol.pointer.EventType.POINTERMOVE, this.handleDraggerDrag_, this);
    ol.events.unlisten(this.dragger_, ol.pointer.EventType.POINTERUP, this.handleDraggerEnd_, this);
    ol.events.unlisten(this.element, ol.events.EventType.CLICK, this.handleContainerClick_, this);
    ol.events.unlisten(this.element.firstChild, ol.events.EventType.CLICK, ol.events.Event.stopPropagation);
    ol.events.listen(this.element, ol.events.EventType.CLICK, function() {alert(this.getErrorMsg(this.name));}, this, false);
  }
};
ol.inherits(himap.control.ZoomSlider, ol.control.ZoomSlider);

himap.control.Measure = function(opt_options) {
  this.name = 'himap.control.Measure';
  var options = opt_options !== undefined ? opt_options : {};
  this.className = options.className !== undefined ? options.className : "hi-measure";

  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(this.name, '100||측정 컨트롤의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}

  var element = options.element !== undefined ? options.element : document.createElement('DIV');
  element.className = this.className + ' ol-unselectable';
  element.setAttribute('unselectable', 'on');

  var tooltip = options.tooltip !== undefined ? options.tooltip : document.createElement('DIV');
  tooltip.className = this.className + '-tooltip ol-unselectable';
  tooltip.setAttribute('unselectable', 'on');

  element.appendChild(tooltip);
  ol.events.listen(element, 'mouseover', function(e) {tooltip.style.display='block';});
  ol.events.listen(element, 'mouseout', function(e) {tooltip.style.display='none';});

  if(!errFlag) {
    this.onStart_ = options.start !== undefined ? options.start : null;
    this.onFinish_ = options.finish !== undefined ? options.finish : null;
    this.onClear_ = options.clear !== undefined ? options.clear : null;

    var distanceIcon = document.createElement('A');
    distanceIcon.className = 'distance';
    distanceIcon.href = '#';
    var areaIcon = document.createElement('A');
    areaIcon.className = 'area';
    areaIcon.href = '#';
    var clearIcon = document.createElement('A');
    clearIcon.className = 'clear';
    clearIcon.href = '#';

    element.appendChild(distanceIcon);
    element.appendChild(areaIcon);
    element.appendChild(clearIcon);

    ol.events.listen(distanceIcon, 'focus', function(e) {this.blur();});
    ol.events.listen(distanceIcon, 'click', this.handleDistanceIconClick_, this, false);
    ol.events.listen(areaIcon, 'focus', function(e) {this.blur();});
    ol.events.listen(areaIcon, 'click', this.handleAreaIconClick_, this, false);
    ol.events.listen(clearIcon, 'focus', function(e) {this.blur();});
    ol.events.listen(clearIcon, 'click', this.handleClearIconClick_, this, false);

    this.isListenEvent_ = false;
    this.downPx_ = null;
    this.mode_ = "area";
    this.finishCoordinate_ = null;

    this.isStarted_ = false;
    this.sketchPoint_ = null;
    this.sketchPolyline_ = null;
    this.sketchPolygon_ = null;

    this.pointFeatures_ = new ol.Collection();
    this.groupId_ = 0;

    this.featureOverlay_ = new ol.layer.Vector({
      source: new ol.source.Vector({features: new ol.Collection(), useSpatialIndex: false}),
      style: options.style !== undefined ? options.style : himap.control.Measure.getDefaultStyleFunction(),
      updateWhileAnimating: true, // optional, for instant visual feedback
      updateWhileInteracting: true // optional, for instant visual feedback
    });

    this.overlays_ = new ol.Collection;
    this.movingOverlay_ = null;

    ol.events.listen(this.overlays_, "add", function(event) {event.element.setMap(this.getMap());}, this, false);
    ol.events.listen(this.overlays_, "remove", function(event) {event.element.setMap(null);}, this, false);
  } else {
    ol.events.listen(element, 'click', function(e) {alert(this.getErrorMsg(this.name));}, this, false);
    this.featureOverlay_ = new ol.layer.Vector({});
  }

  ol.control.Control.call(this, {element: element, target: null});
};
ol.inherits(himap.control.Measure, ol.control.Control);

himap.control.Measure.getDefaultStyleFunction = function() {
  var styles = {};
  styles[ol.geom.GeometryType.POINT] = [
    new ol.style.Style({
      image: new ol.style.Circle({
        radius: 4,
        fill: new ol.style.Fill({color:[255, 255, 255, 1]}),
        stroke: new ol.style.Stroke({color:[255, 78, 0, 1], width:2})
      }),
      zIndex:1E5
    })
  ];

  styles[ol.geom.GeometryType.LINE_STRING] = [
    new ol.style.Style({
      stroke: new ol.style.Stroke({color:[255, 255, 0, 0.9], width:4})
    })
  ];

  styles[ol.geom.GeometryType.POLYGON] = [
    new ol.style.Style({
      fill: new ol.style.Fill({color:[255, 78, 0, 0.3]}),
      stroke: new ol.style.Stroke({color:[255, 78, 0, 0.9], width:4})
    })
  ];

  return function(feature, resolution) {
    return styles[feature.getGeometry().getType()];
  };
};

himap.control.Measure.prototype.setMap = function(map) {
  this.featureOverlay_.setMap(map);
  ol.control.Control.prototype.setMap.call(this, map);
};

/* 거리재기 버튼 클릭 */
himap.control.Measure.prototype.handleDistanceIconClick_ = function(event) {
  this.startMeasure('distance');
  event.preventDefault();
};
/* 면적재기 버튼 클릭 */
himap.control.Measure.prototype.handleAreaIconClick_ = function(event) {
  this.startMeasure('area');
  event.preventDefault();
};
/* 초기화 버튼 클릭 */
himap.control.Measure.prototype.handleClearIconClick_ = function(event) {
  this.clear();
  if (this.onClear_) {this.onClear_.call(this, 'clear');}
  event.preventDefault();
};
/* 측정 시작(거리재기 or 면적재기) */
himap.control.Measure.prototype.startMeasure = function(mode) {
  this.abortFeatures_();
  this.mode_ = mode;
  this.listenViewportEvent_();

  if (this.onStart_) {this.onStart_.call(this, this.mode_);}
};

/* 초기화 수행 */
himap.control.Measure.prototype.clear = function() {
  this.abortFeatures_();
  this.clearFeatures_();
};

/* 측정 시작시 이벤트 추가 */
himap.control.Measure.prototype.listenViewportEvent_ = function() {
  var map = this.getMap();
  ol.events.listen(map, 'pointerdown', this.handlePointerDown_, this, false);
  ol.events.listen(map, 'pointermove', this.handlePointerMove_, this, false);
  ol.events.listen(map, 'pointerup', this.handlePointerUp_, this, false);
  this.isListenEvent_ = true;
};
/* 측정 완료시 이벤트 해제 */
himap.control.Measure.prototype.unlistenViewportEvent_ = function() {
  var map = this.getMap();
  ol.events.unlisten(map, 'pointerdown', this.handlePointerDown_, this, false);
  ol.events.unlisten(map, 'pointermove', this.handlePointerMove_, this, false);
  ol.events.unlisten(map, 'pointerup', this.handlePointerUp_, this, false);
  this.isListenEvent_ = false;
};

himap.control.Measure.prototype.handlePointerDown_ = function(event) {
  if (event.originalEvent.button != 0) {return true;}
  this.downPx_ = event.pixel;
};

himap.control.Measure.prototype.handlePointerMove_ = function(event) {
  if (!this.downPx_) {this.updateSketchFeatures_(event);}
  return true;
};

himap.control.Measure.prototype.handlePointerUp_ = function(event) {
  if (event.originalEvent.button == 2) {this.finishFeatures_(event); return false;}
  else if (event.originalEvent.button != 0 || !this.downPx_) {return true;}

  var downPx = this.downPx_;
  var clickPx = event.pixel;
  var dx = downPx[0] - clickPx[0];
  var dy = downPx[1] - clickPx[1];
  var squaredDistance = dx * dx + dy * dy;
  this.downPx_ = null;
  var pass = true;

  if(squaredDistance == 0) {
    if (!this.isStarted_) {this.isStarted_ = true; this.startSketchFeatures_(event);}
    else {this.addToSketchFeatures_(event);}
  }

  return pass;
};

himap.control.Measure.prototype.startSketchFeatures_ = function(event) {
  var coordinate = event.coordinate;
  var pointFeature = new ol.Feature(new ol.geom.Point(coordinate.slice()));
  pointFeature.setProperties({'groupid':this.groupId_});

  if (this.mode_ == "distance") {
    this.sketchPolyline_ = new ol.Feature(new ol.geom.LineString([coordinate.slice(), coordinate.slice()]));
    this.sketchPolyline_.setProperties({'groupid':this.groupId_});

    if (!this.movingOverlay_) {
      this.movingOverlay_ = this.createMoveOverlay_(coordinate);
    } else {
      this.addOverlay_(this.movingOverlay_);
      this.updateMoveOverlay_(coordinate, "0m", "0m");
    }
  } else {
    this.sketchPolygon_ = new ol.Feature(new ol.geom.Polygon([[coordinate.slice(), coordinate.slice(), coordinate.slice()]]));
    this.sketchPolygon_.setProperties({'groupid':this.groupId_});
  }

  if (pointFeature) {
    this.pointFeatures_.push(pointFeature);
    this.featureOverlay_.getSource().addFeature(pointFeature);
  }

  if (this.sketchPolyline_) {
    this.featureOverlay_.getSource().addFeature(this.sketchPolyline_);
    this.addBasicOverlay_(coordinate, "시작", 'segment');
  }

  if (this.sketchPolygon_) {
    this.featureOverlay_.getSource().addFeature(this.sketchPolygon_);
  }
};

himap.control.Measure.prototype.updateSketchFeatures_ = function(event) {
  var coordinate = event.coordinate;
  var geometry, coordinates;
  var last;

  if (!this.sketchPoint_) {
    this.sketchPoint_ = new ol.Feature(new ol.geom.Point(coordinate.slice()));
    this.sketchPoint_.setProperties({'groupid':this.groupId_});
    this.featureOverlay_.getSource().addFeature(this.sketchPoint_);
  } else {
    geometry = this.sketchPoint_.getGeometry();
    geometry.setCoordinates(coordinate.slice());
  }

  if (this.sketchPolygon_) {
    geometry = this.sketchPolygon_.getGeometry();
    coordinates = geometry.getCoordinates();
    var pop = coordinates[0].pop();

    last = coordinates[0][coordinates[0].length -1];
    last[0] = coordinate[0];
    last[1] = coordinate[1];

    coordinates[0].push(pop.slice());
    geometry.setCoordinates(coordinates);
  }

  if (this.sketchPolyline_) {
    geometry = this.sketchPolyline_.getGeometry();
    coordinates = geometry.getCoordinates();
    last = coordinates[coordinates.length -1];
    last[0] = coordinate[0];
    last[1] = coordinate[1];
    geometry.setCoordinates(coordinates);

    var start = coordinates[coordinates.length-2];
    var end = coordinates[coordinates.length-1];
    var distance = this.getDistance_(start, end);
    distance = this.getDistanceString_(distance);

    var totalDistance = this.getGeometryDistance_(geometry);
    totalDistance = this.getDistanceString_(totalDistance);

    this.updateMoveOverlay_(coordinate, distance, totalDistance);
  }
};

himap.control.Measure.prototype.addToSketchFeatures_ = function(event) {
  var coordinate = event.coordinate;
  var geometry, coordinates;

  if (this.sketchPolygon_) {
    geometry = this.sketchPolygon_.getGeometry();
    coordinates = geometry.getCoordinates();

    var pop = coordinates[0].pop();
    var last = coordinates[0][coordinates[0].length - 1];
    last[0] = coordinate[0];
    last[1] = coordinate[1];

    coordinates[0].push(pop.slice());
    coordinates[0].push(pop.slice());

    geometry.setCoordinates(coordinates);
  }

  if (this.sketchPolyline_) {
    geometry = this.sketchPolyline_.getGeometry();
    coordinates = geometry.getCoordinates();

    coordinates.pop();
    coordinates.push(coordinate.slice());
    coordinates.push(coordinate.slice());
    geometry.setCoordinates(coordinates);

    var start = coordinates[coordinates.length-3];
    var end = coordinates[coordinates.length-2];
    var distance = this.getDistance_(start, end);
    distance = this.getDistanceString_(distance);

    this.addBasicOverlay_(coordinate, distance, 'segment');
  }

  var pointFeature = new ol.Feature(new ol.geom.Point(coordinate.slice()));
  pointFeature.setProperties({'groupid':this.groupId_});
  this.featureOverlay_.getSource().addFeature(pointFeature);
};

himap.control.Measure.prototype.transformFn_ = ol.proj.getTransform('EPSG:3857', 'EPSG:4326');
himap.control.Measure.prototype.getDistance_ = function(start, end) {
  start = this.transformFn_(start);
  end = this.transformFn_(end);

  return ol.sphere.WGS84.haversineDistance(start, end);
};

himap.control.Measure.prototype.getGeometryDistance_ = function(geometry) {
  var clone = geometry.clone();
  clone.transform('EPSG:3857', 'EPSG:4326');

  var coordinates = clone.getCoordinates();
  var sum = 0;
  for (i = 0, length = coordinates.length; i < length - 1; i++ ) {
    sum += ol.sphere.WGS84.haversineDistance(coordinates[i], coordinates[i+1]);
  }

  return sum;
};

himap.control.Measure.prototype.getGeometryArea_ = function(geometry) {
  return geometry.getArea();
};

himap.control.Measure.prototype.getDistanceString_ = function(distance) {
  var suffix = "m";
  if (distance >= 1E3) {suffix = "km"; distance /= 1E3;}
  distance = Math.round(distance * 10) / 10;

  return distance + suffix;
};

himap.control.Measure.prototype.getAreaString_ = function(distance) {
  var suffix = "㎡";
  if (distance >= 1E6) {suffix = "㎢"; distance /= 1E3;}
  distance = Math.round(distance * 10) / 10;

  return distance + suffix;
};

himap.control.Measure.prototype.finishFeatures_ = function(event) {
  if (this.sketchPolygon_) {
    geometry = this.sketchPolygon_.getGeometry();
    coordinates = geometry.getCoordinates();
    var pop = coordinates[0].pop();
    coordinates[0].pop();
    coordinates[0].push(pop.slice());

    if (coordinates[0].length > 3) {
      geometry.setCoordinates(coordinates);

      var area = this.getGeometryArea_(geometry);
      var areaString = this.getAreaString_(area);
      areaString = '총면적 : ' + areaString;

      this.addBasicOverlay_(coordinates[0][coordinates[0].length - 2], areaString, 'area');
      this.addCloseOverlay_(coordinates[0][coordinates[0].length - 2]);
      if (this.onFinish_) {this.onFinish_.call(this, 'area', area);}
    } else {
      this.abortFeatures_(event);
    }
  }

  if (this.sketchPolyline_) {
    geometry = this.sketchPolyline_.getGeometry();
    coordinates = geometry.getCoordinates();
    coordinates.pop();
    geometry.setCoordinates(coordinates);

    var totalDistance = this.getGeometryDistance_(geometry);
    var totalDistanceString = this.getDistanceString_(totalDistance);
    totalDistanceString = '총거리 : ' + totalDistanceString;

    this.removeOverlay_(this.overlays_.item(this.overlays_.getLength() - 1));
    this.addBasicOverlay_(coordinates[coordinates.length - 1], totalDistanceString, 'total');
    this.addCloseOverlay_(coordinates[coordinates.length - 1]);

    if (this.onFinish_) {this.onFinish_.call(this, 'distance', totalDistance);}
  }

  if (this.sketchPoint_) {this.featureOverlay_.getSource().removeFeature(this.sketchPoint_);}

  this.isStarted_ = false;
  this.sketchPoint_ = null;
  this.sketchPolyline_ = null;
  this.sketchPolygon_ = null;
  this.unlistenViewportEvent_();
  this.removeOverlay_(this.movingOverlay_);
  this.groupId_++;
};

himap.control.Measure.prototype.stopMeasure = function() {
  this.abortFeatures_();
};

himap.control.Measure.prototype.abortFeatures_ = function(event) {
  if (!this.isListenEvent_) {return;}

  this.removeGroup_(this.groupId_);
  this.isStarted_ = false;
  this.sketchPoint_ = null;
  this.sketchPolyline_ = null;
  this.sketchPolygon_ = null;
  this.unlistenViewportEvent_();
  this.removeOverlay_(this.movingOverlay_);

  if (this.onFinish_) {this.onFinish_.call(this, "", 0);}
};

himap.control.Measure.prototype.clearFeatures_ = function() {
  this.featureOverlay_.getSource().clear();
  this.clearOverlay_();
};

himap.control.Measure.prototype.removeGroup_ = function(groupId) {
  this.removeFeaturesByGroupId_(groupId);
  this.removeOverlaysByGroupId_(groupId);
};

himap.control.Measure.prototype.removeFeaturesByGroupId_ = function(groupId) {
  var featureSource = this.featureOverlay_.getSource();
  for(features = featureSource.getFeatures(), i = features.length - 1; i >= 0; i--) {
    var feature = features[i];
    if (feature.get("groupid") == groupId) {featureSource.removeFeature(feature);}
  }
};

himap.control.Measure.prototype.addOverlay_ = function(overlay) {
  this.overlays_.push(overlay);
};

himap.control.Measure.prototype.removeOverlay_ = function(overlay) {
  if(this.overlays_.remove(overlay) !== undefined) {return overlay;}
  return undefined;
};

himap.control.Measure.prototype.clearOverlay_ = function() {
  this.overlays_.clear();
};

himap.control.Measure.prototype.removeOverlaysByGroupId_ = function(groupId) {
  for(var i = this.overlays_.getLength() - 1; i >= 0; i--) {
    var overlay = this.overlays_.item(i);
    if (overlay.get("groupid") == groupId) {this.removeOverlay_(overlay);}
  }
};

himap.control.Measure.prototype.addBasicOverlay_ = function(coordnate, text, classAttach) {
  var element = document.createElement('DIV');
  element.className = this.className + '-' + classAttach + ' ol-unselectable';
  element.setAttribute("unselectable", "on");
  element.innerHTML = text;

  var overlay = new ol.Overlay({position: coordnate, positioning: 'top-left', element: element, stopEvent: false});
  overlay.setProperties({'groupid':this.groupId_});
  this.addOverlay_(overlay);
};
//하나의 측정 수행 완료 후 닫기 Overlay 추가
himap.control.Measure.prototype.addCloseOverlay_ = function(coordnate) {
  var element = document.createElement('DIV');
  element.className = this.className + '-close ol-unselectable';
  element.setAttribute("unselectable", "on");
  element.innerHTML = "";

  var link = document.createElement('A');
  link.className = 'ol-unselectable';
  link.setAttribute("unselectable", "on");
  link.href = "#";

  element.appendChild(link);

  var overlay = new ol.Overlay({position: coordnate, positioning: 'center-left', element: element, stopEvent: true});
  overlay.setProperties({'groupid':this.groupId_});
  this.addOverlay_(overlay);

  var groupId = this.groupId_;
  ol.events.listen(link, 'click', function(e) {this.removeGroup_(groupId); e.preventDefault();}, this, false);
};

/* 거리재기 시 거리, 총거리 나타내는 Overlay */
himap.control.Measure.prototype.createMoveOverlay_ = function(coordnate) {
  var element = document.createElement('DIV');
  element.className = this.className + '-move ol-unselectable';
  element.setAttribute("unselectable", "on");
  element.innerHTML = "거  리 : 0m<br/>총거리 : 0m";

  var overlay = new ol.Overlay({position: coordnate, positioning: 'top-left', element: element, stopEvent: false});
  overlay.setProperties({'groupid':this.groupId_});
  this.addOverlay_(overlay);

  return overlay;
};
himap.control.Measure.prototype.updateMoveOverlay_ = function(coordnate, segment, total) {
  this.movingOverlay_.setPosition(coordnate);
  this.movingOverlay_.getElement().innerHTML = "거  리 : " + segment + "<br/>총거리: " + total + "";
};


// 지도 회전
himap.control.Rotate = function(opt_options) {
  this.name = 'himap.control.Rotate';
  var options = opt_options ? opt_options : {};
  var element = document.createElement('div');
  var className = options.className !== undefined ? options.className : 'hi-view-rotate';
  className += ' ' + ol.css.CLASS_UNSELECTABLE + ' ' + ol.css.CLASS_CONTROL;
  element.className = className;

  var errFlag = false;
  if(!options.sysKey) {errFlag = true; this.setErr(this.name, '100||지도 회전 컨트롤의 필수 입력인 sysKey가 없습니다.');}
  else if(sysKeysAll_.indexOf(options.sysKey) == -1) {errFlag = true; this.setErr(name, '200||등록된 syskey가 아닙니다.');}

  if(errFlag) {
    ol.DEBUG && console.assert(errFlag == false, this.getErrorMsg(this.name));
    ol.events.listen(element, ol.events.EventType.CLICK, function(e) {alert(this.getErrorMsg(this.name));}, this);
  } else {
    //ol.events.listen(element, ol.events.EventType.CLICK, this.handleClick_, this);
    ol.events.listen(element, ol.events.EventType.MOUSEDOWN, this.mouseEvent, this);
    ol.events.listen(element, ol.events.EventType.MOUSEOUT, this.mouseEvent, this);
    ol.events.listen(element, ol.events.EventType.MOUSEUP, this.mouseEvent, this);
    ol.events.listen(element, ol.events.EventType.MOUSEMOVE, this.mouseEvent, this);
  }

  var render = options.render ? options.render : himap.control.Rotate.render;
  ol.control.Control.call(this, {
    element: element,
    render: render,
    target: options.target
  });

  this.duration_ = options.duration !== undefined ? options.duration : 250;
  this.autoHide_ = options.autoHide !== undefined ? options.autoHide : false;
};
ol.inherits(himap.control.Rotate, ol.control.Control);


/**
 * as.jeong 마우스 드래그이벤트 처리
 */
himap.control.Rotate.prototype.mouseEvent = function(event)
{	
	if(event.type == ol.events.EventType.MOUSEDOWN) this.mouseState = 'start';
	if(event.type != ol.events.EventType.MOUSEOUT && this.mouseState == 'start') this.handleClick_(event);
	if(event.type == ol.events.EventType.MOUSEUP || event.type == ol.events.EventType.MOUSEOUT) this.mouseState = 'end';
};


himap.control.Rotate.prototype.handleClick_ = function(event) {
  event.preventDefault();

  var map = this.getMap();
  var view = map.getView();
  if (!view) {return;}

  var divWidth = map.getTargetElement().clientWidth;
  var elementRight = $(this.element).css('right').replace('px', '');
  var elementTop = $(this.element).css('top').replace('px', '');

  var x1 = divWidth - elementRight - this.element.clientWidth/2;
  var y1 = eval(elementTop) + this.element.clientHeight;
  var x2 = event.clientX;
  var y2 = event.clientY;

  var distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2));
  if (distance < 10) view.setRotation(0);
  else this.setViewRotation_(x1, y1, x2, y2);
};

himap.control.Rotate.prototype.setViewRotation_ = function(x1, y1, x2, y2) {
  var angle = ol.math.modulo(ol.math.toDegrees(Math.atan2(y2 - y1, x2 - x1)), 360) + 90;
  var rad = ol.math.toRadians(angle);

  this.getMap().getView().animate({
    rotation: rad,
    duration: this.duration_,
    easing: ol.easing.easeOut
  });
};

/**
 * Update the rotate control element.
 */
himap.control.Rotate.render = function(mapEvent) {
  var frameState = mapEvent.frameState;
  if (!frameState) {return;}

  var rotation = frameState.viewState.rotation;
  if (rotation != this.rotation_) {
    if (this.autoHide_) {
      var contains = this.element.classList.contains(ol.css.CLASS_HIDDEN);
      if (!contains && rotation === 0) {
        this.element.classList.add(ol.css.CLASS_HIDDEN);
      } else if (contains && rotation !== 0) {
        this.element.classList.remove(ol.css.CLASS_HIDDEN);
      }
    }
  }

  var angle =  ol.math.toDegrees(this.getMap().getView().getRotation());
  var tempAngle = (angle + 11.25) % 360;
  tempAngle = tempAngle < 0 ? tempAngle + 360 : tempAngle;

  var idx = Math.floor( tempAngle / 22.5 );
  idx = idx < 10 ? '0' + idx : '' + idx;

  var arr = $(this.element).attr('class').split(' ');
  arr[arr.length - 1] = 'v' + idx;
  this.element.className = arr.join(' ');

  this.rotation_ = rotation;
};


/* Overlay 팝업 */
himap.overlay.Popup = function(opt_options) {
  var options = opt_options !== undefined ? opt_options : {};
  this.className = options.className !== undefined ? options.className : 'hi-popup';

  this.closer = document.createElement('A');
  this.closer.className = this.className + '-closer';
  this.content = document.createElement('DIV');
  this.content.className = this.className + '-content';

  var element = document.createElement('DIV');
  element.className = this.className;
  element.setAttribute('unselectable', 'on');
  element.appendChild(this.closer);
  element.appendChild(this.content);

  ol.Overlay.call(this, {element: element});
};
ol.inherits(himap.overlay.Popup, ol.Overlay);

himap.overlay.Popup.prototype.handleCloserClick = function() {
  this.setVisible2(false);
};

himap.overlay.Popup.prototype.setMap = function(map) {
  if (map) {ol.events.listen(this.closer, 'click', this.handleCloserClick, this, false);}
  else {ol.events.unlisten(this.closer, 'click', this.handleCloserClick, this, false);}
  ol.Overlay.prototype.setMap.call(this, map);
};
himap.overlay.Popup.prototype.setVisible = function(visible) {
};
//팝업 보이기 설정
himap.overlay.Popup.prototype.setVisible2 = function(visible) {
  this.getElement().style.display = visible ? 'block' : 'none';
};
// 내용 초기화
himap.overlay.Popup.prototype.clearContent = function() {
  while (this.content.firstChild) this.content.removeChild(this.content.firstChild);
};
// 내용 반환
himap.overlay.Popup.prototype.getContent = function() {
  return this.content;
};
// 자식 element 추가
himap.overlay.Popup.prototype.appendChildToContent = function(element) {
  this.content.appendChild(element);
  return this.content;
};
// (이름, 값) 형태로 내용 추가
himap.overlay.Popup.prototype.appendNameValueToContent = function(name, value) {
  var ul = document.createElement('UL'); ul.className = '';
  var liName = document.createElement('LI'); liName.className = 'name';
  var liValue = document.createElement('LI'); liValue.className = 'value';

  liName.innerHTML = name;
  liValue.innerHTML = value;

  ul.appendChild(liName);
  ul.appendChild(liValue);

  this.content.appendChild(ul);
  return this.content;
};
// 내용 설정
himap.overlay.Popup.prototype.setContentHtml = function(content) {
  this.content.innerHTML = content;
};


/* 지도 클릭 시 Point 렌더링 */
himap.render.Point = function(style) {
  this.map_ = null;
  this.postComposeListenerKey_ = null;
  this.pixel_ = null;
  this.geometry_ = null;
  this.style_ = style;
};
ol.inherits(himap.render.Point, ol.Disposable);

himap.render.Point.prototype.createGeometry_ = function() {
  var pixel = this.pixel_;
  var coordinates = this.map_.getCoordinateFromPixel(pixel);
  return new ol.geom.Point(coordinates);
};
himap.render.Point.prototype.disposeInternal = function() {
  ol.Disposable.call(this, "disposeInternal");
};
himap.render.Point.prototype.handleMapPostCompose_ = function(event) {
  event.vectorContext.setStyle(this.style_);
  event.vectorContext.drawGeometry(this.geometry_);
};
himap.render.Point.prototype.getGeometry = function() {
  return this.geometry_;
};
himap.render.Point.prototype.requestMapRenderFrame_ = function() {
  if(this.map_ && this.pixel_) {this.map_.render();}
};
himap.render.Point.prototype.setMap = function(map) {
  if(this.postComposeListenerKey_) {
    ol.events.unlistenByKey(this.postComposeListenerKey_);
    this.postComposeListenerKey_ = null;
    this.map_.render();
    this.map_ = null;
    this.geometry_ = null;
  }
  this.map_ = map;
  if(this.map_) {
    this.postComposeListenerKey_ = ol.events.listen(map, ol.render.Event.Type.POSTCOMPOSE, this.handleMapPostCompose_, this, false);
    this.requestMapRenderFrame_();
  }
};
himap.render.Point.prototype.setPixel = function(pixel) {
  this.pixel_ = pixel;
  this.geometry_ = this.createGeometry_();
  this.requestMapRenderFrame_();
};

himap.render.PointIndicator = function(opt_options) {
  var options = opt_options !== undefined ? opt_options : {};
  var map = options.map !== undefined ? options.map : null;
  var pixel = options.pixel !== undefined ? options.pixel : null;

  this.resizeMaxCount_ = 5;
  this.resizeInterval_ = 75;

  this.radius_ = options.radius !== undefined ? options.radius : 2;
  this.adjustment_ = options.adjustment !== undefined ? options.adjustment : 2;

  var style = this.getStyle_(this.radius_, 0.8);

  himap.render.Point.call(this, style);
  this.setMap(map);
  this.setPixel(pixel);
  this.resizeIndicator();
};
ol.inherits(himap.render.PointIndicator, himap.render.Point);

himap.render.PointIndicator.styleCache = [];
himap.render.PointIndicator.prototype.getStyle_ = function(radius, opacity) {
  var cacheId = "" + radius + ":" + opacity;

  if (!himap.render.PointIndicator.styleCache[cacheId]) {
    var imageStyle = new ol.style.Style({
	  image: new ol.style.Circle({
		radius: radius,
	    stroke: new ol.style.Stroke({color: [252, 78, 115, opacity], width: 2})
	  })
	});
    himap.render.PointIndicator.styleCache[cacheId] = imageStyle;
  }
  return himap.render.PointIndicator.styleCache[cacheId];
};

himap.render.PointIndicator.prototype.resizeIndicator = function() {
  if (--this.resizeMaxCount_ > 0) {
    this.radius_ = this.radius_ + this.adjustment_;
    var style = this.getStyle_(this.radius_, 0.8);
    this.style_ = style;
    this.requestMapRenderFrame_();

    setTimeout(this.resizeIndicator.bind(this), this.resizeInterval_);
  } else {
    this.setMap(null);
  }
};

// 검색(시설물, 지번주소, 도로명주소 등)
himap.search.query = function(url, method, queryData, success, error, proxy) {
  method = method !== undefined ? method : "GET";
  proxy = proxy !== undefined ? proxy : "";

  if (method.toUpperCase() == "GET") {
    if (url.indexOf("?") > 0) url = url + "&" + $.param(queryData);
    else url = url + "?" + $.param(queryData);
    queryData = {};
  }

  if (proxy != "") url = proxy + "?" + url;

  $.ajax({type: method, url: url, data: queryData, dataType: "json", async: true, cache: false, success: success, error: error});
};

//himap.search.FacSearch.url = "https://capisvr1.ex.co.kr:8443/search/";
himap.search.FacSearch.url = "http://172.16.166.121/search/";
himap.search.FacSearch.query = function(opt_options) {
  var options = opt_options !== undefined ? opt_options : {};
  var url = options.url !== undefined ? options.url : himap.search.FacSearch.url;
  var query = options.query !== undefined ? options.query : "";
  var facType = options.facType !== undefined ? options.facType : "";
  var success = options.success !== undefined ? options.success : function () {};
  var error = options.error !== undefined ? options.error : function () {};

  var queryData;
  if (typeof query == "object") {queryData = query;}
  else {queryData = {'query': query, 'facType': facType};}

  himap.search.query(url, 'get', queryData, success, error, '');
};

// 브이월드 지번 주소, 도로명 주소 검색
himap.search.VworldSearch.url = "http://map.vworld.kr/search.do";
himap.search.VworldSearch.query = function(opt_options) {
  var options = opt_options !== undefined ? opt_options : {};
  var proxy = options.proxy !== undefined ? options.proxy : himap.url.VWORLD_PROXY;
  var q = options.q !== undefined ? options.q : "";
  var category = options.category !== undefined ? options.category : "Juso";
  var pageUnit = options.pageUnit !== undefined ? options.pageUnit : 10;
  var output = "json";
  var pageIndex = options.pageIndex !== undefined ? options.pageIndex : 1;
  var apiKey = options.apiKey !== undefined ? options.apiKey : 'D015C3B6-375B-3762-9FE3-CE4DF00438CD';
  var success = options.success !== undefined ? options.success : function () {};
  var error = options.error !== undefined ? options.error : function () {};
  var queryData = {'q': q, 'category': category, 'pageUnit': pageUnit, 'output': output, 'pageIndex': pageIndex, 'apiKey': apiKey};

  himap.search.query(himap.search.VworldSearch.url, 'get', queryData, success, error, proxy);
};