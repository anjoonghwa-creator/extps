// 에러값 조회
ol.Object.prototype.getErr = function(key) {
  var value = '';
  if (this.valuesErr_ !== undefined && this.valuesErr_.hasOwnProperty(key)) {
    value = this.valuesErr_[key];
  }
  return value;
};
//에러값 세팅
ol.Object.prototype.setErr = function(key, value) {
  if(this.valuesErr_ === undefined) { this.valuesErr_ = {}; }
  this.valuesErr_[key] = value;
};
//에러 키목록 조회
ol.Object.prototype.getErrKeys = function() {
  var values = {};
  if(this.valuesErr_ !== undefined) {values = Object.keys(this.valuesErr_);}

  return values;
};
//에러 세팅 해제
ol.Object.prototype.unsetErr = function(key) {
  if (this.valuesErr_ !== undefined && key in this.valuesErr_) {
    delete this.valuesErr_[key];
  }
};

ol.Object.prototype.getErrProperties = function() {
  var values = {};
  if(this.valuesErr_ !== undefined) {ol.obj.assign({}, this.valuesErr_);}

  return values;
};
ol.Object.prototype.setErrProperties = function(valuesErr_) {
  if(this.valuesErr_ === undefined) { this.valuesErr_ = {}; }

  for (var key in valuesErr_) {
    this.setErr(key, valuesErr_[key]);
  }
};

ol.Object.prototype.getErrorCode = function(key) {
  var value = this.getErr(key);
  return value.split('||')[0];
};
ol.Object.prototype.getErrorMsg = function(key) {
  var value = this.getErr(key);
  return value.split('||')[1];
};

//특정 위치에 레이어 추가
ol.Map.prototype.addLayerAt = function(layer, index) {
  var layers = this.getLayerGroup().getLayers();
  layers.insertAt(index, layer);
};

//맵의 레이어 개수
ol.Map.prototype.getLayersCnt = function() {
  return this.getLayerGroup().getLayers().getLength();
};

ol.Map.prototype.getLayersIndex = function(layerName) {
  var rtnIdx = 0;
  this.getLayerGroup().getLayers().forEach(function(layer, idx) {
    if(layer.get('name') == layerName) {
      rtnIdx = idx;
      return false;
    }
  });

  return rtnIdx;
};


ol.control.Zoom = function(opt_options) {
  var options = opt_options ? opt_options : {};
  var className = options.className !== undefined ? options.className : 'ol-zoom';
  var delta = options.delta !== undefined ? options.delta : 1;
  var zoomInLabel = options.zoomInLabel !== undefined ? options.zoomInLabel : '+';
  var zoomOutLabel = options.zoomOutLabel !== undefined ? options.zoomOutLabel : '\u2212';
  var zoomInTipLabel = options.zoomInTipLabel !== undefined ? options.zoomInTipLabel : 'Zoom in';
  var zoomOutTipLabel = options.zoomOutTipLabel !== undefined ? options.zoomOutTipLabel : 'Zoom out';
  var inElement = document.createElement('button');
  inElement.className = className + '-in';
  inElement.setAttribute('type', 'button');
  inElement.title = zoomInTipLabel;
  inElement.appendChild(typeof zoomInLabel === 'string' ? document.createTextNode(zoomInLabel) : zoomInLabel);
  ol.events.listen(inElement, ol.events.EventType.CLICK, ol.control.Zoom.prototype.handleClick_.bind(this, delta));
  var outElement = document.createElement('button');
  outElement.className = className + '-out';
  outElement.setAttribute('type', 'button');
  outElement.title = zoomOutTipLabel;
  outElement.appendChild(typeof zoomOutLabel === 'string' ? document.createTextNode(zoomOutLabel) : zoomOutLabel);
  ol.events.listen(outElement, ol.events.EventType.CLICK, ol.control.Zoom.prototype.handleClick_.bind(this, -delta));

  inElement.onclick = function() {return false;};
  outElement.onclick = function() {return false;};

  var cssClasses = className + ' ' + ol.css.CLASS_UNSELECTABLE + ' ' + ol.css.CLASS_CONTROL;
  var element = document.createElement('div');
  element.className = cssClasses;
  element.appendChild(inElement);
  element.appendChild(outElement);
  ol.control.Control.call(this, {element: element, target: options.target});
  this.duration_ = options.duration !== undefined ? options.duration : 250;
};
ol.inherits(ol.control.Zoom, ol.control.Control);

ol.control.Zoom2 = function(opt_options) {
	  var options = opt_options ? opt_options : {};
	  var className = options.className !== undefined ? options.className : 'tool-zoom';
	  var delta = options.delta !== undefined ? options.delta : 1;
	  var zoomInLabel = options.zoomInLabel !== undefined ? options.zoomInLabel : '+';
	  var zoomOutLabel = options.zoomOutLabel !== undefined ? options.zoomOutLabel : '\u2212';
	  var zoomInTipLabel = options.zoomInTipLabel !== undefined ? options.zoomInTipLabel : 'Zoom in';
	  var zoomOutTipLabel = options.zoomOutTipLabel !== undefined ? options.zoomOutTipLabel : 'Zoom out';
	  var inElement = document.createElement('button');
	  inElement.className = className + '-in';
	  inElement.setAttribute('type', 'button');
	  inElement.title = zoomInTipLabel;
	  inElement.appendChild(typeof zoomInLabel === 'string' ? document.createTextNode(zoomInLabel) : zoomInLabel);
	  ol.events.listen(inElement, ol.events.EventType.CLICK, ol.control.Zoom.prototype.handleClick_.bind(this, delta));
	  var outElement = document.createElement('button');
	  outElement.className = className + '-out';
	  outElement.setAttribute('type', 'button');
	  outElement.title = zoomOutTipLabel;
	  outElement.appendChild(typeof zoomOutLabel === 'string' ? document.createTextNode(zoomOutLabel) : zoomOutLabel);
	  ol.events.listen(outElement, ol.events.EventType.CLICK, ol.control.Zoom.prototype.handleClick_.bind(this, -delta));

	  inElement.onclick = function() {return false;};
	  outElement.onclick = function() {return false;};

	  var cssClasses = className + ' ' + ol.css.CLASS_UNSELECTABLE + ' ' + ol.css.CLASS_CONTROL;
	  var element = document.createElement('div');
	  var zoomElement = document.getElementById("zoomElement");
	  element.className = cssClasses;
	  element.appendChild(inElement);
	  element.appendChild(outElement);
	  zoomElement.appendChild(element);
	  ol.control.Control.call(this, {element: element, target: options.target});
	  this.duration_ = options.duration !== undefined ? options.duration : 250;
	};
	ol.inherits(ol.control.Zoom2, ol.control.Control);

ol.control.Zoom.prototype.handleClick_ = function(delta, event) {
  event.preventDefault();
  this.zoomByDelta_(delta);
};

ol.control.Zoom.prototype.zoomByDelta_ = function(delta) {
  var map = this.getMap();
  var view = map.getView();
  if (!view) {return;}
  var currentResolution = view.getResolution();
  if (currentResolution) {
    var newResolution = view.constrainResolution(currentResolution, delta);
    if (this.duration_ > 0) {
      if (view.getAnimating()) {view.cancelAnimations();}
      view.animate({resolution: newResolution, duration: this.duration_, easing: ol.easing.easeOut});
    } else {
      view.setResolution(newResolution);
    }
  }
};

ol.uri.appendParams = function(uri, params) {
  var keyParams = [];
  // Skip any null or undefined parameter values
  Object.keys(params).forEach(function(k) {
    if (params[k] !== null && params[k] !== undefined) {
      keyParams.push(k + '=' + encodeURIComponent(params[k]));
    }
  });
  var qs = keyParams.join('&');
  // remove any trailing ? or &
  //uri = uri.replace(/[?&]$/, '');
  // append ? or & depending on whether uri has existing parameters
  //uri = uri.indexOf('?') === -1 ? uri + '?' : uri + '&';
  uri = uri.indexOf('?') === -1 ? uri + '?' : uri;
  return uri + qs;
};

ol.interaction.Draw.prototype.finishDrawing = function() {
  var sketchFeature = this.abortDrawing_();
  var coordinates = this.sketchCoords_;
  var geometry = /** @type {ol.geom.SimpleGeometry} */ (sketchFeature.getGeometry());
  if (this.mode_ === ol.interaction.Draw.Mode.LINE_STRING) {
    coordinates.pop();
    this.geometryFunction_(coordinates, geometry);
  } else if (this.mode_ === ol.interaction.Draw.Mode.POLYGON) {
    coordinates[0].pop();
    this.geometryFunction_(coordinates, geometry);
    coordinates = geometry.getCoordinates();
  }

  if (this.type_ === ol.geom.GeometryType.MULTI_POINT) { sketchFeature.setGeometry(new ol.geom.MultiPoint([coordinates])); }
  else if (this.type_ === ol.geom.GeometryType.MULTI_LINE_STRING) { sketchFeature.setGeometry(new ol.geom.MultiLineString([coordinates])); }
  else if (this.type_ === ol.geom.GeometryType.MULTI_POLYGON) { sketchFeature.setGeometry(new ol.geom.MultiPolygon([coordinates])); }

  this.dispatchEvent(new ol.interaction.Draw.Event(ol.interaction.Draw.EventType.DRAWEND, sketchFeature));

  if (this.features_) { this.setFeatureStyle(sketchFeature); this.features_.push(sketchFeature); }
  if (this.source_) { this.setFeatureStyle(sketchFeature); this.source_.addFeature(sketchFeature); }
};

ol.interaction.Draw.prototype.setFeatureStyle = function(feature) {
  var style = null;

  if (this.mode_ === ol.interaction.Draw.Mode.POINT) {
    if (this.text_ == '') {
      style = new ol.style.Style({
        image:new ol.style.Circle({radius:4, fill:new ol.style.Fill({color:[0, 153, 255, 1]}),
        stroke:new ol.style.Stroke({color:[255, 255, 255, 1], width:2})}),
        zIndex:1E5
      });
    } else {
      style = new ol.style.Style({
        text: new ol.style.Text({
          textAlign: 'left',
          textBaseline: 'top',
          font: 'bold 10pt 굴림',
          text: this.text_,
          fill: new ol.style.Fill({color: [0, 0, 0, 1]}),
          stroke: new ol.style.Stroke({color: [255, 255, 255, 0.8], width: 4}),
          offsetX: 0,
          offsetY: 0,
          rotation: 0
        }),
        zIndex:1E5
      });
    }
  } else if (this.mode_ === ol.interaction.Draw.Mode.LINE_STRING) {
    style = new ol.style.Style({
      stroke:new ol.style.Stroke({color:[0, 153, 255, 1], width:3})
    });
  } else {
    style = new ol.style.Style({
      fill:new ol.style.Fill({color:[255, 255, 255, 0.5]}),
      stroke:new ol.style.Stroke({color:[0, 153, 255, 1], width:3})
    });
  }

  feature.setStyle(style);
};