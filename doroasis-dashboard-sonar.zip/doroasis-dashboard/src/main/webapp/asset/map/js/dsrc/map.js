var _m = new _m();

function info(str) {if (typeof console != "undefined") {/*console.info(str);*/}}

function _m() {
    this.map = null; // 맵 객체(ol)
    this.sysKey = "TIS"; // 시스템키
    this.zoomLevel = 2; // 지도 줌 상태
    this.width = 5;     // 교통량 링크 굵기
    this.scale = 1;     // 노드 피처 스케일
    this.fontScale = 0; // 링크 폰트 스케일
    this.radius = 20;   // 포인트 피처 크기
    this.callback;      // 콜백함수
    
    /**
     * 맵 초기화
     * 
     * @param callback - 맵 로딩 후, 수행 할 함수
     */
    this.mapInit = function(callback) {
        himap.url.SERVER_IP = 'ngeoapi.ex.co.kr:8443'; // 맵서버 IP
        //himap.url.SERVER_IP = 'geoapi.ex.co.kr'; // 맵서버 IP
        sysKeys_ = new ol.Object({"TIS":"TIS_01||TIS_02"});
        sysKeysAll_ = ol.obj.getValues(sysKeys_.getProperties()).join("||");

        // 맵가이드 레이어 : IP||mapdefinition
        mapguidemapLayers_ = new ol.Object({
            "Default" : himap.url.SERVER_IP +"||Library://GGTM/DEFAULT/Maps/Default.MapDefinition" // 기본정보
        });
        
        tileLayers_ = new ol.Object({
            "District" : himap.url.SERVER_IP +"||Library://GGTM/TIS/Maps/TIS.MapDefinition||District||N||N"
        }); 

        // 콜백 함수가 있을 경우 저장
        if ( typeof(callback) == "function" ) {
            this.callback = callback;
        }
        
        // 맵 생성
        this.map = new himap.Map({ 
            "sysKey" : this.sysKey,
            "target" : "mapContent", // 지도 표출되는 엘리먼트의 ID
            "layers" : [ new himap.layer.vworld.Base({"sysKey" : this.sysKey,  "visible" : fnGetCookie("configToolbar_vworld.Base") == "N" ? false : true}), // 브이월드 배경지도
                         new himap.layer.vworld.Satellite({"sysKey":this.sysKey, "visible" : false}), // 브이월드 항공사진 배경
                         new himap.layer.MapGuideMap.Map({"sysKey" : this.sysKey, "name" : "Default", "visible" : fnGetCookie("configToolbar_Default") == "N" ? false : true, "onMapLoaded" : this.handleDefaultMapLoaded, "autoRefreshInterval" : 3*60 * 1000}) // 기본 노선, 이정, 등등
            ],
            "center" : [14042134.02, 4370800.42],
   		   	"zoom" : this.zoomLevel,
            "controls" : [new ol.control.ScaleLine(),
                          new ol.control.Zoom(),
                          new ol.control.MousePosition({
                              "target" : "mapPosition",
                              "projection" : "EPSG:3857",
                              "coordinateFormat" : ol.coordinate.createStringXY(2), // 자리수
                              "undefinedHTML" : "&nbsp;"
                         })]
        });
    };
    
    /**
     * 기본 레이어 로딩 완료시 호출
     */
    this.handleDefaultMapLoaded = function() {
    	
        // 콜백 함수가 있을 경우 수행
        if ( typeof(_m.callback) == "function" ) {
            _m.callback();
            _m.callback = null;
        }
    };

    /**
     * 레이어 On/Off
     * 
     * @param layerName - 대상 레이어명
     * @param obj - 체크박스 객체
     */
    this.setLayerVisible = function(layerName, obj) {
        layer = _m.map.getLayer(layerName);

        if ( layer == null ) {
                
            if ( layerName == "Node" ) { // 노드
                _m.geoJsonMap.initBaseLayer("N");
            } else if ( layerName == "Link" ) { // 링크
                _m.geoJsonMap.initBaseLayer("L");
            } else if ( layerName == "District" ) { // 행정경계
                _m.map.addLayer(new himap.layer.Tile.Layer({
                    "sysKey" : this.sysKey,
                    "name" : 'District',
                    "visible" : true,
                    "removeTileRangeFunction" : true,
                    "extent" : [ 13920000, 4020000, 14540000, 4650000 ]
                }));
            } else if ( layerName == "Inout"){
            	_m.geoJsonMap.initBaseLayer("Inout");
            }
            //[HIST]
            else if(layerName == "Label"){// 라벨
            	_m.geoJsonMap.initBaseLayer("Label");
            }
        } else {
            
            if ( $(obj).is(":checked") != true ) {
                _m.map.getLayer(layerName).setVisible(false);
            } else {
                _m.map.getLayer(layerName).setVisible(true);
            }
        }
    };
    
    /**
     * 피처에 깜빡임 효과 표시
     * 
     * @param feature - 대상 피처
     * @param duration - 지속시간
     */
    this.flashFeature = function(feature, duration) {
        var start = +new Date();
        var listenerKey;
        
        function animate(event) {
            var vectorContext = event.vectorContext;
            var frameState = event.frameState;
            var flashGeom = feature.getGeometry().clone();
            var elapsed = frameState.time - start;
            var elapsedRatio = elapsed / duration;
            var radius = ol.easing.easeOut(elapsedRatio) * 25 + 5;
            var opacity = ol.easing.easeOut(1 - elapsedRatio);
            
            var style = new ol.style.Style({
                "image" : new ol.style.Circle({
                    "radius" : radius,
                    "snapToPixed" : false,
                    "stroke" : new ol.style.Stroke({
                        "color" : [255, 0, 0, opacity],
                        "width" : 0.25 + opacity
                    })
                })
            });
            
            vectorContext.setStyle(style);
            vectorContext.drawGeometry(flashGeom);
            
            if ( elapsed > duration ) {
                ol.Observable.unByKey(listenerKey);
                return;
            }
            
            _m.map.render();
        }
        
        listenerKey = _m.map.on("postcompose", animate);
    };
    

    /**
     * 피처 중앙 좌표로 확대 및 이동
     * 
     * @param layerType - 레이어 유형(N:노드,L:링크)
     * @param paramKey - 파라메터 ID
     * @param paramValue - 파라메터 값
     */
    this.selectFeature = function(layerType, paramKey, paramValue) {
	
        var nodeFeatureList		= _m.geoJsonMap.nodeFeatures;
        var linkFeatureList 	= _m.geoJsonMap.linkFeatures;
        var labelFeatureList	= _m.geoJsonMap.labelFeatures;//[HIST]
        var inoutFeatureList   = _m.geoJsonMap.inoutFeatures;
		console.log(layerType, paramKey, paramValue);
        
        var matchedFeatureList =  [];
        var centerFeature = [];
        var centerPos = [];
        var zoomLevel = _m.map.getView().getZoom();
        var changeZoomLevel;
        console.log(nodeFeatureList);
        // 레이어 타입에 따른 좌표 계산
        if (layerType == "N") {

            // 노드 줌 레벨 설정
            changeZoomLevel = (zoomLevel < 9 ? 9 : zoomLevel);

            // 파라메터와 일치하는 피처를 배열에 저장
            for (var i=0, iMax=nodeFeatureList.length; i<iMax; i++) {

                if (nodeFeatureList[i].values_[paramKey] == paramValue) {
                    centerFeature = nodeFeatureList[i];
                    centerPos = centerFeature.getGeometry().getCoordinates();
                    break;
                }
            }
        } else if (layerType == "Label") {

            // 노드 줌 레벨 설정
            changeZoomLevel = (zoomLevel < 9 ? 9 : zoomLevel);

            // 파라메터와 일치하는 피처를 배열에 저장
            for (var i=0, iMax=labelFeatureList.length; i<iMax; i++) {

                if (labelFeatureList[i].values_[paramKey] == paramValue) {
                    centerFeature = labelFeatureList[i];
                    centerPos = centerFeature.getGeometry().getCoordinates();
                    break;
                }
            }
            

        } 
        
        else if (layerType == "Inout") {

            // 노드 줌 레벨 설정
            changeZoomLevel = (zoomLevel < 9 ? 9 : zoomLevel);

            // 파라메터와 일치하는 피처를 배열에 저장
            for (var i=0, iMax=inoutFeatureList.length; i<iMax; i++) {

                if (inoutFeatureList[i].values_[paramKey] == paramValue) {
                    centerFeature = inoutFeatureList[i];
                    centerPos = centerFeature.getGeometry().getCoordinates();
                    break;
                }
            } 
        }else {

            // 링크 줌 레벨 설정
            changeZoomLevel = (zoomLevel < 9 ? 9 : zoomLevel);

            var addFeatureIdx = 0;
            
            // 파라메터와 일치하는 피처를 배열에 저장
            for (var x=0, xMax=linkFeatureList.length; x<xMax; x++) {
                if (linkFeatureList[x].values_[paramKey] == paramValue) {
                    matchedFeatureList[addFeatureIdx++] = linkFeatureList[x];
                }
            }
            
            // 배열 가운데 위치한 피처를 저장
            if ( matchedFeatureList.length > 0 ) {
                
                if (matchedFeatureList.length == 1) {
                    centerFeature = matchedFeatureList[0];
                } else if (matchedFeatureList.length > 1) {
                    centerFeature = matchedFeatureList[Math.round(matchedFeatureList.length / 2)];
                }
                
                centerPos = centerFeature.getGeometry().getClosestPoint(ol.extent.getCenter(centerFeature.getGeometry().getExtent()));
            }
        }

        if ( typeof(centerFeature.getGeometry) != "undefined" ) {
            _m.map.getView().setCenter(centerPos);// 좌표 이동
            _m.map.getView().setZoom(changeZoomLevel); // 줌 변경
    
            // 선택한 노드 깜빡임 효과 설정
            if (layerType == "N") {
                _m.flashFeature(centerFeature, 2000);
            } else {
                
                // 링크일 경우 가운데 좌표 정보로 피처를 생성해서 전달
                var feature = new ol.Feature({
                    "geometry" : new ol.geom.Point(ol.proj.transform([centerPos[0], centerPos[1]],"EPSG:3857","EPSG:3857"))
                });
                
                _m.flashFeature(feature, 2000);
            }
        } else {
            alert("해당 레이어 또는 좌표 정보가 없습니다.");
        }
    };
    
    /**
     * geoJson 레이어 설정
     */
    this.geoJsonMap = {
        "featureStyle" : [],
        "nodeFeatures" : [],
        "linkFeatures" : [],
        "inoutFeatures" : [],
        "labelFeatures" : [],//[HIST]
        "init" : function(layerType, callbackFn) {
            
            // 색상 정의
            var whiteColor  	= [[255,255,255,0.3],  	 [255,255,255,0.8],  	[255,255,255,1]];
            var blackColor  	= [[0,0,0,0.3],        	 [0,0,0,0.8],        	[0,0,0,1], [126,123,123,1]];
            var greenColor  	= [[0,132,0,0.3],      	 [0,132,0,0.8],      	[0,132,0,1],      [051, 255, 051, 1], [32,225,2,1], [15,97,2,1]];
            var redColor    	= [[255, 0, 0, 0.3],   	 [255, 0, 0, 0.8],   	[255, 0, 0, 1], [240, 6, 6, 1], [167, 1, 1, 1]];
            var blueColor   	= [[0, 128, 255, 0.3], 	 [0, 128, 255, 0.8], 	[0, 128, 255, 1], [1, 13, 228, 1],[1, 9, 95, 1] ];
            var yellowColor 	= [[255, 255, 0, 0.3], 	 [255, 255, 0, 0.8], 	[255, 255, 0, 1], [251, 227,7,1], [189,170,1,1]];
            var orangeColor 	= [[255, 128, 0, 0.3], 	 [255, 128, 0, 0.8], 	[255, 128, 0, 1], [242, 118, 2, 1], [193,93,0,1], [252,132,12]];
            var skyBlueColor 	= [[135, 206, 235, 0.3], [135, 206, 235, 0.8],  [135, 206, 235, 1]];
            var darkKhakiColor 	= [[189, 183, 107, 0.3], [189, 183, 107, 0.8],  [189, 183, 107, 1]];
            var slateBlueColor 	= [[106, 90, 205, 0.3],  [106, 90, 205, 0.8],  	[106, 90, 205, 1]];
            var violetColor 	= [[238, 130, 238, 0.3], [238, 130, 238, 0.8], 	[238, 130, 238, 1]];
            var lavenderColor 	= [[230, 230, 250, 0.3], [230, 230, 250, 0.8], 	[230, 230, 250, 1]];
            var indigoColor 	= [[75, 0, 130, 0.3], 	 [75, 0, 130, 0.8], 	[75, 0, 130, 1]];
            var pinkColor 		= [[255, 192, 203, 0.3], [255, 192, 203, 0.8], 	[255, 192, 203, 1]];
            var purpleColor 	= [[128, 0, 128, 0.3], 	 [128, 0, 128, 0.8], 	[128, 0, 128, 1]];
            var oliveColor 		= [[128, 128, 0, 0.3], 	 [128, 128, 0, 0.8], 	[128, 128, 0, 1]];
            var darksyanColor 	= [[0, 139, 139, 0.3], 	 [0, 139, 139, 0.8], 	[0, 139, 139, 1]];
            var grayColor       = [[68, 69, 69, 0.3],    [68, 69, 69, 0.8],     [68, 69, 69, 1]]
            
            // 링크 스타일(기본 레이어)
            this.featureStyle["LINK1"] = new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : blackColor[3],  "width" : 5})});
            this.featureStyle["LINK2"] = new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : blackColor[3],  "width" : 5})});
            this.featureStyle["LINK3"] = new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : blackColor[3],    "width" : 5})});
            this.featureStyle["Inout1"] = new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : blackColor[3],    "width" : 5})});
            
            // 링크 스타일(점선 강조형)
            this.featureStyle["BLUE_DASH"]    = [new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : blueColor[1],   "width" : 20})}),new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : whiteColor[1], "width" : 10, "lineDash" : [30,10]})})];
            this.featureStyle["GREEN_DASH"]   = [new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : greenColor[1],  "width" : 20})}),new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : whiteColor[1], "width" : 10, "lineDash" : [30,10]})})];
            this.featureStyle["RED_DASH"]     = [new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : redColor[1],    "width" : 20})}),new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : whiteColor[1], "width" : 10, "lineDash" : [30,10]})})];
            this.featureStyle["YELLOW_DASH"]  = [new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : yellowColor[1], "width" : 20})}),new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : whiteColor[1], "width" : 10, "lineDash" : [30,10]})})];
            this.featureStyle["ORANGE_DASH"]  = [new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : orangeColor[1], "width" : 20})}),new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : whiteColor[1], "width" : 10, "lineDash" : [30,10]})})];

            // 링크 스타일(범위 라벨형)
            this.featureStyle["BLUE_LABEL"]   = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : blueColor[1],   "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["GREEN_LABEL"]  = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : greenColor[1],  "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["RED_LABEL"]    = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : redColor[1],    "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["YELLOW_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : yellowColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["ORANGE_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : orangeColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["SKYBLUE_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : skyBlueColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["DARKKHAKI_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : darkKhakiColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["SLATEBLUE_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : slateBlueColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["VIOLET_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : violetColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["LAVENDER_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : lavenderColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["INDIGO_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : indigoColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["PINK_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : pinkColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["PURPLE_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : purpleColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["OLIVE_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : oliveColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["DARKSYAN_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : darksyanColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["WHITE_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[1], "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["BLACK_LABEL"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : blackColor[2], "width" : _m.width, "lineCap" : "square" }) });

            // 링크 스타일(범위 사각형)
            this.featureStyle["BLUE_SQUARE"]   = new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : blueColor[1],   "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["GREEN_SQUARE"]  = new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : greenColor[1],  "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["RED_SQUARE"]    = new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : redColor[1],    "width" : _m.width, "lineCap" : "square" }) });
            this.featureStyle["YELLOW_SQUARE"] = new ol.style.Style({ "stroke" : new ol.style.Stroke({ "color" : yellowColor[1], "width" : _m.width, "lineCap" : "square" }) });
            
            //링크스타일(사각형뺌)
            this.featureStyle["BLUE_LINE"]   = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : blueColor[1],   "width" : _m.width }) });
            this.featureStyle["GREEN_LINE"]  = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : greenColor[1],  "width" : _m.width }) });
            this.featureStyle["RED_LINE"]    = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : redColor[1],    "width" : _m.width }) });
            this.featureStyle["YELLOW_LINE"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : yellowColor[3], "width" : _m.width }) });
            this.featureStyle["ORANGE_LINE"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : orangeColor[1], "width" : _m.width }) });
            this.featureStyle["PURPLE_LINE"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : purpleColor[1], "width" : _m.width }) });
            this.featureStyle["WHITE_LINE"]  = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : _m.width }) });
            this.featureStyle["BLACK_LINE"]  = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : blackColor[2], "width" : _m.width }) });
           
            this.featureStyle["BLUE_LINE_LIGHT"]   = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : blueColor[3],   "width" : _m.width }) });
            this.featureStyle["GREEN_LINE_LIGHT"]  = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : greenColor[4],  "width" : _m.width }) });
            this.featureStyle["RED_LINE_LIGHT"]    = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : redColor[3],    "width" : _m.width }) });
            this.featureStyle["YELLOW_LINE_LIGHT"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : yellowColor[4], "width" : _m.width }) });
            this.featureStyle["ORANGE_LINE_LIGHT"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : orangeColor[3], "width" : _m.width }) });
           
            
            this.featureStyle["BLUE_LINE_DARK"]   = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : blueColor[4],   "width" : _m.width }) });
            this.featureStyle["GREEN_LINE_DARK"]  = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : greenColor[5],  "width" : _m.width }) });
            this.featureStyle["RED_LINE_DARK"]    = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : redColor[4],    "width" : _m.width }) });
            this.featureStyle["YELLOW_LINE_DARK"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : yellowColor[2], "width" : _m.width }) });
            this.featureStyle["ORANGE_LINE_DARK"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "stroke" : new ol.style.Stroke({ "color" : orangeColor[4], "width" : _m.width }) });
           
            // 노드 스타일(기본 레이어)
            this.featureStyle["NODE1"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : redColor[2] }),   "text" : "●" })});
            this.featureStyle["NODE1_2"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : 2.5, "fill" : new ol.style.Fill({ "color" : redColor[2] }),   "text" : "●" })});
            this.featureStyle["NODE1_3"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : 2, "fill" : new ol.style.Fill({ "color" : blueColor[2] }),   "text" : "●" })});
            this.featureStyle["NODE2"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : blueColor[2] }),  "text" : "▲" })});
            this.featureStyle["NODE3"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : blueColor[2] }),  "text" : "▼" })});
            this.featureStyle["NODE4"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : greenColor[2] }), "text" : "■" })});
            this.featureStyle["NODE4_1"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : redColor[2] }), "text" : "■" })});
            this.featureStyle["NODE5"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : greenColor[2] }), "text" : "▣" })});
            this.featureStyle["NODE5_1"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : redColor[2] }), "text" : "▣" })});
            this.featureStyle["NODE6"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "text" : "●" })});
            this.featureStyle["NODE7"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "text" : "★" })});
            this.featureStyle["NODE8"] = new ol.style.Style({"text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.scale, "fill" : new ol.style.Fill({ "color" : redColor[2] }), "text" : "◆" })});

            // 노드 스타일(범위 원형)
            this.featureStyle["BLUE_CIRCLE"]   = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "image" : new ol.style.Circle({ "fill" : new ol.style.Fill({ color:blueColor[0] }),   "stroke" : new ol.style.Stroke({ "color" : blueColor[2] }),   "radius" : _m.radius }) });
            this.featureStyle["GREEN_CIRCLE"]  = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "image" : new ol.style.Circle({ "fill" : new ol.style.Fill({ color:greenColor[0] }),  "stroke" : new ol.style.Stroke({ "color" : greenColor[2] }),  "radius" : _m.radius }) });
            this.featureStyle["RED_CIRCLE"]    = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "image" : new ol.style.Circle({ "fill" : new ol.style.Fill({ color:redColor[0] }),    "stroke" : new ol.style.Stroke({ "color" : redColor[2] }),    "radius" : _m.radius }) });
            this.featureStyle["YELLOW_CIRCLE"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "image" : new ol.style.Circle({ "fill" : new ol.style.Fill({ color:yellowColor[0] }), "stroke" : new ol.style.Stroke({ "color" : yellowColor[2] }), "radius" : _m.radius }) });
            this.featureStyle["ORANGE_CIRCLE"] = new ol.style.Style({ "text" : new ol.style.Text({ "font" : "Dotum, 돋움, Arial, sans-serif", "scale" : _m.fontScale, "fill" : new ol.style.Fill({ "color" : blackColor[2] }), "stroke" : new ol.style.Stroke({ "color" : whiteColor[2], "width" : 2 }) }), "image" : new ol.style.Circle({ "fill" : new ol.style.Fill({ color:orangeColor[0] }), "stroke" : new ol.style.Stroke({ "color" : orangeColor[2] }), "radius" : _m.radius }) });
            
            // 레이어 json 데이터 조회
            this.getGeoJsonFeatures(layerType, callbackFn);
        },
        "getGeoJsonFeatures" : function(layerType, callbackFn) {
            var xmlHttp = new XMLHttpRequest();
            var url = "/route/map/getGeoJsonString.do?layerType="+layerType;
            
            xmlHttp.onreadystatechange = function() {
                if ( xmlHttp.readyState == 4 ) {
                    if ( xmlHttp.status == 200 ) {
                        var geojson = new ol.format.GeoJSON();
                        
                        if ( layerType == "N" ) { // 노드 레이어
                            _m.geoJsonMap.nodeFeatures =  geojson.readFeatures(xmlHttp.responseText, null);
                        } 
                        //[HIST]
                        else if ( layerType == "Label" ) { // 라벨 레이어
                        	
                            _m.geoJsonMap.labelFeatures =  geojson.readFeatures(xmlHttp.responseText, null);
                        }
                        else if( layerType == "Inout"){
                        	
                        	_m.geoJsonMap.inoutFeatures =  geojson.readFeatures(xmlHttp.responseText, null);
                        }
                        else { // 링크 레이어
                            _m.geoJsonMap.linkFeatures =  geojson.readFeatures(xmlHttp.responseText, null);
                        }
                        
                        // 콜백 함수가 있을 경우 수행
                        if ( typeof(callbackFn) == "function" ) {
                            callbackFn();
                        } 
                    }
                }
            };
            xmlHttp.open("POST", url, true);
            xmlHttp.send(null);
        },
        "initBaseLayer" : function(layerType, callbackFn) {
            var layer;                   // 레이어 객체
            var layerName = "";          // 레이어명
            var source;                  // 레이어 소스
            var hiddenFeatureList;       // 피처 리스트
            var matchedFeatureList = []; // 신규 레이어 피처
            var addFeatureIdx = 0;       // 신규 레이어 피처 추가 순번

            // 레이어 타입 코드에 해당하는 값을 설정
            if ( layerType == "N" ) {
                layerName = "Node";
                hiddenFeatureList = _m.geoJsonMap.nodeFeatures;
            } 
            else if ( layerType == "Label" ) {
                layerName = "Label";
                hiddenFeatureList = _m.geoJsonMap.labelFeatures;
            }else if(layerType == "Inout"){
            	layerName = "Inout";
                hiddenFeatureList = _m.geoJsonMap.inoutFeatures;
            }
            else {
                layerName = "Link";
                hiddenFeatureList = _m.geoJsonMap.linkFeatures;
            }
            
            // 레이어명에 해당하는 레이어를 조회
            layer = _m.map.getLayer(layerName);
            
            // 해당 레이어가 없을 경우 생성
            if ( layer == null ) {
            	
                _m.map.addLayer(new ol.layer.Vector({name:layerName}));
                layer = _m.map.getLayer(layerName);
                layer.setSource(new ol.source.Vector());
                layer.setVisible(false);
            } 

            // 레이어를 통해 소스 조회
            source = layer.getSource();
            
            // 기존 소스에 있던 feature 를 초기화
            source.clear();

            // 보기설정 값 조회
            var configNodeCookieList = ["configNode1","configNode2","configNode3","configNode4","configNode5","configNode6","configNode7", "configNode8"];
            var configLinkCookieList = ["configLink1","configLink2","configLink3"];
            var configInoutCookieList = ["configInout1"];
            var configLabelCookieList = [
            		 "configLabel1"										
	            	,"configLabel2"
	            	,"configLabel3"
	            	,"configLabel4"
	            	,"configLabel5"
	            	,"configLabel6"
	            	,"configLabel7"
	            	,"configLabel8"
	            	,"configLabel9"
	            	,"configLabel10"
	            	,"configLabel11"
	            	,"configLabel12"
            	];//[HIST]
            
            var configNodeList = [];
            var configLinkList = [];
            var configInoutList = [];
            var configLabelList = [];//[HIST]
            
            
            var cookieNodeIdx = 0;
            
            // 노드 설정값 조회
            for ( var i=0, iMax=configNodeCookieList.length; i<iMax; i++ ) {
                
                if ( document.cookie.indexOf(configNodeCookieList[i]+"=Y") != -1 ) {
                    configNodeList[cookieNodeIdx++] = "Y";
                } else {
                    configNodeList[cookieNodeIdx++] = "";
                }
            }

            var cookieLinkIdx = 0;
            
            // 링크 설정값 조회
            for ( var x=0, xMax=configLinkCookieList.length; x<xMax; x++ ) {
                
                if ( document.cookie.indexOf(configLinkCookieList[x]+"=Y") != -1 ) {
                    configLinkList[cookieLinkIdx++] = "Y";
                } else {
                    configLinkList[cookieLinkIdx++] = "";
                }
            }
            //진출입
            var cookieInoutIdx = 0;
            for ( var x=0, ioMax=configInoutCookieList.length; x<ioMax; x++ ) {
                
                if ( document.cookie.indexOf(configInoutCookieList[x]+"=Y") != -1 ) {
                    configInoutList[cookieInoutIdx++] = "Y";
                } else {
                    configInoutList[cookieInoutIdx++] = "";
                }
            }
            
            //[HIST] 라벨 설정값 조회
            var cookieLabelIdx = 0;
            
            // 노드 설정값 조회
            for ( var z=0, zMax=configLabelCookieList.length; z<zMax; z++ ) {
                
                if ( document.cookie.indexOf(configLabelCookieList[z]+"=Y") != -1 ) {
                    configLabelList[cookieLabelIdx++] = "Y";
                } else {
                    configLabelList[cookieLabelIdx++] = "";
                }
            }
            //testCode
            
            
            
            // 설정값에 따른 노드/링크 레이어 피처 생성
            for ( var y=0, yMax=hiddenFeatureList.length; y<yMax; y++ ) {
                var hiddenFeature = hiddenFeatureList[y];
                var typeNumber = 0;
                if ( layerType == "N" ) { // 노드
                    
                    if ( hiddenFeature.values_["node_type"] != "" ) {
                        
                        try {
                            typeNumber = Number(hiddenFeature.values_["node_type"])-1;
                            
                            if ( configNodeList[typeNumber] == "Y" ) {
                            	
                        		// 노드 타입별 스타일 적용 
                        		hiddenFeature.setStyle(_m.geoJsonMap.featureStyle["NODE"+(typeNumber+1)].clone());
                        		hiddenFeature.getStyle().getText().setScale(_m.scale);
                        		matchedFeatureList[addFeatureIdx++] = hiddenFeature;
                        		
                        		//testCode
		                		if(hiddenFeature == null){
		                		}
                            }
                        } catch (e) {
                        	//testCode
                        	console.log(e);
                            
                        	continue;
                        }
                    }
                } else if ( layerType == "Label" ) { // 라벨
                	
                	if ( hiddenFeature.values_["node_type"] != "" ) {
                		try {
                			
                			if(configLabelList.indexOf("Y")> -1){
                				var value = fnGetTotalLabel(configLabelList,hiddenFeature);
                				
                				if(value != null 
    									&& value != ''
    									&& value != 'null'	
    									&& value != undefined 
    									&& value != 'undefined'
										&& value != 0
            							&& value != ""){
                					
                					var feature = new ol.style.Style({
    	                				"text" : new ol.style.Text({ 
    	                					"font" : "Dotum, 돋움, Arial, sans-serif"
    	                					, "scale" : _m.scale
    	                					, "fill" : new ol.style.Fill({
    	                						"color" : [0,0,0,0.8] 
    	                						})
    	                					, "text" : String(value) 
    	                					})
    	                				});
    	                			
    		                		hiddenFeature.setStyle(feature);
    		                		hiddenFeature.getStyle().getText().setScale(_m.scale);
    		                		matchedFeatureList[addFeatureIdx++] = hiddenFeature;
                					
                				}
                			}
                			
                			
                			/*
                			for(var li = 0 ; li < configLabelList.length ; li++){
                				
                				if(configLabelList[li] == "Y"){
                					
                					var value = fnGetLabel(li,hiddenFeature);
                					
                					if(value != null 
        									&& value != ''
        									&& value != 'null'	
        									&& value != undefined 
        									&& value != 'undefined'
                							&& value != ""){
                						
	                					var feature = new ol.style.Style({
	    	                				"text" : new ol.style.Text({ 
	    	                					"font" : "Dotum, 돋움, Arial, sans-serif"
	    	                					, "scale" : _m.scale
	    	                					, "fill" : new ol.style.Fill({
	    	                						"color" : [0,0,0,0.8] 
	    	                						})
	    	                					, "text" : String(value) 
	    	                					})
	    	                				});
	    	                			
	    		                		hiddenFeature.setStyle(feature);
	    		                		hiddenFeature.getStyle().getText().setScale(_m.scale);
	    		                		matchedFeatureList[addFeatureIdx++] = hiddenFeature;
	    		                		
	    		                		//testCode
	    		                		console.log("addFeatureIdx : " + addFeatureIdx + ", value : " + value);
	    		                		if(hiddenFeature == null){
	    		                			console.log(hiddenFeature);
	    		                		}
	    		                		
                					}
                				}
                			}
                			/**/
                			
                		 } catch (e) {
                			 continue;
                         }	
                		
                	}
                  
                } else if( layerType == "Inout"){
                	 if ( hiddenFeature.values_["LINK_ID"] != "" ) {
                         
                         try {
                             typeNumber = 0;
                             if ( configInoutList[typeNumber] == "Y" ) {
                                 hiddenFeature.setStyle(_m.geoJsonMap.featureStyle["Inout"+(typeNumber+1)]);
                                 matchedFeatureList[addFeatureIdx++] = hiddenFeature;
                             }
                         } catch (e) {
                        	 console.log(e);
                             continue;
                         }
                     }
                	 
                } else { // 링크
                        if ( hiddenFeature.values_["link_type"] != "" ) {
                        
                        try {
                            typeNumber = Number(hiddenFeature.values_["link_type"])-1;
                            
                            if ( configLinkList[typeNumber] == "Y" ) {
                                
                                hiddenFeature.setStyle(_m.geoJsonMap.featureStyle["LINK"+(typeNumber+1)]);
                                matchedFeatureList[addFeatureIdx++] = hiddenFeature;
                            }
                        } catch (e) {
                            continue;
                        }
                    }
                }
            }
            source.addFeatures(matchedFeatureList);
            
            // 툴바 체크박스에 따른 표시여부 설정
            if ((layerType == "N" && $("#_chkNode").is(":checked") == true) 
            		
            		|| (layerType == "Label" 	&& $("#_chkLabel"	).is(":checked") == true)
            		|| (layerType == "L" 		&& $("#_chkLink"	).is(":checked") == true)
            		|| (layerType == "Inout" 		&& $("#_chkInout"	).is(":checked") == true)
            		) {
                layer.setVisible(true);
            }
            
            layer = null;
            source = null;
            
            // 콜백 함수가 있을 경우 수행
            if ( arguments.length > 0 && typeof(callbackFn) == "function" ) {
                callbackFn();
            }
        },
        "updateBaseLayer" : function(layerType) {
            
            _m.geoJsonMap.initBaseLayer(layerType);
            
            // 툴바 체크박스에 따른 표시여부 설정
            if ( layerType == "N" ) {
            	
                if ( $("#_chkNode").is(":checked") == true ) {
                    _m.map.getLayer("Node").setVisible(true);
                } else {
                    _m.map.getLayer("Node").setVisible(false);
                }
            } 
            else if ( layerType == "Label" ) {
            	
                if ( $("#_chkLabel").is(":checked") == true ) {
                    _m.map.getLayer("Label").setVisible(true);
                } else {
                    _m.map.getLayer("Label").setVisible(false);
                }
            }
            
			else if ( layerType == "Inout" ) {
			            	
                if ( $("#_chkInout").is(":checked") == true ) {
                    _m.map.getLayer("Inout").setVisible(true);
                } else {
                    _m.map.getLayer("Inout").setVisible(false);
                }
            }
			            
            else {//node
                
                if ( $("#_chkLink").is(":checked") == true ) {
                    _m.map.getLayer("Link").setVisible(true);
                } else {
                    _m.map.getLayer("Link").setVisible(false);
                }
            }
        },
        "addJsonLayer" : function(layerType, layerName, param) {
            var layer;                    // 레이어 객체
            var source;                   // 레이어 소스
            var dataList = param.dataList;// 신규 레이어 데이터 리스트
            var hiddenFeatureList;        // 기본 레이어 피처 리스트
            var matchedFeatureList = [];  // 신규 레이어 피처
            var addFeatureIdx = 0;        // 신규 레이어 피처 추가 순번
            
            // 레이어 타입 코드에 해당하는 값을 설정
            if ( layerType == "N" ) {
                hiddenFeatureList = _m.geoJsonMap.nodeFeatures;
                
            } 
            else if ( layerType == "Label" ) {
                hiddenFeatureList = _m.geoJsonMap.labelFeatures;
                
            }
            else if( layerType == "Inout"){
            	hiddenFeatureList = _m.geoJsonMap.inoutFeatures;
            }
            
            else {
                hiddenFeatureList = _m.geoJsonMap.linkFeatures;
            }
            
            // 레이어명에 해당하는 레이어를 조회
            layer = _m.map.getLayer(layerName);
            
            // 해당 레이어가 없을 경우 생성
            if ( layer == null ) {
                _m.map.addLayer(new ol.layer.Vector({name:layerName}));
                layer = _m.map.getLayer(layerName);
                layer.setSource(new ol.source.Vector());
                layer.setVisible(false);
            } 

            // 레이어를 통해 소스 조회
            source = layer.getSource();
            
            // 기존 소스에 있던 feature 를 초기화
            source.clear();
            
            // 로딩되어 있는 geoJson 레이어의 값과 비교하여 일치한 feature 를 
            // 새로운 레이어 freature 로 설정
            for ( var i=0, iMax=dataList.length; i<iMax; i++ ) {
                var data = dataList[i];
                
                for ( var x=0, xMax=hiddenFeatureList.length; x<xMax; x++ ) {
                    var hiddenFeature = hiddenFeatureList[x];
                    var hiddenFeatureKey = hiddenFeature.values_[param.key];
                    
                    if ( hiddenFeatureKey == data.key ) {
                        var matchedFeature = hiddenFeature.clone();

                        if ( typeof(data.label) != "undefined" && data.label != "" ) {
                            matchedFeature.setStyle(_m.geoJsonMap.featureStyle[data.style].clone());    
                        } else {
                            matchedFeature.setStyle(_m.geoJsonMap.featureStyle[data.style]);
                        }
                        
                        // 스케일이 지정되어 있을 경우
                        if ( typeof(data.scale) != "undefined" && Number(data.scale) > 0 && matchedFeature.getStyle().getImage() != null ) {
                            matchedFeature.getStyle().getImage().setRadius(data.scale);
                        }
                        
                        // 라벨이 지정되어 있을 경우
                        if ( typeof(data.label) != "undefined" && data.label != "" && matchedFeature.getStyle().getText() != null ) {
                            matchedFeature.getStyle().getText().setScale(_m.fontScale);
                            matchedFeature.getStyle().getText().setText(data.label+"");
                        }
                        
                        // 굵기가 지정되어 있을 경우
                        if ( typeof(data.width) != "undefined" && Number(data.width) > 0 && matchedFeature.getStyle().getStroke() != null ) {
                            matchedFeature.getStyle().getStroke().setWidth(data.width);
                        }
                        
                        // 스타일 객체가 있을 경우
                        if ( typeof(data.styleObject) != "undefined" && data.styleObject != null ) {
                            matchedFeature.setStyle(data.styleObject);
                        }
                        
                        matchedFeatureList[addFeatureIdx++] = matchedFeature;
                        
                        break;    
                    }
                }
            }
            
            source.addFeatures(matchedFeatureList);
         
            layer = null;
            source = null;                        
        },
        "visible" : function(layerName, visible) {
            if ( _m.map.getLayer(layerName) != null ) {
                _m.map.getLayer(layerName).setVisible(visible);                
            }
        }
        
    };
}