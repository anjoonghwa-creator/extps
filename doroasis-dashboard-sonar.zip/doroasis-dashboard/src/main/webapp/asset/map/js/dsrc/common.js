/**
 * 전역변수 선언
 */
var _propertyCodeList = {}; // 노드/링크 속성코드 리스트
var _zoneCodeList; // 노드/링크 시군구코드 리스트
var _returnValue = []; // 레이어 팝업 리턴값
var _returnCallBack; // 레이어 팝업 콜백
var _returnCallBackParam = null; // 레이어 팝업 콜백


$(document).ready(function(){
    
	/**/
    // 기본 지도 로딩
    _m.mapInit(function(){
        
        // 레이어 json 데이터 로딩
        _m.geoJsonMap.init("N", function(){
            _m.geoJsonMap.init("L", function(){
            	_m.geoJsonMap.init("Inout", function(){
            	//[HIST]
	            	_m.geoJsonMap.init("Label", function(){
	                
		                // 툴바 체크박스를 쿠키에 설정된 상태로 설정
		                fnSetToolbarCheckBox();
		                
		                // 노드/링크 속성정보 공통코드 조회
		                //fnGetPropertyCode();
		                
		                // 노드/링크 시군구코드 조회
		                //fnGetZoneCode();
		                
		                // 노드/링크 보기설정 드롭박스 생성
		                $("#_nodeDropBox").dropdownMultiCheckbox({"checkAllText":"보기설정 : 지점"});
		                $("#_linkDropBox").dropdownMultiCheckbox({"checkAllText":"보기설정 : 구간"});
		                
		                //[HIST] 20201006
		                $("#_labelDropBox").dropdownMultiCheckbox({"checkAllText":"보기설정 : 레이블"});
		                
		                // 노드/링크 보기설정 값 설정
		                fnSetConfigLayer();
		                
		                // 검색창 표시
		                if ( $("#_searchLayer").css("display") != "block" ) {
		                    $("#_btnSearchLayer").trigger("click");                    
		                }
		                
		                // 지도 확대 레벨에 따른 노드/링크속도/RSE경로 레이어 피처 크기 조정
		                _m.map.on("moveend", fnRescale);
		                
		                //_m.map.on("dblclick", fnOpenFeatureProperty);
		                
		                
		                /** 네트워크 이력 현황 **/
		                /*
		                fnCallAjax("/test/map/networkHistory.do", null, function(dataList){
		                	var htmlStr = null;
		                	for(var h=0 ; h<dataList.length;h++){
		                		htmlStr += "<tr>";
		                		htmlStr += "<td class='center' >"+dataList[h].networkno + "</td>";
		                		htmlStr += "<td class='center' >"+dataList[h].networkversion + "</td>";
		                		htmlStr += "<td class='center' >"+dataList[h].networkcreatedate + "</td>";
		                		htmlStr += "<td class='center' >"+dataList[h].networkapplidate + "</td>";
		                		htmlStr += "<td class='center' >"+dataList[h].networkfinal + "</td>";
		                		htmlStr += "<td class='center' >"+dataList[h].networkrse + "</td>";
		                		htmlStr += "<td class='center' >"+dataList[h].networknormalrse + "</td>";
		                		htmlStr += "<td class='center' >"+dataList[h].networkratio + "</td>";
		                		htmlStr += "<td class='center dataRow' onclick=\"fnOpenLayerPopup(this,'_networkInfoLayerDetail',null,"+ dataList[h].networkversion +", 'network')\" id='networkDetailCheck' style='cursor:pointer;'> 상세보기 </td>"
		                		htmlStr += "</tr>";
		                	}
		                	$("#networkHistoryStatus tbody").html(htmlStr);
		                });
		                */
	            	});
            	});
            });
        });
    });
	_m.handleDefaultMapLoaded();

    /**/
});

/**
 * jQuery 하위버전 기능(jQuery.browser)
 */
(function(){
    var matched, browser;
    
    jQuery.uaMatch = function(ua) {
        ua = ua.toLowerCase();
        
        var match = /(chrome)[ \/]([\w.]+)/.exec( ua ) ||
        /(webkit)[ \/]([\w.]+)/.exec( ua ) ||
        /(opera)(?:.*version|)[ \/]([\w.]+)/.exec( ua ) ||
        /(msie) ([\w.]+)/.exec( ua ) ||
        ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec( ua ) ||
        [];

        return {
            "browser" : match[ 1 ] || "",
            "version" : match[ 2 ] || "0"
        };
    };
    
    matched = jQuery.uaMatch(navigator.userAgent);
    browser = {};
    
    if ( browser.chrome ) {
        browser.webkit = true;
    } else if ( browser.webkit ) {
        browser.safari = true;
    }
    
    jQuery.browser = browser;
})();

/**
 * 드롭다운 체크 박스
 * 
 * @param options - 옵션 { checkAllText : 레이블, checkAllYn : 전체선택 체크박스 추가 여부(Y:추가) }
 */
$.extend($.fn, {
    dropdownMultiCheckbox : function(options) {
        var topParent = this;
        var checkAllText = typeof(options.checkAllText) != "undefined" ? options.checkAllText : "전체";
        
        // 전체선택 옵션을 추가할 경우
        if ( typeof (options.checkAllYn) != "undefined" && options.checkAllYn == true ) {
            this.find("dd > ul").prepend("<li><input type='checkbox' class='allmultichk'>"+options.checkAllText+"</li>");
            
            this.find(".allmultichk").on("click",function(e){
                var chk = $(this).is(":checked");
                
                if ( chk == true ) {
                    $(this).parent().nextAll().find("input[type='checkbox'][class!='allmultichk']").attr("checked",true);
                } else {
                    $(this).parent().nextAll().find("input[type='checkbox'][class!='allmultichk']").attr("checked",false);
                }
                
                topParent.setCheckedCnt(options);
            });
        }
        
        this.setCheckedCnt(options);
        this.find("dt").on("click", function(){
            $(".dropdownBox dt").not(this).nextAll().filter("dd").hide();
            $(this).nextAll().filter("dd").slideToggle("fase");
        });
        
        // 항목 체크박스 체크 시 선택된 개수 변경
        this.find("dd input[type='checkbox'][class!='allmultichk']").on("click",function(e){
           topParent.setCheckedCnt(options); 
        });
        
        // 포커스가 나간 경우 닫기
        $("body").mousedown(function(e){
           $(".dropdownBox").each(function(){
               if($(this).find("dd").css("display") == "block" ) {
                   if(!$(this).has(e.target).length){
                       $(this).find("dd").hide();
                   }
               }
           });
        });
    },
    setCheckedCnt : function(options) {
        var chk_cnt = this.find("dd input[type='checkbox'][class!='allmultichk']:checked").length;
        var all_cnt = this.find("dd input[type='checkbox'][class!='allmultichk']").length;
        var checkAllText = typeof(options.checkAllText) != "undefined" ? options.checkAllText : "전체";
        
        if ( chk_cnt == all_cnt ) {
            this.find(".multiCheckValues").html(checkAllText);
            this.find("input[type='checkbox'][class='allmultichk']").attr("checked",true);
        } else {
            this.find(".multiCheckValues").html(checkAllText);
            this.find("input[type='checkbox'][class='allmultichk']").attr("checked",false);
        }
    }
    
});

/**
 * Ajax 호출
 * 
 * @param url - 호출 URL
 * @param param - 파라메터
 * @param callbackFn - 콜백함수
 */
function fnCallAjax(url, param, callbackFn) {
    
    if ( typeof(callbackFn) != "function" ) {
        alert("error : 콜백 함수를 지정해주세요.");
        return false;
    }
    
    $.ajax({
        "type" : "post",
        "async" : false,
        "url" : url,
        "data" : param,
        "traditional":true,
        "dataType" : "json",
        "timeout" : 6000000000,
        "success" : function(rtnData) {
         
            // 콜백 함수 호출
            callbackFn(rtnData);
        },
        "error" : function(xmlHttpRequest, textStatus, errorThrown) {

            alert("error : " + xmlHttpRequest.responseText);

            if (xmlHttpRequest.readyState == 0 || xmlHttpRequest.status == 0) {
                return;
            }
        }
    });
}

/**
 * 프로그레스바 제어
 * 
 * @param mode - 프로그레스바 ON/OFF
 * @param callbackFn - 콜백함수
 */
function fnSetProgress(mode, callbackFn) {
    var win = $(window);
    var winH = win.scrollTop() + ((win.height() - $("#_progressContents").height()) / 2);
    var winW = win.scrollLeft() + ((win.width() - $("#_progressContents").width()) / 2);
    
    $("#_progressContents").css("top",winH);
    $("#_progressContents").css("left",winW);
    
    if ( mode == "ON" ) {
        $("#_progressWrap").fadeIn(300,function(){
            
            $("#_progressContents").fadeIn(300,function(){
                if ( typeof(callbackFn) == "function" ) {
                    callbackFn();                        
                }
            });
        });
    } else {
        $("#_progressWrap").fadeOut(300,function(){
            
            $("#_progressContents").fadeOut(300,function(){
                if ( typeof(callbackFn) == "function" ) {
                    callbackFn();
                }
            });
        });
    }
}

/**
 * 툴바 체크박스 상태에 따른 처리
 * 
 * @param layerName - 레이어명
 * @param obj - 체크박스 엘리먼트
 */
function fnSaveToolbarConfig(layerName, obj) {
    
    // 툴바 체크박스 체크 상태에 따른 설정값 저장
    if ( $(obj).is(":checked") == true ) {
        fnSetCookie("configToolbar_"+layerName,"Y",365);
    } else {
        fnSetCookie("configToolbar_"+layerName,"N",365);
    }
    
    // 체크박스 상태에 따른 지도 표출 설정
    _m.setLayerVisible(layerName, obj);
    
    // 지도 확대 레벨에 따른 노드/링크속도/RSE경로 레이어 피처 크기 조정
    fnRescale();
}

/**
 * 툴바 체크박스를 쿠키에 설정된 상태로 설정
 */
function fnSetToolbarCheckBox() {
    
    // 첫 로딩시, 기본지도가 자동 표출되므로, 지도보기 체크박스 상태를 저장
    if ( fnGetCookie("configToolbar_vworld.Base") == "" ) {
        if ( _m.map.getLayer("vworld.Base").getVisible() == true ) {
            fnSetCookie("configToolbar_vworld.Base","Y",365);
        }
    }
    
    // 지도보기 체크박스 설정
    if ( fnGetCookie("configToolbar_vworld.Base") == "Y" ) {
        $("#_chkVworldBase").trigger("click");
    }
    
    // 노드보기 체크박스 설정
    if ( fnGetCookie("configToolbar_Node") == "Y" ) {
        $("#_chkNode").trigger("click");
    }
    
    // 링크보기 체크박스 설정
    if ( fnGetCookie("configToolbar_Link") == "Y" ) {
        $("#_chkLink").trigger("click");
    }
    //진출입
    if ( fnGetCookie("configToolbar_Inout") == "Y" ) {
        $("#_chkInout").trigger("click");
    }
    // 행정경계
    if ( fnGetCookie("configToolbar_District") == "Y" ) {
        $("#_chkDistrict").trigger("click");
    }
    
    // 항공사진 체크박스 설정
    if ( fnGetCookie("configToolbar_vworld.Satellite") == "Y" ) {
        $("#_chkVworldSatellite").trigger("click");
    }
}

/**
 * 보기설정 레이어 체크박스 설정
 */
function fnSetConfigLayer() {
    
    // 쿠키의 노드 설정 값에 따른 체크박스 설정
    $("input[type=checkbox][name=chkConfigNode]").each(function(){
       if ( fnGetCookie("configNode"+$(this).val()) == "Y" ) {
           $(this).prop("checked",true);
       } else {
           $(this).prop("checked",false);
       } 
    });
    
    // 쿠키의 링크 설정 값에 따른 체크박스 설정
    $("input[type=checkbox][name=chkConfigLink]").each(function(){
        if ( fnGetCookie("configLink"+$(this).val()) == "Y" ) {
            $(this).prop("checked",true);
        } else {
            $(this).prop("checked",false);
        }
    });
    // 쿠키의 진출입 설정 값에 따른 체크박스 설정
    $("input[type=checkbox][name=chkConfigInout]").each(function(){
        if ( fnGetCookie("configInout"+$(this).val()) == "Y" ) {
            $(this).prop("checked",true);
        } else {
            $(this).prop("checked",false);
        }
    });
    
    // 쿠키의 라벨 설정 값에 따른 체크박스 설정
    $("input[type=checkbox][name=chkConfigLabel]").each(function(){
        if ( fnGetCookie("configLabel"+$(this).val()) == "Y" ) {
            $(this).prop("checked",true);
        } else {
            $(this).prop("checked",false);
        }
    });
}

/**
 * 보기설정 값 적용
 */
function fnSetConfig(layerType) {
    var nodeCnt = 0;
    var linkCnt = 0;
    var inoutCnt = 0;
    //[HIST]
    var labelCnt = 0;
    
	if ( layerType == "N" ) {
		
		// 기존의 설정값 삭제
		$("input[type=checkbox][name=chkConfigNode]").each(function(){
			fnDeleteCookie("configNode"+$(this).val());
		});
		
		// 체크한 노드 값 쿠키에 저장
		$("input[type=checkbox][name=chkConfigNode]").each(function(){
			if ( $(this).is(":checked") == true ) {
				nodeCnt++;
				fnSetCookie("configNode"+$(this).val(),"Y",365);
			}
		});
		
		if ( nodeCnt > 0 && $("#_chkNode").is(":checked") != true ) {
			$("#_chkNode").trigger("click");
		} else if ( nodeCnt == 0 && $("#_chkNode").is(":checked") == true ) {
			$("#_chkNode").trigger("click");
		}
		
		// 기본 노드 레이어 새로 작성
		_m.geoJsonMap.updateBaseLayer("N");
	}
	
	if ( layerType == "L" ) {
		
		// 기존의 설정값 삭제
		$("input[type=checkbox][name=chkConfigLink]").each(function(){
			fnDeleteCookie("configLink"+$(this).val());
		});
		
		// 체크한 링크 값 쿠키에 저장
		$("input[type=checkbox][name=chkConfigLink]").each(function(){
			if ( $(this).is(":checked") == true ) {
				linkCnt++;
				fnSetCookie("configLink"+$(this).val(),"Y",365);
			}
		});
		
		if ( linkCnt > 0 && $("#_chkLink").is(":checked") != true ) {
			$("#_chkLink").trigger("click");
		} else if ( linkCnt == 0 && $("#_chkLink").is(":checked") == true ) {
			$("#_chkLink").trigger("click");
		}
		
		// 기본 링크 레이어 새로 작성
		_m.geoJsonMap.updateBaseLayer("L");
	}
	
	if ( layerType == "Inout" ) {
			// 기존의 설정값 삭제
			$("input[type=checkbox][name=chkConfigInout]").each(function(){
				fnDeleteCookie("configInout"+$(this).val());
			});
			
			// 체크한 링크 값 쿠키에 저장
			$("input[type=checkbox][name=chkConfigInout]").each(function(){
				if ( $(this).is(":checked") == true ) {
					inoutCnt++;
					fnSetCookie("configInout"+$(this).val(),"Y",365);
				}
			});
			
			if ( inoutCnt > 0 && $("#_chkInout").is(":checked") != true ) {
				$("#_chkInout").trigger("click");
			} else if ( inoutCnt == 0 && $("#_chkInout").is(":checked") == true ) {
				$("#_chkInout").trigger("click");
			}
			
			// 기본 링크 레이어 새로 작성
			_m.geoJsonMap.updateBaseLayer("Inout");
		}

	if ( layerType == "Label" ) {
		
		// 기존의 설정값 삭제
		$("input[type=checkbox][name=chkConfigLabel]").each(function(){
			fnDeleteCookie("configLabel"+$(this).val());
		});
		
		// 체크한 노드 값 쿠키에 저장
		$("input[type=checkbox][name=chkConfigLabel]").each(function(){
			if ( $(this).is(":checked") == true ) {
				labelCnt++;
				fnSetCookie("configLabel"+$(this).val(),"Y",365);
			}
		});
		
		if ( labelCnt > 0 && $("#_chkLabel").is(":checked") != true ) {
			$("#_chkLabel").trigger("click");
		} else if ( labelCnt == 0 && $("#_chkLabel").is(":checked") == true ) {
			$("#_chkLabel").trigger("click");
		}
		
		// 기본 노드 레이어 새로 작성
		_m.geoJsonMap.updateBaseLayer("Label");
	}

	fnRescale();
    
}

/**
 * 지도 확대/축소
 * 
 * @param flag - (in:확대,out:축소)
 */
function fnGisZoom(flag) {
    var gZoom = _m.map.getView().getZoom(); // 현재 zoom level

    if (flag == "in") {
        gZoom = gZoom + 1;
    } else if (flag == "out") {
        gZoom = gZoom - 1;
    }
    if (gZoom > 0 && gZoom <= 13) {
        _m.map.getView().setZoom(gZoom);
    } else {
        if (gZoom == 0) {
            alert("최소 축소레벨입니다.");
        } else {
            alert("최대 확대레벨입니다.");
        }
    }
}


/**
 * 툴바 레이어 버튼
 * 
 * @param obj - 툴바 object
 * @param id - 툴바와 연결된 레이어 ID
 * @param slideYn - 슬라이드 효과 여부
 */
function fnOpenLayerPopup(obj, id, slideYn, param, check) {
    if ($(obj).hasClass("active") == true) {

        // 툴바 버튼 hover 효과 해제
        $(obj).removeClass("active");
        // 레이어 팝업 숨김
        if ( arguments.length > 2 && slideYn == false ) {
            $("#"+id).fadeOut();            
        } else {
            $("#"+id).slideUp();
        }
    } else {

        // 툴바 버튼 hover 효과 설정
        $(obj).addClass("active");

        // 검색 레이어 팝업 표시
        if ( arguments.length > 2 && slideYn == false ) {
            $("#"+id).fadeIn();
        } else {
            $("#"+id).slideDown();
        }
    }
    //네트워크 현황 보기 
    if(check == "network"){
    	param = { "datekey" : param };
    	
    	fnCallAjax("/map/networkHistoryDetail.do", param, function(dataList){
    		var htmlStr = null;
        	for(var h=0 ; h<dataList.length;h++){
        		htmlStr += "<tr>";
        		htmlStr += "<td class='center' >"+ Number(h+1) + "</td>";
        		htmlStr += "<td class='center' >"+dataList[h].networkDetailVersion + "</td>";
        		htmlStr += "<td class='center' >"+dataList[h].networkDetailRSEID + "</td>";
        		htmlStr += "<td class='center' >"+dataList[h].networkDetailStatus + "</td>";
        		htmlStr += "<td class='center' >"+dataList[h].networkDetailFinal + "</td>";
        		htmlStr += "<td class='center' >"+dataList[h].networkDetailData + "</td>";
        		htmlStr += "<td class='center' > </td>";
        		
        		htmlStr += "</tr>";
        	}
        	$("#networkHistoryDetail tbody").html(htmlStr);
    	})
    }
    
}

/**
 * 레이어 팝업 닫기 버튼
 * 
 * @param id - 닫을 레이어 ID
 * @param slideYn - 슬라이드 효과 여부
 */
function fnCloseLayerPopup(id, slideYn) {
    var toolbarId = "";
   
    if ( id == "_searchLayer" ) {
        toolbarId = "_btnSearchLayer";
    } else if ( id == "_configLayer" ) {
        toolbarId = "_btnConfigLayer";
    } else if( id == "_networkInfoLayer"){
        toolbarId = "_networkInfoLayer"
      	// 툴바 버튼 hover 효과 해제
        $("#_btnNetworkInfoLayer").removeClass("active");
    }  else if( id== "_networkInfoLayerDetail"){
    	toolbarId = "_networkInfoLayerDetail";
    	$("#networkDetailCheck").removeClass("active");
    }
    
    // 툴바 버튼 활성화/비활성화 효과 처리
    if ( toolbarId != "" ) {
        $("#"+toolbarId).removeClass("active");        
    }

    // 레이어 팝업 닫기
    if ( arguments.length > 1 && slideYn == false ) {
        $("#"+id).fadeOut();
    } else {
        $("#"+id).slideUp();        
    }
}

/**
 * 줌 레벨에 따른 피처 스케일 변경
 */
function fnRescale() {
    var newZoomLevel = _m.map.getView().getZoom();
    
    if ( newZoomLevel != _m.map.zoomLevel ) {
        var layerList = _m.map.getLayers().getArray();
        var targetLayerList = [
        		"Node","Link","LinkSpeedLayer","RseRouteLayer","RseStatusLayer","TcsTrafficLayer","LinkTrafficLayer",
        		"RouteTrafficLayer","InNodeOdTrafficLayer","OutNodeOdTrafficLayer","OutLinkOdTrafficLayer"
        	];
        
        _m.zoomLevel = newZoomLevel;
        
        // 줌 레벨에 따른 피처 스케일 설정
        if ( newZoomLevel < 2 ) {
            _m.scale = 0;
            _m.fontScale = 0;
            _m.width = 5;
        } else if ( newZoomLevel >= 2 && newZoomLevel <= 3 ) {
            _m.scale = 1;
            _m.fontScale = 0;
            _m.width = 3;
        } else if ( newZoomLevel >= 4 && newZoomLevel <= 5 ) {
            _m.scale = 1.5;
            _m.fontScale = 0;
            _m.width = 1;
        } else if ( newZoomLevel >= 6 && newZoomLevel <= 7 ) {
            _m.scale = 1.5;
            _m.fontScale = 1.5;
            _m.width = 3;
        } else if ( newZoomLevel >= 8 && newZoomLevel <= 11 ) {
            _m.scale = 2;
            _m.fontScale = 1.5;
            _m.width = 5;
        } else if ( newZoomLevel >= 12 ) {
            _m.scale = 2;
            _m.fontScale = 1.5;
            _m.width = 5;
        }  
        
        // 줌 레벨에 따라 기본지도, 항공사진 이외의 레이어는 숨김/표출 처리
        for ( var k=0, kMax=layerList.length; k<kMax; k++ ) {
            var layer = layerList[k];
            var layerName = layer.get("name");
            
            // 행정경계 레이어 숨김/표출 처리
            if ( layerName == "District" ) {
                if ( newZoomLevel < 2 ) {
                    layer.setVisible(false);
                } else {
                    if ( $("#_chkDistrict").is(":checked") == true ) {
                        layer.setVisible(true);    
                    }
                }
            } else {
                
                // 행정경계 이외의 레이어 숨김/표출 처리
                if ( layer instanceof ol.layer.Vector ) {
                    if ( newZoomLevel < 2 ) {
                        layer.setVisible(false);
                    } else {
                        layer.setVisible(true);
                    }
                }
            }
        }
        
        // 레이어 스타일 조정
        for ( var i=0, iMax=targetLayerList.length; i<iMax; i++ ) {
            var layer = _m.map.getLayer(targetLayerList[i]);
            
            if ( layer != null ) {
                
                var source = layer.getSource();
                
                if ( source != null ) {
                    var featureList = source.getFeatures();

                    for ( var x=0, xMax=featureList.length; x<xMax; x++ ) {
                            
                        try {
                            
                            var feature = featureList[x];
                            
                            // 노드 스타일 적용(축척에 따른 노드 스케일 조절)
                            if ( feature.getStyle().getText() != null ) {
                                if ( targetLayerList[i] == "Node" ) {
                                    
                                    // IC/JC일 경우 명칭 표시
                                    if ( newZoomLevel >= 10 ) {
                                        if ( feature.values_["node_type"] == 2 ) {
                                            feature.getStyle().getText().setText("▲\n"+feature.values_["name"]);                                        
                                        } else if ( feature.values_["node_type"] == 3 ) {
                                            feature.getStyle().getText().setText("▼\n"+feature.values_["name"]);
                                        }
                                    } else {
                                        if ( feature.values_["node_type"] == 2 ) {
                                            feature.getStyle().getText().setText("▲");                                        
                                        } else if ( feature.values_["node_type"] == 3 ) {
                                            feature.getStyle().getText().setText("▼");
                                        }
                                    }
                                    
                                    feature.getStyle().getText().setScale(_m.scale);
                                } else {
                                    feature.getStyle().getText().setScale(_m.fontScale);
                                }
                            }
                            
                            // 링크 스타일 적용(축척에 따른 선 굵기 조절)
                            if ( feature.getStyle().getStroke() != null ) {
                                
                                if ( targetLayerList[i] == "RouteTrafficLayer" ) { // 경로형 교통량
                                	// 경로형 교통량 선 선굵기 선택으로 인해 사용안함 (2018.07.02 수정 - 이동걸)
                                    //feature.getStyle().getStroke().setWidth(_m.width);
                                }
                            }
                            
                        } catch (e) {
                            continue;
                        }
                    }
                    
                    source.changed();
                }
            }
        }
    }
}

/**
 * 노드/링크 속성보기
 */
function fnOpenFeatureProperty(evt) {
    var callback = function(feature, layer) {return feature;};
    var layerFilter = function(layer) {return this === layer;};
    var feature;
    var nodeLayerList = ["Node","NodeLayer","TcsLayer","RseLayer","RseStatusLayer","TcsTrafficLayer", "InNodeOdTrafficLayer", "OutNodeOdTrafficLayer" ];
    var nodeIdList    = ["route_id",  "road_dist",  "sigungu_id",  "node_id",    "node_type", "name",       "toll_id",     "in_out",       "rse_id",   "rse_sub",        "rse_sub2",       "road_rank",   "private_f",   "x",       "y",      "remark"];
    var nodeTextList  = ["노선명",    "이정(km)",   "시군구 정보", "지점ID",     "지점유형",  "지점명",     "톨게이트 ID", "진출입정보",   "RSE ID",   "RSE 부가정보1",  "RSE 부가정보2",  "도로등급",    "민자여부",    "X좌표",   "Y좌표",  "비고"];
    var nodeCodeList  = ["105",       "",           "ZONE",        "",           "111",       "",           "",            "112",           "",        "113",            "114",            "106",         "999",         "",        "",       ""];
    var linkLayerList = ["Link","LinkLayer","RouteLayer","RseRouteLayer","RouteTrafficLayer","LinkTrafficLayer","LinkSpeedLayer", "OutLinkOdTrafficLayer"];
    var linkIdList    = ["f_route_id", "t_route_id",  "sigungu_id",   "link_id",   "link_type",  "f_node_id",     "t_node_id",     "length",        "s_area",        "shelter",       "icjc_name",     "rse_in",       "road_rank", "private_f", "remark"];
    var linkTextList  = ["진입노선명", "진출노선명",  "시군구 정보",  "구간ID",    "구간유형",   "시작지점 ID",   "종료지점 ID",   "구간길이(m)",   "휴게소여부",    "졸음쉼터여부",  "IC/JC명칭",     "RSE 부가정보", "도로등급",  "민자여부",  "비고"];
    var linkCodeList  = ["105",        "105",         "ZONE",         "",          "101",        "",              "",              "",              "102",           "103",           "",              "104",          "106",       "999",       ""];
    var htmlStr = "";
    
    // 노드 피처 조회
    for ( var i=0, iMax=nodeLayerList.length; i<iMax; i++ ) {
       if ( typeof(feature) != "object" ) {
           feature = _m.map.forEachFeatureAtPixel(evt.pixel, callback, {
               "layerFilter" : layerFilter,
               "opt_this" : undefined,
               "opt_this2" : _m.map.getLayer(nodeLayerList[i])
           });
       } else {
           break;
       }
    }
    
    if ( feature ) {
        
        for ( var i=0, iMax=nodeIdList.length; i<iMax; i++ ) {
            var featureValue = featureValue = feature.values_[nodeIdList[i]];
            
            if ( nodeCodeList[i] != "" ) {
                
                if ( nodeCodeList[i] == "ZONE" ) {
                    
                    // 시군구코드에 해당하는 명칭을 가져옴
                    featureValue = fnGetZoneName(featureValue);
                } else {
                    
                    // 공통코드에 해당하는 명칭을 가져옴
                    featureValue = fnGetPropertyName(nodeCodeList[i],featureValue);
                }
            }
            
            htmlStr += "<tr>";
            htmlStr += "<th>"+nodeTextList[i]+"</th>";
            htmlStr += "<td class='view'>"+(featureValue != null && featureValue != "null" ? featureValue : "")+"</td>";
            htmlStr += "</tr>";                
        }
        $("#_propertyLayerTitle").text("지점속성");
    } else {
        
        // 링크 피처 조회
        for ( var x=0, xMax=linkLayerList.length; x<xMax; x++ ) {
           if ( typeof(feature) != "object" ) {
               feature = _m.map.forEachFeatureAtPixel(evt.pixel, callback, {
                   "layerFilter" : layerFilter,
                   "opt_this" : undefined,
                   "opt_this2" : _m.map.getLayer(linkLayerList[x])
               });
           } else {
               break;
           }
        }
        
        if ( feature ) {
            for ( var y=0, yMax=linkIdList.length; y<yMax; y++ ) {
                var featureValue = feature.values_[linkIdList[y]];
                
                if ( linkCodeList[y] != "" ) {
                    
                    if ( linkCodeList[y] == "ZONE" ) {
                        
                        // 노드/링크 시군구코드에 해당하는 명칭을 가져옴
                        featureValue = fnGetZoneName(featureValue);
                    } else {
                        
                        // 노드/링크 속성코드에 해당하는 명칭을 가져옴
                        featureValue = fnGetPropertyName(linkCodeList[y],featureValue);
                        
                    }
                }
                
                htmlStr += "<tr>";
                htmlStr += "<th>"+linkTextList[y]+"</th>";
                htmlStr += "<td class='view'>"+(featureValue != null && featureValue != "null" ? featureValue : "")+"</td>";
                htmlStr += "</tr>";                
            }
            $("#_propertyLayerTitle").text("구간속성");
        }
    }
    
    if ( htmlStr != "" ) {
        $("#_propertyLayerBody").html(htmlStr);
        $("#_propertyLayer").show();
    }
}



/**
 * 공통코드 조회
 */
function fnGetPropertyCode() {
    
    fnCallAjax("/test/map/getComCodeList.do",null, function(dataList){
        var codeList = [];        // 공통코드 리스트
        var groupCodeList = {};   // 그룹코드 리스트
        var curGroupCodeId = "";  // 현재 그룹코드 ID
        var nextGroupCodeId = ""; // 다음 그룹코드 ID
        
        for ( var i=0, iMax=dataList.length; i<iMax; i++ ) {
            curGroupCodeId = dataList[i].groupCodeId;
            
            if ( (i+1) < dataList.length ) {
                nextGroupCodeId = dataList[i+1].groupCodeId;                
            } else {
                nextGroupCodeId = "END";
            }
            
            var codeId = dataList[i].codeId;
            var codeName = dataList[i].codeName;
            var codeData = {};
            
            codeData["id"] = codeId;
            codeData["name"] = codeName;
            
            // 현재 그룹코드의 공통코드를 저장
            codeList.push(codeData);
            
            // 그룹코드 단위로 공통코드를 저장
            if ( curGroupCodeId != nextGroupCodeId || nextGroupCodeId == "END" ) {
                groupCodeList[curGroupCodeId] = codeList;
                
                // 새로운 그룹코드ID로 변경므로 공통코드 배열 초기화
                codeList = [];
            }
        }
        
        // 전역변수에 저장
        _propertyCodeList = groupCodeList;
    });
}

/**
 * 노드/링크 속성코드에 해당하는 값 반환 - name 값 반환
 */
function fnGetPropertyName(groupCodeId, codeId){
	
    var comCodeList = _propertyCodeList[groupCodeId];
    var codeName = "";
    
    for ( var i=0, iMax=comCodeList.length; i<iMax; i++ ) {
        if ( comCodeList[i].id == codeId) {
            codeName = comCodeList[i].name;
            break;
        }
    }
    
    return codeName;
}
/**
 * 노드/링크 속성코드에 해당하는 값 반환 - id 값 반환
 */
function fnGetPropertyId(groupCodeId, codeId){
	
    var comCodeList = _propertyCodeList[groupCodeId];
    var outputCodeId = "";
    
    for ( var i=0, iMax=comCodeList.length; i<iMax; i++ ) {
        if ( comCodeList[i].id == codeId) {
        	outputCodeId = comCodeList[i].id;
            break;
        }
    }
    
    return outputCodeId;
}
/**
 * 노드/링크 시군구코드 조회
 */
function fnGetZoneCode() {
    
    fnCallAjax("/test/map/getZoneCodeList.do",null, function(dataList){
        var zoneCodeList = [];    // 시군구코드 리스트
        
        for ( var i=0, iMax=dataList.length; i<iMax; i++ ) {
            
            var codeId = dataList[i].zoneId;
            var codeName = dataList[i].zoneName;
            var codeData = {};
            
            codeData["id"] = codeId;
            codeData["name"] = codeName;
            
            // 현재 그룹코드의 공통코드를 저장
            zoneCodeList.push(codeData);
        }
        
        _zoneCodeList = zoneCodeList;
    });
}

/**
 * 노드/링크 시군구코드에 해당하는 값 반환
 */
function fnGetZoneName(zoneId){
    var zoneName = "";

    for ( var i=0, iMax=_zoneCodeList.length; i<iMax; i++ ) {
        
        if ( _zoneCodeList[i].id == zoneId) {
            zoneName = _zoneCodeList[i].name;
            break;
        }
    }
    
    return zoneName;
}

/**
 * 쿠키 설정
 * 
 * @param name - 쿠키 이름
 * @param value - 쿠키에 저장할 값
 * @param expiredays - 만료일자
 */
function fnSetCookie(name, value, expiredays) {
    var todayDate = new Date();

    todayDate.setDate(todayDate.getDate() + expiredays);
    document.cookie = name + "=" + escape(value) + "; expires=" + todayDate.toGMTString() + ";";
}

/**
 * 쿠키 값 반환
 * 
 * @param name - 쿠키 이름
 * @returns 쿠키값
 */
function fnGetCookie(name) {
    var cookieValue = "";
    
    if ( document.cookie ) {
        var array = document.cookie.split((escape(name)+"="));
        
        if ( array.length >= 2 ) {
            var arraySub = array[1].split(";");
            cookieValue = unescape(arraySub[0]);
        }
    }
    return cookieValue;
}

/**
 * 쿠키 값 삭제
 * 
 * @param name - 쿠키 이름
 * @param domain - 
 */
function fnDeleteCookie(name) {
    var todayDate = new Date();
    todayDate.setDate(todayDate.getDate()-1);
    
    document.cookie = name + "=; expires="+todayDate.toGMTString()+";";
}

/**
 * 날짜에서 특정 일수를 계산한 날짜 반환
 *  
 * @param targetDate - 기준일자
 * @param addMinDays - 계산 일수
 * @returns {String}
 */
function fnGetCalDateStr(targetDate, calDays) {   
    var date;
    var dateStr = "";

    // 지정한 날짜가 없을 경우, 오늘 날짜로 설정
    if ( arguments.length == 0 ) {
        date = new Date();
    } else {
        date = targetDate;
        
        if ( arguments.length > 1 ) {
            date.setDate(date.getDate() + calDays);        
        }
    }
    
    dateStr += "" + date.getFullYear();
    dateStr += "-" + ((date.getMonth()+ 1)<=9 ? ('0'+ (date.getMonth()+1)): (date.getMonth()+1));
    dateStr += "-" + ((date.getDate() <= 9) ? ('0' + (date.getDate())): (date.getDate()));
    
    return dateStr;
};

/**
 * 특정 날짜를 "날짜(요일)" 형식으로 반환
 * 
 * @param dateStr - 날짜 문자열
 * @param type - 구분자(INIT:초기화, PREV:이전날짜, NEXT:이후날짜)
 * @returns 변환된 날짜 문자열
 */
function fnGetDateStr(dateStr, type) {
    var week = ["일","월","화","수","목","금","토"];
    var calDateStr;
    var calDateWeek;
    var resultStr = "";
    var addCnt = 0;
        
    if ( type == "INIT" ) {
        addCnt = 0; 
    } else if ( type == "PREV") {
        addCnt = -1;
    } else if ( type == "NEXT") {
        addCnt = 1;
    }
    
    // 날짜 계산
    calDateStr = fnGetCalDateStr(new Date(dateStr), addCnt);
    
    // 계산된 날짜의 요일 계산
    calDateWeek = new Date(calDateStr).getDay(); 
    
    resultStr = calDateStr + "("+week[calDateWeek]+")";
    
    return resultStr;
}

/**
 * 날짜 콤보박스 설정
 * 
 * @param type - 구분자(INIT:초기화, PREV:이전 날짜, NEXT:이후 날짜)
 * @param id - 대상 객체ID
 * @returns {Boolean}
 */
function fnSetSchDateCombo(type, id) {
    var schDateStr = $("#"+id).val();
    
    if ( schDateStr != "" && schDateStr.length > 8 ) {
        schDateStr = schDateStr.replace(/-/gi,"").substring(0,8);
        schDateStr = schDateStr.substring(0,4)+"-"+schDateStr.substring(4,6)+"-"+schDateStr.substring(6,8); 
    }
    
    if ( type == "INIT" ) { // 날짜 초기화
        
        // 검색일자가 없을 경우 하루 전날로 설정
        if ( schDateStr == "" ) {
            schDateStr = fnGetCalDateStr(new Date(),-1);
        }
        
        $("#"+id).datepicker({
            hourGrid: 4,
            minuteGrid: 10,
            dateFormat: "yy-mm-dd",
            showOn: "button",
            showButtonPanel: false,
            defaultDate: "-1d",
            changeMonth: true,
            changeYear: true,
            yearRange: "c-10:c",
            showMonthAfterYear: true,
            buttonImage: '/asset/map/images/exdv/calendar.png',
            buttonImageOnly: true,
            monthNames: ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"],
            monthNamesShort: ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"],
            onClose : function() {
                
                if ( $("#"+id).val().indexOf("(") == -1 ) {
                    setTimeout(function(){
                        $("#"+id).val(fnGetDateStr($("#"+id).val(),"FMT"));
                    },100);
                } 
            }
            
        }).mask("9999-99-99");
    }
    
    // 날짜(요일) 형식으로 변환
    $("#"+id).val(fnGetDateStr(schDateStr,type));
}

/**
 * Data가 존재하는 날짜 설정
 * 
 * @param type - 구분자(INIT:초기화, PREV:이전 날짜, NEXT:이후 날짜)
 * @param id - 대상 객체ID
 * @returns {Boolean}
 */
var enableDays;
function fnSetSchDate(type, id) {
    var schDateStr = $("#"+id).val();
    var minDate;
    var maxDate;
    var yearRange;//달력(콤보)에 최소 년도 최대 년도 Set
    
    /*
	$.ajax({
		type:"post",
		async: false,
		url:"/map/getDays.do",
		success:function(json){
			enableDays = json.daysList;
			var firstDay = enableDays[0];
			var lastDay = enableDays[enableDays.length-1];
			
			minDate = new Date(firstDay.substring(0,4), firstDay.substring(4,6)-1, firstDay.substring(6,8));//최소날짜 Set
			maxDate = new Date(lastDay.substring(0,4), lastDay.substring(4,6)-1, lastDay.substring(6,8));//최대날짜 Set
		}
	});
     */
    if ( schDateStr != "" && schDateStr.length > 8 ) {
        schDateStr = schDateStr.replace(/-/gi,"").substring(0,8);
        schDateStr = schDateStr.substring(0,4)+"-"+schDateStr.substring(4,6)+"-"+schDateStr.substring(6,8);
    }
    
    if ( type == "INIT" ) { // 날짜 초기화
        
        // 검색일자가 없을 경우 maxDay로 설정
        if ( schDateStr == "" ) {        	
        	//var year = String(maxDate.getFullYear());//년
        	//var month = String((maxDate.getMonth() + 1));//월
        	//var day = String(maxDate.getDate());//일        	

            var dt = new Date();
        	var year = String(dt.getFullYear());//년
            var month = String(dt.getMonth()+1);//월
            var day = String(dt.getDate());//일 
            
            if(month.length==1){month='0'+month;}
            if(day.length==1){day='0'+day;}
            
            schDateStr = year+'-'+month+'-'+day; 
        }
        
        $("#"+id).datepicker({
            hourGrid: 4,
            minuteGrid: 10,
            dateFormat: "yy-mm-dd",
            showOn: "button",
            showButtonPanel: false,
            defaultDate: "-1d",
            changeMonth: true,
            changeYear: true,
            showMonthAfterYear: true,
            buttonImage: '/asset/map/images/exdv/calendar.png',
            buttonImageOnly: true,
            monthNames: ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"],
            monthNamesShort: ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"],
	        //maxDate: maxDate,
            //minDate: minDate,
            //beforeShowDay: selectableDays,
            onClose : function() {
                if ( $("#"+id).val().indexOf("(") == -1 ) {
                    setTimeout(function(){
                        $("#"+id).val(fnGetDateStr($("#"+id).val(),"FMT"));
                    },100);
                } 
            }
        }).mask("9999-99-99");
    }
    // 날짜(요일) 형식으로 변환
    $("#"+id).val(fnGetDateStr(schDateStr,type));
}

function fnSetSchDateMinus2Day(type, id) {
    var schDateStr = $("#"+id).val();
    var minDate;
    var maxDate = new Date();//최대날짜 Set
	maxDate.setDate(maxDate.getDate() -2);
    var yearRange;//달력(콤보)에 최소 년도 최대 년도 Set
    
    /*
	$.ajax({
		type:"post",
		async: false,
		url:"/map/getDays.do",
		success:function(json){
			enableDays = json.daysList;
			var firstDay = enableDays[0];
			var lastDay = enableDays[enableDays.length-1];
			
			minDate = new Date(firstDay.substring(0,4), firstDay.substring(4,6)-1, firstDay.substring(6,8));//최소날짜 Set
			maxDate = new Date(lastDay.substring(0,4), lastDay.substring(4,6)-1, lastDay.substring(6,8));//최대날짜 Set
		}
	});
     */
    if ( schDateStr != "" && schDateStr.length > 8 ) {
        schDateStr = schDateStr.replace(/-/gi,"").substring(0,8);
        schDateStr = schDateStr.substring(0,4)+"-"+schDateStr.substring(4,6)+"-"+schDateStr.substring(6,8);
    }
    
    if ( type == "INIT" ) { // 날짜 초기화
        
        // 검색일자가 없을 경우 maxDay로 설정
        if ( schDateStr == "" ) {        	
        	//var year = String(maxDate.getFullYear());//년
        	//var month = String((maxDate.getMonth() + 1));//월
        	//var day = String(maxDate.getDate());//일        	
			
			console.log(maxDate);
            var dt = maxDate;
        	var year = String(dt.getFullYear());//년
            var month = String(dt.getMonth()+1);//월
            var day = String(dt.getDate());//일 
            
            if(month.length==1){month='0'+month;}
            if(day.length==1){day='0'+day;}
            
            schDateStr = year+'-'+month+'-'+day; 
        }
        
        $("#"+id).datepicker({
            hourGrid: 4,
            minuteGrid: 10,
            dateFormat: "yy-mm-dd",
            showOn: "button",
            showButtonPanel: false,
            defaultDate: "-3d",
            changeMonth: true,
            changeYear: true,
            showMonthAfterYear: true,
            buttonImage: '/asset/map/images/exdv/calendar.png',
            buttonImageOnly: true,
            monthNames: ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"],
            monthNamesShort: ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"],
	        maxDate: maxDate,
            //minDate: minDate,
            //beforeShowDay: selectableDays,
            onClose : function() {
                if ( $("#"+id).val().indexOf("(") == -1 ) {
                    setTimeout(function(){
                        $("#"+id).val(fnGetDateStr($("#"+id).val(),"FMT"));
                    },100);
                } 
            }
        }).mask("9999-99-99");
    }
    // 날짜(요일) 형식으로 변환
    $("#"+id).val(fnGetDateStr(schDateStr,type));
}

function selectableDays(date) {
	//년
	var year = String(date.getFullYear());
	//월
    var month = String((date.getMonth() + 1));
    if(month.length==1){month='0'+month;}    
    //일
    var day = String(date.getDate());
    if(day.length==1){day='0'+day;}
    
    var dummy = year+month+day;
    
    if ($.inArray(dummy, enableDays) > -1) {
        return [true, ""]; 
    } 
    return [false, ""]; 
}

/**
 * 달력의 날짜를 숫자만 반환
 * 
 * @param str - 대상 날짜 문자열
 */
function fnGetNumDateStr(str) {
    var dateStr = str;
    
    if ( dateStr.replace(/-/gi,"").length >= 8 ) {
        dateStr = dateStr.replace(/-/gi,"").substring(0,8);
    }
    
    return dateStr;
}

/**
 * 달력 레이어 오픈
 * 
 * @param id - 달력 엘리먼트 ID
 */
function fnOpenDateLayer(id) {
    $("#"+id).datepicker("show");
}

/**
 * 시간 선택 콤보박스 옵션 생성
 * 
 * @param id - 대상 객체ID
 * @param startObj - 시작 객체
 */
function fnSetSchTimeCombo(id,fromObjId) {
    var htmlStr = "";
    var minTime = 0;  // 시작 시간
    var maxTime = 24; // 종료 시간
    
    // 특정 시간 이후로 생성할 경우 시작 시간 설정
    if ( arguments.length > 1 ) {
        minTime = parseInt($("#"+fromObjId).val())+1;
    }
    
    // 옵션 추가
    for ( var i=minTime; i<=24; i++ ) {
        htmlStr += "<option value='"+i+"'>"+i+"</option>";
    }
    
    $("#"+id).empty().append(htmlStr);
}

/**
 * 금액 문자열을 숫자만 반환
 * 
 * @param str - 대상 금액 문자열
 */
function fnGetNumStr(obj) {
    var str = "";
    
    if ( typeof(obj) == "object" && typeof(obj.value) != "undefined" ) {
        str = obj.value;
    } else if ( typeof(obj) == "string" ) {
        str = obj;
    }
    
    return str.replace(/,/gi,"");
}

/**
 * 입력된 문자열에서 콤마 제거
 * 
 * @param mode - 모드(ON:콤마 추가, OFF:콤마 제거)
 * @param obj - 대상 객체
 */
function fnCommaFilter(mode, obj) {
    if ( mode == "ON" ) {
        obj.value = fnSetComma(obj.value);
    } else if ( mode == "OFF" ) {
        obj.value = obj.value.replace(/,/gi,"");
    }
}

/**
 * 숫자 문자열에 콤마 표시
 * 
 * @param num - 숫자 문자열
 * @returns 콤마 표시된 문자열
 */
function fnSetComma(num){
    var num = String(num);
    var reg = /(\-?\d+)(\d{3})($|\.\d+)/;
    
    if ( reg.test(num) == true ) {
        return num.replace(reg,function(str,p1,p2,p3){
            return fnSetComma(p1)+","+p2+""+p3;
        });
    } else {
        return num;
    }
}

/**
 * 엔터 클릭 시 버튼 클릭 이벤트 발생
 * 
 * @param id - 대상 엘리먼트 ID
 */
function fnEnterSearch(id) {
    
    if (event.keyCode == 13) {
        $("#" + id).trigger("click");
    }
}

/**
 * 팝업 레이어 표출
 * 
 * @param id - 표출 위치 기준이 되는 엘리먼트 ID
 * @param layerId - 팝업 레이어 ID
 * @param callbackFn - 콜백 함수
 */ 
function fnOpenSubPopup(id, layerId, callbackFn, param) {
	_returnCallBackParam = param;
	
    var offset = $("#"+id).offset();
    var btnLeft = offset.left-1;
    var btnTop = offset.top+$("#"+id).height();

    if ( document.getElementById(layerId).style.display == "none" ) {
        $("#"+layerId).attr("style","left:"+btnLeft+"px; top:"+btnTop+"px;");
        $("#"+layerId).css("z-index",991);
        // 노선검색 레이어일 경우 화면 표출과 동시에 노선검색
        if ( layerId == "_searchRouteLayer" ) {
            $("#"+layerId).fadeIn(function(){
                if ( $("#_searchRouteDataList > tbody > tr.dataRow").length == 0) {
                    $("#_btnSearchRoute").trigger("click");
                }
            });
        } else if ( layerId == "_searchMultiRouteLayer" ) {
            $("#"+layerId).fadeIn(function(){
                if ( $("#_searchMultiRouteDataList > tbody > tr.dataRow").length == 0) {
                    $("#_btnSearchMultiRoute").trigger("click");
                }
            });
        } else {
            $("#"+layerId).fadeIn();
        }
    } else {
        $("#"+layerId).fadeOut();
    }
    
    // 콜백 함수가 있을 경우 설정
    if ( (arguments.length == 3 ||arguments.length == 4) && typeof(callbackFn) == "function" ) {
        _returnCallBack = callbackFn;
    }
}

/**
 * 노선 검색 팝업 : 리스트 조회
 * 
 * @param type - 노선검색 레이어 타입 : 단일(S), 복수(M)
 */
function fnSearchRouteData(type) {

    var resultAreaId = "";
    var schObjId = "";
    
    // 단일 검색/복수 검색에 따른 변수 설정
    if ( type == "S" ) {
        resultAreaId = "_searchRouteDataList";
        schObjId = "_schRouteText";
    } else {
        resultAreaId = "_searchMultiRouteDataList";
        schObjId = "_schMultiRouteText";
    }
    
    var param = {
        "schRouteId" : $("#"+schObjId).val(),
        "schRouteName" : $("#"+schObjId).val()
    };
    
    // 프로그레스바 표출
    fnSetProgress("ON", function(){
        fnCallAjax("/map/selectComRouteList.do", param, function(dataList) {
            var htmlStr = "";
    
            for (var i = 0; i < dataList.length; i++) {
                var data = dataList[i];
    
                if ( type == "S" ) {
                    // 단일 선택은, 클릭시 해당 값 반환
                    htmlStr += "<tr class='dataRow hand' onclick=\"fnSetRouteData('"+type+"','"+data.routeId+"','"+data.routeName+"')\">";
                    htmlStr += "<td class='center'>" + data.routeId + "</td>"; // routeId
                    htmlStr += "<td class='center'>" + data.routeName + "</td>"; // routeName                
                } else {
                    
                    // 복수 선택은, 클릭시 체크박스 설정
                    htmlStr += "<tr class='dataRow hand' onclick=\"fnClickRouteData('chkAddRoute_" + data.routeId + "')\">";
                    htmlStr += "<td class='center'><input type='checkbox' name='chkAddRoute' id='chkAddRoute_" + data.routeId + "' value='" + data.routeId + "' routeName='"+data.routeName+"'/></td>";
                    htmlStr += "<td class='center'>" + data.routeId + "</td>"; // routeId
                    htmlStr += "<td class='center'>" + data.routeName + "</td>"; // routeName
                }
                htmlStr += "</tr>";
            }
    
            // 조회결과 표출
            if (dataList.length == 0) {
                fnSetNoResult("LIST", resultAreaId, 3);
            } else {
                $("#"+resultAreaId+" > tbody").html(htmlStr);
                
                if ( type == "M" ) {
                    
                    // 복수 선택만 체크박스가 있으므로, TR에 걸려있는 이벤트 버블링 방지
                    fnPreventBubble("chkAddRoute");
                }
            }
    
            // 프로그레스바 숨김
            fnSetProgress("OFF");
        });
    });
}

/**
 * 체크박스 전체선택/해제
 * 
 * @param obj - 전체선택 체크박스 객체
 * @param name - 대상 체크박스 이름
 */
function fnCheckAll(obj,name) {
    
    // 전체선택 체크박스 체크 여부에 따라 전체선택/해제
    if ( $(obj).is(":checked") == true ) {
        
        $("input[type=checkbox][name="+name+"]").each(function(){
            $(this).prop("checked",true);
        });
    } else {
        $("input[type=checkbox][name="+name+"]").each(function(){
            $(this).prop("checked",false);
        });
    }
}

/**
 * 노선 검색 팝업 : 리스트 행 선택시 체크
 * 
 * @param id - 대상 객체ID
 */
function fnClickRouteData(id) {
    $("#"+id).trigger("click");
}

/**
 * 노선 검색 팝업 : 선택한 노선 데이터 반환
 * 
 * @param type - 노선검색 레이어 타입 : 단일(S), 복수(M)
 * @param routeId - 노선ID
 * @param routeName - 노선명
 */
function fnSetRouteData(type, routeId, routeName) {
	
	// 레이어 팝업 리턴값 초기화
    _returnValue = [];
    
    // 전역변수에 레이어 팝업 리턴값 설정
    if ( type == "S" ) {
        var data = {};
        data["routeId"] = routeId;
        data["routeName"] = routeName;
        
        _returnValue.push(data);
    } else {
        $("input[type=checkbox][name=chkAddRoute]").each(function(){

            if ( $(this).is(":checked") == true ) {
                var data = {};
                data["routeId"] = $(this).val();
                data["routeName"] = $(this).attr("routeName");
                
                _returnValue.push(data);
            }
        });
    }
    
	// 전역변수에 레이어 팝업 콜백 함수가 설정되어 있을 경우 수행
	if ( typeof(_returnCallBack) == "function" ) {
		if(_returnCallBackParam != null){
			_returnCallBack(_returnCallBackParam);
			_returnCallBackParam = null;
			
		}else{
			_returnCallBack();
			
		}
	}
	
	// 노선 검색 팝업 숨김
    if ( type == "S" ) {
        $("#_searchRouteLayer").fadeOut();        
    } else {
        $("#_searchMultiRouteLayer").fadeOut();
    }
}

/**
 * 검색 결과 데이터가 없을 경우 리스트 영역 표출
 *
 * @param msgType - 표출 메시지
 * @param tbodyId - 표출 대상 테이블 ID
 * @param colspan - 표출 대상 테이블 colspan
 */
function fnSetNoResult(msgType, tbodyId, colspan) {
    var msg = "";
    var htmlStr = "";
    
    if ( msgType == "LIST" ) {
        msg = "조회 정보가 없습니다.";
    } else if ( msgType == "SELECT" ) {
        msg = "선택 정보가 없습니다.";
    } else if ( msgType == "REG" ) {
        msg = "저장 정보가 없습니다.";
    }
    
    if ( msgType == "LIST" ) {
        
        htmlStr += "<tr>";
        htmlStr += "<td class='center' colspan='"+colspan+"'>"+msg+"</td>";
        htmlStr += "</tr>";

        $("#" + tbodyId + "  tbody").html(htmlStr);
    } else {
        
        $("#" + tbodyId + "  tbody").find("#_emptyRow").remove();

        if ($("#" + tbodyId + "  tbody").children("tr").length == 0) {

            htmlStr += "<tr id='_emptyRow'>";
            htmlStr += "<td class='center' colspan='"+colspan+"'>" + msg + "</td>";
            htmlStr += "</tr>";

            $("#" + tbodyId + "  tbody").html(htmlStr);
        }
    }
}

/**
 * 클릭 이벤트 강제로 발생 
 * 
 * @param id - 대상 객체ID
 */
function fnForceClick(id) {
    $("#"+id).trigger("click");
}

/**
 * 체크박스 이벤트 버블링 방지
 * 
 * @param name - 체크박스 이름
 */
function fnPreventBubble(name) {
    $("input[type=checkbox][name="+name+"]").on("click",function(e){
        e.stopPropagation();
    });
}

/**
 * 조회 팝업 닫기 (내부 버튼)
 * 
 */
function fnClosePopup() {
	$("#_btnSearchLayer").click();
}

/**
 * 전자지도 위치 초기화
 * 
 */
function fnGisReset() {
	_m.map.getView().setCenter([14042134.02, 4370800.42]);// 좌표 이동 14226500.13
    _m.map.getView().setZoom(2); // 줌 변경
}


/***
 * 체크한 값의 전체 라벨 리스트 추출
 * @param labelList
 * @param hiddenFeature
 * @returns
 */
function fnGetTotalLabel(labelList,hiddenFeature){
	
	var label = "";
	var labelArray = [];
	var labelCnt = 0;
	
	
	for(var i = 0 ; i < labelList.length ; i++){
		
		if(labelList[i] == "Y"){
			
			label = fnGetLabel(i,hiddenFeature);
			
			if(label != null 
					&& label != ''
					&& label != 'null'	
					&& label != undefined 
					&& label != 'undefined'
					&& label != ""
					&& label != 0	){
				
				labelArray[labelCnt++] = label;
			}
		}
	}
	
	return labelArray.toString();
}


function fnGetLabel(idx, obj){
	var result ="";
	
	/***
	 * 노드 ID 	
		RSE ID	
		이정거리	
		노드명칭	
		톨게이트코드	
		진출입정보	
		노선번호	
		노선명칭	
		도로등급	
		민자구분	
		시군구정보	
		좌표		
	 */
	
	
	
	switch (idx) {
		case 0: //노드 ID
			result = obj.values_["node_id"];
			break;
		case 1: //RSE ID
			result = obj.values_["rse_id"];
			break;
		case 2: //이정거리
			result = obj.values_["road_dist"];
			break;
		case 3: //노드명칭
			result = obj.values_["name"];
			break;
		case 4: //톨게이트코드
			result = obj.values_["toll_id"];
			break;
		case 5: //진출입정보
			result = obj.values_["in_out"];
			
			if(result == '1'){
				result = '진입';
			} else if(result == '2'){
				result = '진출';
			}
			
			break;
		case 6: //노선번호
			result = obj.values_["route_id"];
			break;
		case 7: //노선명칭
			result = obj.values_["r_name"];
			break;
		case 8: //도로등급
			result = obj.values_["road_rank"];
			
			if(result == '101'){
				result = '고속국도';
			}
			
			break;
		case 9: //민자구분
			result = obj.values_["private_f"];
			
			if(result == '1'){
				result = '고속도로(민자외 )_사용';
			} 
			else if(result == '2'){
				result = '민자고속도로_ 가상';
			}
			break;
		case 10: //시군구정보
			result = obj.values_["sigungu_id"];
			break;
		case 11: //좌표
			result = obj.values_["x"] + ", " + obj.values_["y"];
			break;	
		default:
			result = "";
	}
	
	return result;
}


//목록 페이징 
function Paging(element, pagingFunctionName, totCnt, pageSize, pageNo, totalPageCount ,lastPageNoOnPageList, firstPageNoOnPageList ){
	
	$(element).empty();
	element = element											//해당 페이징을 그려줄 엘리먼트
	pagingFunctionName = pagingFunctionName						//호출할 페이징 함수
	totCnt = parseInt(totCnt);									//전체레코드수 
	if(totCnt == 0){
		$(element).append("[총 건수 : "+totCnt+"건]");
		return ""; 
	} 
	pageSize = parseInt(pageSize); 								//페이지 리스트에 게시되는 페이지 건수 
	pageNo = parseInt(pageNo); 									//현재페이지 
	totalPageCount = parseInt(totalPageCount);					//페이지 개수 
	lastPageNoOnPageList = parseInt(lastPageNoOnPageList);		//페이지 리스트의 첫 페이지 번호
	firstPageNoOnPageList = parseInt(firstPageNoOnPageList);	//페이지 리스트의 마지막 페이지 번호
	
	var html ="";
		
	html += "<table>"
	html += "	<tbody>"
	html += "		<tr>"
	html += "			<td height='30'>"
		
	html += "&nbsp;&nbsp;&nbsp;"
	html += "<a href='#' onclick='"+pagingFunctionName+"("+1+"); return false;'>"
	html +=	"<img src='/images/btn_ne01.gif' border='0/'>"
	html += "</a>&nbsp;&nbsp;&nbsp;&nbsp;"
		
	//이전 화살표 
	if(pageNo > pageSize){
			html += "<a href='#' onclick='"+pagingFunctionName+"("+(firstPageNoOnPageList-1)+"); return false;'>"
			html +=	"<img src='/images/btn_ne02.gif' border='0/'>"
			html += "</a>&nbsp;&nbsp;&nbsp;&nbsp;"
	}else{	
			html += "<a href='#' onclick='"+pagingFunctionName+"("+(firstPageNoOnPageList)+"); return false;'>"
			html +=	"<img src='/images/btn_ne02.gif' border='0/'>"
			html += "</a>&nbsp;&nbsp;&nbsp;&nbsp;"
	}

	//paging Bar 
	for(var index=firstPageNoOnPageList;   index <  lastPageNoOnPageList+1;    index++ ){

		if(index == pageNo){ //현재 페이지
			html += "<strong style='margin:4px;'>"+index+"</strong>&nbsp;&nbsp;&nbsp;&nbsp;"
		}else{				 //현재 페이지 제외한 페이지 
			html += "<a href='#' onclick='"+pagingFunctionName+"("+index+"); return false;' style='margin:4px;'>"+index+"</a>&nbsp;&nbsp;&nbsp;&nbsp;"
		} 		
	}
				
	//다음 화살표 
	if(totalPageCount > lastPageNoOnPageList){
			html +=	"<a href='#' onclick='"+pagingFunctionName+"("+(lastPageNoOnPageList+1)+"); return false;'>"
			html +=	"<img src='/images/btn_pre02.gif' border='0/'>"
			html +=	"</a>&nbsp;&nbsp;&nbsp;&nbsp;"
	}else{
			html +=	"<a href='#' onclick='"+pagingFunctionName+"("+(lastPageNoOnPageList)+"); return false;'>"
			html +=	"<img src='/images/btn_pre02.gif' border='0/'>"
			html +=	"</a>&nbsp;&nbsp;&nbsp;&nbsp;"
	}
	
	html +=	"<a href='#' onclick='"+pagingFunctionName+"("+(totalPageCount)+"); return false;'>"
	html +=	"<img src='/images/btn_pre01.gif' border='0/'>"
	html +=	"</a>"

	html += "			</td>"
		
	html += "			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class='tableEleNum' id='total'>[총 건수 : "+totCnt+"건]</span></td>"

	html += "		</tr>"
	html += "	</tbody>"
	html += "</table>"

	$(element).append(html);	
}