/**
 * @target JSON 처리 관련 공통 함수
 */

/**
 * @type jsonLib
 * @class jsonLib
 */
var jsonLib = {};

/**
 * JSON Object인지 여부를 검사한다.
 * 
 * @date 2015. 8. 5.
 * @memberOf jsonLib
 * @param {Object} jsonObj JSON Object or String
 * @returns {Boolean} JSON객체 여부 (JSON객체인경우 true, JSON객체 아닌 경우 false)
 */
jsonLib.isJSON = function(jsonObj) {
	try {
		if (jQuery.isPlainObject(jsonObj) === false && comLib.isArrayObj(jsonObj) === false) {
			return false;
		}
		
		if (typeof jsonObj === "object") {
			if (jsonLib.stringify(jsonObj)) {
				return true;
			} else {
				return false;
			}
		} else if (typeof jsonObj === "string") {
			if (jsonLib.parse(jsonObj)) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	} catch(e) {
		return false;
	}
};

/**
 * JSON Object로 변환해서 반환한다.
 * 
 * @date 2015. 8. 5.
 * @memberOf jsonLib
 * @param {string} str 문자열
 * @returns {Object} JSON 객체
 */
jsonLib.parse = function(str) {
	if (typeof str !== "string") {
		return null;
	}
	
	try {
		return JSON.parse(str);
	} catch(e) {
		alert('str['+str+"] "+e);
		return null;
	}
};

/**
 * JSON Object를 문자열로 변환해서 반환한다.
 * 
 * @date 2015. 8. 5.
 * @memberOf jsonLib
 * @param {Object} jsonObj JSON 객체
 * @returns {String} JSON 문자열
 */
jsonLib.stringify = function(jsonObj) {
	try {
		if (typeof jsonObj !== "object") {
			return null;
		}
		
		return JSON.stringify(jsonObj);
	} catch(e) {
		return null;
	}
};

/**
 * JSON Object를 복제한다.
 * 
 * @date 2015. 8. 5.
 * @memberOf jsonLib
 * @param {Object} jsonObj JSON 객체
 * @returns {String} JSON 문자열
 */
jsonLib.clone = function(jsonObj) {
	try {
		if (jsonLib.isJSON(jsonObj)) {
			return JSON.parse(JSON.stringify(jsonObj));
		} else {
			return null;
		}
	} catch(e) {
		return null;
	}
};


/* ==========================================================================================
 * 해당 프로젝트에서 새로 만든 메소드들을 정의한다.
 * ========================================================================================== */
/**
 * JSON PATH 
 * @date 2015. 10. 5.
 * @memberOf 
 * @param {Object} jsonObj JSON 객체
 * @param {string} expr    
 * @param {String} arg ("VALUE" or "PATH");
 * @returns {objet} JSON or value
 */
jsonLib._jsonPath = function(obj, expr, arg){
	
	var func = {};
	func.resultType = arg && arg.resultType || "VALUE";
	func.result = [];
	func.normalize = function(expr){
	    
	    var subx = [];
	                                return expr.replace(/[\['](\??\(.*?\))[\]']/g, function($0,$1){return "[#"+(subx.push($1)-1)+"]";})
	                    .replace(/'?\.'?|\['?/g, ";")
	                    .replace(/;;;|;;/g, ";..;")
	                    .replace(/;$|'?\]|'$/g, "")
	                    .replace(/#([0-9]+)/g, function($0,$1){return subx[$1];});

	};

	//trace
	func.trace = function(expr, val, path) {    
	    
	    //console.log("call TRACE");
	      
	     if (expr) {
	         
	         
	         var arrExpr = expr.split(";"); //return array
	         var arrLoc  = arrExpr.shift();       //Remove the first item of an array [pop]
	         
	         //The join() method joins the elements of an array into a string, and returns the string.
	         arrExpr = arrExpr.join(";"); //type String
	         
	         //console.log("[trace 01] expr : " +expr);
	         //console.log("[trace 01] typeof arrLoc : "+ typeof arrLoc);
	         //console.log("[trace 01] arrLoc :: "+arrLoc);
	         
	         if (val && val.hasOwnProperty(arrLoc)){
	             //console.log("1");
	             func.trace(arrExpr, val[arrLoc], path + ";" + arrLoc);
	         }else if (arrLoc === "*"){
	             //console.log("2");
	             func.walk(arrLoc, arrExpr, val, path, function(m,l,x,v,p) { func.trace(m+";"+x,v,p); });
	     	 }else if (arrLoc === ".."){
	             
	             //console.log("[trace 02] arrLoc :: "+arrLoc);
	             //console.log("[trace 02] arrExpr :: "+arrExpr);
	             //console.log("[trace 02] val :: "+val);
	             //console.log("[trace 02] path :: "+path);             
	             
	             func.trace(arrExpr, val, path);
	             
	             //console.log("call walk");
	             func.walk(arrLoc, arrExpr, val, path, function(m,l,x,v,p) { typeof v[m] === "object" && func.trace("..;"+arrExpr,v[m],p+";"+m); });
	         }else if (/,/.test(arrLoc)) { // [name1,name2,...]
	             //console.log("[test] /,/.test(loc)");
	             var s = arrLoc.split(/'?,'?/);
	             for (var i=0; i<s.length; i++){
	                 func.trace(s[i]+";"+arrExpr, val, path);
	             }
	         }else if (/^\(.*?\)$/.test(arrLoc)){// [(expr)]
	             func.trace(func.eval(arrLoc, val, path.substr(path.lastIndexOf(";")+1))+";"+arrExpr, val, path);
	         }else if (/^\?\(.*?\)$/.test(arrLoc)){ // [?(expr)]
	             func.walk(arrLoc, arrExpr, val, path, function(m,l,x,v,p) { 
	                 if (func.eval(l.replace(/^\?\((.*?)\)$/,"$1"),v[m],m)){
	                     func.trace(m+";"+arrExpr,v,p); 
	                 }});
	         }else if(/^(-?[0-9]*):(-?[0-9]*):?([0-9]*)$/.test(arrLoc)){ 
	             
	             //console.log("trace 06 :"+arrLoc);
	             
	                 // [start:end:step]  phyton slice syntax
	             func.slice(arrLoc, arrExpr, val, path);
	         }                       
	     }else{
	         func.store(path, val);
	     }
	};
	              
	          
	//walk
	func.walk = function(loc, expr, val, path, pFunc) {
	    
	    //console.log("[walk] expr:"+expr);
	    //console.log("[walk] val:"+val);
	    
	    if (val instanceof Array) {         
	        
	        //console.log("[walk] Array");
	        for (var i = 0;i < val.length; i++){
	            if (i in val){
	                pFunc(i,loc,expr,val,path);
	            }
	        }
	    }else if (typeof val === "object") {
	        for (var m in val){
	            if (val.hasOwnProperty(m)){
	                pFunc(m,loc,expr,val,path);
	            }
	        }       
	    }
	};

	//slice
	func.slice = function(loc, expr, val, path) {
	    if (val instanceof Array) {
	        var len   = val.length;
	        var start = 0;
	        var end   = len; 
	        var step  = 1;
	        
	        loc.replace(/^(-?[0-9]*):(-?[0-9]*):?(-?[0-9]*)$/g, replace(/\$0/,/\$1/,/\$2/,/\$3/));
	        
	        start = (start < 0) ? Math.max(0,start+len) : Math.min(len,start);
	        end   = (end < 0)   ? Math.max(0,end+len)   : Math.min(len,end);
	        
	        for (var i=start; i<end; i+=step){
	               func.trace(i+";"+expr, val, path);
	        }
	        
	        function replace(val0,val1,val2,val3){        
	        	start = parseInt(val1||start);
	            end   = parseInt(val2||end);
	            step  = parseInt(val3||step);
	    	}
	    }
	};

	//eval
	func.eval = function(x, _v, _vname) {

	    try { 
	        return $ && _v && eval(x.replace(/@/g, "_v")); 
	    }catch(e) { 
	        throw new SyntaxError("jsonPath: " + e.message + ": " + x.replace(/@/g, "_v").replace(/\^/g, "_a")); 
	    }
	};        

	//asPath
	func.asPath = function(path) {
	    
	    var arrPath = path.split(";");
	    var rtnPath = "$";
	    
	    for (var i=1; i < arrPath.length; i++){        
	        if(/^[0-9*]+$/.test(x[i])){ //if number 가 포함되어 있으면 index 형태로 표현             
	            rtnPath += ("["+x[i]+"]") ;            
	        }else{                      //else text 형태로 표현
	            rtnPath += ("['"+x[i]+"']");           
	        } 
	    }
	    
	    return rtnPath;
	};

	//store
	func.store = function(path, value) {
	  
	    if (path) {
	        if(func.resultType == "PATH"){
	            func.result[func.result.length] = func.asPath(path);
	        }else{
	            func.result[func.result.length] = value;
	        }
	    }
	    return !!path;
	};	
	
	
	 var $ = obj;
	   
   if (expr && obj && (func.resultType == "VALUE" || func.resultType == "PATH")) {
	   func.trace(func.normalize(expr).replace(/^\$;/,""), obj, "$");
      return func.result.length ? func.result : false;
   }
	
};




jsonLib.xmlToJson =  function(xml) {
	/*
	 NODE TYPE
	 
	1	ELEMENT_NODE
	2	ATTRIBUTE_NODE
	3	TEXT_NODE
	4	CDATA_SECTION_NODE
	5	ENTITY_REFERENCE_NODE
	6	ENTITY_NODE
	7	PROCESSING_INSTRUCTION_NODE
	8	COMMENT_NODE
	9	DOCUMENT_NODE
	10	DOCUMENT_TYPE_NODE
	11	DOCUMENT_FRAGMENT_NODE
	12	NOTATION_NODE
	*/
	
	// Create the return object
	var obj = {};

	if (xml.nodeType == 1) { // ELEMENT_NODE
		// do attributes
		if (xml.attributes.length > 0) {
		obj["@attributes"] = {};
			for (var j = 0; j < xml.attributes.length; j++) {
				var attribute = xml.attributes.item(j);
				obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
			}
		}
	} else if (xml.nodeType == 3) { // text
		obj = xml.nodeValue;
	}

	// do children
	if (xml.hasChildNodes()) {
		for(var i = 0; i < xml.childNodes.length; i++) {
			var item = xml.childNodes.item(i);
			var nodeName = item.nodeName;
			if (typeof(obj[nodeName]) == "undefined") {
				obj[nodeName] = xmlToJson(item);
			} else {
				if (typeof(obj[nodeName].push) == "undefined") {
					var old = obj[nodeName];
					obj[nodeName] = [];
					obj[nodeName].push(old);
				}
				obj[nodeName].push(xmlToJson(item));
			}
		}
	}
	return obj;
};

jsonLib.eqFilter = function(my_object, my_criteria)
{	
	var tmpData = JSON.parse(JSON.stringify(my_object));
	return tmpData.filter(function(obj)
	{
		return Object.keys(my_criteria).every(function(c)
		{
			return obj[c] == my_criteria[c];
		});
	});
};

jsonLib.neFilter = function(my_object, my_criteria)
{
	var tmpData = JSON.parse(JSON.stringify(my_object));
	return tmpData.filter(function(obj)
	{
		return Object.keys(my_criteria).every(function(c)
		{
			return obj[c] != my_criteria[c];
		});
	});
};

jsonLib.neFilterArr = function(my_object, my_criteria)
{	
	var object =  WebSquare.util.getComponentById(my_object);	
	var objArray ;

	if(typeof object =='undefined'){
		var tmpData = JSON.parse(JSON.stringify(my_object));
		objArray = tmpData;
	}else{
		objArray = object.getAllJSON();
	}
	var obj2 = [];
	for(var i=0;i < my_criteria.length; i++){
		var tmpData = objArray.filter(function(obj)
				{	
					var tmpObj =  Object.keys(my_criteria[i]).every(function(c)
					{	
						return obj[c] != my_criteria[i][c];
					});	
					return tmpObj;
	
				});
		obj2 = obj2.concat(tmpData);
	}
	return obj2;	
};

jsonLib.eqFilterArr = function(my_object, my_criteria)
{	
	var object =  WebSquare.util.getComponentById(my_object);	
	var objArray ;

	if(typeof object =='undefined'){
		var tmpData = JSON.parse(JSON.stringify(my_object));
		objArray = tmpData;
	}else{
		objArray = object.getAllJSON();
	}
	var obj2 = [];
	for(var i=0;i < my_criteria.length; i++){
		var tmpData = objArray.filter(function(obj)
				{	
					var tmpObj =  Object.keys(my_criteria[i]).every(function(c)
					{	
						return obj[c] == my_criteria[i][c];
					});	
					return tmpObj;
	
				});
		obj2 = obj2.concat(tmpData);
	}
	return obj2;	
};

jsonLib.eqFilterArr2 = function(my_object, my_criteria)
{	
	var object =  WebSquare.util.getComponentById(my_object);	
	var objArray ;

	if(typeof object =='undefined'){
		var tmpData = JSON.parse(JSON.stringify(my_object));
		objArray = tmpData;
	}else{
		objArray = object.getAllJSON();
	}
	var obj2 = [];
	
	var tmpData = objArray.filter(function(obj)
			{	
				for(var i=0;i < my_criteria.length; i++){
					var tmpObj =  Object.keys(my_criteria[i]).every(function(c)
					{	
						return obj[c] == my_criteria[i][c];
					});	
					return tmpObj;
				}
			});
	obj2 = obj2.concat(tmpData);
	
	return obj2;
};

/*
 * search by direct regex
 * var arr = jsonLib.regexPatternFilter("dltCmnCd","({[^{]*\"cmnCd\":\"3\"[^{]*})");
 * @author kim sae chang 
 * @date 2016.07.11
 */
jsonLib.regexPatternFilter = function(my_object, _regexPattern)
{	
	var object =  WebSquare.util.getComponentById(my_object);	
	var jsonObj = object.getAllJSON();
	var searchString  = JSON.stringify(jsonObj);
	var pattern = new RegExp(_regexPattern,'ig');
	var arr = new Array();
	var idx =0;
	while ((matchs = pattern.exec(searchString))) {
	    console.dir(matchs[0]);
	    arr[idx++] = JSON.parse(matchs[0]);
	}
	return arr;
};

/*
 * search by key and value 
 * param1 : dataCollectionId
 * param2 : keyName String
 * param3 : value String
 * 
 * ex1) var arr = jsonLib.regexKeyValFilter("dltCmnCd","cmnDc","3");
 * 
 * ex2) var arr = jsonLib.regexKeyValFilter("dltCmnCd","cmnDc",null);
 * 
 * var o = jsonLib.regexKeyValFilter("dltUser", "userId", "111",false);
 * true: like검색, false:eq검색
 * 
 * @author kim sae chang
 * @date 2016.07.11 
 */
jsonLib.regexKeyValFilter = function(my_object, _key, _val,_isLike)
{	
	if(_isLike){
		_val = '[^\"]*?'+_val+'[^\"]*?';
	}
	var object =  WebSquare.util.getComponentById(my_object);	
	var jsonObj = object.getAllJSON();
	var searchString  = JSON.stringify(jsonObj);
	var patternStr = "({[^{]*\""+_key+"\":\""+_val+"\"[^{]*})";
	if(_val == null){
		patternStr = "({[^{]*\""+_key+"\":\"[^{]*})";
	}else{
		patternStr = "({[^{]*\""+_key+"\":\""+_val+"\"[^{]*})";
	}
	var pattern = new RegExp(patternStr,'ig');
	var arr = new Array();
	var idx =0;
	while ((matchs = pattern.exec(searchString))) {
	    try{
	    	arr[idx++] = JSON.parse(matchs[0]);
	    }catch(e){
	    }
	    
	}
	return arr;
};


/*
 * search by key and value 
 * param1 : dataCollectionId
 * param2 : keyName String
 * param3 : value String
 * 
 * ex1) var arr = jsonLib.regexKeyValFilter("dltCmnCd","cmnDc","3");
 * 
 * ex2) var arr = jsonLib.regexKeyValFilter("dltCmnCd","cmnDc",null);
 * 
 * var o = jsonLib.regexKeyValFilter("dltUser", "userId", "111",false);
 * true: like검색, false:eq검색
 * 
 * @author kim sae chang
 * @date 2016.08.30 
 */
jsonLib.regexKeyValFilterByArr = function(array_object, _key, _val,_isLike)
{	
	if(_isLike){
		_val = '[^\"]*?'+_val+'[^\"]*?';
	}
	var searchString  = JSON.stringify(array_object);
	var patternStr = "({[^{]*\""+_key+"\":\""+_val+"\"[^{]*})";
	if(_val == null){
		patternStr = "({[^{]*\""+_key+"\":\"[^{]*})";
	}else{
		patternStr = "({[^{]*\""+_key+"\":\""+_val+"\"[^{]*})";
	}
	var pattern = new RegExp(patternStr,'ig');
	var arr = new Array();
	var idx =0;
	while ((matchs = pattern.exec(searchString))) {
	    try{
	    	arr[idx++] = JSON.parse(matchs[0]);
	    }catch(e){
	    }
	    
	}
	return arr;
};
