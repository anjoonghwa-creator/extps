<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" import="com.ex.dashboard.LockdownSettings" %>
<%
  String mapProvider = LockdownSettings.get("LOCKDOWN_MAP_PROVIDER", "lockdown.mapProvider", "himap");
  boolean useHiMap = "himap".equalsIgnoreCase(mapProvider);
  boolean mockMode = "1".equals(request.getParameter("mock"));
  boolean previewAnalysisRefresh = mockMode && "1".equals(request.getParameter("refreshing"));
%>
<!DOCTYPE html>
<html lang="ko" class="dark">
<head>
  <meta charset="UTF-8">
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="data:,">
  <title>한국도로공사 | 사고처리 총괄화면</title>
  <% if (useHiMap) { %>
  <%-- 최초 AS-IS 소스의 HiMap 자산. --%>
  <link rel="stylesheet" href="/asset/map/css/all.css">
  <!-- <link rel="stylesheet" href="/asset/map/css/ol.css"> -->
  <link rel="stylesheet" href="/asset/map/css/mapapi.css">
  <link rel="stylesheet" href="/asset/map/css/style_map.css">
  <script src="/asset/map/js/common/jquery-1.11.1.min.js"></script>
  <script src="/asset/map/js/common/jsonLib.js"></script>
  <script src="/asset/map/js/openlayers/build/ol-debug.js"></script>
  <!-- <script src="/asset/map/js/mapapi/ol-patch.js"></script> -->
  <script src="/asset/map/js/mapapi/mapapi.js?v=standard-find-1"></script>
  <!-- <script src="/asset/map/js/mapapi/mapcontrol.js"></script> -->
  <% } else { %>
  <%-- 최초 AS-IS 개발환경과 동일한 VWorld 2.0 라이브러리. --%>
  <script src="/asset/map/js/common/jquery-1.11.1.min.js"></script>
  <script src="https://map.vworld.kr/js/vworldMapInit.js.do?version=2.0&apiKey=88A3DFA4-B355-30BB-85EA-7314FCDDA8DE"></script>
  <% } %>
  <style>
    /* 연동용 식별자만 AS-IS 지도 컨테이너명으로 바꾼다. */
    #vmap { width: 100%; height: 100%; background: #0d1e30; }
  </style>
  <% if (!mockMode || previewAnalysisRefresh) { %>
  <link rel="stylesheet" href="/asset/css/analysis-adapter.css">
  <% } %>
  <% if (!mockMode) { %>
  <link rel="stylesheet" href="/asset/css/lockdownAc001MapOverlays.asis.css">
  <% } %>
  <%-- 실제 화면과 목업 화면 모두 캡처 대상 해상도에 맞춘다. --%>
  <!-- <link rel="stylesheet" href="/asset/css/resolution-1280x720.css"> -->
</head>
<body class="<%= mockMode ? "mock-mode" : "" %>">
  <%-- 퍼블리싱 원본 body를 가공 없이 포함한다. --%>
  <%@ include file="/WEB-INF/publishing/incidentDashboard.jsp" %>

  <% if (!mockMode) { %>
  <%-- 초기 lockdownAc001Main.jsp의 지도 오버레이 마크업을 별도 보존해 지도 패널 안으로 옮긴다. --%>
  <%-- <div id="asisMapOverlays" class="asis-map-overlays">
    <%@ include file="/WEB-INF/asis/lockdownAc001MapOverlays.jspf" %>
  </div>
  <script>document.getElementById("map-panel").appendChild(document.getElementById("asisMapOverlays"));</script> --%>

  <%-- AS-IS 지도 스크립트가 참조하는 최소 호환 DOM. 화면에는 노출하지 않는다. --%>
  <div hidden aria-hidden="true">
    <input name="host_addr" value="<%= useHiMap ? "himap" : "127.0.0.1" %>">
    <input name="acdt_no" value="">
    <input name="cnzn_id" value="">
    <input name="acdt_ocrn_dstnc" value="">
    <input name="alfc_blc_yn" value="N">
    <div id="left-panel"></div>
    <div id="middle-panel"></div>
  </div>
  <script>document.getElementById("map").id = "vmap";</script>
  <% } %>

  <script>
    window.LOCKDOWN_MOCK_MODE = <%= mockMode ? "true" : "false" %>;
    window.LOCKDOWN_MAP_PROVIDER = "<%= useHiMap ? "himap" : "vworld" %>";
  </script>
  <% if (previewAnalysisRefresh) { %>
  <script>
    (function () {
      var target = document.querySelector(".progress-card .progress-ai");
      if (!target) return;
      var status = document.createElement("div");
      status.id = "analysisApiStatus";
      status.className = "analysis-refresh-status";
      status.setAttribute("role", "status");
      status.setAttribute("data-state", "refreshing");
      status.setAttribute("aria-label", "AI 분석 갱신 중");
      target.appendChild(status);
    })();
  </script>
  <% } %>

  <script src="/asset/js/publishing/publishing-original.js"></script>

  <% if (!mockMode) { %>
  <script src="/asset/js/lockdown/geojsonTojs/detour.js"></script>
  <script src="/asset/js/lockdown/geojsonTojs/gtmH200Object.js"></script>
  <script src="/asset/js/lockdown/geojsonTojs/lineObject.js"></script>
  <script src="/asset/js/lockdown/geojsonTojs/vmsObject.js"></script>
  <script src="/asset/js/lockdown/geojsonTojs/vms2Object.js"></script>
  <script src="/asset/js/lockdown/geojsonTojs/vmsTitObject.js"></script>
  <script src="/asset/js/lockdown/geojsonTojs/icjcLabelNameObject.js"></script>
  <script src="/asset/js/lockdown/geojsonTojs/icjcLabelSymbolObject.js"></script>
  <script src="/asset/js/lockdown/api-bridge.js"></script>
  <script src="/asset/js/lockdown/lockdownAc001Map.asis.js"></script>
  <script src="/asset/js/lockdown/analysis-adapter2.js"></script>
  <% } %>
</body>
</html>
