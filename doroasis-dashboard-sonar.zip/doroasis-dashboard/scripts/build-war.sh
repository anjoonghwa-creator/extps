#!/bin/sh
set -eu
project_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$project_dir"
if [ ! -f .env ]; then
  echo ".env 설정 파일이 없습니다." >&2
  exit 1
fi
set -a
. ./.env
set +a
: "${LOCKDOWN_API_BASE_URL:?API 주소가 필요합니다.}"
: "${LOCKDOWN_API_KEY:?API 키가 필요합니다.}"
: "${LOCKDOWN_MAP_PROVIDER:?지도 제공자가 필요합니다.}"
mode=${1:-docker}
case "$mode" in
  docker)
    docker_image=$(docker build -q --target build \
      --build-arg "LOCKDOWN_API_BASE_URL=$LOCKDOWN_API_BASE_URL" \
      --build-arg "LOCKDOWN_API_KEY=$LOCKDOWN_API_KEY" \
      --build-arg "LOCKDOWN_MAP_PROVIDER=$LOCKDOWN_MAP_PROVIDER" .)
    build_container=$(docker create "$docker_image")
    trap 'docker rm "$build_container" >/dev/null 2>&1 || true' EXIT
    mkdir -p target
    docker cp "$build_container:/app/target/dashboard.war" target/dashboard.war
    ;;
  maven)
    mvn --batch-mode --no-transfer-progress -DskipTests \
      "-Dlockdown.apiBaseUrl=$LOCKDOWN_API_BASE_URL" \
      "-Dlockdown.apiKey=$LOCKDOWN_API_KEY" \
      "-Dlockdown.mapProvider=$LOCKDOWN_MAP_PROVIDER" clean package
    ;;
  *)
    echo "사용법: sh scripts/build-war.sh [docker|maven]" >&2
    exit 1
    ;;
esac
echo "빌드 완료: $project_dir/target/dashboard.war"
